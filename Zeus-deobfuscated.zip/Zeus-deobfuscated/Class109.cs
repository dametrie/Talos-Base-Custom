﻿// Decompiled with JetBrains decompiler
// Type: Class109
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;

internal sealed class Class109
{
  private readonly Class29 class29_0;
  private List<Class111> list_0;
  private Dictionary<Struct17, Class111> dictionary_0;
  private readonly Class112 class112_0;

  internal Class109([In] Class112 obj0, Class29 class100_0)
  {
    this.class112_0 = obj0;
    this.class29_0 = class100_0;
  }

  internal Stack<Struct17> method_0([In] Struct17 obj0_1, Struct17 class100_0)
  {
    try
    {
      this.dictionary_0 = new Dictionary<Struct17, Class111>();
      this.list_0 = new List<Class111>();
      Class111 class111_1 = new Class111(obj0_1);
      Class111 class111_2 = new Class111(class100_0);
      this.dictionary_0.Add(obj0_1, class111_1);
      this.dictionary_0.Add(class100_0, class111_2);
      class111_1.Boolean_0 = true;
      class111_1.Single_0 = 0.0f;
      this.list_0.Add(class111_1);
      while (this.list_0.Count > 0)
      {
        // ISSUE: object of a compiler-generated type is created
        // ISSUE: variable of a compiler-generated type
        Class109.Class110 class110 = new Class109.Class110();
        // ISSUE: reference to a compiler-generated field
        class110.class109_0 = this;
        // ISSUE: reference to a compiler-generated field
        class110.class111_0 = this.list_0[0];
        // ISSUE: reference to a compiler-generated field
        if ((int) class110.class111_0.Struct17_0.Int16_0 != (int) class100_0.Int16_0)
        {
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          class110.class93_0 = this.class112_0.Dictionary_3[class110.class111_0.Struct17_0.Int16_0];
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated method
          // ISSUE: reference to a compiler-generated method
          List<Class92> list = class110.class93_0.Dictionary_1.Values.Where<Class92>(new Func<Class92, bool>(class110.method_0)).OrderBy<Class92, int>(new Func<Class92, int>(class110.method_1)).ToList<Class92>();
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated method
          foreach (KeyValuePair<Struct16, Class94> keyValuePair in class110.class93_0.Dictionary_2.Where<KeyValuePair<Struct16, Class94>>(class110.func_0 ?? (class110.func_0 = new Func<KeyValuePair<Struct16, Class94>, bool>(class110.method_2))).OrderBy<KeyValuePair<Struct16, Class94>, int>((Func<KeyValuePair<Struct16, Class94>, int>) (obj0_2 => this.class29_0.Struct16_1.method_0(obj0_2.Key))).ToList<KeyValuePair<Struct16, Class94>>())
          {
            foreach (Class95 class95 in keyValuePair.Value.List_0)
            {
              if (this.class112_0.Dictionary_3.ContainsKey(class95.Int16_0))
              {
                Struct17 struct170 = class95.Struct17_0;
                // ISSUE: reference to a compiler-generated field
                Class92 class92 = new Class92((byte) keyValuePair.Key.short_0, (byte) keyValuePair.Key.short_1, (byte) struct170.Int16_1, (byte) struct170.Int16_2, class110.class93_0.Int16_0, struct170.Int16_0);
                Class111 class111_3;
                if (this.dictionary_0.ContainsKey(struct170))
                {
                  class111_3 = this.dictionary_0[struct170];
                }
                else
                {
                  class111_3 = new Class111(struct170)
                  {
                    Class92_0 = class92
                  };
                  this.dictionary_0.Add(struct170, class111_3);
                }
                if (!class111_3.Boolean_1)
                {
                  // ISSUE: reference to a compiler-generated field
                  float num = class110.class111_0.Single_0 + 1f;
                  if (class111_3.Boolean_0)
                  {
                    if ((double) class111_3.Single_0 > (double) num)
                    {
                      class111_3.Single_0 = num;
                      // ISSUE: reference to a compiler-generated field
                      class111_3.Class111_0 = class110.class111_0;
                    }
                  }
                  else
                  {
                    class111_3.Single_0 = num;
                    // ISSUE: reference to a compiler-generated field
                    class111_3.Class111_0 = class110.class111_0;
                    class111_3.Boolean_0 = true;
                    this.list_0.Add(class111_3);
                  }
                }
              }
            }
          }
          foreach (Class92 class92 in list)
          {
            Struct17 struct171 = class92.Struct17_1;
            Class111 class111_4;
            if (this.dictionary_0.ContainsKey(struct171) && Struct17.smethod_1(struct171, class100_0))
              class111_4 = this.dictionary_0[struct171];
            else if (Struct17.smethod_0(struct171, class100_0))
            {
              class111_4 = this.dictionary_0[struct171];
              this.dictionary_0[struct171].Class92_0 = class92;
            }
            else
            {
              class111_4 = new Class111(struct171)
              {
                Class92_0 = class92
              };
              this.dictionary_0.Add(struct171, class111_4);
            }
            if (!class111_4.Boolean_1)
            {
              // ISSUE: reference to a compiler-generated field
              float num = class110.class111_0.Single_0 + 1f;
              if (class111_4.Boolean_0)
              {
                if ((double) class111_4.Single_0 > (double) num)
                {
                  class111_4.Single_0 = num;
                  // ISSUE: reference to a compiler-generated field
                  class111_4.Class111_0 = class110.class111_0;
                }
              }
              else
              {
                class111_4.Single_0 = num;
                // ISSUE: reference to a compiler-generated field
                class111_4.Class111_0 = class110.class111_0;
                class111_4.Boolean_0 = true;
                this.list_0.Add(class111_4);
              }
            }
          }
          // ISSUE: reference to a compiler-generated field
          this.list_0.Remove(class110.class111_0);
          // ISSUE: reference to a compiler-generated field
          class110.class111_0.Boolean_0 = false;
          // ISSUE: reference to a compiler-generated field
          class110.class111_0.Boolean_1 = true;
        }
        else
        {
          Stack<Struct17> struct17Stack = new Stack<Struct17>();
          // ISSUE: reference to a compiler-generated field
          if (Struct17.smethod_1(class110.class111_0.Struct17_0, class100_0))
            struct17Stack.Push(class100_0);
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          for (; class110.class111_0 != class111_1 && class110.class111_0?.Class92_0 != null; class110.class111_0 = class110.class111_0.Class111_0)
          {
            // ISSUE: reference to a compiler-generated field
            struct17Stack.Push(class110.class111_0.Class92_0.Struct17_0);
          }
          return struct17Stack;
        }
      }
      return new Stack<Struct17>();
    }
    catch
    {
      return new Stack<Struct17>();
    }
  }
}
