﻿// Decompiled with JetBrains decompiler
// Type: Struct12
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

internal struct Struct12
{
  internal byte byte_0;
  internal uint uint_0;
  internal sbyte sbyte_0;
  internal uint uint_1;
  internal uint uint_2;
  internal byte byte_1;
  internal byte byte_2;
  internal short short_0;
  internal Enum3 enum3_0;
  internal byte byte_3;
  internal byte byte_4;
  internal uint uint_3;
  internal uint uint_4;
  internal uint uint_5;
  internal bool bool_0;
  internal byte byte_5;
  internal uint uint_6;
  internal byte byte_6;
  internal byte byte_7;
  internal byte byte_8;
  internal Enum4 enum4_0;
  internal uint uint_7;
  internal uint uint_8;
  internal short short_1;
  internal uint uint_9;
  internal Enum3 enum3_1;
  internal byte byte_9;
  internal uint uint_10;
  internal uint uint_11;
  internal byte byte_10;
  internal byte byte_11;
}
