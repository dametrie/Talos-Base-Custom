﻿// Decompiled with JetBrains decompiler
// Type: Class21
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;

internal sealed class Class21 : IEnumerable<Class76>, IEnumerable
{
  private readonly Class76[] class76_0;

  internal int Int32_0 { get; }

  internal Class76 this[byte value]
  {
    get => value != (byte) 0 && (int) value < this.Int32_0 ? this.class76_0[(int) value - 1] : (Class76) null;
    [param: In] set
    {
      if (value == (byte) 0 || (int) value >= this.Int32_0)
        return;
      this.class76_0[(int) value - 1] = value;
    }
  }

  internal Class76 this[string value] => this.method_2(value);

  internal int Int32_1
  {
    get
    {
      int int321 = 0;
      for (int index = 0; index < this.Int32_0; ++index)
      {
        if (this.class76_0[index] != null)
          ++int321;
      }
      return int321;
    }
  }

  internal bool Boolean_0 => ((IEnumerable<Class76>) this.class76_0).Count<Class76>((Func<Class76, bool>) (value => value != null)) == 59;

  internal Class21(int value)
  {
    this.Int32_0 = value;
    this.class76_0 = new Class76[value];
  }

  internal bool method_0(string value)
  {
    for (int index = 0; index < this.Int32_0; ++index)
    {
      if (this.class76_0[index] != null && this.class76_0[index].String_0.Equals(value, StringComparison.CurrentCultureIgnoreCase))
        return true;
    }
    return false;
  }

  internal int method_1(string value, [In] bool obj1)
  {
    int num = 0;
    for (int index = 0; index < this.Int32_0; ++index)
    {
      if (this.class76_0[index] != null && this.class76_0[index].String_0.Equals(value, StringComparison.CurrentCultureIgnoreCase))
        num += obj1 ? this.class76_0[index].Int32_0 : 1;
    }
    return num;
  }

  internal Class76 method_2(string value)
  {
    for (int index = 0; index < this.Int32_0; ++index)
    {
      if (this.class76_0[index] != null && this.class76_0[index].String_0.Equals(value, StringComparison.CurrentCultureIgnoreCase))
        return this.class76_0[index];
    }
    return (Class76) null;
  }

  public IEnumerator<Class76> GetEnumerator()
  {
    for (int index = 0; index < this.Int32_0; ++index)
    {
      if (this.class76_0[index] == null)
        continue;
      yield return this.class76_0[index];
    }
  }

  IEnumerator IEnumerable.GetEnumerator() => (IEnumerator) this.GetEnumerator();
}
