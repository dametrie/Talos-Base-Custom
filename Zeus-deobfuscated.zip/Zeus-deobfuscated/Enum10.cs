﻿// Decompiled with JetBrains decompiler
// Type: Enum10
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;

[Flags]
internal enum Enum10 : uint
{
  None = 0,
  Dall = 1,
  Pramh = 2,
  Suain = 4,
  BeagSuain = 8,
  Poison = 16, // 0x00000010
  NaomhAite = 32, // 0x00000020
  FasNadur = 64, // 0x00000040
  Dion = 128, // 0x00000080
  AsgallFaileas = 256, // 0x00000100
  DeireasFaileas = 512, // 0x00000200
  Armachd = 1024, // 0x00000400
  Beannaich = 2048, // 0x00000800
  FasDeireas = 4096, // 0x00001000
  InnerFire = 8192, // 0x00002000
  Hide = 16384, // 0x00004000
  Eisd = 32768, // 0x00008000
  Halt = 65536, // 0x00010000
  Pause = 131072, // 0x00020000
  Purify = 262144, // 0x00040000
  Coma = 524288, // 0x00080000
  PotentMantidScent = 1048576, // 0x00100000
  PerfectDefense = 2097152, // 0x00200000
  SpellSkillBonus1 = 4194304, // 0x00400000
  DragonsFire = 8388608, // 0x00800000
  Mist = 16777216, // 0x01000000
}
