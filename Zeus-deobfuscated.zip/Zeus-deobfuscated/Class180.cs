﻿// Decompiled with JetBrains decompiler
// Type: Class180
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

internal class Class180
{
  internal byte byte_0;
  internal byte[] byte_1;
  internal int int_0;

  internal Class180(Enum15 int_0)
  {
    this.byte_0 = (byte) int_0;
    this.byte_1 = new byte[0];
    this.int_0 = 0;
    this.method_17(this.byte_0);
  }

  internal Class180([In] Enum14 obj0)
  {
    this.byte_0 = (byte) obj0;
    this.byte_1 = new byte[0];
    this.int_0 = 0;
    this.method_17(this.byte_0);
  }

  internal Class180(byte[] int_0)
  {
    this.byte_0 = int_0[0];
    this.byte_1 = int_0;
    this.int_0 = 0;
  }

  internal TimeSpan method_0() => new TimeSpan((int) this.method_2(), (int) this.method_2(), (int) this.method_2(), (int) this.method_2());

  internal byte[] method_1(int stream_0)
  {
    byte[] destinationArray = new byte[stream_0];
    Array.Copy((Array) this.byte_1, this.int_0, (Array) destinationArray, 0, stream_0);
    this.int_0 += stream_0;
    return destinationArray;
  }

  internal byte method_2()
  {
    if (this.int_0 >= this.byte_1.Length)
      throw new EndOfStreamException();
    return this.byte_1[this.int_0++];
  }

  internal bool method_3()
  {
    if (this.int_0 >= this.byte_1.Length)
      throw new EndOfStreamException();
    return this.byte_1[this.int_0++] > (byte) 0;
  }

  internal short method_4()
  {
    byte[] numArray = this.method_1(2);
    return (short) ((int) numArray[0] << 8 | (int) numArray[1]);
  }

  internal ushort method_5()
  {
    byte[] numArray = this.method_1(2);
    return (ushort) ((uint) numArray[0] << 8 | (uint) numArray[1]);
  }

  internal int method_6()
  {
    byte[] numArray = this.method_1(4);
    return (int) numArray[0] << 24 | (int) numArray[1] << 16 | (int) numArray[2] << 8 | (int) numArray[3];
  }

  internal uint method_7()
  {
    byte[] numArray = this.method_1(4);
    return (uint) ((int) numArray[0] << 24 | (int) numArray[1] << 16 | (int) numArray[2] << 8) | (uint) numArray[3];
  }

  internal long method_8()
  {
    byte[] numArray = this.method_1(8);
    return (long) ((int) numArray[0] << 24 | (int) numArray[1] << 16 | (int) numArray[2] << 8 | (int) numArray[3] | (int) numArray[4] << 24 | (int) numArray[5] << 16 | (int) numArray[6] << 8 | (int) numArray[7]);
  }

  internal ulong method_9()
  {
    byte[] numArray = this.method_1(8);
    return (ulong) ((int) numArray[0] << 24 | (int) numArray[1] << 16 | (int) numArray[2] << 8 | (int) numArray[3] | (int) numArray[4] << 24 | (int) numArray[5] << 16 | (int) numArray[6] << 8 | (int) numArray[7]);
  }

  internal string method_10()
  {
    int num = this.byte_1.Length;
    for (int index = 0; index < this.byte_1.Length; ++index)
    {
      if (this.byte_1[index] == (byte) 0)
      {
        num = index;
        break;
      }
    }
    byte[] numArray = new byte[num - this.int_0];
    Buffer.BlockCopy((Array) this.byte_1, this.int_0, (Array) numArray, 0, numArray.Length);
    this.int_0 = num + 1;
    if (this.int_0 > this.byte_1.Length)
      this.int_0 = this.byte_1.Length;
    return Encoding.GetEncoding(949).GetString(numArray);
  }

  internal string method_11()
  {
    if (this.int_0 >= this.byte_1.Length)
      throw new EndOfStreamException();
    int stream_0 = (int) this.method_2();
    if (this.int_0 + stream_0 > this.byte_1.Length)
    {
      --this.int_0;
      throw new EndOfStreamException();
    }
    byte[] bytes = this.method_1(stream_0);
    return Encoding.GetEncoding(949).GetString(bytes);
  }

  internal string method_12()
  {
    if (this.int_0 + 1 > this.byte_1.Length)
      throw new EndOfStreamException();
    int stream_0 = (int) this.method_5();
    if (this.int_0 + stream_0 > this.byte_1.Length)
    {
      this.int_0 -= 2;
      throw new EndOfStreamException();
    }
    byte[] bytes = this.method_1(stream_0);
    return Encoding.GetEncoding(949).GetString(bytes);
  }

  internal Class144 method_13() => new Class144(this.method_5(), this.method_2(), this.method_2(), this.method_5(), this.method_2(), this.method_2(), this.method_5(), this.method_2(), this.method_5(), this.method_2(), this.method_5(), this.method_5(), this.method_2(), this.method_2());

  internal Struct16 method_14()
  {
    if (this.int_0 + 4 > this.byte_1.Length)
      throw new EndOfStreamException();
    return new Struct16((short) this.method_5(), (short) this.method_5());
  }

  internal void method_15([In] byte[] obj0)
  {
    int newSize = this.int_0 + obj0.Length;
    if (newSize > this.byte_1.Length)
      Array.Resize<byte>(ref this.byte_1, newSize);
    Array.Copy((Array) obj0, 0, (Array) this.byte_1, this.int_0, obj0.Length);
    this.int_0 += obj0.Length;
  }

  internal void method_16(TimeSpan stream_0) => this.method_15(new byte[4]
  {
    (byte) stream_0.Days,
    (byte) stream_0.Hours,
    (byte) stream_0.Minutes,
    (byte) stream_0.Seconds
  });

  internal void method_17([In] byte obj0) => this.method_15(new byte[1]
  {
    obj0
  });

  internal void method_18([In] sbyte obj0) => this.method_15(new byte[1]
  {
    (byte) obj0
  });

  internal void method_19([In] bool obj0) => this.method_17(obj0 ? (byte) 1 : (byte) 0);

  internal void method_20(short byte_0) => this.method_15(new byte[2]
  {
    (byte) ((uint) byte_0 >> 8),
    (byte) byte_0
  });

  internal void method_21(ushort uint_3) => this.method_15(new byte[2]
  {
    (byte) ((uint) uint_3 >> 8),
    (byte) uint_3
  });

  internal void method_22(int uint_1) => this.method_15(new byte[4]
  {
    (byte) (uint_1 >> 24),
    (byte) (uint_1 >> 16),
    (byte) (uint_1 >> 8),
    (byte) uint_1
  });

  internal void method_23(uint class0_0) => this.method_15(new byte[4]
  {
    (byte) (class0_0 >> 24),
    (byte) (class0_0 >> 16),
    (byte) (class0_0 >> 8),
    (byte) class0_0
  });

  internal void method_24([In] long obj0) => this.method_15(new byte[8]
  {
    (byte) (obj0 >> 56),
    (byte) (obj0 >> 48),
    (byte) (obj0 >> 40),
    (byte) (obj0 >> 32),
    (byte) (obj0 >> 24),
    (byte) (obj0 >> 16),
    (byte) (obj0 >> 8),
    (byte) obj0
  });

  internal void method_25(ulong int_2) => this.method_15(new byte[8]
  {
    (byte) (int_2 >> 56),
    (byte) (int_2 >> 48),
    (byte) (int_2 >> 40),
    (byte) (int_2 >> 32),
    (byte) (int_2 >> 24),
    (byte) (int_2 >> 16),
    (byte) (int_2 >> 8),
    (byte) int_2
  });

  internal void method_26([In] string obj0, bool int_3)
  {
    this.method_15(Encoding.GetEncoding(949).GetBytes(obj0));
    if (!int_3)
      return;
    this.method_17((byte) 0);
  }

  internal void method_27([In] string obj0)
  {
    byte[] bytes = Encoding.GetEncoding(949).GetBytes(obj0);
    if (bytes.Length > (int) byte.MaxValue)
      throw new ArgumentOutOfRangeException(\u003CModule\u003E.smethod_6<string>(2235711424U), (object) obj0, \u003CModule\u003E.smethod_9<string>(3423497807U));
    this.method_17((byte) bytes.Length);
    this.method_15(bytes);
  }

  internal void method_28(string class0_0)
  {
    byte[] bytes = Encoding.GetEncoding(949).GetBytes(class0_0);
    if (bytes.Length > (int) ushort.MaxValue)
      throw new ArgumentOutOfRangeException(\u003CModule\u003E.smethod_6<string>(2235711424U), (object) class0_0, \u003CModule\u003E.smethod_8<string>(1916939768U));
    this.method_21((ushort) bytes.Length);
    this.method_15(bytes);
  }

  internal void method_29([In] Class144 obj0)
  {
    this.method_21(obj0.UInt16_0);
    this.method_17(obj0.Byte_0);
    this.method_17(obj0.Byte_1);
    this.method_21(obj0.UInt16_1);
    this.method_17(obj0.Byte_2);
    this.method_17(obj0.Byte_3);
    this.method_21(obj0.UInt16_2);
    this.method_17(obj0.Byte_4);
    this.method_21(obj0.UInt16_3);
    this.method_17(obj0.Byte_5);
    this.method_21(obj0.UInt16_4);
    this.method_21(obj0.UInt16_5);
    this.method_17(obj0.Byte_6);
    this.method_17(obj0.Byte_7);
  }

  internal void method_30([In] Struct16 obj0)
  {
    this.method_20(obj0.short_0);
    this.method_20(obj0.short_1);
  }
}
