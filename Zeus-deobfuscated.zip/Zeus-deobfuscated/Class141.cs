﻿// Decompiled with JetBrains decompiler
// Type: Class141
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Runtime.InteropServices;

internal class Class141 : Class140
{
  internal bool Boolean_0 { get; }

  internal Class141(int value, [In] ushort obj1, [In] Struct16 obj2, [In] Class88 obj3, [In] bool obj4)
    : base(value, string.Empty, obj1, obj2, obj3)
  {
    this.Boolean_0 = obj4;
    this.UInt16_0 = obj1;
  }
}
