﻿// Decompiled with JetBrains decompiler
// Type: Class12
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Collections.Generic;
using System.Runtime.InteropServices;

internal class Class12
{
  internal string String_0 { get; [param: In] set; }

  internal ushort UInt16_0 { get; set; }

  internal List<short> List_0 { get; [param: In] set; }

  internal string String_1 { get; set; }

  internal bool Boolean_0 { get; [param: In] set; }

  internal short Int16_0 { get; [param: In] set; }

  internal short Int16_1 { get; set; }

  internal string String_2 { get; set; }

  internal string String_3 { get; [param: In] set; }

  internal bool Boolean_1 { get; set; }

  internal Class12(
    [In] string obj0,
    ushort uint_23,
    [Out] List<short> int_28,
    [Out] bool int_29,
    [In] string obj4,
    [In] short obj5,
    [In] short obj6,
    [In] string obj7,
    [In] string obj8,
    [In] bool obj9)
  {
    this.String_0 = obj0;
    this.UInt16_0 = uint_23;
    this.List_0 = int_28;
    this.String_1 = obj4;
    this.Boolean_0 = int_29;
    this.Int16_0 = obj5;
    this.Int16_1 = obj6;
    this.String_2 = obj7;
    this.String_3 = obj8;
    this.Boolean_1 = obj9;
  }
}
