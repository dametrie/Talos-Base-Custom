﻿// Decompiled with JetBrains decompiler
// Type: Class76
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Runtime.InteropServices;

internal sealed class Class76
{
  internal byte Byte_0 { get; [param: In] set; }

  internal ushort UInt16_0 { get; [param: In] set; }

  internal string String_0 { get; }

  internal int Int32_0 { get; }

  internal int Int32_1 { get; set; }

  internal int Int32_2 { get; [param: In] set; }

  internal DateTime DateTime_0 { get; [param: In] set; }

  internal bool Boolean_0 { get; [param: In] set; }

  internal Class24 Class24_0 { get; set; }

  internal bool Boolean_1 { get; [param: In] set; }

  internal Class10 Class10_0 { get; set; }

  internal Class17 Class17_0 { get; [param: In] set; }

  internal bool Boolean_2 { get; [param: In] set; }

  private byte Byte_1 { get; }

  internal Class76(
    [In] byte obj0,
    [In] ushort obj1,
    [In] byte obj2,
    string uint_1,
    int uint_2,
    [In] int obj5,
    [In] int obj6)
  {
    this.Byte_0 = obj0;
    this.UInt16_0 = obj1;
    this.Byte_1 = obj2;
    this.String_0 = uint_1;
    this.Int32_0 = uint_2;
    this.Int32_1 = obj5;
    this.Int32_2 = obj6;
    this.Boolean_0 = false;
    this.Class24_0 = new Class24();
    this.DateTime_0 = DateTime.MinValue;
  }
}
