﻿// Decompiled with JetBrains decompiler
// Type: Class133
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;

internal sealed class Class133 : IEnumerable
{
  private const int int_0 = 90;
  private readonly Class132[] class132_0;

  internal Dictionary<string, Class132> Dictionary_0 { get; [param: In] set; }

  internal Class132 this[[In] string obj0] => this.Dictionary_0.ContainsKey(obj0) ? this.Dictionary_0[obj0] : (Class132) null;

  internal Class132 this[byte intptr_0] => this.class132_0[(int) intptr_0];

  internal int Int32_0 => 90;

  internal Class133()
  {
    this.Dictionary_0 = new Dictionary<string, Class132>();
    this.class132_0 = new Class132[90];
  }

  internal void method_0([In] Class132 obj0)
  {
    if (this.Dictionary_0.ContainsKey(obj0.String_0))
    {
      Class132 class132 = this.Dictionary_0[obj0.String_0];
      class132.Byte_0 = obj0.Byte_0;
      class132.Byte_1 = obj0.Byte_1;
      class132.Byte_2 = obj0.Byte_2;
      if (obj0.Double_0 > class132.Double_0)
        class132.Double_0 = obj0.Double_0;
      obj0 = class132;
    }
    else
      this.Dictionary_0.Add(obj0.String_0, obj0);
    this.class132_0[(int) obj0.Byte_0] = obj0;
  }

  internal void method_1([In] byte obj0)
  {
    if (this.class132_0[(int) obj0] == null)
      return;
    this.Dictionary_0[this.class132_0[(int) obj0].String_0].Byte_0 = (byte) 0;
    this.class132_0[(int) obj0] = (Class132) null;
  }

  public IEnumerator GetEnumerator() => ((IEnumerable) this.Dictionary_0).GetEnumerator();
}
