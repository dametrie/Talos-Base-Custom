﻿// Decompiled with JetBrains decompiler
// Type: Class132
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Runtime.InteropServices;

internal class Class132
{
  internal string String_0 { get; }

  internal byte Byte_0 { get; set; }

  internal ushort UInt16_0 { get; }

  internal byte Byte_1 { get; [param: In] set; }

  internal byte Byte_2 { get; set; }

  internal DateTime DateTime_0 { get; [param: In] set; }

  internal DateTime DateTime_1 { get; [param: In] set; }

  internal double Double_0 { get; [param: In] set; }

  internal bool Boolean_0
  {
    get
    {
      if (this.DateTime_1 == DateTime.MinValue || this.Double_0 == 0.0)
        return true;
      double num = Math.Max(1.0, this.Double_0);
      TimeSpan timeSpan1 = DateTime.UtcNow.Subtract(this.DateTime_0);
      TimeSpan timeSpan2 = DateTime.UtcNow.Subtract(this.DateTime_1);
      return timeSpan1.TotalSeconds > 0.5 && timeSpan2.TotalSeconds > num;
    }
  }

  internal Class132(byte intptr_0, string int_2, [In] ushort obj2, [In] byte obj3, [In] byte obj4)
  {
    this.Byte_0 = intptr_0;
    this.String_0 = int_2;
    this.UInt16_0 = obj2;
    this.Byte_1 = obj3;
    this.Byte_2 = obj4;
    this.DateTime_0 = DateTime.MinValue;
  }
}
