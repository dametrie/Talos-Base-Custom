﻿// Decompiled with JetBrains decompiler
// Type: Form5
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using MapsCacheEditor;
using SharpUpdate;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;
using WindowsInput.Native;

internal sealed class Form5 : Form, ISharpUpdatable
{
  internal const int int_0 = -20;
  internal const int int_1 = 524288;
  internal const int int_2 = 2;
  private const int int_3 = 256;
  internal static readonly object object_0 = new object();
  internal static Dictionary<string, GClass0> dictionary_0 = new Dictionary<string, GClass0>();
  private readonly ArrayList arrayList_0 = new ArrayList();
  private readonly DateTime dateTime_0 = DateTime.MinValue;
  internal Class178 class178_0;
  private ToolStripMenuItem toolStripMenuItem_0;
  internal int int_4;
  private ToolStripMenuItem toolStripMenuItem_1;
  private IntPtr intptr_0;
  private ToolStripMenuItem toolStripMenuItem_2;
  private IContainer icontainer_0;
  internal Dictionary<string, int> dictionary_1 = new Dictionary<string, int>();
  internal Struct5 struct5_0;
  internal Struct5 struct5_1;
  internal string string_0 = "";
  internal BindingList<string> bindingList_0 = new BindingList<string>((IList<string>) new List<string>());
  internal int int_5;
  internal int int_6;
  internal System.Windows.Forms.Timer timer_0;
  private ToolStripMenuItem toolStripMenuItem_3;
  internal DateTime dateTime_1 = DateTime.MinValue;
  private readonly Dictionary<Class29, TabPage> dictionary_2;
  internal int int_7;
  private MenuStrip menuStrip_0;
  private ToolStripMenuItem toolStripMenuItem_4;
  internal List<Class96> list_0 = new List<Class96>();
  internal int int_8;
  internal ToolStripMenuItem toolStripMenuItem_5;
  private ToolStripMenuItem toolStripMenuItem_6;
  private ToolStripMenuItem toolStripMenuItem_7;
  private ToolStripMenuItem toolStripMenuItem_8;
  private ToolStripMenuItem toolStripMenuItem_9;
  internal List<int> list_1 = new List<int>();
  internal Dictionary<string, string> dictionary_3 = new Dictionary<string, string>((IEqualityComparer<string>) StringComparer.OrdinalIgnoreCase);
  private ToolStripMenuItem toolStripMenuItem_10;
  internal Dictionary<string, Class144> dictionary_4 = new Dictionary<string, Class144>();
  internal int int_9;
  private ToolStripMenuItem toolStripMenuItem_11;
  internal Dictionary<int, int> dictionary_5 = new Dictionary<int, int>();
  internal TabControl tabControl_0;
  internal Form2 form2_0;
  internal int int_10;
  private ToolStripMenuItem toolStripMenuItem_12;
  private ToolStripMenuItem toolStripMenuItem_13;
  internal bool bool_0;
  private readonly SharpUpdater sharpUpdater_0;
  internal string string_1;
  private readonly List<Keys> list_2 = new List<Keys>()
  {
    Keys.Alt,
    Keys.Menu,
    Keys.Control,
    Keys.ControlKey,
    Keys.Shift,
    Keys.ShiftKey,
    Keys.LWin,
    Keys.RWin
  };

  internal Class112 Class112_0 { get; private set; }

  internal int Int32_0 => this.int_7;

  internal Form5()
  {
    Application.EnableVisualStyles();
    this.method_4();
    this.int_7 = Thread.CurrentThread.ManagedThreadId;
    this.dictionary_2 = new Dictionary<Class29, TabPage>();
    Accolade.Properties.Settings.Default.DarkAgesPath = Environment.ExpandEnvironmentVariables(Accolade.Properties.Settings.Default.DarkAgesPath);
    Accolade.Properties.Settings.Default.DataPath = Environment.ExpandEnvironmentVariables(Accolade.Properties.Settings.Default.DataPath);
    this.Opacity = (double) Accolade.Properties.Settings.Default.BotwindowOpacity / 100.0;
    this.method_6();
    Control.CheckForIllegalCrossThreadCalls = false;
    this.form2_0 = new Form2();
    this.sharpUpdater_0 = new SharpUpdater((ISharpUpdatable) this);
    this.sharpUpdater_0.DoUpdate();
  }

  private void timer_0_Tick(object value, [In] EventArgs obj1)
  {
    if (this.int_5 == 0 && this.int_8 == 0 && this.int_9 == 0)
    {
      this.timer_0.Stop();
      Process.GetCurrentProcess().Kill();
    }
    else
    {
      if (this.int_9 < 1)
      {
        this.int_9 = 59;
        if (this.int_8 < 1)
        {
          this.int_8 = 59;
          if (this.int_5 != 0)
            --this.int_5;
        }
        else
          --this.int_8;
      }
      else
        --this.int_9;
      string str;
      if (this.int_9 <= 59)
        str = \u003CModule\u003E.smethod_6<string>(3485800011U) + this.int_5.ToString() + \u003CModule\u003E.smethod_7<string>(1156210857U) + this.int_8.ToString() + \u003CModule\u003E.smethod_7<string>(1156210857U) + this.int_9.ToString() + \u003CModule\u003E.smethod_9<string>(2181263643U);
      else
        str = \u003CModule\u003E.smethod_8<string>(1456332539U) + this.int_5.ToString() + \u003CModule\u003E.smethod_6<string>(2657540495U) + this.int_8.ToString() + \u003CModule\u003E.smethod_5<string>(13905911U) + this.int_9.ToString() + \u003CModule\u003E.smethod_5<string>(2855792601U);
      this.Text = str;
    }
  }

  private void tabControl_0_DrawItem(object value, [In] DrawItemEventArgs obj1)
  {
    Graphics graphics = obj1.Graphics;
    TabPage tabPage = this.tabControl_0.TabPages[obj1.Index];
    Rectangle tabRect = this.tabControl_0.GetTabRect(obj1.Index);
    Brush brush;
    Font font;
    if (obj1.State == DrawItemState.Selected)
    {
      brush = (Brush) new SolidBrush(Color.Black);
      graphics.FillRectangle(Brushes.White, tabRect);
      font = new Font(\u003CModule\u003E.smethod_7<string>(1521212547U), 14f, FontStyle.Bold, GraphicsUnit.Pixel);
    }
    else
    {
      brush = (Brush) new SolidBrush(obj1.ForeColor);
      graphics.FillRectangle(Brushes.WhiteSmoke, tabRect);
      font = new Font(\u003CModule\u003E.smethod_6<string>(2348004861U), 14f, FontStyle.Regular, GraphicsUnit.Pixel);
    }
    StringFormat format = new StringFormat()
    {
      Alignment = StringAlignment.Center,
      LineAlignment = StringAlignment.Center
    };
    graphics.DrawString(tabPage.Text, font, brush, (RectangleF) tabRect, format);
  }

  private void method_0()
  {
    Thread.Sleep(1000);
    Process.GetCurrentProcess().Kill();
  }

  internal void method_1([In] string obj0, Class29 short_2)
  {
    if (this.dictionary_3.ContainsKey(obj0) && this.dictionary_3[obj0].Equals(short_2.class88_0.String_0))
      return;
    this.dictionary_3[obj0] = short_2.class88_0.String_0;
    Class180 stream_1 = new Class180(Enum14.RangerAlert);
    stream_1.method_27(obj0);
    stream_1.method_27(short_2.class88_0.String_0);
    this.class178_0.method_2(stream_1);
  }

  internal void method_2(Class29 short_1)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Form5.Class78 class78 = new Form5.Class78();
    // ISSUE: reference to a compiler-generated field
    class78.form5_0 = this;
    // ISSUE: reference to a compiler-generated field
    class78.class29_0 = short_1;
    if (this.InvokeRequired)
    {
      // ISSUE: reference to a compiler-generated method
      this.Invoke((Delegate) new Action(class78.method_0));
    }
    else
    {
      // ISSUE: reference to a compiler-generated field
      Control2 control2_1 = new Control2(class78.class29_0);
      control2_1.Dock = DockStyle.Fill;
      Control2 control2_2 = control2_1;
      // ISSUE: reference to a compiler-generated field
      TabPage tabPage = new TabPage(class78.class29_0.String_0);
      tabPage.Controls.Add((Control) control2_2);
      this.tabControl_0.TabPages.Add(tabPage);
      // ISSUE: reference to a compiler-generated field
      this.dictionary_2.Add(class78.class29_0, tabPage);
      foreach (Class29 class29 in this.Class112_0.IEnumerable_0)
      {
        // ISSUE: reference to a compiler-generated field
        if (class29.Class26_0?.control3_1 != null && class29 != class78.class29_0)
        {
          // ISSUE: reference to a compiler-generated field
          if (class29.Class26_0.method_44(class78.class29_0.String_0))
          {
            // ISSUE: reference to a compiler-generated field
            class29.Control2_0.tabControl_1.TabPages[class78.class29_0.String_0]?.Dispose();
            // ISSUE: reference to a compiler-generated field
            class29.Class26_0.method_43(class78.class29_0.String_0);
          }
          // ISSUE: reference to a compiler-generated field
          Class145 class142_4 = new Class145(class78.class29_0.String_0)
          {
            Control3_0 = class29.Class26_0.control3_1
          };
          class29.Class26_0.method_42(class142_4);
        }
      }
    }
  }

  internal void method_3([In] Class29 obj0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Form5.Class79 class79 = new Form5.Class79();
    // ISSUE: reference to a compiler-generated field
    class79.form5_0 = this;
    // ISSUE: reference to a compiler-generated field
    class79.class29_0 = obj0;
    try
    {
      if (this.InvokeRequired)
      {
        // ISSUE: reference to a compiler-generated method
        this.Invoke((Delegate) new Action(class79.method_0));
      }
      else
      {
        try
        {
          // ISSUE: reference to a compiler-generated field
          if (!this.dictionary_2.ContainsKey(class79.class29_0))
            return;
          // ISSUE: reference to a compiler-generated field
          this.tabControl_0.Controls.Remove((Control) this.dictionary_2[class79.class29_0]);
          // ISSUE: reference to a compiler-generated field
          this.dictionary_2.Remove(class79.class29_0);
          // ISSUE: reference to a compiler-generated field
          class79.class29_0.Control2_0.Dispose();
          // ISSUE: reference to a compiler-generated field
          class79.class29_0.method_162();
        }
        catch
        {
        }
      }
    }
    catch
    {
    }
  }

  void Form.Dispose([In] bool obj0)
  {
    if (obj0 && this.icontainer_0 != null)
      this.icontainer_0.Dispose();
    // ISSUE: explicit non-virtual call
    __nonvirtual (((Form) this).Dispose(obj0));
  }

  private void method_4()
  {
    this.icontainer_0 = (IContainer) new Container();
    ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (Form5));
    this.tabControl_0 = new TabControl();
    this.menuStrip_0 = new MenuStrip();
    this.toolStripMenuItem_5 = new ToolStripMenuItem();
    this.toolStripMenuItem_6 = new ToolStripMenuItem();
    this.toolStripMenuItem_1 = new ToolStripMenuItem();
    this.toolStripMenuItem_10 = new ToolStripMenuItem();
    this.toolStripMenuItem_0 = new ToolStripMenuItem();
    this.toolStripMenuItem_12 = new ToolStripMenuItem();
    this.toolStripMenuItem_11 = new ToolStripMenuItem();
    this.toolStripMenuItem_3 = new ToolStripMenuItem();
    this.toolStripMenuItem_2 = new ToolStripMenuItem();
    this.toolStripMenuItem_7 = new ToolStripMenuItem();
    this.toolStripMenuItem_8 = new ToolStripMenuItem();
    this.toolStripMenuItem_9 = new ToolStripMenuItem();
    this.toolStripMenuItem_13 = new ToolStripMenuItem();
    this.toolStripMenuItem_4 = new ToolStripMenuItem();
    this.timer_0 = new System.Windows.Forms.Timer(this.icontainer_0);
    this.menuStrip_0.SuspendLayout();
    this.SuspendLayout();
    componentResourceManager.ApplyResources((object) this.tabControl_0, \u003CModule\u003E.smethod_8<string>(389112825U));
    this.tabControl_0.DrawMode = TabDrawMode.OwnerDrawFixed;
    this.tabControl_0.ForeColor = Color.Black;
    this.tabControl_0.HotTrack = true;
    this.tabControl_0.Multiline = true;
    this.tabControl_0.Name = \u003CModule\u003E.smethod_7<string>(2798315151U);
    this.tabControl_0.SelectedIndex = 0;
    this.tabControl_0.SizeMode = TabSizeMode.Fixed;
    this.tabControl_0.DrawItem += new DrawItemEventHandler(this.tabControl_0_DrawItem);
    this.tabControl_0.MouseLeave += new EventHandler(this.tabControl_0_MouseLeave);
    this.tabControl_0.MouseMove += new MouseEventHandler(this.tabControl_0_MouseMove);
    this.menuStrip_0.BackColor = Color.White;
    this.menuStrip_0.Items.AddRange(new ToolStripItem[6]
    {
      (ToolStripItem) this.toolStripMenuItem_5,
      (ToolStripItem) this.toolStripMenuItem_1,
      (ToolStripItem) this.toolStripMenuItem_10,
      (ToolStripItem) this.toolStripMenuItem_0,
      (ToolStripItem) this.toolStripMenuItem_2,
      (ToolStripItem) this.toolStripMenuItem_4
    });
    componentResourceManager.ApplyResources((object) this.menuStrip_0, \u003CModule\u003E.smethod_9<string>(1671144471U));
    this.menuStrip_0.Name = \u003CModule\u003E.smethod_9<string>(1671144471U);
    this.toolStripMenuItem_5.DropDownItems.AddRange(new ToolStripItem[1]
    {
      (ToolStripItem) this.toolStripMenuItem_6
    });
    componentResourceManager.ApplyResources((object) this.toolStripMenuItem_5, \u003CModule\u003E.smethod_8<string>(4203962817U));
    this.toolStripMenuItem_5.Name = \u003CModule\u003E.smethod_5<string>(4116049641U);
    this.toolStripMenuItem_5.MouseUp += new MouseEventHandler(this.toolStripMenuItem_6_MouseUp);
    this.toolStripMenuItem_6.BackColor = Color.White;
    this.toolStripMenuItem_6.ForeColor = Color.Black;
    this.toolStripMenuItem_6.Name = \u003CModule\u003E.smethod_7<string>(3591374802U);
    componentResourceManager.ApplyResources((object) this.toolStripMenuItem_6, \u003CModule\u003E.smethod_8<string>(922722682U));
    this.toolStripMenuItem_6.MouseUp += new MouseEventHandler(this.toolStripMenuItem_6_MouseUp);
    this.toolStripMenuItem_1.Name = \u003CModule\u003E.smethod_6<string>(1391711526U);
    componentResourceManager.ApplyResources((object) this.toolStripMenuItem_1, \u003CModule\u003E.smethod_8<string>(682664030U));
    this.toolStripMenuItem_1.Click += new EventHandler(this.toolStripMenuItem_1_Click);
    this.toolStripMenuItem_10.Name = \u003CModule\u003E.smethod_6<string>(3876490074U);
    componentResourceManager.ApplyResources((object) this.toolStripMenuItem_10, \u003CModule\u003E.smethod_6<string>(3876490074U));
    this.toolStripMenuItem_10.Click += new EventHandler(this.toolStripMenuItem_10_Click);
    this.toolStripMenuItem_0.DropDownItems.AddRange(new ToolStripItem[3]
    {
      (ToolStripItem) this.toolStripMenuItem_12,
      (ToolStripItem) this.toolStripMenuItem_11,
      (ToolStripItem) this.toolStripMenuItem_3
    });
    this.toolStripMenuItem_0.Name = \u003CModule\u003E.smethod_9<string>(1082287465U);
    componentResourceManager.ApplyResources((object) this.toolStripMenuItem_0, \u003CModule\u003E.smethod_9<string>(1082287465U));
    this.toolStripMenuItem_12.Name = \u003CModule\u003E.smethod_8<string>(904078240U);
    componentResourceManager.ApplyResources((object) this.toolStripMenuItem_12, \u003CModule\u003E.smethod_6<string>(3009819432U));
    this.toolStripMenuItem_12.Click += new EventHandler(this.toolStripMenuItem_12_Click);
    this.toolStripMenuItem_11.Name = \u003CModule\u003E.smethod_7<string>(2115662288U);
    componentResourceManager.ApplyResources((object) this.toolStripMenuItem_11, \u003CModule\u003E.smethod_9<string>(1332150566U));
    this.toolStripMenuItem_11.Click += new EventHandler(this.toolStripMenuItem_11_Click);
    this.toolStripMenuItem_3.Name = \u003CModule\u003E.smethod_6<string>(785500926U);
    componentResourceManager.ApplyResources((object) this.toolStripMenuItem_3, \u003CModule\u003E.smethod_9<string>(2097329324U));
    this.toolStripMenuItem_3.Click += new EventHandler(this.toolStripMenuItem_3_Click);
    this.toolStripMenuItem_2.DropDownItems.AddRange(new ToolStripItem[3]
    {
      (ToolStripItem) this.toolStripMenuItem_7,
      (ToolStripItem) this.toolStripMenuItem_8,
      (ToolStripItem) this.toolStripMenuItem_9
    });
    this.toolStripMenuItem_2.Name = \u003CModule\u003E.smethod_5<string>(251483438U);
    componentResourceManager.ApplyResources((object) this.toolStripMenuItem_2, \u003CModule\u003E.smethod_7<string>(503113686U));
    this.toolStripMenuItem_7.Name = \u003CModule\u003E.smethod_8<string>(4096977711U);
    componentResourceManager.ApplyResources((object) this.toolStripMenuItem_7, \u003CModule\u003E.smethod_9<string>(572168293U));
    this.toolStripMenuItem_7.Click += new EventHandler(this.toolStripMenuItem_7_Click);
    this.toolStripMenuItem_8.Name = \u003CModule\u003E.smethod_9<string>(1386139010U);
    componentResourceManager.ApplyResources((object) this.toolStripMenuItem_8, \u003CModule\u003E.smethod_7<string>(2145217980U));
    this.toolStripMenuItem_8.Click += new EventHandler(this.toolStripMenuItem_8_Click);
    this.toolStripMenuItem_9.BackColor = Color.White;
    this.toolStripMenuItem_9.DropDownItems.AddRange(new ToolStripItem[1]
    {
      (ToolStripItem) this.toolStripMenuItem_13
    });
    this.toolStripMenuItem_9.ForeColor = Color.Black;
    this.toolStripMenuItem_9.Name = \u003CModule\u003E.smethod_8<string>(1589406085U);
    componentResourceManager.ApplyResources((object) this.toolStripMenuItem_9, \u003CModule\u003E.smethod_9<string>(3749313327U));
    this.toolStripMenuItem_9.MouseEnter += new EventHandler(this.toolStripMenuItem_9_MouseEnter);
    this.toolStripMenuItem_13.Name = \u003CModule\u003E.smethod_8<string>(2603133246U);
    componentResourceManager.ApplyResources((object) this.toolStripMenuItem_13, \u003CModule\u003E.smethod_5<string>(1511740478U));
    this.toolStripMenuItem_4.Alignment = ToolStripItemAlignment.Right;
    this.toolStripMenuItem_4.Name = \u003CModule\u003E.smethod_5<string>(1447465956U);
    componentResourceManager.ApplyResources((object) this.toolStripMenuItem_4, \u003CModule\u003E.smethod_7<string>(994496792U));
    this.toolStripMenuItem_4.Click += new EventHandler(this.toolStripMenuItem_4_Click);
    this.timer_0.Interval = 1000;
    this.timer_0.Tick += new EventHandler(this.timer_0_Tick);
    componentResourceManager.ApplyResources((object) this, \u003CModule\u003E.smethod_5<string>(4225078124U));
    this.AutoScaleMode = AutoScaleMode.Font;
    this.BackColor = Color.White;
    this.Controls.Add((Control) this.tabControl_0);
    this.Controls.Add((Control) this.menuStrip_0);
    this.DoubleBuffered = true;
    this.ForeColor = Color.Black;
    this.FormBorderStyle = FormBorderStyle.FixedSingle;
    this.MainMenuStrip = this.menuStrip_0;
    this.MaximizeBox = false;
    this.Name = \u003CModule\u003E.smethod_8<string>(4230051257U);
    this.SizeGripStyle = SizeGripStyle.Hide;
    this.FormClosing += new FormClosingEventHandler(this.Form5_FormClosing);
    this.Load += new EventHandler(this.Form5_Load);
    this.menuStrip_0.ResumeLayout(false);
    this.menuStrip_0.PerformLayout();
    this.ResumeLayout(false);
    this.PerformLayout();
  }

  internal void method_5()
  {
    for (int int_1 = 1; int_1 <= 5; ++int_1)
      Class137.UnregisterHotKey(this.Handle, int_1);
    for (int int_1 = 9; int_1 <= 12; ++int_1)
      Class137.UnregisterHotKey(this.Handle, int_1);
  }

  internal void method_6()
  {
    KeyEventArgs short_4 = new KeyEventArgs(Keys.None);
    if (Accolade.Properties.Settings.Default.RefreshAll)
    {
      try
      {
        Class137.RegisterHotKey(this.Handle, 1, 0U, (uint) Keys.F5.GetHashCode());
      }
      catch
      {
      }
    }
    TextBox textBox1 = new TextBox();
    textBox1.Text = Accolade.Properties.Settings.Default.BotHotKey;
    textBox1.Name = \u003CModule\u003E.smethod_5<string>(4160803602U);
    this.method_17((object) textBox1, short_4);
    TextBox textBox2 = new TextBox();
    textBox2.Text = Accolade.Properties.Settings.Default.WalkHotKey;
    textBox2.Name = \u003CModule\u003E.smethod_9<string>(3014080444U);
    this.method_17((object) textBox2, short_4);
    TextBox textBox3 = new TextBox();
    textBox3.Text = Accolade.Properties.Settings.Default.CastHotKey;
    textBox3.Name = \u003CModule\u003E.smethod_7<string>(1815548939U);
    this.method_17((object) textBox3, short_4);
    TextBox textBox4 = new TextBox();
    textBox4.Text = Accolade.Properties.Settings.Default.SoundHotKey;
    textBox4.Name = \u003CModule\u003E.smethod_7<string>(3942795428U);
    this.method_17((object) textBox4, short_4);
    TextBox textBox5 = new TextBox();
    textBox5.Text = Accolade.Properties.Settings.Default.Combo1HotKey;
    textBox5.Name = \u003CModule\u003E.smethod_7<string>(714571832U);
    this.method_17((object) textBox5, short_4);
    TextBox textBox6 = new TextBox();
    textBox6.Text = Accolade.Properties.Settings.Default.Combo2HotKey;
    textBox6.Name = \u003CModule\u003E.smethod_9<string>(1475976635U);
    this.method_17((object) textBox6, short_4);
    TextBox textBox7 = new TextBox();
    textBox7.Text = Accolade.Properties.Settings.Default.Combo3HotKey;
    textBox7.Name = \u003CModule\u003E.smethod_9<string>(917065504U);
    this.method_17((object) textBox7, short_4);
    TextBox textBox8 = new TextBox();
    textBox8.Text = Accolade.Properties.Settings.Default.Combo4HotKey;
    textBox8.Name = \u003CModule\u003E.smethod_9<string>(3280239821U);
    this.method_17((object) textBox8, short_4);
  }

  internal void method_7()
  {
    string str = AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_8<string>(2657941472U);
    if (!File.Exists(str))
      return;
    foreach (XElement element in XDocument.Load(str).Element((XName) \u003CModule\u003E.smethod_5<string>(3617538356U)).Elements())
      this.dictionary_1.Add(element.Name.ToString().ToUpper(), Convert.ToInt32(element.Value));
  }

  internal void method_8()
  {
    string fileName = AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_6<string>(2206939496U);
    XDocument xdocument = new XDocument();
    XmlWriter writer = xdocument.CreateWriter();
    writer.WriteStartDocument();
    writer.WriteStartElement(\u003CModule\u003E.smethod_7<string>(3621199368U));
    foreach (KeyValuePair<string, int> keyValuePair in this.dictionary_1)
      writer.WriteElementString(keyValuePair.Key.ToUpper(), keyValuePair.Value.ToString());
    writer.WriteEndElement();
    writer.WriteEndDocument();
    writer.Flush();
    writer.Close();
    xdocument.Save(fileName);
  }

  private void toolStripMenuItem_1_Click([In] object obj0, [In] EventArgs obj1)
  {
    int num = (int) new Form6(this).ShowDialog();
  }

  private void toolStripMenuItem_6_MouseUp([In] object obj0, [In] MouseEventArgs obj1)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Form5.Class80 class80 = new Form5.Class80();
    // ISSUE: reference to a compiler-generated field
    class80.form5_0 = this;
    // ISSUE: reference to a compiler-generated field
    class80.object_0 = obj0;
    try
    {
      string path = Accolade.Properties.Settings.Default.DarkAgesPath.Replace(\u003CModule\u003E.smethod_9<string>(3055597324U), \u003CModule\u003E.smethod_7<string>(742564328U));
      if (!File.Exists(path))
        File.WriteAllBytes(path, Class9.Byte_1);
    }
    catch
    {
      int num = (int) Form1.smethod_0(this, \u003CModule\u003E.smethod_6<string>(3863458528U), (IWin32Window) null, true);
      return;
    }
    if (Form5.dictionary_0.Count == 0)
    {
      try
      {
        string str = Accolade.Properties.Settings.Default.DarkAgesPath.Replace(\u003CModule\u003E.smethod_6<string>(975385566U), "");
        if (!Directory.Exists(str))
          throw new Exception();
        foreach (string file in Directory.GetFiles(str, \u003CModule\u003E.smethod_7<string>(384902791U), SearchOption.TopDirectoryOnly))
        {
          string key = file.Replace(str, "");
          Form5.dictionary_0.Add(key, GClass0.smethod_0(file));
        }
      }
      catch
      {
        int num = (int) Form1.smethod_0(this, \u003CModule\u003E.smethod_7<string>(3339442338U), (IWin32Window) null, true);
        return;
      }
    }
    // ISSUE: reference to a compiler-generated method
    ThreadPool.QueueUserWorkItem(new WaitCallback(class80.method_0));
  }

  internal void method_9(string string_1, [In] string obj1, [In] Process obj2)
  {
    Class137.GetClientRect(obj2.MainWindowHandle, ref this.struct5_0);
    System.Drawing.Point int_4 = new System.Drawing.Point((int) ((double) this.struct5_0.Int32_3 * 0.2), (int) ((double) this.struct5_0.Int32_2 * 0.66));
    Thread.Sleep(5000);
    Class13.smethod_1((VirtualKeyCode) 13, obj2);
    Thread.Sleep(500);
    Class13.smethod_4(new System.Drawing.Point(++int_4.X, ++int_4.Y), obj2);
    Class13.smethod_3(int_4, obj2);
    Thread.Sleep(500);
    Class13.smethod_2(string_1, obj2, true);
    Class13.smethod_1((VirtualKeyCode) 13, obj2);
    Class13.smethod_2(obj1, obj2, false);
    Thread.Sleep(500);
    Class13.smethod_1((VirtualKeyCode) 13, obj2);
  }

  internal Process method_10([In] bool obj0)
  {
    if (!Directory.Exists(Accolade.Properties.Settings.Default.DataPath))
      Directory.CreateDirectory(Accolade.Properties.Settings.Default.DataPath);
    string path = Accolade.Properties.Settings.Default.DarkAgesPath.Replace(\u003CModule\u003E.smethod_7<string>(152792302U), \u003CModule\u003E.smethod_5<string>(2039744376U));
    try
    {
      if (!File.Exists(path))
        File.WriteAllText(path, Class9.String_3);
      string[] contents = File.ReadAllLines(path);
      contents[6] = \u003CModule\u003E.smethod_6<string>(1071340548U);
      File.WriteAllLines(path, contents);
    }
    catch
    {
    }
    string darkAgesPath = Accolade.Properties.Settings.Default.DarkAgesPath;
    Struct13 struct13 = new Struct13();
    struct13.Int32_0 = Marshal.SizeOf<Struct13>(struct13);
    Struct14 struct14;
    Class77.CreateProcess(darkAgesPath, (string) null, IntPtr.Zero, IntPtr.Zero, false, Enum8.Suspended, IntPtr.Zero, (string) null, ref struct13, ref struct14);
    Process processById = Process.GetProcessById(struct14.Int32_0);
    IntPtr class29_0 = Class77.OpenProcess_1(2035711U, 1, processById.Id);
    if (Accolade.Properties.Settings.Default.UseDawnd)
      this.method_11(class29_0, darkAgesPath.Replace(\u003CModule\u003E.smethod_5<string>(197665510U), \u003CModule\u003E.smethod_7<string>(742564328U)));
    using (Stream0 stream0 = new Stream0(struct14.Int32_0, Enum7.VmOperation | Enum7.VmRead | Enum7.VmWrite))
    {
      if (obj0)
      {
        ((Stream) stream0).Position = 6281349L;
        ((Stream) stream0).WriteByte((byte) 144);
        ((Stream) stream0).WriteByte((byte) 144);
        ((Stream) stream0).WriteByte((byte) 144);
        ((Stream) stream0).WriteByte((byte) 144);
        ((Stream) stream0).WriteByte((byte) 144);
      }
      ((Stream) stream0).Position = 4404130L;
      ((Stream) stream0).WriteByte((byte) 235);
      ((Stream) stream0).Position = 4404162L;
      ((Stream) stream0).WriteByte((byte) 106);
      ((Stream) stream0).WriteByte((byte) 1);
      ((Stream) stream0).WriteByte((byte) 106);
      ((Stream) stream0).WriteByte((byte) 0);
      ((Stream) stream0).WriteByte((byte) 106);
      ((Stream) stream0).WriteByte((byte) 0);
      ((Stream) stream0).WriteByte((byte) 106);
      ((Stream) stream0).WriteByte((byte) 127);
      ((Stream) stream0).Position = 275684L;
      ((Stream) stream0).WriteByte((byte) 50);
      ((Stream) stream0).WriteByte((byte) 10);
      ((Stream) stream0).Position = 4384287L;
      ((Stream) stream0).WriteByte((byte) 144);
      ((Stream) stream0).WriteByte((byte) 144);
      ((Stream) stream0).WriteByte((byte) 144);
      ((Stream) stream0).WriteByte((byte) 144);
      ((Stream) stream0).WriteByte((byte) 144);
      ((Stream) stream0).WriteByte((byte) 144);
      if (!Accolade.Properties.Settings.Default.UseDawnd)
      {
        ((Stream) stream0).Position = 5744601L;
        ((Stream) stream0).WriteByte((byte) 235);
      }
      ((Stream) stream0).Position = 7290020L;
      Class77.ResumeThread(struct14.IntPtr_1);
    }
    do
      ;
    while (processById.MainWindowHandle == IntPtr.Zero);
    Class137.GetClientRect(processById.MainWindowHandle, ref this.struct5_0);
    Class137.GetWindowRect_1(processById.MainWindowHandle, ref this.struct5_1);
    this.int_10 = this.struct5_1.Int32_2 - this.struct5_0.Int32_2;
    this.int_4 = this.struct5_1.Int32_3 - this.struct5_0.Int32_3;
    if (Accolade.Properties.Settings.Default.UseDawnd && !Accolade.Properties.Settings.Default.SmallWindowOpt)
    {
      if (Accolade.Properties.Settings.Default.LargeWindowOpt)
        Class137.MoveWindow(processById.MainWindowHandle, this.struct5_1.Int32_0, this.struct5_1.Int32_1, 1280 + this.int_4, 960 + this.int_10, true);
      else if (Accolade.Properties.Settings.Default.FullWindowOpt)
      {
        Class137.SetWindowLong(processById.MainWindowHandle, -16, 268435456);
        Class137.ShowWindowAsync(processById.MainWindowHandle, 3);
      }
    }
    Class137.SetWindowLong(processById.MainWindowHandle, -20, Class137.GetWindowLong(processById.MainWindowHandle, -20) | 524288);
    Class137.SetLayeredWindowAttributes(processById.MainWindowHandle, 0U, (byte) Math.Truncate((double) byte.MaxValue / (100.0 / (double) Accolade.Properties.Settings.Default.DawindowOpacity)), 2U);
    Class137.SetWindowText(processById.MainWindowHandle, \u003CModule\u003E.smethod_9<string>(200678705U));
    return processById;
  }

  internal unsafe void method_11(IntPtr class29_0, string struct16_0)
  {
    int num1 = struct16_0.Length + 1;
    IntPtr num2 = Class77.VirtualAllocEx(class29_0, (IntPtr) (void*) null, (uint) num1, 4096U, 64U);
    IntPtr num3;
    Class77.WriteProcessMemory_2(class29_0, num2, struct16_0, (UIntPtr) (ulong) num1, ref num3);
    UIntPtr procAddress = Class77.GetProcAddress(Class77.GetModuleHandle(\u003CModule\u003E.smethod_6<string>(2858089601U)), \u003CModule\u003E.smethod_5<string>(2470145469U));
    if (procAddress == UIntPtr.Zero)
    {
      int num4 = (int) Form1.smethod_0(this, \u003CModule\u003E.smethod_8<string>(3217639769U), (IWin32Window) null, true);
    }
    else
    {
      IntPtr remoteThread = Class77.CreateRemoteThread(class29_0, (IntPtr) (void*) null, 0U, procAddress, num2, 0U, ref num3);
      if (remoteThread == IntPtr.Zero)
      {
        int num5 = (int) Form1.smethod_0(this, \u003CModule\u003E.smethod_5<string>(3132411250U), (IWin32Window) null, true);
      }
      else
      {
        switch ((uint) Class77.WaitForSingleObject(remoteThread, 10000))
        {
          case 128:
          case 258:
          case uint.MaxValue:
            int num6 = (int) Form1.smethod_0(this, \u003CModule\u003E.smethod_7<string>(1921278012U), (IWin32Window) null, true);
            if (!(remoteThread != IntPtr.Zero))
              break;
            Class77.CloseHandle(remoteThread);
            break;
          default:
            Class77.VirtualFreeEx(class29_0, num2, (UIntPtr) 0UL, 32768U);
            if (!(remoteThread != IntPtr.Zero))
              break;
            Class77.CloseHandle(remoteThread);
            break;
        }
      }
    }
  }

  private void toolStripMenuItem_10_Click(object class139_0, [In] EventArgs obj1) => new Form4(this.string_1, this).Show();

  private void toolStripMenuItem_12_Click([In] object obj0, EventArgs short_4)
  {
    try
    {
      foreach (Class29 class29 in this.Class112_0.IEnumerable_0)
        class29.Control2_0.method_56(0, 0, true, false);
    }
    catch
    {
    }
  }

  private void toolStripMenuItem_11_Click(object struct16_0, EventArgs struct16_1)
  {
    try
    {
      foreach (Class29 class29 in this.Class112_0.IEnumerable_0)
        class29.Control2_0.method_56(640, 480, false, false);
    }
    catch
    {
    }
  }

  private void toolStripMenuItem_3_Click(object struct16_0, EventArgs struct16_1)
  {
    try
    {
      foreach (Class29 class29 in this.Class112_0.IEnumerable_0)
        class29.Control2_0.method_56(1280, 960, false, false);
    }
    catch
    {
    }
  }

  private void toolStripMenuItem_7_Click(object short_2, EventArgs short_3)
  {
    Dictionary<Class29, Struct16> dictionary = new Dictionary<Class29, Struct16>();
    int index = 0;
    short num1 = (short) (Screen.AllScreens[0].Bounds.Left - 10);
    short top = (short) Screen.AllScreens[0].Bounds.Top;
    short num2 = (short) (Screen.AllScreens[0].Bounds.Right + 50);
    short num3 = (short) (Screen.AllScreens[0].Bounds.Bottom + 100);
    try
    {
      foreach (Class29 key in this.Class112_0.IEnumerable_0)
      {
        key.Control2_0.method_56(640, 480, false, false);
        dictionary.Add(key, new Struct16(num1, top));
        num1 += (short) 640;
        if ((int) num1 + 640 > (int) num2)
        {
          num1 = (short) (Screen.AllScreens[index].Bounds.Left - 10);
          top += (short) (480 + key.int_9);
          if ((int) top + 480 + key.int_9 > (int) num3)
          {
            if (index + 1 < ((IEnumerable<Screen>) Screen.AllScreens).Count<Screen>())
            {
              ++index;
              num1 = (short) (Screen.AllScreens[index].Bounds.Left - 10);
              top = (short) Screen.AllScreens[index].Bounds.Top;
              num2 = (short) (Screen.AllScreens[index].Bounds.Right + 50);
              num3 = (short) (Screen.AllScreens[index].Bounds.Bottom + 100);
            }
            else
              break;
          }
        }
      }
    }
    catch
    {
    }
    foreach (KeyValuePair<Class29, Struct16> keyValuePair in dictionary)
      Class137.MoveWindow(keyValuePair.Key.intptr_0, (int) keyValuePair.Value.short_0, (int) keyValuePair.Value.short_1, 640 + keyValuePair.Key.int_10, 480 + keyValuePair.Key.int_9, true);
  }

  private void toolStripMenuItem_8_Click(object int_0, EventArgs int_1)
  {
    Dictionary<Class29, Struct16> dictionary = new Dictionary<Class29, Struct16>();
    int index = 0;
    short num1 = (short) (Screen.AllScreens[0].Bounds.Right - 650);
    short top = (short) Screen.AllScreens[0].Bounds.Top;
    short num2 = (short) (Screen.AllScreens[0].Bounds.Left - 10);
    short num3 = (short) (Screen.AllScreens[0].Bounds.Bottom + 50);
    try
    {
      foreach (Class29 key in this.Class112_0.IEnumerable_0)
      {
        key.Control2_0.method_56(640, 480, false, false);
        dictionary.Add(key, new Struct16(num1, top));
        num1 -= (short) 100;
        top += (short) (key.int_9 - 10);
        if ((int) num1 - 100 < (int) num2 || (int) top + key.int_9 - 10 > (int) num3)
        {
          if (index + 1 < ((IEnumerable<Screen>) Screen.AllScreens).Count<Screen>())
          {
            ++index;
            num1 = (short) (Screen.AllScreens[index].Bounds.Right - 650);
            top = (short) Screen.AllScreens[index].Bounds.Top;
            num2 = (short) (Screen.AllScreens[index].Bounds.Left - 10);
            num3 = (short) (Screen.AllScreens[index].Bounds.Bottom + 50);
          }
          else
            break;
        }
      }
    }
    catch
    {
    }
    foreach (KeyValuePair<Class29, Struct16> keyValuePair in dictionary)
      Class137.MoveWindow(keyValuePair.Key.intptr_0, (int) keyValuePair.Value.short_0, (int) keyValuePair.Value.short_1, 640 + keyValuePair.Key.int_10, 480 + keyValuePair.Key.int_9, true);
  }

  private void method_12(object struct16_0, [In] EventArgs obj1)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Form5.Class81 class81 = new Form5.Class81();
    // ISSUE: reference to a compiler-generated field
    class81.dictionary_0 = new Dictionary<Class29, Struct16>();
    // ISSUE: reference to a compiler-generated field
    class81.class29_0 = this.Class112_0.method_75((struct16_0 as ToolStripMenuItem).Text);
    int index = 0;
    short num1 = (short) (Screen.AllScreens[0].Bounds.Left - 10);
    short top1 = (short) Screen.AllScreens[0].Bounds.Top;
    // ISSUE: reference to a compiler-generated field
    class81.class29_0.Control2_0.method_56(1280, 960, false, false);
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    class81.dictionary_0.Add(class81.class29_0, new Struct16(num1, top1));
    short num2 = (short) (Screen.AllScreens[0].Bounds.Left + 1280 - 10);
    short top2 = (short) Screen.AllScreens[0].Bounds.Top;
    short num3 = (short) (Screen.AllScreens[0].Bounds.Right + 50);
    short num4 = (short) (Screen.AllScreens[0].Bounds.Bottom + 100);
    try
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated method
      foreach (Class29 key in this.Class112_0.IEnumerable_0.Where<Class29>(class81.func_0 ?? (class81.func_0 = new Func<Class29, bool>(class81.method_0))))
      {
        key.Control2_0.method_56(640, 480, false, false);
        // ISSUE: reference to a compiler-generated field
        class81.dictionary_0.Add(key, new Struct16(num2, top2));
        top2 += (short) (480 + key.int_9);
        if ((int) num2 + 640 > (int) num3 || (int) top2 + 480 > (int) num4)
        {
          if (index + 1 < ((IEnumerable<Screen>) Screen.AllScreens).Count<Screen>())
          {
            ++index;
            num2 = (short) (Screen.AllScreens[index].Bounds.Left - 10);
            top2 = (short) Screen.AllScreens[index].Bounds.Top;
            num3 = (short) (Screen.AllScreens[index].Bounds.Right + 50);
            num4 = (short) (Screen.AllScreens[index].Bounds.Bottom + 100);
            break;
          }
          break;
        }
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated method
      foreach (Class29 key in this.Class112_0.IEnumerable_0.Where<Class29>(class81.func_1 ?? (class81.func_1 = new Func<Class29, bool>(class81.method_1))))
      {
        key.Control2_0.method_56(640, 480, false, false);
        // ISSUE: reference to a compiler-generated field
        class81.dictionary_0.Add(key, new Struct16(num2, top2));
        num2 += (short) 640;
        if ((int) num2 + 640 > (int) num3)
        {
          num2 = (short) (Screen.AllScreens[index].Bounds.Left - 10);
          top2 += (short) (480 + key.int_9);
          if ((int) top2 + 480 + key.int_9 > (int) num4)
          {
            if (index + 1 < ((IEnumerable<Screen>) Screen.AllScreens).Count<Screen>())
            {
              ++index;
              num2 = (short) (Screen.AllScreens[index].Bounds.Left - 10);
              top2 = (short) Screen.AllScreens[index].Bounds.Top;
              num3 = (short) (Screen.AllScreens[index].Bounds.Right + 50);
              num4 = (short) (Screen.AllScreens[index].Bounds.Bottom + 100);
            }
            else
              break;
          }
        }
      }
    }
    catch
    {
    }
    // ISSUE: reference to a compiler-generated field
    foreach (KeyValuePair<Class29, Struct16> keyValuePair in class81.dictionary_0)
    {
      // ISSUE: reference to a compiler-generated field
      if (keyValuePair.Key == class81.class29_0)
        Class137.MoveWindow(keyValuePair.Key.intptr_0, (int) keyValuePair.Value.short_0, (int) keyValuePair.Value.short_1, 1280 + keyValuePair.Key.int_10, 960 + keyValuePair.Key.int_9, true);
      else
        Class137.MoveWindow(keyValuePair.Key.intptr_0, (int) keyValuePair.Value.short_0, (int) keyValuePair.Value.short_1, 640 + keyValuePair.Key.int_10, 480 + keyValuePair.Key.int_9, true);
    }
  }

  private void toolStripMenuItem_9_MouseEnter([In] object obj0, EventArgs short_3)
  {
    while (this.toolStripMenuItem_9.DropDownItems.Count > 0)
      this.toolStripMenuItem_9.DropDownItems[0].Dispose();
    foreach (Class29 class29 in this.Class112_0.IEnumerable_0)
    {
      this.toolStripMenuItem_9.DropDownItems.Add((ToolStripItem) new ToolStripMenuItem(class29.String_0, (Image) null, new EventHandler(this.method_12), class29.String_0));
      this.toolStripMenuItem_9.DropDownClosed += new EventHandler(class29.Control2_0.toolStripMenuItem_11_DropDownClosed);
    }
  }

  private void tabControl_0_MouseMove(object direction_0, [In] MouseEventArgs obj1)
  {
    for (int index = 0; index < this.tabControl_0.TabCount; ++index)
    {
      Class112 class1120 = this.Class112_0;
      TabPage tabPage = this.tabControl_0.TabPages[index];
      string class29_0;
      if (tabPage == null)
      {
        class29_0 = (string) null;
      }
      else
      {
        class29_0 = tabPage.Text;
        if (class29_0 != null)
          goto label_5;
      }
      class29_0 = "";
label_5:
      Class29 class29 = class1120.method_75(class29_0);
      if (class29 != null)
      {
        Rectangle tabRect = this.tabControl_0.GetTabRect(index);
        if (tabRect.Contains(obj1.X, obj1.Y))
        {
          if (!class29.bool_45)
            this.form2_0.method_0(class29, tabRect);
          else
            this.form2_0.Location = class29.Class112_0.form5_0.PointToScreen(new System.Drawing.Point(tabRect.Left - this.form2_0.Width, tabRect.Bottom - this.form2_0.Height / 2));
        }
      }
    }
  }

  private void tabControl_0_MouseLeave(object other, [In] EventArgs obj1)
  {
    if (!this.form2_0.Visible)
      return;
    System.Drawing.Point position = Cursor.Position;
    if (Cursor.Position.X <= this.form2_0.Right && Cursor.Position.Y <= this.form2_0.Bottom)
      return;
    this.form2_0.method_1();
  }

  private void toolStripMenuItem_4_Click(object value, [In] EventArgs obj1)
  {
    if (Class137.IsWindow(this.intptr_0))
      return;
    using (MemoryStream mapDataStream = new MemoryStream(Class9.Byte_2))
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      Form5.Class82 class82 = new Form5.Class82();
      // ISSUE: reference to a compiler-generated field
      class82.mapsCacheViewer_0 = new MapsCacheViewer(mapDataStream);
      // ISSUE: reference to a compiler-generated field
      this.intptr_0 = class82.mapsCacheViewer_0.Handle;
      // ISSUE: reference to a compiler-generated method
      new Thread(new ThreadStart(class82.method_0)).Start();
    }
  }

  public string String_0 => \u003CModule\u003E.smethod_5<string>(516656076U);

  public string String_1 => \u003CModule\u003E.smethod_9<string>(2983566486U);

  public Assembly Assembly_0 => Assembly.GetExecutingAssembly();

  public Icon Icon_0 => this.Icon;

  public Uri Uri_0 => new Uri(\u003CModule\u003E.smethod_8<string>(4177874377U));

  public Form Form_0 => (Form) this;

  void Form.WndProc(ref Message value)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Form5.Class83 class83 = new Form5.Class83();
    // ISSUE: reference to a compiler-generated field
    class83.form5_0 = this;
    if (value.Msg == 786)
    {
      StringBuilder stringBuilder = new StringBuilder(256);
      Class137.GetWindowText(Class137.GetForegroundWindow(), stringBuilder, 256);
      switch ((int) value.WParam)
      {
        case 1:
          if (!Accolade.Properties.Settings.Default.RefreshAll)
            return;
          using (IEnumerator<Class29> enumerator = this.Class112_0.IEnumerable_0.GetEnumerator())
          {
            while (enumerator.MoveNext())
              enumerator.Current.method_105(false);
            return;
          }
        case 2:
          using (IEnumerator<Class29> enumerator = this.Class112_0.IEnumerable_0.GetEnumerator())
          {
            while (enumerator.MoveNext())
              enumerator.Current.Control2_0?.toolStripMenuItem_2_Click(new object(), new EventArgs());
            return;
          }
        case 3:
          this.Class112_0.bool_1 = !this.Class112_0.bool_1;
          using (IEnumerator<Class29> enumerator = this.Class112_0.IEnumerable_0.GetEnumerator())
          {
            while (enumerator.MoveNext())
            {
              Class29 current = enumerator.Current;
              if (current.Control2_0 != null)
              {
                if (!current.Control2_0.checkBox_21.Checked)
                  current.method_75((byte) 1, \u003CModule\u003E.smethod_8<string>(2443971260U) + (this.Class112_0.bool_1 ? \u003CModule\u003E.smethod_7<string>(1345917418U) : \u003CModule\u003E.smethod_5<string>(2811038640U)));
                if (this.Class112_0.bool_1)
                  current.Boolean_3 = false;
              }
            }
            return;
          }
        case 4:
          this.Class112_0.bool_2 = !this.Class112_0.bool_2;
          using (IEnumerator<Class29> enumerator = this.Class112_0.IEnumerable_0.GetEnumerator())
          {
            while (enumerator.MoveNext())
            {
              Class29 current = enumerator.Current;
              if (current.Control2_0 != null)
              {
                if (!current.Control2_0.checkBox_21.Checked)
                  current.method_75((byte) 1, \u003CModule\u003E.smethod_7<string>(798549320U) + (this.Class112_0.bool_2 ? \u003CModule\u003E.smethod_8<string>(1856868850U) : \u003CModule\u003E.smethod_5<string>(2811038640U)));
                if (this.Class112_0.bool_2)
                  current.Boolean_4 = false;
              }
            }
            return;
          }
        case 5:
          this.Class112_0.bool_3 = !this.Class112_0.bool_3;
          using (IEnumerator<Class29> enumerator = this.Class112_0.IEnumerable_0.GetEnumerator())
          {
            while (enumerator.MoveNext())
            {
              Class29 current = enumerator.Current;
              if (current.Control2_0 != null && !current.Control2_0.checkBox_21.Checked)
                current.method_75((byte) 1, \u003CModule\u003E.smethod_7<string>(1865293020U) + (this.Class112_0.bool_3 ? \u003CModule\u003E.smethod_8<string>(1856868850U) : \u003CModule\u003E.smethod_9<string>(1701090346U)));
            }
            return;
          }
        case 9:
        case 10:
        case 11:
        case 12:
          // ISSUE: reference to a compiler-generated field
          class83.int_0 = (int) value.WParam - 8;
          // ISSUE: reference to a compiler-generated field
          class83.class29_0 = this.Class112_0.method_75(stringBuilder.ToString());
          // ISSUE: reference to a compiler-generated field
          if (class83.class29_0 == null)
            return;
          // ISSUE: reference to a compiler-generated method
          ThreadPool.QueueUserWorkItem(new WaitCallback(class83.method_0));
          return;
      }
    }
    // ISSUE: explicit non-virtual call
    __nonvirtual (((Form) this).WndProc(ref value));
  }

  private void method_13(Class29 struct17_0, int struct17_1)
  {
    string[] source = new string[9]
    {
      \u003CModule\u003E.smethod_8<string>(1691994132U),
      \u003CModule\u003E.smethod_5<string>(1955949293U),
      \u003CModule\u003E.smethod_5<string>(1229408990U),
      \u003CModule\u003E.smethod_5<string>(2364447781U),
      \u003CModule\u003E.smethod_9<string>(1990724209U),
      \u003CModule\u003E.smethod_6<string>(662543023U),
      \u003CModule\u003E.smethod_8<string>(209125091U),
      \u003CModule\u003E.smethod_6<string>(792773044U),
      \u003CModule\u003E.smethod_9<string>(2294575754U)
    };
    switch (struct17_1)
    {
      case 1:
        if (!struct17_0.bool_8)
          return;
        break;
      case 2:
        if (!struct17_0.bool_9)
          return;
        break;
      case 3:
        if (!struct17_0.bool_10)
          return;
        break;
      case 4:
        if (!struct17_0.bool_11)
          return;
        break;
    }
    string[] lines = (struct17_0.Control2_0.groupBox_6.Controls[\u003CModule\u003E.smethod_9<string>(2853486885U) + struct17_1.ToString() + \u003CModule\u003E.smethod_7<string>(873440252U)] as TextBox).Lines;
    if (!struct17_0.Control2_0.method_44(struct17_1))
      return;
    for (int index = 0; index < lines.Length; ++index)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      Form5.Class84 class84 = new Form5.Class84();
      string input = lines[index];
      if (struct17_0.method_22(input))
      {
        struct17_0.method_29(input);
      }
      else
      {
        // ISSUE: reference to a compiler-generated field
        if ((class84.match_0 = Regex.Match(input, \u003CModule\u003E.smethod_6<string>(224973570U), RegexOptions.IgnoreCase)).Success)
        {
          // ISSUE: reference to a compiler-generated field
          struct17_0.method_29(struct17_0.Class21_0[byte.Parse(class84.match_0.Groups[1].Value)]?.String_0);
        }
        else
        {
          // ISSUE: reference to a compiler-generated field
          if ((class84.match_0 = Regex.Match(input, \u003CModule\u003E.smethod_7<string>(1610514911U), RegexOptions.IgnoreCase)).Success)
          {
            // ISSUE: reference to a compiler-generated field
            struct17_0.method_30(struct17_0.Class133_0[byte.Parse(class84.match_0.Groups[1].Value)].String_0);
          }
          else
          {
            // ISSUE: reference to a compiler-generated field
            if ((class84.match_0 = Regex.Match(input, \u003CModule\u003E.smethod_7<string>(4017686360U))).Success)
            {
              // ISSUE: reference to a compiler-generated field
              switch (class84.match_0.Groups.Cast<Group>().Where<Group>((Func<Group, bool>) (obj0 => !string.IsNullOrEmpty(obj0.Value))).ToList<Group>().Count)
              {
                case 2:
                  // ISSUE: reference to a compiler-generated field
                  struct17_0.method_31(class84.match_0.Groups[3].ToString(), (Class142) null, false, false);
                  continue;
                case 3:
                  try
                  {
                    // ISSUE: reference to a compiler-generated method
                    Class142 class142 = struct17_0.Dictionary_0.Values.OfType<Class142>().Where<Class142>(new Func<Class142, bool>(class84.method_0)).First<Class142>();
                    // ISSUE: reference to a compiler-generated field
                    struct17_0.method_31(class84.match_0.Groups[1].ToString(), class142, false, false);
                    continue;
                  }
                  catch
                  {
                    continue;
                  }
                default:
                  continue;
              }
            }
            else if (struct17_0.method_23(input) && input.Trim() != \u003CModule\u003E.smethod_7<string>(4065317624U))
              struct17_0.method_30(input);
            else if (input.Contains(\u003CModule\u003E.smethod_6<string>(2709752118U)))
              Thread.Sleep(Convert.ToInt32(input.Remove(0, 6)));
            else if (input == \u003CModule\u003E.smethod_7<string>(4065317624U))
            {
              foreach (KeyValuePair<string, Class132> keyValuePair in struct17_0.Class133_0)
              {
                if (((IEnumerable<string>) source).Contains<string>(keyValuePair.Key))
                  struct17_0.method_30(keyValuePair.Key);
              }
            }
            else if (input == \u003CModule\u003E.smethod_9<string>(441520609U))
              struct17_0.method_109();
            else if (input == \u003CModule\u003E.smethod_7<string>(1930547775U))
              struct17_0.method_107();
            else if (input == \u003CModule\u003E.smethod_9<string>(1771042590U))
              struct17_0.method_110();
            else if (input == \u003CModule\u003E.smethod_8<string>(3329887567U))
              this.method_14(struct17_0);
            else if (input == \u003CModule\u003E.smethod_7<string>(817455260U))
              this.method_15(struct17_0);
            else if (input == \u003CModule\u003E.smethod_8<string>(4103556076U))
              this.method_16(struct17_0);
          }
        }
      }
    }
  }

  internal void method_14(Class29 struct17_0) => ThreadPool.QueueUserWorkItem(new WaitCallback(new Form5.Class86()
  {
    class29_0 = struct17_0
  }.method_0));

  internal void method_15([In] Class29 obj0)
  {
    obj0.bool_44 = true;
    obj0.method_30(\u003CModule\u003E.smethod_9<string>(2647219258U));
    while (obj0.bool_44)
      Thread.Sleep(5);
  }

  internal void method_16(Class29 short_3)
  {
    Enum3 enum3 = short_3.method_137(short_3.enum3_0);
    if (enum3 == short_3.Enum3_0)
      return;
    switch (enum3)
    {
      case Enum3.Fire:
        short_3.method_29(\u003CModule\u003E.smethod_9<string>(715426279U));
        break;
      case Enum3.Water:
        short_3.method_29(\u003CModule\u003E.smethod_7<string>(2571529538U));
        break;
      case Enum3.Wind:
        short_3.method_29(\u003CModule\u003E.smethod_7<string>(3420574181U));
        break;
      case Enum3.Earth:
        short_3.method_29(\u003CModule\u003E.smethod_8<string>(1969116648U));
        break;
      case Enum3.Holy:
        short_3.method_29(\u003CModule\u003E.smethod_6<string>(452012963U));
        break;
      case Enum3.Darkness:
        short_3.method_29(\u003CModule\u003E.smethod_8<string>(2513892502U));
        break;
      case Enum3.Any:
        if (short_3.Enum3_0 != Enum3.None)
          break;
        short_3.method_29(\u003CModule\u003E.smethod_7<string>(2364199486U));
        break;
    }
  }

  internal void method_17([In] object obj0, KeyEventArgs short_4)
  {
    try
    {
      KeysConverter keysConverter = new KeysConverter();
      TextBox textBox = obj0 as TextBox;
      List<Keys> keysList = new List<Keys>();
      if (string.IsNullOrEmpty(textBox.Text))
        return;
      Match match = Regex.Match(textBox.Text, \u003CModule\u003E.smethod_7<string>(1722484895U));
      foreach (Group group in match.Groups)
      {
        if (group != match.Groups[0] && group.Success)
          keysList.Add((Keys) keysConverter.ConvertFromString(group.Value));
      }
      if (this.list_2.Contains(keysList[keysList.Count - 1]))
      {
        textBox.Text = "";
      }
      else
      {
        string name = textBox.Name;
        int uint_1;
        // ISSUE: reference to a compiler-generated method
        switch (Class181.smethod_0(name))
        {
          case 524642968:
            if (!(name == \u003CModule\u003E.smethod_9<string>(3014080444U)))
              return;
            uint_1 = 4;
            break;
          case 2204040798:
            if (!(name == \u003CModule\u003E.smethod_8<string>(948811122U)))
              return;
            uint_1 = 2;
            break;
          case 2518218100:
            if (!(name == \u003CModule\u003E.smethod_7<string>(3942795428U)))
              return;
            uint_1 = 5;
            break;
          case 3287411856:
            if (!(name == \u003CModule\u003E.smethod_6<string>(2360609212U)))
              return;
            uint_1 = 9;
            break;
          case 3320967094:
            if (!(name == \u003CModule\u003E.smethod_9<string>(917065504U)))
              return;
            uint_1 = 11;
            break;
          case 3337744713:
            if (!(name == \u003CModule\u003E.smethod_6<string>(2490839233U)))
              return;
            uint_1 = 10;
            break;
          case 3371299951:
            if (!(name == \u003CModule\u003E.smethod_6<string>(1248449959U)))
              return;
            uint_1 = 12;
            break;
          case 3810417378:
            if (!(name == \u003CModule\u003E.smethod_8<string>(3509875301U)))
              return;
            uint_1 = 3;
            break;
          default:
            return;
        }
        try
        {
          switch (keysList.Count)
          {
            case 1:
              Class137.RegisterHotKey(this.Handle, uint_1, 0U, (uint) keysList[0].GetHashCode());
              break;
            case 2:
              Class137.RegisterHotKey(this.Handle, uint_1, Class18.smethod_0(keysList[0]), (uint) keysList[1].GetHashCode());
              break;
            case 3:
              Class137.RegisterHotKey(this.Handle, uint_1, Class18.smethod_0(keysList[0]) | Class18.smethod_0(keysList[1]), (uint) keysList[2].GetHashCode());
              break;
            case 4:
              Class137.RegisterHotKey(this.Handle, uint_1, Class18.smethod_0(keysList[0]) | Class18.smethod_0(keysList[1]) | Class18.smethod_0(keysList[2]), (uint) keysList[3].GetHashCode());
              break;
          }
        }
        catch
        {
        }
      }
    }
    catch
    {
      int num = (int) Form1.smethod_0(this, \u003CModule\u003E.smethod_6<string>(2793102749U), (IWin32Window) null, true);
    }
  }

  private void Form5_Load(object short_3, EventArgs struct16_0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Form5.Class87 class87 = new Form5.Class87();
    // ISSUE: reference to a compiler-generated field
    class87.form5_0 = this;
    if (!Directory.Exists(AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_8<string>(3864813097U)))
      Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_5<string>(3707551153U));
    this.Class112_0 = new Class112(this);
    this.method_7();
    if (!new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator))
    {
      int num = (int) Form1.smethod_0(this, \u003CModule\u003E.smethod_8<string>(583572962U), (IWin32Window) null, true);
    }
    string path1 = AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_9<string>(2099407918U);
    List<string> stringList = new List<string>();
    if (File.Exists(path1))
    {
      foreach (string str in ((IEnumerable<string>) File.ReadAllLines(path1)).ToList<string>())
      {
        try
        {
          string[] strArray = str.Split(' ');
          int result1;
          if (int.TryParse(strArray[0], out result1))
          {
            int result2;
            if (int.TryParse(strArray[1], out result2))
              this.dictionary_5.Add(result1, result2);
          }
        }
        catch
        {
        }
      }
    }
    string path2 = Class106.smethod_2(Environment.SpecialFolder.CommonApplicationData, \u003CModule\u003E.smethod_6<string>(1430891603U), Array.Empty<object>());
    if (Directory.Exists(path2))
    {
      foreach (string enumerateFile in Directory.EnumerateFiles(path2))
      {
        Class96 class96 = Class96.smethod_0(enumerateFile);
        if (class96 != null)
          this.list_0.Add(class96);
      }
    }
    // ISSUE: reference to a compiler-generated field
    class87.dateTime_0 = DateTime.UtcNow;
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    if (class87.dateTime_0.Month == 2 && class87.dateTime_0.Day >= 13 || class87.dateTime_0.Month == 3 && class87.dateTime_0.Day <= 4)
      Class103.dictionary_0[(short) 500] = new Struct19(new Struct16(85, 31), new Struct18((short) 10, (short) 10)).List_0.ToArray();
    // ISSUE: reference to a compiler-generated method
    this.Invoke((Delegate) new Action(class87.method_0));
  }

  private void Form5_FormClosing(object other, [In] FormClosingEventArgs obj1)
  {
    if (this.class178_0 != null)
      this.class178_0.method_2(new Class180(Enum14.KillRequest));
    foreach (Process process in Process.GetProcessesByName(\u003CModule\u003E.smethod_9<string>(3472289766U)))
    {
      if (!Class137.IsWindowVisible(process.MainWindowHandle))
        process.Kill();
    }
    new Thread((ThreadStart) (() => this.method_0())).Start();
  }
}
