﻿// Decompiled with JetBrains decompiler
// Type: Form3
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

internal class Form3 : Form
{
  private readonly IContainer icontainer_0;
  internal Class29 class29_0;
  internal Button button_0;
  internal Label label_0;
  internal NumericUpDown numericUpDown_0;
  internal NumericUpDown numericUpDown_1;
  internal NumericUpDown numericUpDown_2;
  internal Label label_1;
  internal Label label_2;
  internal Label label_3;
  internal NumericUpDown numericUpDown_3;
  internal NumericUpDown numericUpDown_4;
  internal NumericUpDown numericUpDown_5;
  internal Label label_4;
  internal NumericUpDown numericUpDown_6;
  internal Label label_5;
  internal Button button_1;
  internal ListBox listBox_0;
  internal NumericUpDown numericUpDown_7;
  internal NumericUpDown numericUpDown_8;
  internal NumericUpDown numericUpDown_9;
  internal NumericUpDown numericUpDown_10;
  internal NumericUpDown numericUpDown_11;
  internal CheckBox checkBox_0;
  internal CheckBox checkBox_1;
  internal CheckBox checkBox_2;
  internal CheckBox checkBox_3;
  internal Button button_2;
  internal Button button_3;
  internal Button button_4;
  internal ListBox listBox_1;
  internal TextBox textBox_0;
  internal Button button_5;
  internal Label label_6;
  internal Label label_7;
  internal Button button_6;
  internal Button button_7;
  internal Button button_8;
  internal Label label_8;
  private readonly object object_0 = new object();

  internal Form3(Class29 int_2)
  {
    this.method_0();
    this.class29_0 = int_2;
  }

  void Form.Dispose([In] bool obj0)
  {
    if (obj0 && this.icontainer_0 != null)
      this.icontainer_0.Dispose();
    // ISSUE: explicit non-virtual call
    __nonvirtual (((Form) this).Dispose(obj0));
  }

  private void method_0()
  {
    ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (Form3));
    this.button_0 = new Button();
    this.label_0 = new Label();
    this.numericUpDown_0 = new NumericUpDown();
    this.numericUpDown_1 = new NumericUpDown();
    this.numericUpDown_2 = new NumericUpDown();
    this.label_1 = new Label();
    this.label_2 = new Label();
    this.label_3 = new Label();
    this.numericUpDown_3 = new NumericUpDown();
    this.numericUpDown_4 = new NumericUpDown();
    this.numericUpDown_5 = new NumericUpDown();
    this.label_4 = new Label();
    this.numericUpDown_6 = new NumericUpDown();
    this.label_5 = new Label();
    this.button_1 = new Button();
    this.listBox_0 = new ListBox();
    this.numericUpDown_7 = new NumericUpDown();
    this.numericUpDown_8 = new NumericUpDown();
    this.numericUpDown_9 = new NumericUpDown();
    this.numericUpDown_10 = new NumericUpDown();
    this.numericUpDown_11 = new NumericUpDown();
    this.label_8 = new Label();
    this.checkBox_3 = new CheckBox();
    this.checkBox_2 = new CheckBox();
    this.checkBox_1 = new CheckBox();
    this.checkBox_0 = new CheckBox();
    this.button_2 = new Button();
    this.button_5 = new Button();
    this.textBox_0 = new TextBox();
    this.listBox_1 = new ListBox();
    this.button_4 = new Button();
    this.button_3 = new Button();
    this.label_6 = new Label();
    this.label_7 = new Label();
    this.button_6 = new Button();
    this.button_7 = new Button();
    this.button_8 = new Button();
    this.numericUpDown_0.BeginInit();
    this.numericUpDown_1.BeginInit();
    this.numericUpDown_2.BeginInit();
    this.numericUpDown_3.BeginInit();
    this.numericUpDown_4.BeginInit();
    this.numericUpDown_5.BeginInit();
    this.numericUpDown_6.BeginInit();
    this.numericUpDown_7.BeginInit();
    this.numericUpDown_8.BeginInit();
    this.numericUpDown_9.BeginInit();
    this.numericUpDown_10.BeginInit();
    this.numericUpDown_11.BeginInit();
    this.SuspendLayout();
    this.button_0.FlatStyle = FlatStyle.Flat;
    this.button_0.Font = new Font(\u003CModule\u003E.smethod_6<string>(4181633304U), 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.button_0.Location = new Point(659, 185);
    this.button_0.Name = \u003CModule\u003E.smethod_9<string>(418517337U);
    this.button_0.Size = new Size(111, 40);
    this.button_0.TabIndex = 44;
    this.button_0.Text = \u003CModule\u003E.smethod_6<string>(1332227785U);
    this.button_0.UseVisualStyleBackColor = true;
    this.button_0.Click += new EventHandler(this.button_0_Click);
    this.label_0.AutoSize = true;
    this.label_0.Location = new Point(432, 46);
    this.label_0.Name = \u003CModule\u003E.smethod_5<string>(2961469956U);
    this.label_0.Size = new Size(59, 13);
    this.label_0.TabIndex = 41;
    this.label_0.Text = \u003CModule\u003E.smethod_6<string>(2988746817U);
    this.label_0.TextAlign = ContentAlignment.MiddleCenter;
    this.numericUpDown_0.Location = new Point(563, 121);
    this.numericUpDown_0.Maximum = new Decimal(new int[4]
    {
      2000,
      0,
      0,
      0
    });
    this.numericUpDown_0.Name = \u003CModule\u003E.smethod_7<string>(3178827515U);
    this.numericUpDown_0.Size = new Size(46, 22);
    this.numericUpDown_0.TabIndex = 40;
    this.numericUpDown_0.Value = new Decimal(new int[4]
    {
      1000,
      0,
      0,
      0
    });
    this.numericUpDown_1.Location = new Point(567, 95);
    this.numericUpDown_1.Maximum = new Decimal(new int[4]
    {
      12,
      0,
      0,
      0
    });
    this.numericUpDown_1.Minimum = new Decimal(new int[4]
    {
      1,
      0,
      0,
      0
    });
    this.numericUpDown_1.Name = \u003CModule\u003E.smethod_6<string>(2704847080U);
    this.numericUpDown_1.Size = new Size(42, 22);
    this.numericUpDown_1.TabIndex = 39;
    this.numericUpDown_1.Value = new Decimal(new int[4]
    {
      10,
      0,
      0,
      0
    });
    this.numericUpDown_2.Location = new Point(566, 69);
    this.numericUpDown_2.Maximum = new Decimal(new int[4]
    {
      30,
      0,
      0,
      0
    });
    this.numericUpDown_2.Name = \u003CModule\u003E.smethod_9<string>(47027749U);
    this.numericUpDown_2.Size = new Size(43, 22);
    this.numericUpDown_2.TabIndex = 38;
    this.numericUpDown_2.Value = new Decimal(new int[4]
    {
      6,
      0,
      0,
      0
    });
    this.label_1.AutoSize = true;
    this.label_1.Location = new Point(390, 71);
    this.label_1.Name = \u003CModule\u003E.smethod_7<string>(799648562U);
    this.label_1.Size = new Size(102, 13);
    this.label_1.TabIndex = 36;
    this.label_1.Text = \u003CModule\u003E.smethod_6<string>(764428311U);
    this.label_1.TextAlign = ContentAlignment.MiddleCenter;
    this.label_2.AutoSize = true;
    this.label_2.Location = new Point(377, 123);
    this.label_2.Name = \u003CModule\u003E.smethod_6<string>(2835077101U);
    this.label_2.Size = new Size(115, 13);
    this.label_2.TabIndex = 35;
    this.label_2.Text = \u003CModule\u003E.smethod_7<string>(3943894670U);
    this.label_2.TextAlign = ContentAlignment.MiddleCenter;
    this.label_3.AutoSize = true;
    this.label_3.Location = new Point(365, 97);
    this.label_3.Name = \u003CModule\u003E.smethod_5<string>(3964628908U);
    this.label_3.Size = new Size(129, 13);
    this.label_3.TabIndex = 34;
    this.label_3.Text = \u003CModule\u003E.smethod_8<string>(2402960377U);
    this.label_3.TextAlign = ContentAlignment.MiddleCenter;
    this.numericUpDown_3.Location = new Point(496, 121);
    this.numericUpDown_3.Maximum = new Decimal(new int[4]
    {
      2000,
      0,
      0,
      0
    });
    this.numericUpDown_3.Name = \u003CModule\u003E.smethod_5<string>(994193174U);
    this.numericUpDown_3.Size = new Size(46, 22);
    this.numericUpDown_3.TabIndex = 33;
    this.numericUpDown_3.Value = new Decimal(new int[4]
    {
      600,
      0,
      0,
      0
    });
    this.numericUpDown_4.Location = new Point(500, 95);
    this.numericUpDown_4.Maximum = new Decimal(new int[4]
    {
      12,
      0,
      0,
      0
    });
    this.numericUpDown_4.Minimum = new Decimal(new int[4]
    {
      1,
      0,
      0,
      0
    });
    this.numericUpDown_4.Name = \u003CModule\u003E.smethod_8<string>(1682784421U);
    this.numericUpDown_4.Size = new Size(42, 22);
    this.numericUpDown_4.TabIndex = 32;
    this.numericUpDown_4.Value = new Decimal(new int[4]
    {
      10,
      0,
      0,
      0
    });
    this.numericUpDown_5.Location = new Point(500, 69);
    this.numericUpDown_5.Maximum = new Decimal(new int[4]
    {
      30,
      0,
      0,
      0
    });
    this.numericUpDown_5.Name = \u003CModule\u003E.smethod_5<string>(826603008U);
    this.numericUpDown_5.Size = new Size(42, 22);
    this.numericUpDown_5.TabIndex = 31;
    this.numericUpDown_5.Value = new Decimal(new int[4]
    {
      4,
      0,
      0,
      0
    });
    this.label_4.AutoSize = true;
    this.label_4.Location = new Point(492, 157);
    this.label_4.Name = \u003CModule\u003E.smethod_5<string>(35788183U);
    this.label_4.Size = new Size(113, 13);
    this.label_4.TabIndex = 30;
    this.label_4.Text = \u003CModule\u003E.smethod_7<string>(3564481548U);
    this.label_4.TextAlign = ContentAlignment.MiddleCenter;
    this.numericUpDown_6.Location = new Point(449, 155);
    this.numericUpDown_6.Maximum = new Decimal(new int[4]
    {
      10,
      0,
      0,
      0
    });
    this.numericUpDown_6.Name = \u003CModule\u003E.smethod_5<string>(3539940654U);
    this.numericUpDown_6.Size = new Size(37, 22);
    this.numericUpDown_6.TabIndex = 29;
    this.numericUpDown_6.Value = new Decimal(new int[4]
    {
      1,
      0,
      0,
      0
    });
    this.label_5.AutoSize = true;
    this.label_5.Location = new Point(339, 157);
    this.label_5.Name = \u003CModule\u003E.smethod_5<string>(2749125829U);
    this.label_5.Size = new Size(104, 13);
    this.label_5.TabIndex = 28;
    this.label_5.Text = \u003CModule\u003E.smethod_7<string>(3866158093U);
    this.label_5.TextAlign = ContentAlignment.MiddleCenter;
    this.button_1.FlatStyle = FlatStyle.Flat;
    this.button_1.Font = new Font(\u003CModule\u003E.smethod_6<string>(4181633304U), 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.button_1.Location = new Point(659, 292);
    this.button_1.Name = \u003CModule\u003E.smethod_6<string>(4030586985U);
    this.button_1.Size = new Size(111, 40);
    this.button_1.TabIndex = 27;
    this.button_1.Text = \u003CModule\u003E.smethod_7<string>(2441752856U);
    this.button_1.UseVisualStyleBackColor = true;
    this.button_1.Click += new EventHandler(this.button_1_Click);
    this.listBox_0.BackColor = Color.White;
    this.listBox_0.ForeColor = Color.Black;
    this.listBox_0.FormattingEnabled = true;
    this.listBox_0.Location = new Point(327, 185);
    this.listBox_0.Name = \u003CModule\u003E.smethod_5<string>(376681354U);
    this.listBox_0.SelectionMode = SelectionMode.MultiExtended;
    this.listBox_0.Size = new Size(326, 147);
    this.listBox_0.TabIndex = 26;
    this.numericUpDown_7.Location = new Point(634, 121);
    this.numericUpDown_7.Maximum = new Decimal(new int[4]
    {
      2000,
      0,
      0,
      0
    });
    this.numericUpDown_7.Name = \u003CModule\u003E.smethod_7<string>(62573903U);
    this.numericUpDown_7.Size = new Size(46, 22);
    this.numericUpDown_7.TabIndex = 50;
    this.numericUpDown_7.Value = new Decimal(new int[4]
    {
      1500,
      0,
      0,
      0
    });
    this.numericUpDown_8.Location = new Point(638, 95);
    this.numericUpDown_8.Maximum = new Decimal(new int[4]
    {
      12,
      0,
      0,
      0
    });
    this.numericUpDown_8.Minimum = new Decimal(new int[4]
    {
      1,
      0,
      0,
      0
    });
    this.numericUpDown_8.Name = \u003CModule\u003E.smethod_7<string>(2469745352U);
    this.numericUpDown_8.Size = new Size(42, 22);
    this.numericUpDown_8.TabIndex = 49;
    this.numericUpDown_8.Value = new Decimal(new int[4]
    {
      10,
      0,
      0,
      0
    });
    this.numericUpDown_9.Location = new Point(637, 69);
    this.numericUpDown_9.Maximum = new Decimal(new int[4]
    {
      30,
      0,
      0,
      0
    });
    this.numericUpDown_9.Name = \u003CModule\u003E.smethod_9<string>(909790425U);
    this.numericUpDown_9.Size = new Size(43, 22);
    this.numericUpDown_9.TabIndex = 48;
    this.numericUpDown_9.Value = new Decimal(new int[4]
    {
      8,
      0,
      0,
      0
    });
    this.numericUpDown_10.Location = new Point(707, 95);
    this.numericUpDown_10.Maximum = new Decimal(new int[4]
    {
      12,
      0,
      0,
      0
    });
    this.numericUpDown_10.Minimum = new Decimal(new int[4]
    {
      1,
      0,
      0,
      0
    });
    this.numericUpDown_10.Name = \u003CModule\u003E.smethod_8<string>(2242482718U);
    this.numericUpDown_10.Size = new Size(42, 22);
    this.numericUpDown_10.TabIndex = 53;
    this.numericUpDown_10.Value = new Decimal(new int[4]
    {
      10,
      0,
      0,
      0
    });
    this.numericUpDown_11.Location = new Point(706, 69);
    this.numericUpDown_11.Maximum = new Decimal(new int[4]
    {
      30,
      0,
      0,
      0
    });
    this.numericUpDown_11.Name = \u003CModule\u003E.smethod_6<string>(4064434829U);
    this.numericUpDown_11.Size = new Size(43, 22);
    this.numericUpDown_11.TabIndex = 52;
    this.numericUpDown_11.Value = new Decimal(new int[4]
    {
      10,
      0,
      0,
      0
    });
    this.label_8.AutoSize = true;
    this.label_8.Font = new Font(\u003CModule\u003E.smethod_9<string>(546047130U), 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.label_8.ForeColor = Color.Red;
    this.label_8.Location = new Point(30, 9);
    this.label_8.Name = \u003CModule\u003E.smethod_8<string>(3231437112U);
    this.label_8.Size = new Size(719, 32);
    this.label_8.TabIndex = 56;
    this.label_8.Text = \u003CModule\u003E.smethod_6<string>(1425986565U);
    this.label_8.TextAlign = ContentAlignment.MiddleCenter;
    this.checkBox_3.AutoSize = true;
    this.checkBox_3.Checked = true;
    this.checkBox_3.CheckState = CheckState.Checked;
    this.checkBox_3.Location = new Point(503, 45);
    this.checkBox_3.Name = \u003CModule\u003E.smethod_6<string>(1118647133U);
    this.checkBox_3.Size = new Size(39, 17);
    this.checkBox_3.TabIndex = 129;
    this.checkBox_3.Text = \u003CModule\u003E.smethod_8<string>(2830900801U);
    this.checkBox_3.UseVisualStyleBackColor = true;
    this.checkBox_2.AutoSize = true;
    this.checkBox_2.Checked = true;
    this.checkBox_2.CheckState = CheckState.Checked;
    this.checkBox_2.Location = new Point(572, 45);
    this.checkBox_2.Name = \u003CModule\u003E.smethod_9<string>(3794183705U);
    this.checkBox_2.Size = new Size(39, 17);
    this.checkBox_2.TabIndex = 130;
    this.checkBox_2.Text = \u003CModule\u003E.smethod_7<string>(246039553U);
    this.checkBox_2.UseVisualStyleBackColor = true;
    this.checkBox_1.AutoSize = true;
    this.checkBox_1.Location = new Point(641, 45);
    this.checkBox_1.Name = \u003CModule\u003E.smethod_5<string>(1592184433U);
    this.checkBox_1.Size = new Size(39, 17);
    this.checkBox_1.TabIndex = 131;
    this.checkBox_1.Text = \u003CModule\u003E.smethod_7<string>(933370131U);
    this.checkBox_1.UseVisualStyleBackColor = true;
    this.checkBox_0.AutoSize = true;
    this.checkBox_0.Checked = true;
    this.checkBox_0.CheckState = CheckState.Checked;
    this.checkBox_0.Location = new Point(710, 45);
    this.checkBox_0.Name = \u003CModule\u003E.smethod_9<string>(890944341U);
    this.checkBox_0.Size = new Size(39, 17);
    this.checkBox_0.TabIndex = 132;
    this.checkBox_0.Text = \u003CModule\u003E.smethod_8<string>(1523622435U);
    this.checkBox_0.UseVisualStyleBackColor = true;
    this.button_2.FlatStyle = FlatStyle.Flat;
    this.button_2.Font = new Font(\u003CModule\u003E.smethod_8<string>(2058547965U), 18f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.button_2.Location = new Point(26, 281);
    this.button_2.Name = \u003CModule\u003E.smethod_9<string>(4068089375U);
    this.button_2.Size = new Size(270, 51);
    this.button_2.TabIndex = 133;
    this.button_2.Text = \u003CModule\u003E.smethod_8<string>(936520025U);
    this.button_2.UseVisualStyleBackColor = true;
    this.button_2.Click += new EventHandler(this.button_2_Click);
    this.button_5.FlatStyle = FlatStyle.Flat;
    this.button_5.Location = new Point(211, 205);
    this.button_5.Name = \u003CModule\u003E.smethod_8<string>(2963974347U);
    this.button_5.Size = new Size(52, 23);
    this.button_5.TabIndex = 138;
    this.button_5.Text = \u003CModule\u003E.smethod_8<string>(2723915695U);
    this.button_5.UseVisualStyleBackColor = true;
    this.button_5.Click += new EventHandler(this.button_5_Click);
    this.textBox_0.Font = new Font(\u003CModule\u003E.smethod_9<string>(868744759U), 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.textBox_0.Location = new Point(64, 238);
    this.textBox_0.Name = \u003CModule\u003E.smethod_9<string>(3254118658U);
    this.textBox_0.Size = new Size(141, 23);
    this.textBox_0.TabIndex = 137;
    this.listBox_1.BackColor = Color.White;
    this.listBox_1.ForeColor = Color.Black;
    this.listBox_1.FormattingEnabled = true;
    this.listBox_1.Location = new Point(64, 55);
    this.listBox_1.Name = \u003CModule\u003E.smethod_5<string>(2723892429U);
    this.listBox_1.Size = new Size(141, 173);
    this.listBox_1.TabIndex = 136;
    this.listBox_1.SelectedIndexChanged += new EventHandler(this.listBox_1_SelectedIndexChanged);
    this.button_4.FlatStyle = FlatStyle.Flat;
    this.button_4.Location = new Point(211, 176);
    this.button_4.Name = \u003CModule\u003E.smethod_5<string>(544271520U);
    this.button_4.Size = new Size(52, 23);
    this.button_4.TabIndex = 135;
    this.button_4.Text = \u003CModule\u003E.smethod_6<string>(2467826733U);
    this.button_4.UseVisualStyleBackColor = true;
    this.button_4.Click += new EventHandler(this.button_4_Click);
    this.button_3.FlatStyle = FlatStyle.Flat;
    this.button_3.Location = new Point(211, 238);
    this.button_3.Name = \u003CModule\u003E.smethod_7<string>(1962851572U);
    this.button_3.Size = new Size(52, 23);
    this.button_3.TabIndex = 134;
    this.button_3.Text = \u003CModule\u003E.smethod_9<string>(1209249175U);
    this.button_3.UseVisualStyleBackColor = true;
    this.button_3.Click += new EventHandler(this.button_3_Click);
    this.label_6.AutoSize = true;
    this.label_6.Location = new Point(638, 157);
    this.label_6.Name = \u003CModule\u003E.smethod_9<string>(2087504437U);
    this.label_6.Size = new Size(114, 13);
    this.label_6.TabIndex = 47;
    this.label_6.Text = \u003CModule\u003E.smethod_8<string>(402910168U);
    this.label_6.TextAlign = ContentAlignment.MiddleCenter;
    this.label_7.AutoSize = true;
    this.label_7.Location = new Point(649, 144);
    this.label_7.Name = \u003CModule\u003E.smethod_8<string>(2190305838U);
    this.label_7.Size = new Size(94, 13);
    this.label_7.TabIndex = 46;
    this.label_7.Text = \u003CModule\u003E.smethod_5<string>(3919874947U);
    this.label_7.TextAlign = ContentAlignment.MiddleCenter;
    this.button_6.FlatStyle = FlatStyle.Flat;
    this.button_6.Location = new Point(211, 147);
    this.button_6.Name = \u003CModule\u003E.smethod_6<string>(3970676049U);
    this.button_6.Size = new Size(52, 23);
    this.button_6.TabIndex = 140;
    this.button_6.Text = \u003CModule\u003E.smethod_9<string>(2646415568U);
    this.button_6.UseVisualStyleBackColor = true;
    this.button_6.Click += new EventHandler(this.button_6_Click);
    this.button_7.FlatStyle = FlatStyle.Flat;
    this.button_7.Font = new Font(\u003CModule\u003E.smethod_5<string>(3528514976U), 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.button_7.Location = new Point(659, 231);
    this.button_7.Name = \u003CModule\u003E.smethod_5<string>(1675979516U);
    this.button_7.Size = new Size(111, 25);
    this.button_7.TabIndex = 141;
    this.button_7.Text = \u003CModule\u003E.smethod_7<string>(159216420U);
    this.button_7.UseVisualStyleBackColor = true;
    this.button_7.Click += new EventHandler(this.button_7_Click);
    this.button_8.FlatStyle = FlatStyle.Flat;
    this.button_8.Font = new Font(\u003CModule\u003E.smethod_6<string>(4181633304U), 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.button_8.Location = new Point(659, 261);
    this.button_8.Name = \u003CModule\u003E.smethod_8<string>(435576973U);
    this.button_8.Size = new Size(111, 25);
    this.button_8.TabIndex = 142;
    this.button_8.Text = \u003CModule\u003E.smethod_8<string>(195518321U);
    this.button_8.UseVisualStyleBackColor = true;
    this.button_8.Click += new EventHandler(this.button_8_Click);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.BackColor = Color.White;
    this.ClientSize = new Size(782, 344);
    this.ControlBox = false;
    this.Controls.Add((Control) this.button_8);
    this.Controls.Add((Control) this.button_7);
    this.Controls.Add((Control) this.button_6);
    this.Controls.Add((Control) this.button_5);
    this.Controls.Add((Control) this.textBox_0);
    this.Controls.Add((Control) this.listBox_1);
    this.Controls.Add((Control) this.button_4);
    this.Controls.Add((Control) this.button_3);
    this.Controls.Add((Control) this.button_2);
    this.Controls.Add((Control) this.checkBox_0);
    this.Controls.Add((Control) this.checkBox_1);
    this.Controls.Add((Control) this.checkBox_2);
    this.Controls.Add((Control) this.checkBox_3);
    this.Controls.Add((Control) this.label_8);
    this.Controls.Add((Control) this.numericUpDown_10);
    this.Controls.Add((Control) this.numericUpDown_11);
    this.Controls.Add((Control) this.numericUpDown_7);
    this.Controls.Add((Control) this.numericUpDown_8);
    this.Controls.Add((Control) this.numericUpDown_9);
    this.Controls.Add((Control) this.label_6);
    this.Controls.Add((Control) this.label_7);
    this.Controls.Add((Control) this.button_0);
    this.Controls.Add((Control) this.label_0);
    this.Controls.Add((Control) this.numericUpDown_0);
    this.Controls.Add((Control) this.numericUpDown_1);
    this.Controls.Add((Control) this.numericUpDown_2);
    this.Controls.Add((Control) this.label_1);
    this.Controls.Add((Control) this.label_2);
    this.Controls.Add((Control) this.label_3);
    this.Controls.Add((Control) this.numericUpDown_3);
    this.Controls.Add((Control) this.numericUpDown_4);
    this.Controls.Add((Control) this.numericUpDown_5);
    this.Controls.Add((Control) this.label_4);
    this.Controls.Add((Control) this.numericUpDown_6);
    this.Controls.Add((Control) this.label_5);
    this.Controls.Add((Control) this.button_1);
    this.Controls.Add((Control) this.listBox_0);
    this.Font = new Font(\u003CModule\u003E.smethod_6<string>(2348004861U), 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.ForeColor = Color.Black;
    this.FormBorderStyle = FormBorderStyle.FixedToolWindow;
    this.Icon = (Icon) componentResourceManager.GetObject(\u003CModule\u003E.smethod_6<string>(3848230780U));
    this.Name = \u003CModule\u003E.smethod_5<string>(1080370301U);
    this.Text = \u003CModule\u003E.smethod_5<string>(516656076U);
    this.numericUpDown_0.EndInit();
    this.numericUpDown_1.EndInit();
    this.numericUpDown_2.EndInit();
    this.numericUpDown_3.EndInit();
    this.numericUpDown_4.EndInit();
    this.numericUpDown_5.EndInit();
    this.numericUpDown_6.EndInit();
    this.numericUpDown_7.EndInit();
    this.numericUpDown_8.EndInit();
    this.numericUpDown_9.EndInit();
    this.numericUpDown_10.EndInit();
    this.numericUpDown_11.EndInit();
    this.ResumeLayout(false);
    this.PerformLayout();
  }

  private void button_1_Click([In] object obj0, [In] EventArgs obj1)
  {
    if (!Monitor.TryEnter(Class112.object_0, 1000))
      return;
    try
    {
      this.listBox_0.Items.Add((object) (\u003CModule\u003E.smethod_5<string>(353829998U) + this.class29_0.Struct16_0.short_0.ToString() + \u003CModule\u003E.smethod_9<string>(3671282314U) + this.class29_0.Struct16_0.short_1.ToString() + \u003CModule\u003E.smethod_8<string>(2649597394U) + this.class29_0.class88_0.String_0 + \u003CModule\u003E.smethod_8<string>(382084420U) + this.class29_0.class88_0.Int16_0.ToString()));
      this.class29_0.Class26_0.list_15.Add(this.class29_0.Struct17_0);
    }
    finally
    {
      Monitor.Exit(Class112.object_0);
    }
  }

  private void button_0_Click([In] object obj0, [In] EventArgs obj1)
  {
    if (this.listBox_0.SelectedItems.Count <= 0)
      return;
    foreach (string input in this.listBox_0.SelectedItems.Cast<string>().ToList<string>())
    {
      Match match = Regex.Match(input, \u003CModule\u003E.smethod_7<string>(2868064414U));
      this.class29_0.Class26_0.list_15.Remove(new Struct17(short.Parse(match.Groups[4].ToString()), new Struct16(short.Parse(match.Groups[1].ToString()), short.Parse(match.Groups[2].ToString()))));
      this.listBox_0.Items.Remove((object) input);
    }
  }

  private void listBox_1_SelectedIndexChanged(object byte_0, EventArgs value) => this.textBox_0.Text = this.listBox_1.SelectedItem.ToString();

  internal void button_4_Click(object string_0, [In] EventArgs obj1)
  {
    if (!Monitor.TryEnter(Class112.object_0, 2000))
      return;
    try
    {
      this.class29_0.Control2_0.method_2();
      this.class29_0.Control2_0.bool_1 = true;
      string str = AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_5<string>(3665158903U);
      if (this.listBox_1.SelectedItem != null && !string.IsNullOrEmpty(this.listBox_1.SelectedItem.ToString()) && File.Exists(str + this.listBox_1.SelectedItem?.ToString()))
      {
        List<string> list = ((IEnumerable<string>) File.ReadAllLines(str + this.listBox_1.SelectedItem?.ToString())).ToList<string>();
        Match match1 = Regex.Match(list[0], \u003CModule\u003E.smethod_7<string>(2510402877U));
        this.checkBox_3.Checked = Convert.ToBoolean(match1.Groups[1].Value);
        this.checkBox_2.Checked = Convert.ToBoolean(match1.Groups[2].Value);
        this.checkBox_1.Checked = Convert.ToBoolean(match1.Groups[3].Value);
        this.checkBox_0.Checked = Convert.ToBoolean(match1.Groups[4].Value);
        this.numericUpDown_5.Value = Convert.ToDecimal(match1.Groups[5].Value);
        this.numericUpDown_2.Value = Convert.ToDecimal(match1.Groups[6].Value);
        this.numericUpDown_9.Value = Convert.ToDecimal(match1.Groups[7].Value);
        this.numericUpDown_11.Value = Convert.ToDecimal(match1.Groups[8].Value);
        this.numericUpDown_4.Value = Convert.ToDecimal(match1.Groups[9].Value);
        this.numericUpDown_1.Value = Convert.ToDecimal(match1.Groups[10].Value);
        this.numericUpDown_8.Value = Convert.ToDecimal(match1.Groups[11].Value);
        this.numericUpDown_10.Value = Convert.ToDecimal(match1.Groups[12].Value);
        this.numericUpDown_3.Value = Convert.ToDecimal(match1.Groups[13].Value);
        this.numericUpDown_0.Value = Convert.ToDecimal(match1.Groups[14].Value);
        this.numericUpDown_7.Value = Convert.ToDecimal(match1.Groups[15].Value);
        this.numericUpDown_6.Value = Convert.ToDecimal(match1.Groups[17].Value);
        this.listBox_0.Items.Clear();
        this.class29_0.Class26_0.list_15.Clear();
        for (int index = 1; index < list.Count; ++index)
        {
          this.listBox_0.Items.Add((object) list[index]);
          Match match2 = Regex.Match(list[index], \u003CModule\u003E.smethod_5<string>(3131442166U));
          this.class29_0.Class26_0.list_15.Add(new Struct17(short.Parse(match2.Groups[4].Value), short.Parse(match2.Groups[1].Value), short.Parse(match2.Groups[2].Value)));
        }
      }
      this.class29_0.Control2_0.bool_1 = false;
      if (!(this.class29_0.Control2_0.toolStripMenuItem_2.Text == \u003CModule\u003E.smethod_5<string>(3838461908U)))
        return;
      this.class29_0.Class25_0.method_0();
    }
    finally
    {
      Monitor.Exit(Class112.object_0);
    }
  }

  private void button_3_Click(object string_0, [In] EventArgs obj1)
  {
    if (string.IsNullOrEmpty(this.textBox_0.Text))
      return;
    if (Regex.Match(this.textBox_0.Text, \u003CModule\u003E.smethod_5<string>(2385381302U)).Success)
    {
      int num = (int) Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_8<string>(2489119735U), (IWin32Window) this, true);
    }
    else
    {
      string path = AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_7<string>(1008261063U);
      if (!Directory.Exists(path))
        Directory.CreateDirectory(path);
      List<string> stringList1 = new List<string>();
      List<string> stringList2 = stringList1;
      string[] strArray = new string[33];
      strArray[0] = this.checkBox_3.Checked.ToString();
      strArray[1] = \u003CModule\u003E.smethod_8<string>(1421900021U);
      strArray[2] = this.checkBox_2.Checked.ToString();
      strArray[3] = \u003CModule\u003E.smethod_9<string>(366607487U);
      bool flag = this.checkBox_1.Checked;
      strArray[4] = flag.ToString();
      strArray[5] = \u003CModule\u003E.smethod_7<string>(2075004763U);
      flag = this.checkBox_0.Checked;
      strArray[6] = flag.ToString();
      strArray[7] = \u003CModule\u003E.smethod_6<string>(899990565U);
      strArray[8] = this.numericUpDown_5.Value.ToString();
      strArray[9] = \u003CModule\u003E.smethod_6<string>(899990565U);
      strArray[10] = this.numericUpDown_2.Value.ToString();
      strArray[11] = \u003CModule\u003E.smethod_6<string>(899990565U);
      strArray[12] = this.numericUpDown_9.Value.ToString();
      strArray[13] = \u003CModule\u003E.smethod_5<string>(2854823517U);
      strArray[14] = this.numericUpDown_11.Value.ToString();
      strArray[15] = \u003CModule\u003E.smethod_7<string>(2075004763U);
      strArray[16] = this.numericUpDown_4.Value.ToString();
      strArray[17] = \u003CModule\u003E.smethod_6<string>(899990565U);
      strArray[18] = this.numericUpDown_1.Value.ToString();
      strArray[19] = \u003CModule\u003E.smethod_6<string>(899990565U);
      strArray[20] = this.numericUpDown_8.Value.ToString();
      strArray[21] = \u003CModule\u003E.smethod_9<string>(366607487U);
      strArray[22] = this.numericUpDown_10.Value.ToString();
      strArray[23] = \u003CModule\u003E.smethod_9<string>(366607487U);
      strArray[24] = this.numericUpDown_3.Value.ToString();
      strArray[25] = \u003CModule\u003E.smethod_6<string>(899990565U);
      strArray[26] = this.numericUpDown_0.Value.ToString();
      strArray[27] = \u003CModule\u003E.smethod_7<string>(2075004763U);
      strArray[28] = this.numericUpDown_7.Value.ToString();
      strArray[29] = \u003CModule\u003E.smethod_7<string>(2075004763U);
      strArray[30] = 0.ToString();
      strArray[31] = \u003CModule\u003E.smethod_6<string>(899990565U);
      strArray[32] = this.numericUpDown_6.Value.ToString();
      string str = string.Concat(strArray);
      stringList2.Add(str);
      List<string> contents = stringList1;
      foreach (object obj in this.listBox_0.Items)
        contents.Add(obj.ToString());
      File.WriteAllLines(path + \u003CModule\u003E.smethod_5<string>(1401742911U) + this.textBox_0.Text, (IEnumerable<string>) contents);
      if (this.listBox_1.Items.Contains((object) this.textBox_0.Text))
        return;
      this.class29_0.Control2_0.bindingList_0.Add(this.textBox_0.Text);
    }
  }

  private void button_5_Click([In] object obj0, EventArgs bool_0 = true)
  {
    try
    {
      string path = string.Format(\u003CModule\u003E.smethod_9<string>(1229370163U), (object) AppDomain.CurrentDomain.BaseDirectory, this.listBox_1.SelectedItem);
      if (File.Exists(path))
        File.Delete(path);
      this.class29_0.Control2_0.bindingList_0.Remove(path);
    }
    catch
    {
    }
  }

  private void button_2_Click(object class76_0, [In] EventArgs obj1) => this.Hide();

  private void button_6_Click(object string_1, EventArgs form5_1)
  {
    this.class29_0.Class26_0.list_15.Clear();
    this.listBox_0.Items.Clear();
  }

  private void button_7_Click(object sender, EventArgs e)
  {
    lock (this.object_0)
    {
      int topIndex = this.listBox_0.TopIndex;
      List<string> list1 = this.listBox_0.Items.Cast<string>().ToList<string>();
      List<string> list2 = this.listBox_0.SelectedItems.Cast<string>().ToList<string>();
      List<Struct17> list15 = this.class29_0.Class26_0.list_15;
      for (int index1 = 0; index1 < list2.Count; ++index1)
      {
        if (list2[index1] != list1[index1])
        {
          int index2 = list1.IndexOf(list2[index1]);
          string str = list1[index2 - 1];
          list1[index2 - 1] = list1[index2];
          list1[index2] = str;
          Struct17 struct17 = list15[index2 - 1];
          list15[index2 - 1] = list15[index2];
          list15[index2] = struct17;
        }
      }
      this.listBox_0.Items.Clear();
      this.listBox_0.Items.AddRange((object[]) list1.ToArray());
      this.listBox_0.SelectedItems.Clear();
      foreach (object obj in list2)
        this.listBox_0.SelectedItems.Add(obj);
      this.listBox_0.TopIndex = topIndex;
    }
  }

  private void button_8_Click(object disposing, [In] EventArgs obj1)
  {
    lock (this.object_0)
    {
      int topIndex = this.listBox_0.TopIndex;
      List<string> list1 = this.listBox_0.Items.Cast<string>().Reverse<string>().ToList<string>();
      List<string> list2 = this.listBox_0.SelectedItems.Cast<string>().Reverse<string>().ToList<string>();
      List<Struct17> list15 = this.class29_0.Class26_0.list_15;
      this.class29_0.Class26_0.list_15.Reverse();
      for (int index1 = 0; index1 < list2.Count; ++index1)
      {
        if (list2[index1] != list1[index1])
        {
          int index2 = list1.IndexOf(list2[index1]);
          string str = list1[index2 - 1];
          list1[index2 - 1] = list1[index2];
          list1[index2] = str;
          Struct17 struct17 = list15[index2 - 1];
          list15[index2 - 1] = list15[index2];
          list15[index2] = struct17;
        }
      }
      list1.Reverse();
      list2.Reverse();
      list15.Reverse();
      this.listBox_0.Items.Clear();
      this.listBox_0.Items.AddRange((object[]) list1.ToArray());
      this.listBox_0.SelectedItems.Clear();
      foreach (object obj in list2)
        this.listBox_0.SelectedItems.Add(obj);
      this.listBox_0.TopIndex = topIndex;
    }
  }
}
