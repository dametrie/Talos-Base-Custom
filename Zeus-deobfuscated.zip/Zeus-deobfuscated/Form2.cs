﻿// Decompiled with JetBrains decompiler
// Type: Form2
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

internal class Form2 : Form
{
  private Class29 class29_0;
  private IContainer icontainer_0;
  internal MenuStrip menuStrip_0;
  private ToolStripMenuItem toolStripMenuItem_0;
  internal Label label_0;
  private Label label_1;

  internal Form2() => this.method_2();

  internal void method_0([In] Class29 obj0, [In] Rectangle obj1)
  {
    if (this.class29_0 != null)
    {
      Class11.DwmUnregisterThumbnail(this.class29_0.intptr_1);
      Class11.DwmUpdateThumbnailProperties(this.class29_0.intptr_1, ref this.class29_0.struct8_0);
      this.class29_0.bool_45 = false;
    }
    this.class29_0 = obj0;
    this.label_1.Text = this.class29_0.string_3;
    this.Name = this.class29_0.string_3;
    this.Location = this.class29_0.Class112_0.form5_0.PointToScreen(new Point(obj1.Left - this.Width, obj1.Bottom - this.Height / 2));
    if (Class11.DwmRegisterThumbnail(this.Handle, this.class29_0.intptr_0, ref this.class29_0.intptr_1) != 0)
    {
      this.label_0.Visible = true;
    }
    else
    {
      this.label_0.Visible = false;
      this.class29_0.struct8_0 = new Class16.Struct8()
      {
        bool_1 = true,
        int_0 = Class11.int_0 | Class11.int_2 | Class11.int_1,
        byte_0 = byte.MaxValue,
        struct9_0 = new Class16.Struct9(0, 24, 205, 188)
      };
      Class11.DwmUpdateThumbnailProperties(this.class29_0.intptr_1, ref this.class29_0.struct8_0);
      this.class29_0.bool_45 = true;
      if (this.Visible)
        return;
      this.Show();
    }
  }

  private void toolStripMenuItem_0_Click([In] object obj0, [In] EventArgs obj1)
  {
    this.class29_0.method_6(false);
    Process.GetProcessById(this.class29_0.int_4).Kill();
    this.method_1();
  }

  private void Form2_Click([In] object obj0, [In] EventArgs obj1)
  {
    Class137.SetForegroundWindow((int) this.class29_0.intptr_0);
    Class137.ShowWindow(this.class29_0.intptr_0, 1U);
    this.method_1();
  }

  private void label_1_Click(object value, [In] EventArgs obj1) => this.Form2_Click(value, obj1);

  private void menuStrip_0_Click(object value, [In] EventArgs obj1)
  {
    if (this.toolStripMenuItem_0.Bounds.Contains(this.PointToClient(Cursor.Position)))
      return;
    this.Form2_Click(value, obj1);
  }

  internal void Form2_MouseLeave(object value, [In] EventArgs obj1)
  {
    if (Cursor.Position.X > this.Left && Cursor.Position.Y < this.Bottom && Cursor.Position.Y > this.Top)
      return;
    this.method_1();
  }

  private void menuStrip_0_MouseLeave(object value, [In] EventArgs obj1) => this.Form2_MouseLeave(value, obj1);

  internal void method_1()
  {
    if (this.class29_0 == null)
      return;
    Class11.DwmUnregisterThumbnail(this.class29_0.intptr_1);
    Class11.DwmUpdateThumbnailProperties(this.class29_0.intptr_1, ref this.class29_0.struct8_0);
    this.class29_0.bool_45 = false;
    this.Hide();
  }

  void Form.Dispose(bool value)
  {
    if (value && this.icontainer_0 != null)
      this.icontainer_0.Dispose();
    // ISSUE: explicit non-virtual call
    __nonvirtual (((Form) this).Dispose(value));
  }

  private void method_2()
  {
    this.menuStrip_0 = new MenuStrip();
    this.toolStripMenuItem_0 = new ToolStripMenuItem();
    this.label_0 = new Label();
    this.label_1 = new Label();
    this.menuStrip_0.SuspendLayout();
    this.SuspendLayout();
    this.menuStrip_0.BackColor = Color.FromArgb(64, 64, 64);
    this.menuStrip_0.Items.AddRange(new ToolStripItem[1]
    {
      (ToolStripItem) this.toolStripMenuItem_0
    });
    this.menuStrip_0.Location = new Point(0, 0);
    this.menuStrip_0.Name = \u003CModule\u003E.smethod_6<string>(454465482U);
    this.menuStrip_0.RenderMode = ToolStripRenderMode.Professional;
    this.menuStrip_0.Size = new Size(205, 24);
    this.menuStrip_0.TabIndex = 0;
    this.menuStrip_0.Text = \u003CModule\u003E.smethod_9<string>(2702953820U);
    this.menuStrip_0.Click += new EventHandler(this.menuStrip_0_Click);
    this.menuStrip_0.MouseLeave += new EventHandler(this.menuStrip_0_MouseLeave);
    this.toolStripMenuItem_0.Alignment = ToolStripItemAlignment.Right;
    this.toolStripMenuItem_0.Font = new Font(\u003CModule\u003E.smethod_9<string>(868744759U), 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.toolStripMenuItem_0.ForeColor = Color.Red;
    this.toolStripMenuItem_0.ImageAlign = ContentAlignment.MiddleRight;
    this.toolStripMenuItem_0.Name = \u003CModule\u003E.smethod_5<string>(3592789498U);
    this.toolStripMenuItem_0.RightToLeft = RightToLeft.No;
    this.toolStripMenuItem_0.Size = new Size(32, 20);
    this.toolStripMenuItem_0.Text = \u003CModule\u003E.smethod_8<string>(3046186686U);
    this.toolStripMenuItem_0.Click += new EventHandler(this.toolStripMenuItem_0_Click);
    this.label_0.AutoSize = true;
    this.label_0.Font = new Font(\u003CModule\u003E.smethod_5<string>(3528514976U), 20.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.label_0.Location = new Point(21, 73);
    this.label_0.Name = \u003CModule\u003E.smethod_5<string>(3464240454U);
    this.label_0.Size = new Size(162, 62);
    this.label_0.TabIndex = 1;
    this.label_0.Text = \u003CModule\u003E.smethod_7<string>(4006120573U);
    this.label_0.TextAlign = ContentAlignment.MiddleCenter;
    this.label_0.Visible = false;
    this.label_0.Click += new EventHandler(this.Form2_Click);
    this.label_1.AutoSize = true;
    this.label_1.BackColor = Color.FromArgb(64, 64, 64);
    this.label_1.Font = new Font(\u003CModule\u003E.smethod_9<string>(546047130U), 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.label_1.Location = new Point(3, 6);
    this.label_1.Name = \u003CModule\u003E.smethod_7<string>(286513871U);
    this.label_1.Size = new Size(39, 13);
    this.label_1.TabIndex = 2;
    this.label_1.Text = \u003CModule\u003E.smethod_5<string>(1156070501U);
    this.label_1.Click += new EventHandler(this.label_1_Click);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.AutoSize = true;
    this.BackColor = Color.Black;
    this.ClientSize = new Size(205, 188);
    this.ControlBox = false;
    this.Controls.Add((Control) this.label_1);
    this.Controls.Add((Control) this.label_0);
    this.Controls.Add((Control) this.menuStrip_0);
    this.DoubleBuffered = true;
    this.ForeColor = Color.White;
    this.FormBorderStyle = FormBorderStyle.None;
    this.Margin = new Padding(0);
    this.MaximizeBox = false;
    this.MinimizeBox = false;
    this.Name = \u003CModule\u003E.smethod_5<string>(3997957191U);
    this.Opacity = 0.85;
    this.ShowIcon = false;
    this.ShowInTaskbar = false;
    this.SizeGripStyle = SizeGripStyle.Hide;
    this.StartPosition = FormStartPosition.Manual;
    this.TopMost = true;
    this.Click += new EventHandler(this.Form2_Click);
    this.MouseLeave += new EventHandler(this.Form2_MouseLeave);
    this.menuStrip_0.ResumeLayout(false);
    this.menuStrip_0.PerformLayout();
    this.ResumeLayout(false);
    this.PerformLayout();
  }
}
