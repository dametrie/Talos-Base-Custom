﻿// Decompiled with JetBrains decompiler
// Type: Class137
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Runtime.InteropServices;
using System.Text;

internal static class Class137
{
  internal const int int_0 = -16;
  internal const uint uint_0 = 268435456;
  internal const int int_1 = 3;

  [DllImport("user32.dll")]
  internal static extern int SetWindowText([In] IntPtr obj0, [In] string obj1);

  [DllImport("user32.dll")]
  internal static extern bool PostMessage([In] IntPtr obj0, int stringBuilder_0, int int_2, [In] int obj3);

  [DllImport("user32.dll")]
  internal static extern int MapVirtualKey(int int_2, [In] int obj1);

  [DllImport("user32.dll")]
  internal static extern IntPtr GetWindowRect(IntPtr intptr_0, [In] ref Class16.Struct9 obj1);

  [DllImport("user32.dll")]
  internal static extern bool RegisterHotKey([In] IntPtr obj0, int uint_1, uint uint_2, uint uint_3);

  [DllImport("user32.dll")]
  internal static extern bool UnregisterHotKey(IntPtr int_0, int int_1);

  [DllImport("user32.dll")]
  internal static extern bool ShowWindowAsync(IntPtr struct19_0, int struct19_1);

  [DllImport("user32.dll")]
  internal static extern int SetWindowLong(IntPtr image_0, int int_0, int int_1);

  [DllImport("user32.dll", SetLastError = true)]
  internal static extern bool MoveWindow(
    IntPtr string_0,
    int string_1,
    [In] int obj2,
    [In] int obj3,
    [In] int obj4,
    [In] bool obj5);

  [DllImport("user32.dll", EntryPoint = "GetWindowRect")]
  internal static extern bool GetWindowRect_1(IntPtr value, [In] ref Struct5 obj1);

  [DllImport("user32.dll")]
  internal static extern bool GetClientRect(IntPtr value, [In] ref Struct5 obj1);

  [DllImport("user32.dll")]
  internal static extern int GetWindowLong([In] IntPtr obj0, int string_1);

  [DllImport("user32.dll")]
  internal static extern bool SetLayeredWindowAttributes(
    [In] IntPtr obj0,
    [In] uint obj1,
    [In] byte obj2,
    uint struct16_1);

  [DllImport("user32.dll", EntryPoint = "GetWindowRect")]
  internal static extern bool GetWindowRect_2(IntPtr int_1, ref Struct19 ushort_1);

  [DllImport("user32.dll")]
  internal static extern bool PrintWindow([In] IntPtr obj0, [In] IntPtr obj1, int struct16_1);

  [DllImport("user32.dll", SetLastError = true)]
  internal static extern IntPtr FindWindow(string value, [In] string obj1);

  [DllImport("user32.dll")]
  internal static extern bool RedrawWindow(IntPtr value, [In] IntPtr obj1, [In] IntPtr obj2, [In] uint obj3);

  [DllImport("user32.dll")]
  internal static extern bool IsWindowVisible(IntPtr value);

  [DllImport("user32.dll")]
  internal static extern bool ShowWindow(IntPtr value, [In] uint obj1);

  [DllImport("user32.dll")]
  internal static extern IntPtr SendMessage(
    IntPtr value,
    [In] uint obj1,
    [In] IntPtr obj2,
    [In] IntPtr obj3);

  [DllImport("user32.dll", EntryPoint = "PostMessage")]
  internal static extern IntPtr PostMessage_1(
    IntPtr value,
    uint string_3,
    [In] IntPtr obj2,
    [In] IntPtr obj3);

  [DllImport("user32.dll")]
  internal static extern uint MapVirtualKeyEx([In] uint obj0, [In] uint obj1, IntPtr ushort_2);

  [DllImport("user32.dll")]
  internal static extern IntPtr GetForegroundWindow();

  [DllImport("user32.dll")]
  internal static extern int GetWindowText([In] IntPtr obj0, [In] StringBuilder obj1, [In] int obj2);

  [DllImport("user32.dll")]
  internal static extern bool FlashWindowEx(ref Class16.Struct7 value);

  [DllImport("User32.dll")]
  internal static extern int SetForegroundWindow(int value);

  [DllImport("user32.dll")]
  internal static extern bool IsWindow(IntPtr value);

  internal static Class16.Struct7 smethod_0(IntPtr value, [In] uint obj1, [In] uint obj2, [In] uint obj3)
  {
    Class16.Struct7 struct7 = new Class16.Struct7();
    struct7.uint_0 = Convert.ToUInt32(Marshal.SizeOf<Class16.Struct7>(struct7));
    struct7.intptr_0 = value;
    struct7.uint_1 = obj1;
    struct7.uint_3 = obj2;
    struct7.uint_2 = obj3;
    return struct7;
  }
}
