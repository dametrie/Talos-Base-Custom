﻿// Decompiled with JetBrains decompiler
// Type: Control1
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using Accolade.Properties;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

internal class Control1 : UserControl
{
  private readonly Class29 class29_0;
  internal bool bool_0;
  internal Class142 class142_0;
  private Button button_0;
  private PictureBox pictureBox_0;
  private Label label_0;

  internal Control1(Class142 sender, Class29 e)
  {
    try
    {
      this.method_0();
      this.class142_0 = sender;
      this.class29_0 = e;
      string string_2 = string.Format(\u003CModule\u003E.smethod_9<string>(2496686193U), (object) sender.UInt16_0);
      GClass22 bool_0 = GClass22.smethod_0(Settings.Default.DarkAgesPath.Replace(\u003CModule\u003E.smethod_5<string>(197665510U), \u003CModule\u003E.smethod_8<string>(1871981866U)));
      if (!bool_0.method_0(string_2))
        return;
      GClass14 gclass14 = GClass14.smethod_2(string_2, bool_0);
      int num = gclass14.byte_5 == (byte) 0 || (int) gclass14.byte_0 == (int) gclass14.byte_4 ? (int) gclass14.byte_0 + (int) gclass14.byte_1 : (int) gclass14.byte_0 - (int) gclass14.byte_5;
      if (num < 0)
        num = 0;
      if (num >= gclass14.Int32_2)
        num = gclass14.Int32_2 - 1;
      GClass16 gclass16 = GClass16.smethod_2(gclass14.string_0, bool_0);
      Bitmap bitmap = GClass9.smethod_2(gclass14[num], gclass16);
      bitmap.RotateFlip(RotateFlipType.RotateNoneFlipX);
      this.pictureBox_0.SizeMode = bitmap.Width > 100 || bitmap.Height > 100 ? PictureBoxSizeMode.Zoom : PictureBoxSizeMode.CenterImage;
      this.pictureBox_0.Image = (Image) bitmap;
      this.label_0.Text = \u003CModule\u003E.smethod_5<string>(55772953U) + sender.UInt16_0.ToString();
      this.Name = sender.UInt16_0.ToString();
    }
    catch
    {
    }
  }

  private void method_0()
  {
    this.pictureBox_0 = new PictureBox();
    this.label_0 = new Label();
    this.button_0 = new Button();
    ((ISupportInitialize) this.pictureBox_0).BeginInit();
    this.SuspendLayout();
    this.pictureBox_0.Location = new Point(160, -1);
    this.pictureBox_0.Margin = new Padding(0);
    this.pictureBox_0.Name = \u003CModule\u003E.smethod_8<string>(932798026U);
    this.pictureBox_0.Size = new Size(106, 100);
    this.pictureBox_0.SizeMode = PictureBoxSizeMode.CenterImage;
    this.pictureBox_0.TabIndex = 6;
    this.pictureBox_0.TabStop = false;
    this.label_0.Font = new Font(\u003CModule\u003E.smethod_8<string>(2058547965U), 18f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.label_0.ForeColor = Color.Black;
    this.label_0.Location = new Point(14, 3);
    this.label_0.Name = \u003CModule\u003E.smethod_9<string>(859723562U);
    this.label_0.Size = new Size(124, 85);
    this.label_0.TabIndex = 8;
    this.label_0.Text = \u003CModule\u003E.smethod_8<string>(4214038161U);
    this.label_0.TextAlign = ContentAlignment.MiddleCenter;
    this.button_0.Font = new Font(\u003CModule\u003E.smethod_7<string>(1521212547U), 21.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.button_0.ForeColor = Color.Black;
    this.button_0.Location = new Point(-1, 91);
    this.button_0.Name = \u003CModule\u003E.smethod_5<string>(3495650902U);
    this.button_0.Size = new Size(267, 55);
    this.button_0.TabIndex = 9;
    this.button_0.Text = \u003CModule\u003E.smethod_9<string>(1546164486U);
    this.button_0.UseVisualStyleBackColor = true;
    this.button_0.MouseClick += new MouseEventHandler(this.button_0_MouseClick);
    this.AutoSizeMode = AutoSizeMode.GrowAndShrink;
    this.BorderStyle = BorderStyle.FixedSingle;
    this.Controls.Add((Control) this.button_0);
    this.Controls.Add((Control) this.label_0);
    this.Controls.Add((Control) this.pictureBox_0);
    this.Name = \u003CModule\u003E.smethod_7<string>(3294375972U);
    this.Size = new Size(265, 145);
    this.Load += new EventHandler(this.Control1_Load);
    ((ISupportInitialize) this.pictureBox_0).EndInit();
    this.ResumeLayout(false);
  }

  private void button_0_MouseClick(object sender, MouseEventArgs e)
  {
    ushort result;
    if (e.Button != MouseButtons.Left || !ushort.TryParse(this.Name, out result))
      return;
    this.class29_0.Control2_0.method_16(result);
  }

  private void Control1_Load(object sender, EventArgs e) => this.bool_0 = true;
}
