﻿// Decompiled with JetBrains decompiler
// Type: Class98
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;

internal abstract class Class98
{
  protected byte[] byte_0;
  protected byte byte_1;
  protected byte[] byte_2;
  protected int int_0;
  protected byte byte_3;
  protected byte byte_4;
  protected DateTime dateTime_0;

  internal byte Byte_0
  {
    get => this.byte_3;
    set => this.byte_3 = value;
  }

  internal int Int32_0
  {
    get => this.int_0;
    [param: In] set => this.int_0 = value;
  }

  internal byte Byte_1 => this.byte_4;

  internal byte Byte_2 => this.byte_1;

  internal byte[] Byte_3 => this.byte_0;

  internal byte[] Byte_4 => this.byte_2;

  internal DateTime DateTime_0 => this.dateTime_0;

  internal bool Boolean_0 => (uint) this.Class98\u002E⁫​‎‪‫⁫‏‫‌⁭‭⁭⁭‮‫‍‪‏⁬‪‮‪‌‌‌‫‮​⁯‏⁫⁫‮‫⁭‬⁮⁬​‌‮ > 0U;

  internal abstract Enum11 Class98\u002E⁫​‎‪‫⁫‏‫‌⁭‭⁭⁭‮‫‍‪‏⁬‪‮‪‌‌‌‫‮​⁯‏⁫⁫‮‫⁭‬⁮⁬​‌‮ { get; }

  internal Class98([In] byte obj0)
  {
    this.byte_4 = (byte) 170;
    this.byte_1 = obj0;
    this.byte_0 = new byte[0];
  }

  internal Class98(byte[] value)
  {
    this.byte_2 = value;
    this.byte_4 = value[0];
    this.byte_1 = value[3];
    this.byte_3 = value[4];
    this.dateTime_0 = DateTime.UtcNow;
    int length = value.Length - (this.Boolean_0 ? 5 : 4);
    this.byte_0 = new byte[length];
    Array.Copy((Array) value, value.Length - length, (Array) this.byte_0, 0, length);
  }

  internal abstract void Class98\u002E‪⁭‏⁬‏‎​⁪⁮‎‬‪‪‏⁭‬⁬‪‮‏‍‮⁮⁭‌‌‌⁪‍‍‎‮‌‬⁬‮‏‌‏‎‮(Class72 string_0);

  internal abstract void Class98\u002E‏‫‮​⁪‭‎⁬⁫‍⁪‌‍‏‏⁯⁯‭‫⁫‬‪‬‌‌‪⁯⁮‮⁭⁬‏⁬‮‭⁪‮‭‎⁭‮(Class72 disposing);

  internal void method_0()
  {
    this.int_0 = 0;
    this.byte_0 = new byte[0];
  }

  internal byte[] method_1(int value)
  {
    if (this.int_0 + value > this.byte_0.Length)
      throw new EndOfStreamException();
    byte[] destinationArray = new byte[value];
    Array.Copy((Array) this.byte_0, this.int_0, (Array) destinationArray, 0, value);
    this.int_0 += value;
    return destinationArray;
  }

  internal byte method_2()
  {
    if (this.int_0 >= this.byte_0.Length)
      throw new EndOfStreamException();
    return this.byte_0[this.int_0++];
  }

  internal sbyte method_3()
  {
    if (this.int_0 >= this.byte_0.Length)
      throw new EndOfStreamException();
    return (sbyte) this.byte_0[this.int_0++];
  }

  internal bool method_4()
  {
    if (this.int_0 >= this.byte_0.Length)
      throw new EndOfStreamException();
    return this.byte_0[this.int_0++] > (byte) 0;
  }

  internal short method_5()
  {
    byte[] numArray = this.method_1(2);
    return (short) ((int) numArray[0] << 8 | (int) numArray[1]);
  }

  internal ushort method_6()
  {
    byte[] numArray = this.method_1(2);
    return (ushort) ((uint) numArray[0] << 8 | (uint) numArray[1]);
  }

  internal int method_7()
  {
    byte[] numArray = this.method_1(4);
    return (int) numArray[0] << 24 | (int) numArray[1] << 16 | (int) numArray[2] << 8 | (int) numArray[3];
  }

  internal uint method_8()
  {
    byte[] numArray = this.method_1(4);
    return (uint) ((int) numArray[0] << 24 | (int) numArray[1] << 16 | (int) numArray[2] << 8) | (uint) numArray[3];
  }

  internal string method_9()
  {
    int num = this.byte_0.Length;
    for (int index = 0; index < this.byte_0.Length; ++index)
    {
      if (this.byte_0[index] == (byte) 0)
      {
        num = index;
        break;
      }
    }
    byte[] numArray = new byte[num - this.int_0];
    Buffer.BlockCopy((Array) this.byte_0, this.int_0, (Array) numArray, 0, numArray.Length);
    this.int_0 = num + 1;
    if (this.int_0 > this.byte_0.Length)
      this.int_0 = this.byte_0.Length;
    return Encoding.GetEncoding(949).GetString(numArray);
  }

  internal string method_10()
  {
    if (this.int_0 >= this.byte_0.Length)
      throw new EndOfStreamException();
    int num = (int) this.method_2();
    if (this.int_0 + num > this.byte_0.Length)
    {
      --this.int_0;
      throw new EndOfStreamException();
    }
    byte[] bytes = this.method_1(num);
    return Encoding.GetEncoding(949).GetString(bytes);
  }

  internal string method_11()
  {
    if (this.int_0 + 1 > this.byte_0.Length)
      throw new EndOfStreamException();
    int num = (int) this.method_6();
    if (this.int_0 + num > this.byte_0.Length)
    {
      this.int_0 -= 2;
      throw new EndOfStreamException();
    }
    byte[] bytes = this.method_1(num);
    return Encoding.GetEncoding(949).GetString(bytes);
  }

  internal Struct16 method_12()
  {
    if (this.int_0 + 4 > this.byte_0.Length)
      throw new EndOfStreamException();
    return new Struct16((short) this.method_6(), (short) this.method_6());
  }

  internal void method_13(byte[] value)
  {
    int newSize = this.int_0 + value.Length;
    if (newSize > this.byte_0.Length)
      Array.Resize<byte>(ref this.byte_0, newSize);
    Array.Copy((Array) value, 0, (Array) this.byte_0, this.int_0, value.Length);
    this.int_0 += value.Length;
  }

  internal void method_14(byte value) => this.method_13(new byte[1]
  {
    value
  });

  internal void method_15(sbyte sender) => this.method_13(new byte[1]
  {
    (byte) sender
  });

  internal void method_16([In] bool obj0) => this.method_14(obj0 ? (byte) 1 : (byte) 0);

  internal void method_17(short sender) => this.method_13(new byte[2]
  {
    (byte) ((uint) sender >> 8),
    (byte) sender
  });

  internal void method_18([In] ushort obj0) => this.method_13(new byte[2]
  {
    (byte) ((uint) obj0 >> 8),
    (byte) obj0
  });

  internal void method_19(int specialFolder_0) => this.method_13(new byte[4]
  {
    (byte) (specialFolder_0 >> 24),
    (byte) (specialFolder_0 >> 16),
    (byte) (specialFolder_0 >> 8),
    (byte) specialFolder_0
  });

  internal void method_20([In] uint obj0) => this.method_13(new byte[4]
  {
    (byte) (obj0 >> 24),
    (byte) (obj0 >> 16),
    (byte) (obj0 >> 8),
    (byte) obj0
  });

  internal void method_21([In] string obj0, [In] bool obj1)
  {
    this.method_13(Encoding.GetEncoding(949).GetBytes(obj0));
    if (!obj1)
      return;
    this.method_14((byte) 0);
  }

  internal void method_22([In] string obj0)
  {
    byte[] bytes = Encoding.GetEncoding(949).GetBytes(obj0);
    if (bytes.Length > (int) byte.MaxValue)
      throw new ArgumentOutOfRangeException(\u003CModule\u003E.smethod_9<string>(1060323490U), (object) obj0, \u003CModule\u003E.smethod_7<string>(319831243U));
    this.method_14((byte) bytes.Length);
    this.method_13(bytes);
  }

  internal void method_23(string object_0)
  {
    byte[] bytes = Encoding.GetEncoding(949).GetBytes(object_0);
    if (bytes.Length > (int) ushort.MaxValue)
      throw new ArgumentOutOfRangeException(\u003CModule\u003E.smethod_5<string>(2402540152U), (object) object_0, \u003CModule\u003E.smethod_8<string>(1916939768U));
    this.method_18((ushort) bytes.Length);
    this.method_13(bytes);
  }

  internal void method_24(Struct16 object_0)
  {
    this.method_17(object_0.short_0);
    this.method_17(object_0.short_1);
  }

  internal void method_25(Array class112_1)
  {
    foreach (object class112_1_1 in class112_1)
    {
      if (class112_1_1 is char)
        this.method_14((byte) class112_1_1);
      if (class112_1_1 is byte num1)
        this.method_14(num1);
      if (class112_1_1 is sbyte sender1)
        this.method_15(sender1);
      if (class112_1_1 is bool flag)
        this.method_16(flag);
      if (class112_1_1 is short sender2)
        this.method_17(sender2);
      if (class112_1_1 is ushort num2)
        this.method_18(num2);
      if (class112_1_1 is int specialFolder_0)
        this.method_19(specialFolder_0);
      if (class112_1_1 is uint num3)
        this.method_20(num3);
      if (class112_1_1 is string)
        this.method_22((string) class112_1_1);
      if (class112_1_1 is Struct16 object_0)
        this.method_24(object_0);
      if (class112_1_1 is Array)
        this.method_25((Array) class112_1_1);
    }
  }

  internal byte[] method_26()
  {
    int num = this.byte_0.Length + (this.Boolean_0 ? 5 : 4) - 3;
    byte[] destinationArray = new byte[num + 3];
    destinationArray[0] = this.byte_4;
    destinationArray[1] = (byte) (num / 256);
    destinationArray[2] = (byte) (num % 256);
    destinationArray[3] = this.byte_1;
    destinationArray[4] = this.byte_3;
    Array.Copy((Array) this.byte_0, 0, (Array) destinationArray, destinationArray.Length - this.byte_0.Length, this.byte_0.Length);
    return destinationArray;
  }

  internal string method_27()
  {
    byte[] destinationArray = new byte[this.byte_0.Length + 1];
    destinationArray[0] = this.byte_1;
    Array.Copy((Array) this.byte_0, 0, (Array) destinationArray, 1, this.byte_0.Length);
    return BitConverter.ToString(destinationArray).Replace('-', ' ');
  }

  internal string method_28([In] bool obj0)
  {
    char[] chArray = new char[this.byte_0.Length + 1];
    byte[] destinationArray = new byte[this.byte_0.Length + 1];
    destinationArray[0] = this.byte_1;
    Array.Copy((Array) this.byte_0, 0, (Array) destinationArray, 1, this.byte_0.Length);
    for (int index = 0; index < destinationArray.Length; ++index)
    {
      byte num = destinationArray[index];
      chArray[index] = num != (byte) 10 && num != (byte) 13 || obj0 ? (num < (byte) 32 || num > (byte) 126 ? '.' : (char) num) : (char) num;
    }
    return new string(chArray);
  }

  internal static byte[] smethod_0(string struct17_0, Class29 struct17_1, [In] ref byte obj2)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class98.Class101 class101 = new Class98.Class101();
    // ISSUE: reference to a compiler-generated field
    class101.class29_0 = struct17_1;
    Regex regex1 = new Regex(\u003CModule\u003E.smethod_8<string>(849720054U), RegexOptions.Compiled);
    Regex regex2 = new Regex(\u003CModule\u003E.smethod_9<string>(3648611518U), RegexOptions.Compiled);
    string input = struct17_0;
    // ISSUE: reference to a compiler-generated method
    MatchEvaluator evaluator = new MatchEvaluator(class101.method_0);
    struct17_0 = regex1.Replace(input, evaluator);
    struct17_0 = regex2.Replace(struct17_0, (MatchEvaluator) (class92_0 => string.Format(\u003CModule\u003E.smethod_5<string>(3771825675U), (object) (byte) int.Parse(class92_0.Groups[1].Value), (object) (byte) int.Parse(class92_0.Groups[2].Value))));
    struct17_0 = struct17_0.Replace(\u003CModule\u003E.smethod_5<string>(1777882200U), string.Empty);
    struct17_0 = struct17_0.Replace(\u003CModule\u003E.smethod_7<string>(2075004763U), string.Empty);
    if (struct17_0.Length >= 2 && struct17_0.Length % 2 == 0 && Regex.IsMatch(struct17_0, \u003CModule\u003E.smethod_7<string>(2975539890U), RegexOptions.IgnoreCase))
    {
      obj2 = byte.Parse(struct17_0.Substring(0, 2), NumberStyles.HexNumber);
      byte[] numArray = new byte[(struct17_0.Length - 2) / 2];
      for (int index = 0; index < numArray.Length; ++index)
      {
        int startIndex = 2 + index * 2;
        numArray[index] = byte.Parse(struct17_0.Substring(startIndex, 2), NumberStyles.HexNumber);
      }
      return numArray;
    }
    obj2 = (byte) 0;
    return (byte[]) null;
  }
}
