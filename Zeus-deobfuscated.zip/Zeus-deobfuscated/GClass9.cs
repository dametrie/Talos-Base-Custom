﻿// Decompiled with JetBrains decompiler
// Type: GClass9
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

public class GClass9
{
  public static Bitmap smethod_0(GClass19 value, [In] GClass16 obj1) => GClass9.smethod_4(value.Int32_1, value.Int32_0, value.Byte_1, obj1, GEnum0.HPF);

  public static Bitmap smethod_1(GClass11 ushort_3, GClass16 ushort_4) => GClass9.smethod_4(ushort_3.Int32_1, ushort_3.Int32_0, ushort_3.Byte_0, ushort_4, GEnum0.EPF);

  public static Bitmap smethod_2([In] GClass15 obj0, [In] GClass16 obj1) => GClass9.smethod_4(obj0.Int32_3, obj0.Int32_2, obj0.Byte_0, obj1, GEnum0.MPF);

  public static Bitmap smethod_3(byte[] int_3, GClass16 value) => GClass9.smethod_4(56, 27, int_3, value, GEnum0.Tile);

  private static unsafe Bitmap smethod_4(
    int value,
    [In] int obj1,
    [In] byte[] obj2,
    [In] GClass16 obj3,
    [In] GEnum0 obj4)
  {
    Bitmap bitmap = new Bitmap(value, obj1);
    BitmapData bitmapdata = bitmap.LockBits(new Rectangle(0, 0, bitmap.Width, bitmap.Height), ImageLockMode.WriteOnly, bitmap.PixelFormat);
    for (int index1 = 0; index1 < bitmapdata.Height; ++index1)
    {
      byte* numPtr1 = (byte*) ((int) (void*) bitmapdata.Scan0 + index1 * bitmapdata.Stride);
      for (int index2 = 0; index2 < bitmapdata.Width; ++index2)
      {
        int num1 = obj4 != GEnum0.EPF ? (int) obj2[index1 * value + index2] : (int) obj2[index2 * obj1 + index1];
        Color color;
        if (num1 > 0)
        {
          if (bitmapdata.PixelFormat == PixelFormat.Format32bppArgb)
          {
            byte* numPtr2 = numPtr1 + index2 * 4;
            color = obj3[num1];
            int b = (int) color.B;
            *numPtr2 = (byte) b;
            byte* numPtr3 = numPtr1 + (index2 * 4 + 1);
            color = obj3[num1];
            int g = (int) color.G;
            *numPtr3 = (byte) g;
            byte* numPtr4 = numPtr1 + (index2 * 4 + 2);
            color = obj3[num1];
            int r = (int) color.R;
            *numPtr4 = (byte) r;
            byte* numPtr5 = numPtr1 + (index2 * 4 + 3);
            color = obj3[num1];
            int a = (int) color.A;
            *numPtr5 = (byte) a;
          }
          else if (bitmapdata.PixelFormat == PixelFormat.Format24bppRgb)
          {
            byte* numPtr6 = numPtr1 + index2 * 3;
            color = obj3[num1];
            int b = (int) color.B;
            *numPtr6 = (byte) b;
            byte* numPtr7 = numPtr1 + (index2 * 3 + 1);
            color = obj3[num1];
            int g = (int) color.G;
            *numPtr7 = (byte) g;
            byte* numPtr8 = numPtr1 + (index2 * 3 + 2);
            color = obj3[num1];
            int r = (int) color.R;
            *numPtr8 = (byte) r;
          }
          else if (bitmapdata.PixelFormat == PixelFormat.Format16bppRgb555)
          {
            color = obj3[num1];
            int num2 = ((int) color.R & 248) << 7;
            color = obj3[num1];
            int num3 = ((int) color.G & 248) << 2;
            int num4 = num2 + num3;
            color = obj3[num1];
            int num5 = (int) color.B >> 3;
            ushort num6 = (ushort) (num4 + num5);
            numPtr1[index2 * 2] = (byte) ((uint) num6 % 256U);
            numPtr1[index2 * 2 + 1] = (byte) ((uint) num6 / 256U);
          }
          else if (bitmapdata.PixelFormat == PixelFormat.Format16bppRgb565)
          {
            color = obj3[num1];
            int num7 = ((int) color.R & 248) << 8;
            color = obj3[num1];
            int num8 = ((int) color.G & 252) << 3;
            int num9 = num7 + num8;
            color = obj3[num1];
            int num10 = (int) color.B >> 3;
            ushort num11 = (ushort) (num9 + num10);
            numPtr1[index2 * 2] = (byte) ((uint) num11 % 256U);
            numPtr1[index2 * 2 + 1] = (byte) ((uint) num11 / 256U);
          }
        }
      }
    }
    bitmap.UnlockBits(bitmapdata);
    if (obj4 == GEnum0.EPF)
      bitmap.RotateFlip(RotateFlipType.Rotate90FlipX);
    return bitmap;
  }

  public static Bitmap smethod_5(
    GClass12 value,
    [In] GClass20 obj1,
    [In] GClass18 obj2,
    [In] GClass18 obj3,
    [In] GClass22 obj4)
  {
    int num1 = 256;
    Bitmap bitmap1 = new Bitmap(56 * (value.Int32_2 + value.Int32_1), 28 * (value.Int32_1 + value.Int32_1));
    Graphics graphics = Graphics.FromImage((Image) bitmap1);
    int num2 = bitmap1.Width / 2 - 1 - 28 + 1;
    int num3 = 256;
    Dictionary<int, Bitmap> dictionary1 = new Dictionary<int, Bitmap>();
    for (int index = 0; index < value.Int32_1; ++index)
    {
      for (int stream_0 = 0; stream_0 < value.Int32_2; ++stream_0)
      {
        int uint162 = (int) value[stream_0, index].UInt16_2;
        if (uint162 > 0)
          --uint162;
        if (!dictionary1.ContainsKey(uint162))
        {
          Bitmap bitmap2 = GClass9.smethod_3(obj1[uint162], obj2[uint162 + 2]);
          dictionary1.Add(uint162, bitmap2);
        }
        graphics.DrawImageUnscaled((Image) dictionary1[uint162], num2 + stream_0 * 56 / 2, num3 + stream_0 * 28 / 2);
      }
      num2 -= 28;
      num3 += 14;
    }
    int num4 = bitmap1.Width / 2 - 1 - 28 + 1;
    int num5 = num1;
    Dictionary<int, Bitmap> dictionary2 = new Dictionary<int, Bitmap>();
    for (int index = 0; index < value.Int32_1; ++index)
    {
      for (int stream_0 = 0; stream_0 < value.Int32_2; ++stream_0)
      {
        int uint161 = (int) value[stream_0, index].UInt16_1;
        if (!dictionary2.ContainsKey(uint161))
        {
          Bitmap bitmap3 = GClass9.smethod_0(GClass19.smethod_3(\u003CModule\u003E.smethod_6<string>(2097952968U) + uint161.ToString().PadLeft(5, '0') + \u003CModule\u003E.smethod_9<string>(845505880U), true, obj4), obj3[uint161 + 1]);
          dictionary2.Add(uint161, bitmap3);
        }
        if (uint161 % 10000 > 1)
          graphics.DrawImageUnscaled((Image) dictionary2[uint161], num4 + stream_0 * 56 / 2, num5 + (stream_0 + 1) * 28 / 2 - dictionary2[uint161].Height + 14);
        int uint160 = (int) value[stream_0, index].UInt16_0;
        if (!dictionary2.ContainsKey(uint160))
        {
          Bitmap bitmap4 = GClass9.smethod_0(GClass19.smethod_3(\u003CModule\u003E.smethod_6<string>(2097952968U) + uint160.ToString().PadLeft(5, '0') + \u003CModule\u003E.smethod_7<string>(3800903338U), true, obj4), obj3[uint160 + 1]);
          dictionary2.Add(uint160, bitmap4);
        }
        if (uint160 % 10000 > 1)
          graphics.DrawImageUnscaled((Image) dictionary2[uint160], num4 + (stream_0 + 1) * 56 / 2, num5 + (stream_0 + 1) * 28 / 2 - dictionary2[uint160].Height + 14);
      }
      num4 -= 28;
      num5 += 14;
    }
    graphics.Dispose();
    return bitmap1;
  }
}
