﻿// Decompiled with JetBrains decompiler
// Type: Form1
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

internal class Form1 : Form
{
  private IContainer icontainer_0;
  private Label label_0;
  private Button button_0;
  private Button button_1;

  internal Form1(string int_4)
  {
    this.method_0();
    this.label_0.Text = int_4;
  }

  internal static DialogResult smethod_0(
    [In] Form5 obj0,
    string int_5,
    [In] IWin32Window obj2,
    [In] bool obj3)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Form1.Class14 class14 = new Form1.Class14();
    // ISSUE: reference to a compiler-generated field
    class14.form5_0 = obj0;
    // ISSUE: reference to a compiler-generated field
    class14.string_0 = int_5;
    // ISSUE: reference to a compiler-generated field
    class14.iwin32Window_0 = obj2;
    // ISSUE: reference to a compiler-generated field
    if (class14.form5_0.InvokeRequired)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated method
      return (DialogResult) class14.form5_0.Invoke((Delegate) new Func<DialogResult>(class14.method_0));
    }
    // ISSUE: reference to a compiler-generated field
    using (Form1 form1 = new Form1(class14.string_0))
    {
      form1.button_0.Visible = obj3;
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      return form1.ShowDialog(class14.iwin32Window_0 ?? (IWin32Window) class14.form5_0);
    }
  }

  private void button_0_Click([In] object obj0, EventArgs e) => this.DialogResult = DialogResult.Cancel;

  private void button_1_Click([In] object obj0, EventArgs e) => this.DialogResult = DialogResult.OK;

  void Form.Dispose([In] bool obj0)
  {
    if (obj0 && this.icontainer_0 != null)
      this.icontainer_0.Dispose();
    // ISSUE: explicit non-virtual call
    __nonvirtual (((Form) this).Dispose(obj0));
  }

  private void method_0()
  {
    ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (Form1));
    this.label_0 = new Label();
    this.button_0 = new Button();
    this.button_1 = new Button();
    this.SuspendLayout();
    this.label_0.Location = new Point(0, 1);
    this.label_0.Name = \u003CModule\u003E.smethod_9<string>(2600977107U);
    this.label_0.Size = new Size(284, 47);
    this.label_0.TabIndex = 7;
    this.label_0.Text = \u003CModule\u003E.smethod_5<string>(2567727941U);
    this.label_0.TextAlign = ContentAlignment.MiddleCenter;
    this.button_0.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.button_0.DialogResult = DialogResult.Cancel;
    this.button_0.FlatStyle = FlatStyle.Flat;
    this.button_0.Location = new Point(197, 51);
    this.button_0.Name = \u003CModule\u003E.smethod_7<string>(3303279321U);
    this.button_0.Size = new Size(75, 23);
    this.button_0.TabIndex = 6;
    this.button_0.Text = \u003CModule\u003E.smethod_5<string>(1475061067U);
    this.button_0.UseVisualStyleBackColor = true;
    this.button_0.Click += new EventHandler(this.button_0_Click);
    this.button_1.DialogResult = DialogResult.OK;
    this.button_1.FlatStyle = FlatStyle.Flat;
    this.button_1.Location = new Point(12, 51);
    this.button_1.Name = \u003CModule\u003E.smethod_7<string>(3990609899U);
    this.button_1.Size = new Size(75, 23);
    this.button_1.TabIndex = 5;
    this.button_1.Text = \u003CModule\u003E.smethod_7<string>(2650182150U);
    this.button_1.UseVisualStyleBackColor = true;
    this.button_1.Click += new EventHandler(this.button_1_Click);
    this.AcceptButton = (IButtonControl) this.button_1;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.AutoSize = true;
    this.BackColor = Color.White;
    this.ClientSize = new Size(284, 86);
    this.Controls.Add((Control) this.label_0);
    this.Controls.Add((Control) this.button_0);
    this.Controls.Add((Control) this.button_1);
    this.DoubleBuffered = true;
    this.ForeColor = Color.Black;
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Icon = (Icon) componentResourceManager.GetObject(\u003CModule\u003E.smethod_8<string>(3680203284U));
    this.MaximizeBox = false;
    this.MinimizeBox = false;
    this.Name = \u003CModule\u003E.smethod_6<string>(2712631832U);
    this.ShowInTaskbar = false;
    this.SizeGripStyle = SizeGripStyle.Hide;
    this.StartPosition = FormStartPosition.CenterParent;
    this.Text = \u003CModule\u003E.smethod_6<string>(1209782516U);
    this.TopMost = true;
    this.ResumeLayout(false);
  }
}
