﻿// Decompiled with JetBrains decompiler
// Type: Class105
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Runtime.InteropServices;

internal sealed class Class105
{
  internal bool Boolean_0 { get; [param: In] set; }

  internal Class105 Class105_0 { get; set; }

  internal bool Boolean_1 { get; [param: In] set; }

  internal bool Boolean_2 { get; set; }

  internal float Single_0 { get; [param: In] set; }

  internal float Single_1 { get; set; }

  internal Struct16 Struct16_0 { get; }

  internal Class105[] Class105_1 { get; }

  internal Class105([In] short obj0, short class99_0)
  {
    this.Struct16_0 = new Struct16(obj0, class99_0);
    this.Class105_1 = new Class105[4];
  }
}
