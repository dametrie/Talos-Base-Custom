﻿// Decompiled with JetBrains decompiler
// Type: Class24
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using Accolade;
using System.Collections.Generic;
using System.Runtime.InteropServices;

internal sealed class Class24
{
  private readonly TemClass temClass_0;

  internal string String_0 { get; set; }

  internal int Int32_0 { get; set; }

  internal int Int32_1 { get; set; }

  internal bool Boolean_0 { get; set; }

  internal Dictionary<string, byte> Dictionary_0 { get; }

  internal Class24()
  {
    this.String_0 = \u003CModule\u003E.smethod_8<string>(1848524772U);
    this.Dictionary_0 = new Dictionary<string, byte>();
    this.Int32_0 = 0;
    this.Int32_1 = 0;
    this.Boolean_0 = false;
    this.temClass_0 = TemClass.Peasant;
  }

  internal Class24(
    string value,
    [In] Dictionary<string, byte> obj1,
    [In] int obj2,
    [In] int obj3,
    [In] bool obj4,
    [In] TemClass obj5)
  {
    this.String_0 = value;
    this.Dictionary_0 = obj1;
    this.Int32_0 = obj2;
    this.Int32_1 = obj3;
    this.Boolean_0 = obj4;
    this.temClass_0 = obj5;
  }

  internal Class24(Class24 value)
  {
    this.String_0 = string.Copy(value.String_0);
    this.Dictionary_0 = value.Dictionary_0;
    this.Int32_0 = value.Int32_0;
    this.Int32_1 = value.Int32_1;
    this.Boolean_0 = value.Boolean_0;
    this.temClass_0 = value.temClass_0;
  }

  internal bool method_0(byte value, [In] byte obj1, [In] uint obj2, [In] TemClass obj3)
  {
    if ((int) value < this.Int32_0 || (int) obj1 < this.Int32_1 || this.Boolean_0 && obj2 != 0U)
      return false;
    return this.temClass_0 == TemClass.Peasant || this.temClass_0 == obj3;
  }
}
