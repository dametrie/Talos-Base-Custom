﻿// Decompiled with JetBrains decompiler
// Type: Struct17
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

internal struct Struct17 : IEquatable<Struct17>
{
  internal short Int16_0 { get; [param: In] set; }

  internal short Int16_1 { get; [param: In] set; }

  internal short Int16_2 { get; [param: In] set; }

  internal Struct16 Struct16_0 => new Struct16(this.Int16_1, this.Int16_2);

  [SpecialName]
  public static bool smethod_0(Struct17 string_1, [In] Struct17 obj1) => string_1.Equals(obj1);

  [SpecialName]
  public static bool smethod_1(Struct17 string_1, [In] Struct17 obj1) => !string_1.Equals(obj1);

  internal Struct17(short value, [In] short obj1, [In] short obj2)
  {
    this.Int16_0 = value;
    this.Int16_1 = obj1;
    this.Int16_2 = obj2;
  }

  internal Struct17(short class72_0, [In] Struct16 obj1)
  {
    this.Int16_0 = class72_0;
    this.Int16_1 = obj1.short_0;
    this.Int16_2 = obj1.short_1;
  }

  public bool Equals(Struct17 int_1) => this.GetHashCode() == int_1.GetHashCode();

  public virtual bool System\u002EValueType\u002EEquals(object byte_5) => byte_5 is Struct17 struct17 && this.GetHashCode() == struct17.GetHashCode();

  public virtual int System\u002EValueType\u002EGetHashCode() => ((int) this.Int16_0 << 16) + ((int) this.Int16_1 << 8) + (int) this.Int16_2;

  public virtual string System\u002EValueType\u002EToString() => string.Format(\u003CModule\u003E.smethod_8<string>(4051379196U), (object) this.Int16_0, (object) this.Int16_1, (object) this.Int16_2);
}
