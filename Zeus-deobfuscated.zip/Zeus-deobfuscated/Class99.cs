﻿// Decompiled with JetBrains decompiler
// Type: Class99
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Security.Cryptography;

internal sealed class Class99 : Class98
{
  internal bool Boolean_1 => this.byte_1 == (byte) 57 || this.byte_1 == (byte) 58;

  Enum11 Class98.\u206B​‎‪‫⁫‏‫‌⁭‭⁭⁭‮‫‍‪‏⁬‪‮‪‌‌‌‫‮​⁯‏⁫⁫‮‫⁭‬⁮⁬​‌‮
  {
    get
    {
      byte byte1 = this.byte_1;
      if (byte1 <= (byte) 67)
      {
        if (byte1 <= (byte) 16)
        {
          if (byte1 <= (byte) 4)
          {
            if (byte1 != (byte) 0)
            {
              if ((uint) byte1 - 2U <= 2U)
                goto label_20;
              else
                goto label_19;
            }
          }
          else if (byte1 != (byte) 11)
          {
            if (byte1 != (byte) 16)
              goto label_19;
          }
          else
            goto label_20;
        }
        else if (byte1 <= (byte) 45)
        {
          if (byte1 == (byte) 38 || byte1 == (byte) 45)
            goto label_20;
          else
            goto label_19;
        }
        else if (byte1 == (byte) 58 || (uint) byte1 - 66U <= 1U)
          goto label_20;
        else
          goto label_19;
      }
      else if (byte1 <= (byte) 98)
      {
        if (byte1 <= (byte) 75)
        {
          if (byte1 != (byte) 72)
          {
            if (byte1 == (byte) 75)
              goto label_20;
            else
              goto label_19;
          }
        }
        else if (byte1 == (byte) 87 || byte1 == (byte) 98)
          goto label_20;
        else
          goto label_19;
      }
      else if (byte1 <= (byte) 113)
      {
        if (byte1 == (byte) 104 || byte1 == (byte) 113)
          goto label_20;
        else
          goto label_19;
      }
      else if (byte1 == (byte) 115 || byte1 == (byte) 123)
        goto label_20;
      else
        goto label_19;
      return Enum11.None;
label_19:
      return Enum11.MD5Key;
label_20:
      return Enum11.Normal;
    }
  }

  internal Class99(byte keyValuePair_0)
    : base(keyValuePair_0)
  {
  }

  internal Class99(byte[] value)
    : base(value)
  {
  }

  void Class98.\u202A⁭‏⁬‏‎​⁪⁮‎‬‪‪‏⁭‬⁬‪‮‏‍‮⁮⁭‌‌‌⁪‍‍‎‮‌‬⁬‮‏‌‏‎‮(Class72 value)
  {
    this.int_0 = this.byte_0.Length;
    ushort num1 = (ushort) (Class138.smethod_2(65277) + 256);
    byte num2 = (byte) (Class138.smethod_2(155) + 100);
    byte[] numArray1;
    switch (((Class98) this).Class98\u002E⁫​‎‪‫⁫‏‫‌⁭‭⁭⁭‮‫‍‪‏⁬‪‮‪‌‌‌‫‮​⁯‏⁫⁫‮‫⁭‬⁮⁬​‌‮)
    {
      case Enum11.Normal:
        this.method_14((byte) 0);
        numArray1 = value.Byte_1;
        break;
      case Enum11.MD5Key:
        this.method_14((byte) 0);
        this.method_14(this.byte_1);
        numArray1 = value.method_0(num1, num2);
        break;
      default:
        return;
    }
    for (int index1 = 0; index1 < this.byte_0.Length; ++index1)
    {
      int index2 = index1 / value.Byte_1.Length % 256;
      this.byte_0[index1] ^= (byte) ((uint) value.Byte_2[index2] ^ (uint) numArray1[index1 % numArray1.Length]);
      if (index2 != (int) this.byte_3)
        this.byte_0[index1] ^= value.Byte_2[(int) this.byte_3];
    }
    byte[] numArray2 = new byte[this.byte_0.Length + 2];
    numArray2[0] = this.byte_1;
    numArray2[1] = this.byte_3;
    Buffer.BlockCopy((Array) this.byte_0, 0, (Array) numArray2, 2, this.byte_0.Length);
    byte[] hash = MD5.Create().ComputeHash(numArray2);
    this.method_14(hash[13]);
    this.method_14(hash[3]);
    this.method_14(hash[11]);
    this.method_14(hash[7]);
    this.method_14((byte) ((int) num1 % 256 ^ 112));
    this.method_14((byte) ((uint) num2 ^ 35U));
    this.method_14((byte) (((int) num1 >> 8) % 256 ^ 116));
  }

  void Class98.\u200F‫‮​⁪‭‎⁬⁫‍⁪‌‍‏‏⁯⁯‭‫⁫‬‪‬‌‌‪⁯⁮‮⁭⁬‏⁬‮‭⁪‮‭‎⁭‮(Class72 value)
  {
    int num1 = this.byte_0.Length - 7;
    ushort num2 = (ushort) (((int) this.byte_0[num1 + 6] << 8 | (int) this.byte_0[num1 + 4]) ^ 29808);
    byte num3 = (byte) ((uint) this.byte_0[num1 + 5] ^ 35U);
    int newSize;
    byte[] numArray;
    switch (((Class98) this).Class98\u002E⁫​‎‪‫⁫‏‫‌⁭‭⁭⁭‮‫‍‪‏⁬‪‮‪‌‌‌‫‮​⁯‏⁫⁫‮‫⁭‬⁮⁬​‌‮)
    {
      case Enum11.Normal:
        newSize = num1 - 1;
        numArray = value.Byte_1;
        break;
      case Enum11.MD5Key:
        newSize = num1 - 2;
        numArray = value.method_0(num2, num3);
        break;
      default:
        return;
    }
    for (int index1 = 0; index1 < newSize; ++index1)
    {
      int index2 = index1 / value.Byte_1.Length % 256;
      this.byte_0[index1] ^= (byte) ((uint) value.Byte_2[index2] ^ (uint) numArray[index1 % numArray.Length]);
      if (index2 != (int) this.byte_3)
        this.byte_0[index1] ^= value.Byte_2[(int) this.byte_3];
    }
    Array.Resize<byte>(ref this.byte_0, newSize);
  }

  internal void method_29()
  {
    ushort num = Class74.smethod_1(this.byte_0, 6, this.byte_0.Length - 6);
    this.byte_0[0] = (byte) Class138.smethod_1();
    this.byte_0[1] = (byte) Class138.smethod_1();
    this.byte_0[2] = (byte) ((this.byte_0.Length - 4) / 256);
    this.byte_0[3] = (byte) ((this.byte_0.Length - 4) % 256);
    this.byte_0[4] = (byte) ((uint) num / 256U);
    this.byte_0[5] = (byte) ((uint) num % 256U);
  }

  internal void method_30()
  {
    Array.Resize<byte>(ref this.byte_0, this.byte_0.Length + 6);
    Buffer.BlockCopy((Array) this.byte_0, 0, (Array) this.byte_0, 6, this.byte_0.Length - 6);
    this.method_29();
    int num1 = (int) this.byte_0[2] << 8 | (int) this.byte_0[3];
    int num2 = (int) (byte) ((uint) this.byte_0[1] ^ (uint) (byte) ((uint) this.byte_0[0] - 45U));
    byte num3 = (byte) (num2 + 114);
    byte num4 = (byte) (num2 + 40);
    this.byte_0[2] ^= num3;
    this.byte_0[3] ^= (byte) (((int) num3 + 1) % 256);
    for (int index = 0; index < num1; ++index)
      this.byte_0[4 + index] ^= (byte) (((int) num4 + index) % 256);
  }

  internal void method_31()
  {
    int num1 = (int) (byte) ((uint) this.byte_0[1] ^ (uint) (byte) ((uint) this.byte_0[0] - 45U));
    byte num2 = (byte) (num1 + 114);
    byte num3 = (byte) (num1 + 40);
    this.byte_0[2] ^= num2;
    this.byte_0[3] ^= (byte) (((int) num2 + 1) % 256);
    int num4 = (int) this.byte_0[2] << 8 | (int) this.byte_0[3];
    for (int index = 0; index < num4; ++index)
      this.byte_0[4 + index] ^= (byte) (((int) num3 + index) % 256);
    Buffer.BlockCopy((Array) this.byte_0, 6, (Array) this.byte_0, 0, this.byte_0.Length - 6);
    Array.Resize<byte>(ref this.byte_0, this.byte_0.Length - 6);
  }

  internal Class99 method_32()
  {
    Class99 class99 = new Class99(this.byte_1);
    class99.method_13(this.byte_0);
    class99.dateTime_0 = this.dateTime_0;
    return class99;
  }

  public virtual string System\u002EObject\u002EToString()
  {
    string class0_0 = this.method_27().Substring(0, 2);
    // ISSUE: reference to a compiler-generated method
    switch (Class181.smethod_0(class0_0))
    {
      case 233362851:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(1860728532U))
          return \u003CModule\u003E.smethod_5<string>(641894658U) + this.method_27();
        break;
      case 334175660:
        if (class0_0 == \u003CModule\u003E.smethod_9<string>(2845740592U))
          return \u003CModule\u003E.smethod_9<string>(2984370176U) + this.method_27();
        break;
      case 350953279:
        if (class0_0 == \u003CModule\u003E.smethod_6<string>(1279845284U))
          return \u003CModule\u003E.smethod_8<string>(1648161330U) + this.method_27();
        break;
      case 368025088:
        if (class0_0 == \u003CModule\u003E.smethod_8<string>(259986298U))
          return \u003CModule\u003E.smethod_5<string>(3696125475U) + this.method_27();
        break;
      case 418357945:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(2221142264U))
          return \u003CModule\u003E.smethod_5<string>(1645053610U) + this.method_27();
        break;
      case 434988469:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(4124144524U))
          return \u003CModule\u003E.smethod_8<string>(4076151963U) + this.method_27();
        break;
      case 435135564:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(2156867742U))
          return \u003CModule\u003E.smethod_8<string>(1520350476U) + this.method_27();
        break;
      case 451766088:
        if (class0_0 == \u003CModule\u003E.smethod_8<string>(1674249770U))
          return \u003CModule\u003E.smethod_7<string>(1548289008U) + this.method_27();
        break;
      case 468396612:
        if (class0_0 == \u003CModule\u003E.smethod_9<string>(2590681006U))
          return \u003CModule\u003E.smethod_9<string>(2091661625U) + this.method_27();
        break;
      case 468543707:
        if (class0_0 == \u003CModule\u003E.smethod_8<string>(3941762744U))
          return \u003CModule\u003E.smethod_8<string>(3087197569U) + this.method_27();
        break;
      case 485174231:
        if (class0_0 == \u003CModule\u003E.smethod_8<string>(2874543030U))
          return \u003CModule\u003E.smethod_5<string>(3243821777U) + this.method_27();
        break;
      case 485321326:
        if (class0_0 == \u003CModule\u003E.smethod_7<string>(944935918U))
          return \u003CModule\u003E.smethod_6<string>(3149944968U) + this.method_27();
        break;
      case 485468421:
        if (class0_0 == \u003CModule\u003E.smethod_6<string>(3610954116U))
          return \u003CModule\u003E.smethod_9<string>(2133746588U) + this.method_27();
        break;
      case 502098945:
        if (class0_0 == \u003CModule\u003E.smethod_7<string>(3625791416U))
          return \u003CModule\u003E.smethod_7<string>(179868763U) + this.method_27();
        break;
      case 518729469:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(3995595480U))
          return \u003CModule\u003E.smethod_9<string>(2729310590U) + this.method_27();
        break;
      case 518876564:
        if (class0_0 == \u003CModule\u003E.smethod_7<string>(4173159514U))
          return \u003CModule\u003E.smethod_7<string>(1000920910U) + this.method_27();
        break;
      case 535654183:
        if (class0_0 == \u003CModule\u003E.smethod_7<string>(2559047716U))
          return \u003CModule\u003E.smethod_5<string>(3847525875U) + this.method_27();
        break;
      case 569209421:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(1592204766U))
          return \u003CModule\u003E.smethod_7<string>(1604274000U) + this.method_27();
        break;
      case 955388848:
        if (class0_0 == \u003CModule\u003E.smethod_8<string>(3354660334U))
          return \u003CModule\u003E.smethod_8<string>(2794962037U) + this.method_27();
        break;
      case 972166467:
        if (class0_0 == \u003CModule\u003E.smethod_7<string>(1408326528U))
          return \u003CModule\u003E.smethod_9<string>(336190398U) + this.method_27();
        break;
      case 1005721705:
        if (class0_0 == \u003CModule\u003E.smethod_7<string>(2531055220U))
          return \u003CModule\u003E.smethod_7<string>(4033197034U) + this.method_27();
        break;
      case 1022499324:
        if (class0_0 == \u003CModule\u003E.smethod_7<string>(1955694626U))
          return \u003CModule\u003E.smethod_7<string>(1380334032U) + this.method_27();
        break;
      case 1206611848:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(1025159746U))
          return \u003CModule\u003E.smethod_6<string>(652134874U) + this.method_27();
        break;
      case 1307277562:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(3931320958U))
          return \u003CModule\u003E.smethod_7<string>(3100174903U) + this.method_27();
        break;
      case 1324055181:
        if (class0_0 == \u003CModule\u003E.smethod_7<string>(2503062724U))
          return \u003CModule\u003E.smethod_8<string>(1941712535U) + this.method_27();
        break;
      case 1474509299:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(536196970U))
          return \u003CModule\u003E.smethod_9<string>(3172831016U) + this.method_27();
        break;
      case 1491286918:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(1989277576U))
          return \u003CModule\u003E.smethod_7<string>(988439088U) + this.method_27();
        break;
      case 1541619775:
        if (class0_0 == \u003CModule\u003E.smethod_9<string>(884001738U))
          return \u003CModule\u003E.smethod_9<string>(2790241637U) + this.method_27();
        break;
      case 1558397394:
        if (class0_0 == \u003CModule\u003E.smethod_6<string>(2214895126U))
          return \u003CModule\u003E.smethod_8<string>(1786497568U) + this.method_27();
        break;
      case 1575175013:
        if (class0_0 == \u003CModule\u003E.smethod_8<string>(3247675228U))
          return \u003CModule\u003E.smethod_8<string>(2373599978U) + this.method_27();
        break;
      case 1810753227:
        if (class0_0 == \u003CModule\u003E.smethod_9<string>(1472858744U))
          return \u003CModule\u003E.smethod_7<string>(2089416195U) + this.method_27();
        break;
      case 1827530846:
        if (class0_0 == \u003CModule\u003E.smethod_7<string>(2587040212U))
          return \u003CModule\u003E.smethod_9<string>(2905632342U) + this.method_27();
        break;
      case 1877863703:
        if (class0_0 == \u003CModule\u003E.smethod_6<string>(1847644758U))
          return \u003CModule\u003E.smethod_8<string>(2822366150U) + this.method_27();
        break;
      case 2112205916:
        if (class0_0 == \u003CModule\u003E.smethod_6<string>(2061225410U))
          return \u003CModule\u003E.smethod_8<string>(1199395158U) + this.method_27();
        break;
      case 2263057392:
        if (class0_0 == \u003CModule\u003E.smethod_6<string>(1800765368U))
          return \u003CModule\u003E.smethod_7<string>(1781498739U) + this.method_27();
        break;
      case 2280673654:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(2285416786U))
          return \u003CModule\u003E.smethod_6<string>(4071963264U) + this.method_27();
        break;
      case 2314375987:
        if (class0_0 == \u003CModule\u003E.smethod_8<string>(1807323316U))
          return \u003CModule\u003E.smethod_8<string>(1114551473U) + this.method_27();
        break;
      case 2330020773:
        if (class0_0 == \u003CModule\u003E.smethod_7<string>(18154698U))
          return \u003CModule\u003E.smethod_6<string>(3116097124U) + this.method_27();
        break;
      case 2330167868:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(3442358182U))
          return \u003CModule\u003E.smethod_5<string>(4037018646U) + this.method_27();
        break;
      case 2347931225:
        if (class0_0 == \u003CModule\u003E.smethod_9<string>(433774316U))
          return \u003CModule\u003E.smethod_6<string>(3420813159U) + this.method_27();
        break;
      case 2363723106:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(600471492U))
          return \u003CModule\u003E.smethod_7<string>(2083175284U) + this.method_27();
        break;
      case 2363870201:
        if (class0_0 == \u003CModule\u003E.smethod_6<string>(3871414158U))
          return \u003CModule\u003E.smethod_8<string>(2266614872U) + this.method_27();
        break;
      case 2380500725:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(2053552098U))
          return \u003CModule\u003E.smethod_6<string>(4121466051U) + this.method_27();
        break;
      case 2414894606:
        if (class0_0 == \u003CModule\u003E.smethod_8<string>(2767557924U))
          return \u003CModule\u003E.smethod_7<string>(2938460838U) + this.method_27();
        break;
      case 2431672225:
        if (class0_0 == \u003CModule\u003E.smethod_6<string>(1540305326U))
          return \u003CModule\u003E.smethod_5<string>(3824674519U) + this.method_27();
        break;
      case 2498929796:
        if (class0_0 == \u003CModule\u003E.smethod_7<string>(341582828U))
          return \u003CModule\u003E.smethod_8<string>(1301117572U) + this.method_27();
        break;
      case 2565201629:
        if (class0_0 == \u003CModule\u003E.smethod_7<string>(537530300U))
          return \u003CModule\u003E.smethod_5<string>(2628692001U) + this.method_27();
        break;
    }
    return \u003CModule\u003E.smethod_6<string>(2678527671U) + this.method_27();
  }
}
