﻿// Decompiled with JetBrains decompiler
// Type: Class73
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Runtime.InteropServices;

internal static class Class73
{
  private static readonly uint[] uint_0 = \u003CModule\u003E.smethod_9<uint[]>(1294375279U);

  internal static uint smethod_0([In] byte[] obj0)
  {
    uint num = uint.MaxValue;
    for (int index = 0; index < obj0.Length; ++index)
      num = num >> 8 ^ Class73.uint_0[(int) num & (int) byte.MaxValue ^ (int) obj0[index]];
    return num;
  }
}
