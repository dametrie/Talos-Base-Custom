﻿// Decompiled with JetBrains decompiler
// Type: GClass4
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Runtime.InteropServices;

public class GClass4
{
  public bool Boolean_0 => this.Byte_0 != null && this.Byte_0.Length >= 1 && this.Int32_1 >= 1 && this.Int32_0 >= 1 && this.Int32_1 * this.Int32_0 == this.Byte_0.Length;

  public byte[] Byte_0 { get; }

  public int Int32_0 { get; }

  public int Int32_1 { get; }

  public int Int32_2 { get; [param: In] set; }

  public int Int32_3 { get; set; }

  public GClass4([In] int obj0, int gclass16_0, [In] int obj2, [In] int obj3, [In] byte[] obj4)
  {
    this.Int32_3 = obj0;
    this.Int32_2 = gclass16_0;
    this.Int32_1 = obj2;
    this.Int32_0 = obj3;
    this.Byte_0 = obj4;
  }

  public virtual string System\u002EObject\u002EToString() => \u003CModule\u003E.smethod_5<string>(871356969U) + this.Int32_3.ToString() + \u003CModule\u003E.smethod_6<string>(1504090402U) + this.Int32_2.ToString() + \u003CModule\u003E.smethod_8<string>(2348152151U) + this.Int32_1.ToString() + \u003CModule\u003E.smethod_8<string>(2212447259U) + this.Int32_0.ToString() + \u003CModule\u003E.smethod_7<string>(3919114233U);
}
