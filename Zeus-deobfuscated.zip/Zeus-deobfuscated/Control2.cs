﻿// Decompiled with JetBrains decompiler
// Type: Control2
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using Accolade.Properties;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Forms.Layout;
using System.Xml;
using System.Xml.Linq;

internal class Control2 : UserControl
{
  private readonly object object_0 = new object();
  internal Class29 class29_0;
  internal CheckBox checkBox_0;
  internal ToolStripMenuItem toolStripMenuItem_0;
  internal ToolStripMenuItem toolStripMenuItem_1;
  internal ToolStripMenuItem toolStripMenuItem_2;
  internal MenuStrip menuStrip_0;
  internal GroupBox groupBox_0;
  internal Button button_0;
  internal Button button_1;
  internal Button button_2;
  internal Stopwatch stopwatch_0 = new Stopwatch();
  internal Stopwatch stopwatch_1 = new Stopwatch();
  internal Stopwatch stopwatch_2 = new Stopwatch();
  private IContainer icontainer_0;
  internal TabPage tabPage_0;
  internal Panel panel_0;
  internal ListBox listBox_0;
  internal Panel panel_1;
  internal RichTextBox richTextBox_0;
  internal RichTextBox richTextBox_1;
  internal Panel panel_2;
  internal RichTextBox richTextBox_2;
  internal Panel panel_3;
  internal Button button_3;
  internal Button button_4;
  internal ToolStrip toolStrip_0;
  internal ToolStripLabel toolStripLabel_0;
  internal ToolStripButton toolStripButton_0;
  internal ToolStripButton toolStripButton_1;
  internal ToolStripSeparator toolStripSeparator_0;
  internal ToolStripButton toolStripButton_2;
  internal ToolStripSeparator toolStripSeparator_1;
  internal ToolStripButton toolStripButton_3;
  internal Button button_5;
  internal TabPage tabPage_1;
  internal GroupBox groupBox_1;
  internal Button button_6;
  internal NumericUpDown numericUpDown_0;
  internal GroupBox groupBox_2;
  internal TextBox textBox_0;
  internal Label label_0;
  internal Label label_1;
  internal ToolStripMenuItem toolStripMenuItem_3;
  internal ToolStripMenuItem toolStripMenuItem_4;
  internal ToolStripMenuItem toolStripMenuItem_5;
  internal GroupBox groupBox_3;
  internal CheckBox checkBox_1;
  internal Label label_2;
  internal TextBox textBox_1;
  internal Button button_7;
  internal Button button_8;
  internal CheckBox checkBox_2;
  internal GroupBox groupBox_4;
  internal Label label_3;
  internal RadioButton radioButton_0;
  internal RadioButton radioButton_1;
  internal CheckBox checkBox_3;
  internal TextBox textBox_2;
  internal Label label_4;
  internal ulong ulong_0;
  internal uint uint_0;
  internal uint uint_1;
  internal uint uint_2;
  internal uint uint_3;
  internal bool bool_0;
  internal bool bool_1;
  internal int int_0;
  internal string string_0;
  internal string string_1;
  internal string string_2;
  internal int int_1;
  internal bool bool_2;
  internal List<string> list_0 = new List<string>()
  {
    "",
    "",
    "",
    "",
    ""
  };
  internal GClass22 gclass22_0;
  internal GClass10 gclass10_0;
  internal GClass10 gclass10_1;
  internal GClass16 gclass16_0;
  internal List<string> list_1 = new List<string>();
  internal BindingList<string> bindingList_0 = new BindingList<string>();
  internal BindingList<string> bindingList_1 = new BindingList<string>();
  internal BindingList<string> bindingList_2 = new BindingList<string>();
  internal BindingList<string> bindingList_3 = new BindingList<string>();
  internal Dictionary<string, DateTime> dictionary_0 = new Dictionary<string, DateTime>();
  internal List<string> list_2 = new List<string>();
  internal List<string> list_3 = new List<string>();
  internal List<string> list_4 = new List<string>();
  internal Class28 class28_0;
  internal Class28 class28_1;
  internal Form3 form3_0;
  private ToolStripMenuItem toolStripMenuItem_6;
  private ToolStripMenuItem toolStripMenuItem_7;
  private ToolStripMenuItem toolStripMenuItem_8;
  private ToolStripMenuItem toolStripMenuItem_9;
  internal DateTime dateTime_0 = DateTime.MinValue;
  private ToolStripMenuItem toolStripMenuItem_10;
  private string string_3 = "";
  private ToolStripMenuItem toolStripMenuItem_11;
  internal Label label_5;
  internal TabPage tabPage_2;
  internal GroupBox groupBox_5;
  internal Label label_6;
  internal Label label_7;
  internal Button button_9;
  internal Label label_8;
  internal GroupBox groupBox_6;
  internal Label label_9;
  internal CheckBox checkBox_4;
  internal Button button_10;
  internal TextBox textBox_3;
  internal CheckBox checkBox_5;
  internal Button button_11;
  internal TextBox textBox_4;
  internal CheckBox checkBox_6;
  internal Button button_12;
  internal TextBox textBox_5;
  internal CheckBox checkBox_7;
  internal Button button_13;
  internal TextBox textBox_6;
  internal TabPage tabPage_3;
  internal GroupBox groupBox_7;
  internal Label label_10;
  internal Button button_14;
  internal GroupBox groupBox_8;
  internal Label label_11;
  internal Button button_15;
  internal GroupBox groupBox_9;
  internal Label label_12;
  internal Button button_16;
  internal GroupBox groupBox_10;
  internal Label label_13;
  internal Button button_17;
  internal TabPage tabPage_4;
  internal CheckBox checkBox_8;
  internal CheckBox checkBox_9;
  internal TextBox textBox_7;
  internal CheckBox checkBox_10;
  internal Button button_18;
  internal CheckBox checkBox_11;
  internal CheckBox checkBox_12;
  internal GroupBox groupBox_11;
  internal GroupBox groupBox_12;
  internal Label label_14;
  internal CheckBox checkBox_13;
  internal Button button_19;
  internal CheckBox checkBox_14;
  internal GroupBox groupBox_13;
  internal TabPage tabPage_5;
  internal GroupBox groupBox_14;
  internal Button button_20;
  internal Button button_21;
  internal ListBox listBox_1;
  internal Button button_22;
  internal Button button_23;
  internal ListBox listBox_2;
  internal GroupBox groupBox_15;
  internal Button button_24;
  internal TextBox textBox_8;
  internal Button button_25;
  internal GroupBox groupBox_16;
  internal ComboBox comboBox_0;
  internal RadioButton radioButton_2;
  internal RadioButton radioButton_3;
  internal Button button_26;
  internal GroupBox groupBox_17;
  internal Button button_27;
  internal Button button_28;
  internal Button button_29;
  internal Button button_30;
  internal GroupBox groupBox_18;
  internal Button button_31;
  internal Label label_15;
  internal TextBox textBox_9;
  internal Button button_32;
  internal Button button_33;
  internal Button button_34;
  internal GroupBox groupBox_19;
  internal TextBox textBox_10;
  internal Button button_35;
  internal GroupBox groupBox_20;
  internal CheckBox checkBox_15;
  internal Button button_36;
  internal CheckBox checkBox_16;
  internal TextBox textBox_11;
  internal GroupBox groupBox_21;
  internal NumericUpDown numericUpDown_1;
  internal Label label_16;
  internal NumericUpDown numericUpDown_2;
  internal Label label_17;
  internal Label label_18;
  internal Label label_19;
  internal ComboBox comboBox_1;
  internal NumericUpDown numericUpDown_3;
  internal Label label_20;
  internal Button button_37;
  internal TabPage tabPage_6;
  internal GroupBox groupBox_22;
  internal TextBox textBox_12;
  internal GroupBox groupBox_23;
  internal CheckBox checkBox_17;
  internal CheckBox checkBox_18;
  internal Button button_38;
  internal CheckBox checkBox_19;
  internal CheckBox checkBox_20;
  internal NumericUpDown numericUpDown_4;
  internal NumericUpDown numericUpDown_5;
  internal NumericUpDown numericUpDown_6;
  internal NumericUpDown numericUpDown_7;
  internal NumericUpDown numericUpDown_8;
  internal NumericUpDown numericUpDown_9;
  internal Label label_21;
  internal NumericUpDown numericUpDown_10;
  internal NumericUpDown numericUpDown_11;
  internal NumericUpDown numericUpDown_12;
  internal NumericUpDown numericUpDown_13;
  internal NumericUpDown numericUpDown_14;
  internal NumericUpDown numericUpDown_15;
  internal NumericUpDown numericUpDown_16;
  internal Label label_22;
  internal Label label_23;
  internal Label label_24;
  internal Label label_25;
  internal Label label_26;
  internal Label label_27;
  internal Label label_28;
  internal Label label_29;
  internal Label label_30;
  internal Label label_31;
  internal Label label_32;
  internal Label label_33;
  internal Label label_34;
  internal NumericUpDown numericUpDown_17;
  internal GroupBox groupBox_24;
  internal Button button_39;
  internal Label label_35;
  internal ListBox listBox_3;
  internal Button button_40;
  internal TextBox textBox_13;
  internal ComboBox comboBox_2;
  internal GroupBox groupBox_25;
  internal CheckBox checkBox_21;
  internal NumericUpDown numericUpDown_18;
  internal CheckBox checkBox_22;
  internal CheckBox checkBox_23;
  internal GroupBox groupBox_26;
  internal CheckBox checkBox_24;
  internal CheckBox checkBox_25;
  internal CheckBox checkBox_26;
  internal CheckBox checkBox_27;
  internal CheckBox checkBox_28;
  internal GroupBox groupBox_27;
  internal CheckBox checkBox_29;
  internal CheckBox checkBox_30;
  internal CheckBox checkBox_31;
  internal CheckBox checkBox_32;
  internal CheckBox checkBox_33;
  internal CheckBox checkBox_34;
  internal TabPage tabPage_7;
  internal TabControl tabControl_0;
  internal TabPage tabPage_8;
  internal TableLayoutPanel tableLayoutPanel_0;
  internal TabPage tabPage_9;
  internal TabControl tabControl_1;
  internal TabPage tabPage_10;
  internal GroupBox groupBox_28;
  internal Label label_36;
  internal NumericUpDown numericUpDown_19;
  internal Button button_41;
  internal CheckBox checkBox_35;
  internal Button button_42;
  internal Button button_43;
  internal TextBox textBox_14;
  internal ListBox listBox_4;
  internal GroupBox groupBox_29;
  internal CheckBox checkBox_36;
  internal CheckBox checkBox_37;
  internal CheckBox checkBox_38;
  internal CheckBox checkBox_39;
  internal CheckBox checkBox_40;
  internal CheckBox checkBox_41;
  internal GroupBox groupBox_30;
  internal CheckBox checkBox_42;
  internal CheckBox checkBox_43;
  internal CheckBox checkBox_44;
  internal GroupBox groupBox_31;
  internal TextBox textBox_15;
  internal ComboBox comboBox_3;
  internal CheckBox checkBox_45;
  internal CheckBox checkBox_46;
  internal CheckBox checkBox_47;
  internal CheckBox checkBox_48;
  internal CheckBox checkBox_49;
  internal CheckBox checkBox_50;
  internal CheckBox checkBox_51;
  internal CheckBox checkBox_52;
  internal TextBox textBox_16;
  internal CheckBox checkBox_53;
  internal CheckBox checkBox_54;
  internal CheckBox checkBox_55;
  internal CheckBox checkBox_56;
  internal CheckBox checkBox_57;
  internal CheckBox checkBox_58;
  internal CheckBox checkBox_59;
  internal CheckBox checkBox_60;
  internal CheckBox checkBox_61;
  internal CheckBox checkBox_62;
  internal CheckBox checkBox_63;
  internal CheckBox checkBox_64;
  internal GroupBox groupBox_32;
  internal CheckBox checkBox_65;
  internal CheckBox checkBox_66;
  internal CheckBox checkBox_67;
  internal Label label_37;
  internal Label label_38;
  internal Label label_39;
  internal TrackBar trackBar_0;
  internal Button button_44;
  internal Button button_45;
  internal ComboBox comboBox_4;
  internal Label label_40;
  internal NumericUpDown numericUpDown_20;
  internal Label label_41;
  internal TextBox textBox_17;
  internal CheckBox checkBox_68;
  internal GroupBox groupBox_33;
  internal CheckBox checkBox_69;
  internal CheckBox checkBox_70;
  internal CheckBox checkBox_71;
  internal CheckBox checkBox_72;
  internal CheckBox checkBox_73;
  internal GroupBox groupBox_34;
  internal CheckBox checkBox_74;
  internal CheckBox checkBox_75;
  internal CheckBox checkBox_76;
  internal GroupBox groupBox_35;
  internal CheckBox checkBox_77;
  internal Button button_46;
  internal Button button_47;
  internal CheckBox checkBox_78;
  internal CheckBox checkBox_79;
  internal Label label_42;
  internal Label label_43;
  internal TextBox textBox_18;
  internal ListBox listBox_5;
  internal GroupBox groupBox_36;
  internal CheckBox checkBox_80;
  internal CheckBox checkBox_81;
  internal CheckBox checkBox_82;
  internal CheckBox checkBox_83;
  internal NumericUpDown numericUpDown_21;
  internal ComboBox comboBox_5;
  internal NumericUpDown numericUpDown_22;
  internal ComboBox comboBox_6;
  internal Label label_44;
  internal ComboBox comboBox_7;
  internal GroupBox groupBox_37;
  internal CheckBox checkBox_84;
  internal CheckBox checkBox_85;
  internal ComboBox comboBox_8;
  internal ComboBox comboBox_9;
  internal TabPage tabPage_11;
  internal TableLayoutPanel tableLayoutPanel_1;
  internal TabPage tabPage_12;
  internal GroupBox groupBox_38;
  internal Label label_45;
  internal Label label_46;
  internal Label label_47;
  internal GroupBox groupBox_39;
  internal Button button_48;
  internal Button button_49;
  internal Button button_50;
  internal Button button_51;
  internal ListBox listBox_6;
  internal Class27 class27_0;
  internal GroupBox groupBox_40;
  internal Button button_52;
  internal Button button_53;
  internal Button button_54;
  internal Button button_55;
  internal ListBox listBox_7;
  internal GroupBox groupBox_41;
  internal Button button_56;
  internal Button button_57;
  internal ListBox listBox_8;
  internal GroupBox groupBox_42;
  internal Label label_48;
  internal Label label_49;
  internal Label label_50;
  internal Label label_51;
  internal Label label_52;
  internal Button button_58;
  internal Button button_59;
  internal TextBox textBox_19;
  internal Button button_60;
  internal TextBox textBox_20;
  internal Button button_61;
  internal Button button_62;
  internal GroupBox groupBox_43;
  internal Label label_53;
  internal Label label_54;
  internal Label label_55;
  internal Label label_56;
  internal Label label_57;
  internal Button button_63;
  internal Button button_64;
  internal CheckBox checkBox_86;
  internal CheckBox checkBox_87;
  internal Button button_65;
  internal ComboBox comboBox_10;
  internal ComboBox comboBox_11;
  internal Label label_58;
  internal Label label_59;
  internal TabControl tabControl_2;
  internal CheckBox checkBox_88;
  internal Button button_66;
  internal Button button_67;
  internal GClass25 gclass25_0;
  private GroupBox groupBox_44;
  internal TextBox textBox_21;
  internal CheckBox checkBox_89;
  internal Label label_60;
  internal GroupBox groupBox_45;
  internal TextBox textBox_22;
  internal Button button_68;
  internal CheckBox checkBox_90;
  internal CheckBox checkBox_91;
  internal GroupBox groupBox_46;
  internal ComboBox comboBox_12;
  internal Button button_69;
  internal CheckBox checkBox_92;
  internal Button button_70;
  internal GroupBox groupBox_47;
  internal Label label_61;
  internal Button button_71;
  internal GroupBox groupBox_48;
  internal Button button_72;
  internal Label label_62;
  private TabPage tabPage_13;
  private GroupBox groupBox_49;
  internal CheckBox checkBox_93;
  internal CheckBox checkBox_94;
  internal CheckBox checkBox_95;
  internal CheckBox checkBox_96;
  private GroupBox groupBox_50;
  internal Label label_63;
  internal NumericUpDown numericUpDown_23;
  internal RadioButton radioButton_4;
  internal CheckBox checkBox_97;
  internal RadioButton radioButton_5;
  internal TextBox textBox_23;
  private GroupBox groupBox_51;
  internal CheckBox checkBox_98;
  internal NumericUpDown numericUpDown_24;
  internal Label label_64;
  private GroupBox groupBox_52;
  internal CheckBox checkBox_99;
  internal CheckBox checkBox_100;
  internal GroupBox groupBox_53;
  internal Button button_73;
  private GroupBox groupBox_54;
  internal TextBox textBox_24;
  internal TextBox textBox_25;
  internal CheckBox checkBox_101;
  private readonly List<Keys> list_5 = new List<Keys>()
  {
    Keys.Alt,
    Keys.Menu,
    Keys.Control,
    Keys.ControlKey,
    Keys.Shift,
    Keys.ShiftKey,
    Keys.LWin,
    Keys.RWin
  };
  internal Label label_65;
  private readonly Dictionary<string, int> dictionary_1 = new Dictionary<string, int>()
  {
    {
      \u003CModule\u003E.smethod_5<string>(1732623364U),
      1
    },
    {
      \u003CModule\u003E.smethod_7<string>(1132896076U),
      2
    },
    {
      \u003CModule\u003E.smethod_7<string>(2473323825U),
      3
    }
  };

  internal Control2(Class29 sender)
  {
    this.method_0();
    this.class29_0 = sender;
    sender.Control2_0 = this;
    this.form3_0 = new Form3(sender);
    this.gclass22_0 = GClass22.smethod_0(Settings.Default.DarkAgesPath.Replace(\u003CModule\u003E.smethod_8<string>(2112040518U), \u003CModule\u003E.smethod_7<string>(3596052517U)));
    this.gclass10_1 = GClass10.smethod_2(\u003CModule\u003E.smethod_6<string>(4075099295U), this.gclass22_0);
    this.gclass10_0 = GClass10.smethod_2(\u003CModule\u003E.smethod_7<string>(1434572621U), this.gclass22_0);
    this.gclass16_0 = GClass16.smethod_2(\u003CModule\u003E.smethod_6<string>(1436651031U), this.gclass22_0);
    this.string_1 = Settings.Default.DarkAgesPath.Replace(\u003CModule\u003E.smethod_5<string>(197665510U), sender.String_0 + \u003CModule\u003E.smethod_6<string>(3921429579U));
    this.string_2 = AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_9<string>(1053048411U);
    this.method_26();
    BindingList<string> bindingList = new BindingList<string>();
    bindingList.Add(\u003CModule\u003E.smethod_7<string>(283851433U));
    bindingList.Add(\u003CModule\u003E.smethod_7<string>(1076911084U));
    bindingList.Add(\u003CModule\u003E.smethod_6<string>(3223400084U));
    bindingList.Add(\u003CModule\u003E.smethod_8<string>(2370518592U));
    bindingList.Add(\u003CModule\u003E.smethod_9<string>(3057675918U));
    bindingList.Add(\u003CModule\u003E.smethod_5<string>(427612363U));
    bindingList.Add(\u003CModule\u003E.smethod_7<string>(2445331329U));
    bindingList.Add(\u003CModule\u003E.smethod_9<string>(4145552305U));
    bindingList.Add(\u003CModule\u003E.smethod_8<string>(823181574U));
    bindingList.Add(\u003CModule\u003E.smethod_7<string>(2311609760U));
    bindingList.Add(\u003CModule\u003E.smethod_7<string>(3708022501U));
    bindingList.Add(\u003CModule\u003E.smethod_9<string>(1958699740U));
    bindingList.Add(\u003CModule\u003E.smethod_8<string>(289571717U));
    bindingList.Add(\u003CModule\u003E.smethod_9<string>(2851408291U));
    bindingList.Add(\u003CModule\u003E.smethod_8<string>(716196468U));
    bindingList.Add(\u003CModule\u003E.smethod_8<string>(3517319299U));
    bindingList.Add(\u003CModule\u003E.smethod_6<string>(3176520694U));
    bindingList.Add(\u003CModule\u003E.smethod_5<string>(1925446930U));
    bindingList.Add(\u003CModule\u003E.smethod_9<string>(1478526443U));
    bindingList.Add(\u003CModule\u003E.smethod_5<string>(1070357583U));
    bindingList.Add(\u003CModule\u003E.smethod_5<string>(382858402U));
    bindingList.Add(\u003CModule\u003E.smethod_7<string>(1456324206U));
    bindingList.Add(\u003CModule\u003E.smethod_9<string>(2272847386U));
    bindingList.Add(\u003CModule\u003E.smethod_7<string>(3082734619U));
    bindingList.Add(\u003CModule\u003E.smethod_9<string>(1058244896U));
    bindingList.Add(\u003CModule\u003E.smethod_5<string>(254309358U));
    this.bindingList_3 = bindingList;
    this.form3_0.listBox_1.DataSource = (object) this.bindingList_0;
    this.listBox_7.DataSource = (object) this.bindingList_1;
    this.listBox_8.DataSource = (object) this.bindingList_2;
    this.listBox_6.DataSource = (object) sender.Class112_0.form5_0.bindingList_0;
    this.listBox_5.DataSource = (object) this.bindingList_3;
    this.toolStripButton_0.Checked = Settings.Default.LogOnStartup;
    this.toolStripButton_1.Checked = Settings.Default.LogOnStartup;
    Class28 class28_1 = new Class28(\u003CModule\u003E.smethod_5<string>(1643115442U));
    class28_1.BackColor = Color.White;
    class28_1.ForeColor = Color.Crimson;
    class28_1.Location = new Point(6, 282);
    class28_1.MaximumSize = new Size(50, 196);
    class28_1.Name = \u003CModule\u003E.smethod_8<string>(3385561426U);
    class28_1.Size = new Size(50, 196);
    class28_1.Step = 10;
    class28_1.Style = ProgressBarStyle.Continuous;
    class28_1.TabIndex = 14;
    this.class28_1 = class28_1;
    Class28 class28_2 = new Class28(\u003CModule\u003E.smethod_8<string>(2756582500U));
    class28_2.BackColor = Color.White;
    class28_2.ForeColor = Color.MidnightBlue;
    class28_2.Location = new Point(65, 282);
    class28_2.MaximumSize = new Size(50, 196);
    class28_2.Name = \u003CModule\u003E.smethod_9<string>(2279554382U);
    class28_2.Size = new Size(50, 196);
    class28_2.Step = 10;
    class28_2.Style = ProgressBarStyle.Continuous;
    class28_2.TabIndex = 15;
    this.class28_0 = class28_2;
    GClass25 gclass25 = new GClass25();
    gclass25.BackColor = Color.White;
    gclass25.ForeColor = Color.Black;
    gclass25.Boolean_0 = false;
    gclass25.Location = new Point(121, 253);
    gclass25.Name = \u003CModule\u003E.smethod_8<string>(3145502774U);
    gclass25.Size = new Size(508, 225);
    gclass25.TabIndex = 0;
    gclass25.Text = "";
    gclass25.ReadOnly = true;
    gclass25.Font = new Font(\u003CModule\u003E.smethod_5<string>(125760314U), 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.gclass25_0 = gclass25;
    this.gclass25_0.LinkClicked += new LinkClickedEventHandler(this.gclass25_0_LinkClicked);
    this.tabPage_12.Controls.Add((Control) this.class28_0);
    this.tabPage_12.Controls.Add((Control) this.class28_1);
    this.tabPage_12.Controls.Add((Control) this.gclass25_0);
  }

  private void method_0()
  {
    this.menuStrip_0 = new MenuStrip();
    this.toolStripMenuItem_2 = new ToolStripMenuItem();
    this.toolStripMenuItem_1 = new ToolStripMenuItem();
    this.toolStripMenuItem_0 = new ToolStripMenuItem();
    this.toolStripMenuItem_10 = new ToolStripMenuItem();
    this.toolStripMenuItem_11 = new ToolStripMenuItem();
    this.toolStripMenuItem_3 = new ToolStripMenuItem();
    this.toolStripMenuItem_4 = new ToolStripMenuItem();
    this.toolStripMenuItem_5 = new ToolStripMenuItem();
    this.toolStripMenuItem_6 = new ToolStripMenuItem();
    this.toolStripMenuItem_7 = new ToolStripMenuItem();
    this.toolStripMenuItem_8 = new ToolStripMenuItem();
    this.toolStripMenuItem_9 = new ToolStripMenuItem();
    this.tabPage_1 = new TabPage();
    this.groupBox_4 = new GroupBox();
    this.label_4 = new Label();
    this.textBox_2 = new TextBox();
    this.checkBox_3 = new CheckBox();
    this.label_3 = new Label();
    this.radioButton_0 = new RadioButton();
    this.radioButton_1 = new RadioButton();
    this.checkBox_2 = new CheckBox();
    this.groupBox_3 = new GroupBox();
    this.label_2 = new Label();
    this.textBox_1 = new TextBox();
    this.button_7 = new Button();
    this.button_8 = new Button();
    this.checkBox_1 = new CheckBox();
    this.groupBox_2 = new GroupBox();
    this.label_1 = new Label();
    this.label_0 = new Label();
    this.textBox_0 = new TextBox();
    this.groupBox_1 = new GroupBox();
    this.button_6 = new Button();
    this.numericUpDown_0 = new NumericUpDown();
    this.groupBox_0 = new GroupBox();
    this.button_0 = new Button();
    this.button_1 = new Button();
    this.button_5 = new Button();
    this.button_2 = new Button();
    this.checkBox_0 = new CheckBox();
    this.tabPage_0 = new TabPage();
    this.panel_0 = new Panel();
    this.listBox_0 = new ListBox();
    this.panel_1 = new Panel();
    this.richTextBox_0 = new RichTextBox();
    this.richTextBox_1 = new RichTextBox();
    this.panel_2 = new Panel();
    this.richTextBox_2 = new RichTextBox();
    this.panel_3 = new Panel();
    this.button_3 = new Button();
    this.button_4 = new Button();
    this.toolStrip_0 = new ToolStrip();
    this.toolStripLabel_0 = new ToolStripLabel();
    this.toolStripButton_0 = new ToolStripButton();
    this.toolStripButton_1 = new ToolStripButton();
    this.toolStripSeparator_0 = new ToolStripSeparator();
    this.toolStripButton_2 = new ToolStripButton();
    this.toolStripSeparator_1 = new ToolStripSeparator();
    this.toolStripButton_3 = new ToolStripButton();
    this.label_5 = new Label();
    this.tabPage_2 = new TabPage();
    this.groupBox_5 = new GroupBox();
    this.label_6 = new Label();
    this.label_7 = new Label();
    this.button_9 = new Button();
    this.label_8 = new Label();
    this.groupBox_6 = new GroupBox();
    this.label_9 = new Label();
    this.checkBox_4 = new CheckBox();
    this.button_10 = new Button();
    this.textBox_3 = new TextBox();
    this.checkBox_5 = new CheckBox();
    this.button_11 = new Button();
    this.textBox_4 = new TextBox();
    this.checkBox_6 = new CheckBox();
    this.button_12 = new Button();
    this.textBox_5 = new TextBox();
    this.checkBox_7 = new CheckBox();
    this.button_13 = new Button();
    this.textBox_6 = new TextBox();
    this.tabPage_3 = new TabPage();
    this.groupBox_47 = new GroupBox();
    this.label_61 = new Label();
    this.button_71 = new Button();
    this.groupBox_7 = new GroupBox();
    this.label_10 = new Label();
    this.button_14 = new Button();
    this.groupBox_8 = new GroupBox();
    this.label_11 = new Label();
    this.button_15 = new Button();
    this.groupBox_9 = new GroupBox();
    this.label_12 = new Label();
    this.button_16 = new Button();
    this.groupBox_10 = new GroupBox();
    this.label_13 = new Label();
    this.button_17 = new Button();
    this.tabPage_4 = new TabPage();
    this.checkBox_10 = new CheckBox();
    this.checkBox_8 = new CheckBox();
    this.checkBox_9 = new CheckBox();
    this.textBox_7 = new TextBox();
    this.button_18 = new Button();
    this.checkBox_11 = new CheckBox();
    this.checkBox_12 = new CheckBox();
    this.groupBox_11 = new GroupBox();
    this.groupBox_12 = new GroupBox();
    this.label_14 = new Label();
    this.checkBox_13 = new CheckBox();
    this.button_19 = new Button();
    this.checkBox_14 = new CheckBox();
    this.groupBox_13 = new GroupBox();
    this.tabPage_5 = new TabPage();
    this.groupBox_48 = new GroupBox();
    this.button_72 = new Button();
    this.label_62 = new Label();
    this.groupBox_46 = new GroupBox();
    this.button_70 = new Button();
    this.checkBox_92 = new CheckBox();
    this.comboBox_12 = new ComboBox();
    this.button_69 = new Button();
    this.groupBox_45 = new GroupBox();
    this.checkBox_91 = new CheckBox();
    this.checkBox_90 = new CheckBox();
    this.textBox_22 = new TextBox();
    this.button_68 = new Button();
    this.groupBox_14 = new GroupBox();
    this.button_20 = new Button();
    this.button_21 = new Button();
    this.listBox_1 = new ListBox();
    this.button_22 = new Button();
    this.listBox_2 = new ListBox();
    this.button_23 = new Button();
    this.groupBox_15 = new GroupBox();
    this.button_24 = new Button();
    this.textBox_8 = new TextBox();
    this.button_25 = new Button();
    this.groupBox_16 = new GroupBox();
    this.comboBox_0 = new ComboBox();
    this.radioButton_2 = new RadioButton();
    this.radioButton_3 = new RadioButton();
    this.button_26 = new Button();
    this.groupBox_17 = new GroupBox();
    this.button_27 = new Button();
    this.button_28 = new Button();
    this.button_29 = new Button();
    this.button_30 = new Button();
    this.groupBox_18 = new GroupBox();
    this.button_31 = new Button();
    this.label_15 = new Label();
    this.textBox_9 = new TextBox();
    this.button_32 = new Button();
    this.button_33 = new Button();
    this.button_34 = new Button();
    this.groupBox_19 = new GroupBox();
    this.checkBox_88 = new CheckBox();
    this.textBox_10 = new TextBox();
    this.button_35 = new Button();
    this.groupBox_20 = new GroupBox();
    this.checkBox_15 = new CheckBox();
    this.button_36 = new Button();
    this.checkBox_16 = new CheckBox();
    this.textBox_11 = new TextBox();
    this.label_60 = new Label();
    this.groupBox_21 = new GroupBox();
    this.numericUpDown_1 = new NumericUpDown();
    this.label_16 = new Label();
    this.numericUpDown_2 = new NumericUpDown();
    this.label_17 = new Label();
    this.label_18 = new Label();
    this.label_19 = new Label();
    this.comboBox_1 = new ComboBox();
    this.numericUpDown_3 = new NumericUpDown();
    this.label_20 = new Label();
    this.button_37 = new Button();
    this.tabPage_6 = new TabPage();
    this.groupBox_22 = new GroupBox();
    this.textBox_12 = new TextBox();
    this.groupBox_23 = new GroupBox();
    this.checkBox_17 = new CheckBox();
    this.checkBox_18 = new CheckBox();
    this.button_38 = new Button();
    this.checkBox_19 = new CheckBox();
    this.checkBox_20 = new CheckBox();
    this.numericUpDown_4 = new NumericUpDown();
    this.numericUpDown_5 = new NumericUpDown();
    this.numericUpDown_6 = new NumericUpDown();
    this.numericUpDown_7 = new NumericUpDown();
    this.numericUpDown_8 = new NumericUpDown();
    this.numericUpDown_9 = new NumericUpDown();
    this.label_21 = new Label();
    this.numericUpDown_10 = new NumericUpDown();
    this.numericUpDown_11 = new NumericUpDown();
    this.numericUpDown_12 = new NumericUpDown();
    this.numericUpDown_13 = new NumericUpDown();
    this.numericUpDown_14 = new NumericUpDown();
    this.numericUpDown_15 = new NumericUpDown();
    this.numericUpDown_16 = new NumericUpDown();
    this.label_22 = new Label();
    this.label_23 = new Label();
    this.label_24 = new Label();
    this.label_25 = new Label();
    this.label_26 = new Label();
    this.label_27 = new Label();
    this.label_28 = new Label();
    this.label_29 = new Label();
    this.label_30 = new Label();
    this.label_31 = new Label();
    this.label_32 = new Label();
    this.label_33 = new Label();
    this.label_34 = new Label();
    this.numericUpDown_17 = new NumericUpDown();
    this.groupBox_24 = new GroupBox();
    this.button_39 = new Button();
    this.label_35 = new Label();
    this.listBox_3 = new ListBox();
    this.button_40 = new Button();
    this.textBox_13 = new TextBox();
    this.comboBox_2 = new ComboBox();
    this.groupBox_25 = new GroupBox();
    this.checkBox_21 = new CheckBox();
    this.numericUpDown_18 = new NumericUpDown();
    this.checkBox_22 = new CheckBox();
    this.checkBox_23 = new CheckBox();
    this.groupBox_26 = new GroupBox();
    this.checkBox_24 = new CheckBox();
    this.checkBox_25 = new CheckBox();
    this.checkBox_26 = new CheckBox();
    this.checkBox_27 = new CheckBox();
    this.checkBox_28 = new CheckBox();
    this.groupBox_27 = new GroupBox();
    this.checkBox_29 = new CheckBox();
    this.checkBox_30 = new CheckBox();
    this.checkBox_31 = new CheckBox();
    this.checkBox_32 = new CheckBox();
    this.checkBox_33 = new CheckBox();
    this.checkBox_34 = new CheckBox();
    this.tabPage_7 = new TabPage();
    this.tabControl_0 = new TabControl();
    this.tabPage_8 = new TabPage();
    this.tableLayoutPanel_0 = new TableLayoutPanel();
    this.tabPage_9 = new TabPage();
    this.tabControl_1 = new TabControl();
    this.tabPage_10 = new TabPage();
    this.groupBox_44 = new GroupBox();
    this.textBox_21 = new TextBox();
    this.checkBox_89 = new CheckBox();
    this.groupBox_28 = new GroupBox();
    this.label_36 = new Label();
    this.numericUpDown_19 = new NumericUpDown();
    this.button_41 = new Button();
    this.checkBox_35 = new CheckBox();
    this.button_42 = new Button();
    this.button_43 = new Button();
    this.textBox_14 = new TextBox();
    this.listBox_4 = new ListBox();
    this.groupBox_29 = new GroupBox();
    this.checkBox_36 = new CheckBox();
    this.checkBox_37 = new CheckBox();
    this.checkBox_38 = new CheckBox();
    this.checkBox_39 = new CheckBox();
    this.checkBox_40 = new CheckBox();
    this.checkBox_41 = new CheckBox();
    this.groupBox_30 = new GroupBox();
    this.checkBox_42 = new CheckBox();
    this.checkBox_43 = new CheckBox();
    this.checkBox_44 = new CheckBox();
    this.groupBox_31 = new GroupBox();
    this.textBox_15 = new TextBox();
    this.comboBox_3 = new ComboBox();
    this.checkBox_45 = new CheckBox();
    this.checkBox_46 = new CheckBox();
    this.checkBox_47 = new CheckBox();
    this.checkBox_48 = new CheckBox();
    this.checkBox_49 = new CheckBox();
    this.checkBox_50 = new CheckBox();
    this.checkBox_51 = new CheckBox();
    this.checkBox_52 = new CheckBox();
    this.textBox_16 = new TextBox();
    this.checkBox_53 = new CheckBox();
    this.checkBox_54 = new CheckBox();
    this.checkBox_55 = new CheckBox();
    this.checkBox_56 = new CheckBox();
    this.checkBox_57 = new CheckBox();
    this.checkBox_58 = new CheckBox();
    this.checkBox_59 = new CheckBox();
    this.checkBox_60 = new CheckBox();
    this.checkBox_61 = new CheckBox();
    this.checkBox_62 = new CheckBox();
    this.checkBox_63 = new CheckBox();
    this.checkBox_64 = new CheckBox();
    this.groupBox_32 = new GroupBox();
    this.checkBox_65 = new CheckBox();
    this.checkBox_66 = new CheckBox();
    this.checkBox_67 = new CheckBox();
    this.label_37 = new Label();
    this.label_38 = new Label();
    this.label_39 = new Label();
    this.trackBar_0 = new TrackBar();
    this.button_44 = new Button();
    this.button_45 = new Button();
    this.comboBox_4 = new ComboBox();
    this.label_40 = new Label();
    this.numericUpDown_20 = new NumericUpDown();
    this.label_41 = new Label();
    this.textBox_17 = new TextBox();
    this.checkBox_68 = new CheckBox();
    this.groupBox_33 = new GroupBox();
    this.checkBox_69 = new CheckBox();
    this.checkBox_70 = new CheckBox();
    this.checkBox_71 = new CheckBox();
    this.checkBox_72 = new CheckBox();
    this.checkBox_73 = new CheckBox();
    this.groupBox_34 = new GroupBox();
    this.checkBox_74 = new CheckBox();
    this.checkBox_75 = new CheckBox();
    this.checkBox_76 = new CheckBox();
    this.groupBox_35 = new GroupBox();
    this.checkBox_77 = new CheckBox();
    this.button_46 = new Button();
    this.button_47 = new Button();
    this.checkBox_78 = new CheckBox();
    this.checkBox_79 = new CheckBox();
    this.label_42 = new Label();
    this.label_43 = new Label();
    this.textBox_18 = new TextBox();
    this.listBox_5 = new ListBox();
    this.groupBox_36 = new GroupBox();
    this.checkBox_80 = new CheckBox();
    this.checkBox_81 = new CheckBox();
    this.checkBox_82 = new CheckBox();
    this.checkBox_83 = new CheckBox();
    this.numericUpDown_21 = new NumericUpDown();
    this.comboBox_5 = new ComboBox();
    this.numericUpDown_22 = new NumericUpDown();
    this.comboBox_6 = new ComboBox();
    this.label_44 = new Label();
    this.comboBox_7 = new ComboBox();
    this.groupBox_37 = new GroupBox();
    this.checkBox_84 = new CheckBox();
    this.checkBox_85 = new CheckBox();
    this.comboBox_8 = new ComboBox();
    this.comboBox_9 = new ComboBox();
    this.tabPage_11 = new TabPage();
    this.tableLayoutPanel_1 = new TableLayoutPanel();
    this.tabPage_12 = new TabPage();
    this.groupBox_38 = new GroupBox();
    this.label_45 = new Label();
    this.label_46 = new Label();
    this.label_47 = new Label();
    this.groupBox_39 = new GroupBox();
    this.button_48 = new Button();
    this.button_49 = new Button();
    this.button_50 = new Button();
    this.button_51 = new Button();
    this.listBox_6 = new ListBox();
    this.class27_0 = new Class27();
    this.groupBox_40 = new GroupBox();
    this.button_52 = new Button();
    this.button_53 = new Button();
    this.button_54 = new Button();
    this.button_55 = new Button();
    this.listBox_7 = new ListBox();
    this.groupBox_41 = new GroupBox();
    this.button_67 = new Button();
    this.button_56 = new Button();
    this.button_57 = new Button();
    this.listBox_8 = new ListBox();
    this.groupBox_42 = new GroupBox();
    this.button_66 = new Button();
    this.label_48 = new Label();
    this.label_49 = new Label();
    this.label_50 = new Label();
    this.label_51 = new Label();
    this.label_52 = new Label();
    this.button_58 = new Button();
    this.button_59 = new Button();
    this.textBox_19 = new TextBox();
    this.button_60 = new Button();
    this.textBox_20 = new TextBox();
    this.button_61 = new Button();
    this.button_62 = new Button();
    this.groupBox_43 = new GroupBox();
    this.label_53 = new Label();
    this.label_54 = new Label();
    this.label_55 = new Label();
    this.label_56 = new Label();
    this.label_57 = new Label();
    this.button_63 = new Button();
    this.button_64 = new Button();
    this.checkBox_86 = new CheckBox();
    this.checkBox_87 = new CheckBox();
    this.button_65 = new Button();
    this.comboBox_10 = new ComboBox();
    this.comboBox_11 = new ComboBox();
    this.label_58 = new Label();
    this.label_59 = new Label();
    this.tabControl_2 = new TabControl();
    this.tabPage_13 = new TabPage();
    this.label_65 = new Label();
    this.groupBox_54 = new GroupBox();
    this.textBox_25 = new TextBox();
    this.checkBox_101 = new CheckBox();
    this.textBox_24 = new TextBox();
    this.checkBox_93 = new CheckBox();
    this.groupBox_49 = new GroupBox();
    this.checkBox_94 = new CheckBox();
    this.checkBox_95 = new CheckBox();
    this.checkBox_96 = new CheckBox();
    this.groupBox_50 = new GroupBox();
    this.label_63 = new Label();
    this.numericUpDown_23 = new NumericUpDown();
    this.radioButton_4 = new RadioButton();
    this.checkBox_97 = new CheckBox();
    this.radioButton_5 = new RadioButton();
    this.textBox_23 = new TextBox();
    this.groupBox_51 = new GroupBox();
    this.checkBox_98 = new CheckBox();
    this.numericUpDown_24 = new NumericUpDown();
    this.label_64 = new Label();
    this.groupBox_52 = new GroupBox();
    this.checkBox_99 = new CheckBox();
    this.checkBox_100 = new CheckBox();
    this.groupBox_53 = new GroupBox();
    this.button_73 = new Button();
    this.menuStrip_0.SuspendLayout();
    this.tabPage_1.SuspendLayout();
    this.groupBox_4.SuspendLayout();
    this.groupBox_3.SuspendLayout();
    this.groupBox_2.SuspendLayout();
    this.groupBox_1.SuspendLayout();
    this.numericUpDown_0.BeginInit();
    this.groupBox_0.SuspendLayout();
    this.tabPage_0.SuspendLayout();
    this.panel_0.SuspendLayout();
    this.panel_1.SuspendLayout();
    this.panel_2.SuspendLayout();
    this.panel_3.SuspendLayout();
    this.toolStrip_0.SuspendLayout();
    this.tabPage_2.SuspendLayout();
    this.groupBox_5.SuspendLayout();
    this.groupBox_6.SuspendLayout();
    this.tabPage_3.SuspendLayout();
    this.groupBox_47.SuspendLayout();
    this.groupBox_7.SuspendLayout();
    this.groupBox_8.SuspendLayout();
    this.groupBox_9.SuspendLayout();
    this.groupBox_10.SuspendLayout();
    this.tabPage_4.SuspendLayout();
    this.groupBox_12.SuspendLayout();
    this.tabPage_5.SuspendLayout();
    this.groupBox_48.SuspendLayout();
    this.groupBox_46.SuspendLayout();
    this.groupBox_45.SuspendLayout();
    this.groupBox_14.SuspendLayout();
    this.groupBox_15.SuspendLayout();
    this.groupBox_16.SuspendLayout();
    this.groupBox_17.SuspendLayout();
    this.groupBox_18.SuspendLayout();
    this.groupBox_19.SuspendLayout();
    this.groupBox_20.SuspendLayout();
    this.groupBox_21.SuspendLayout();
    this.numericUpDown_1.BeginInit();
    this.numericUpDown_2.BeginInit();
    this.numericUpDown_3.BeginInit();
    this.tabPage_6.SuspendLayout();
    this.groupBox_22.SuspendLayout();
    this.groupBox_23.SuspendLayout();
    this.numericUpDown_4.BeginInit();
    this.numericUpDown_5.BeginInit();
    this.numericUpDown_6.BeginInit();
    this.numericUpDown_7.BeginInit();
    this.numericUpDown_8.BeginInit();
    this.numericUpDown_9.BeginInit();
    this.numericUpDown_10.BeginInit();
    this.numericUpDown_11.BeginInit();
    this.numericUpDown_12.BeginInit();
    this.numericUpDown_13.BeginInit();
    this.numericUpDown_14.BeginInit();
    this.numericUpDown_15.BeginInit();
    this.numericUpDown_16.BeginInit();
    this.numericUpDown_17.BeginInit();
    this.groupBox_24.SuspendLayout();
    this.groupBox_25.SuspendLayout();
    this.numericUpDown_18.BeginInit();
    this.groupBox_26.SuspendLayout();
    this.groupBox_27.SuspendLayout();
    this.tabPage_7.SuspendLayout();
    this.tabControl_0.SuspendLayout();
    this.tabPage_8.SuspendLayout();
    this.tabPage_9.SuspendLayout();
    this.tabControl_1.SuspendLayout();
    this.tabPage_10.SuspendLayout();
    this.groupBox_44.SuspendLayout();
    this.groupBox_28.SuspendLayout();
    this.numericUpDown_19.BeginInit();
    this.groupBox_29.SuspendLayout();
    this.groupBox_30.SuspendLayout();
    this.groupBox_31.SuspendLayout();
    this.groupBox_32.SuspendLayout();
    this.trackBar_0.BeginInit();
    this.numericUpDown_20.BeginInit();
    this.groupBox_33.SuspendLayout();
    this.groupBox_34.SuspendLayout();
    this.groupBox_35.SuspendLayout();
    this.groupBox_36.SuspendLayout();
    this.numericUpDown_21.BeginInit();
    this.numericUpDown_22.BeginInit();
    this.groupBox_37.SuspendLayout();
    this.tabPage_11.SuspendLayout();
    this.tabPage_12.SuspendLayout();
    this.groupBox_38.SuspendLayout();
    this.groupBox_39.SuspendLayout();
    this.groupBox_40.SuspendLayout();
    this.groupBox_41.SuspendLayout();
    this.groupBox_42.SuspendLayout();
    this.groupBox_43.SuspendLayout();
    this.tabControl_2.SuspendLayout();
    this.tabPage_13.SuspendLayout();
    this.groupBox_54.SuspendLayout();
    this.groupBox_49.SuspendLayout();
    this.groupBox_50.SuspendLayout();
    this.numericUpDown_23.BeginInit();
    this.groupBox_51.SuspendLayout();
    this.numericUpDown_24.BeginInit();
    this.groupBox_52.SuspendLayout();
    this.SuspendLayout();
    this.menuStrip_0.BackColor = Color.White;
    this.menuStrip_0.GripMargin = new Padding(0);
    this.menuStrip_0.Items.AddRange(new ToolStripItem[8]
    {
      (ToolStripItem) this.toolStripMenuItem_2,
      (ToolStripItem) this.toolStripMenuItem_1,
      (ToolStripItem) this.toolStripMenuItem_0,
      (ToolStripItem) this.toolStripMenuItem_10,
      (ToolStripItem) this.toolStripMenuItem_11,
      (ToolStripItem) this.toolStripMenuItem_3,
      (ToolStripItem) this.toolStripMenuItem_4,
      (ToolStripItem) this.toolStripMenuItem_5
    });
    this.menuStrip_0.Location = new Point(0, 0);
    this.menuStrip_0.Name = \u003CModule\u003E.smethod_5<string>(815177330U);
    this.menuStrip_0.Padding = new Padding(0);
    this.menuStrip_0.Size = new Size(850, 24);
    this.menuStrip_0.TabIndex = 1;
    this.menuStrip_0.Text = \u003CModule\u003E.smethod_8<string>(3526303990U);
    this.toolStripMenuItem_2.ForeColor = Color.Black;
    this.toolStripMenuItem_2.Name = \u003CModule\u003E.smethod_7<string>(3617804102U);
    this.toolStripMenuItem_2.Padding = new Padding(0);
    this.toolStripMenuItem_2.Size = new Size(35, 24);
    this.toolStripMenuItem_2.Text = \u003CModule\u003E.smethod_7<string>(333595514U);
    this.toolStripMenuItem_2.Click += new EventHandler(this.toolStripMenuItem_2_Click);
    this.toolStripMenuItem_1.ForeColor = Color.Black;
    this.toolStripMenuItem_1.Name = \u003CModule\u003E.smethod_9<string>(3245097461U);
    this.toolStripMenuItem_1.Padding = new Padding(0);
    this.toolStripMenuItem_1.Size = new Size(38, 24);
    this.toolStripMenuItem_1.Text = \u003CModule\u003E.smethod_7<string>(1126655165U);
    this.toolStripMenuItem_1.Click += new EventHandler(this.toolStripMenuItem_1_Click);
    this.toolStripMenuItem_0.ForeColor = Color.Black;
    this.toolStripMenuItem_0.Name = \u003CModule\u003E.smethod_8<string>(1598165756U);
    this.toolStripMenuItem_0.Padding = new Padding(0);
    this.toolStripMenuItem_0.Size = new Size(37, 24);
    this.toolStripMenuItem_0.Text = \u003CModule\u003E.smethod_8<string>(1656695981U);
    this.toolStripMenuItem_0.MouseEnter += new EventHandler(this.toolStripMenuItem_0_MouseEnter);
    this.toolStripMenuItem_10.Name = \u003CModule\u003E.smethod_9<string>(4235389930U);
    this.toolStripMenuItem_10.Size = new Size(43, 24);
    this.toolStripMenuItem_10.Text = \u003CModule\u003E.smethod_5<string>(1539335589U);
    this.toolStripMenuItem_10.Click += new EventHandler(this.toolStripMenuItem_10_Click);
    this.toolStripMenuItem_11.Name = \u003CModule\u003E.smethod_6<string>(4145418380U);
    this.toolStripMenuItem_11.Size = new Size(52, 24);
    this.toolStripMenuItem_11.Text = \u003CModule\u003E.smethod_5<string>(2788166951U);
    this.toolStripMenuItem_11.MouseEnter += new EventHandler(this.toolStripMenuItem_11_MouseEnter);
    this.toolStripMenuItem_3.Name = \u003CModule\u003E.smethod_8<string>(2798459016U);
    this.toolStripMenuItem_3.Size = new Size(75, 24);
    this.toolStripMenuItem_3.Text = \u003CModule\u003E.smethod_6<string>(3033259127U);
    this.toolStripMenuItem_3.MouseEnter += new EventHandler(this.toolStripMenuItem_3_MouseEnter);
    this.toolStripMenuItem_4.Name = \u003CModule\u003E.smethod_9<string>(341858097U);
    this.toolStripMenuItem_4.Size = new Size(57, 24);
    this.toolStripMenuItem_4.Text = \u003CModule\u003E.smethod_9<string>(3950384469U);
    this.toolStripMenuItem_4.MouseEnter += new EventHandler(this.toolStripMenuItem_4_MouseEnter);
    this.toolStripMenuItem_5.DropDownItems.AddRange(new ToolStripItem[4]
    {
      (ToolStripItem) this.toolStripMenuItem_6,
      (ToolStripItem) this.toolStripMenuItem_7,
      (ToolStripItem) this.toolStripMenuItem_8,
      (ToolStripItem) this.toolStripMenuItem_9
    });
    this.toolStripMenuItem_5.Name = \u003CModule\u003E.smethod_5<string>(3867490312U);
    this.toolStripMenuItem_5.Size = new Size(63, 24);
    this.toolStripMenuItem_5.Text = \u003CModule\u003E.smethod_7<string>(2361353841U);
    this.toolStripMenuItem_6.Name = \u003CModule\u003E.smethod_8<string>(904078240U);
    this.toolStripMenuItem_6.Size = new Size(137, 22);
    this.toolStripMenuItem_6.Text = \u003CModule\u003E.smethod_9<string>(2018591490U);
    this.toolStripMenuItem_6.Click += new EventHandler(this.toolStripMenuItem_6_Click);
    this.toolStripMenuItem_7.Name = \u003CModule\u003E.smethod_9<string>(1332150566U);
    this.toolStripMenuItem_7.Size = new Size(137, 22);
    this.toolStripMenuItem_7.Text = \u003CModule\u003E.smethod_7<string>(2852736947U);
    this.toolStripMenuItem_7.Click += new EventHandler(this.toolStripMenuItem_7_Click);
    this.toolStripMenuItem_8.Name = \u003CModule\u003E.smethod_8<string>(3651708518U);
    this.toolStripMenuItem_8.Size = new Size(137, 22);
    this.toolStripMenuItem_8.Text = \u003CModule\u003E.smethod_5<string>(1302222271U);
    this.toolStripMenuItem_8.Click += new EventHandler(this.toolStripMenuItem_8_Click);
    this.toolStripMenuItem_9.Name = \u003CModule\u003E.smethod_6<string>(1045960968U);
    this.toolStripMenuItem_9.Size = new Size(137, 22);
    this.toolStripMenuItem_9.Text = \u003CModule\u003E.smethod_9<string>(3215151586U);
    this.toolStripMenuItem_9.Click += new EventHandler(this.toolStripMenuItem_9_Click);
    this.tabPage_1.BackColor = Color.White;
    this.tabPage_1.Controls.Add((Control) this.groupBox_4);
    this.tabPage_1.Controls.Add((Control) this.groupBox_3);
    this.tabPage_1.Controls.Add((Control) this.groupBox_2);
    this.tabPage_1.Controls.Add((Control) this.groupBox_1);
    this.tabPage_1.Controls.Add((Control) this.groupBox_0);
    this.tabPage_1.Location = new Point(4, 24);
    this.tabPage_1.Name = \u003CModule\u003E.smethod_5<string>(447132924U);
    this.tabPage_1.Size = new Size(842, 516);
    this.tabPage_1.TabIndex = 13;
    this.tabPage_1.Text = \u003CModule\u003E.smethod_7<string>(1506068287U);
    this.groupBox_4.Controls.Add((Control) this.label_4);
    this.groupBox_4.Controls.Add((Control) this.textBox_2);
    this.groupBox_4.Controls.Add((Control) this.checkBox_3);
    this.groupBox_4.Controls.Add((Control) this.label_3);
    this.groupBox_4.Controls.Add((Control) this.radioButton_0);
    this.groupBox_4.Controls.Add((Control) this.radioButton_1);
    this.groupBox_4.Controls.Add((Control) this.checkBox_2);
    this.groupBox_4.Location = new Point(284, 196);
    this.groupBox_4.Name = \u003CModule\u003E.smethod_5<string>(2821959443U);
    this.groupBox_4.Size = new Size(487, 121);
    this.groupBox_4.TabIndex = (int) sbyte.MaxValue;
    this.groupBox_4.TabStop = false;
    this.groupBox_4.Text = \u003CModule\u003E.smethod_6<string>(290643934U);
    this.label_4.AutoSize = true;
    this.label_4.Location = new Point(17, 60);
    this.label_4.Name = \u003CModule\u003E.smethod_7<string>(1751759840U);
    this.label_4.Size = new Size(61, 13);
    this.label_4.TabIndex = 197;
    this.label_4.Text = \u003CModule\u003E.smethod_6<string>(136974218U);
    this.textBox_2.Location = new Point(85, 56);
    this.textBox_2.Name = \u003CModule\u003E.smethod_8<string>(3390824118U);
    this.textBox_2.Size = new Size(44, 20);
    this.textBox_2.TabIndex = 134;
    this.textBox_2.Text = \u003CModule\u003E.smethod_5<string>(1111780749U);
    this.textBox_2.TextAlign = HorizontalAlignment.Center;
    this.checkBox_3.AutoSize = true;
    this.checkBox_3.ForeColor = Color.Black;
    this.checkBox_3.Location = new Point(20, 87);
    this.checkBox_3.Name = \u003CModule\u003E.smethod_9<string>(1531711197U);
    this.checkBox_3.Size = new Size(160, 17);
    this.checkBox_3.TabIndex = 133;
    this.checkBox_3.Text = \u003CModule\u003E.smethod_7<string>(109655546U);
    this.checkBox_3.UseVisualStyleBackColor = true;
    this.label_3.AutoSize = true;
    this.label_3.Font = new Font(\u003CModule\u003E.smethod_9<string>(868744759U), 12f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label_3.Location = new Point(306, 22);
    this.label_3.Name = \u003CModule\u003E.smethod_7<string>(2243142946U);
    this.label_3.Size = new Size(123, 21);
    this.label_3.TabIndex = 132;
    this.label_3.Text = \u003CModule\u003E.smethod_7<string>(1478075791U);
    this.label_3.TextAlign = ContentAlignment.MiddleCenter;
    this.radioButton_0.AutoSize = true;
    this.radioButton_0.Checked = true;
    this.radioButton_0.Location = new Point(272, 54);
    this.radioButton_0.Name = \u003CModule\u003E.smethod_6<string>(2053953292U);
    this.radioButton_0.Size = new Size(77, 17);
    this.radioButton_0.TabIndex = 9;
    this.radioButton_0.TabStop = true;
    this.radioButton_0.Text = \u003CModule\u003E.smethod_7<string>(657023644U);
    this.radioButton_0.UseVisualStyleBackColor = true;
    this.radioButton_1.AutoSize = true;
    this.radioButton_1.Location = new Point(373, 54);
    this.radioButton_1.Name = \u003CModule\u003E.smethod_9<string>(237567183U);
    this.radioButton_1.Size = new Size(86, 17);
    this.radioButton_1.TabIndex = 8;
    this.radioButton_1.Text = \u003CModule\u003E.smethod_6<string>(1900283576U);
    this.radioButton_1.UseVisualStyleBackColor = true;
    this.checkBox_2.AutoSize = true;
    this.checkBox_2.ForeColor = Color.Black;
    this.checkBox_2.Location = new Point(20, 32);
    this.checkBox_2.Name = \u003CModule\u003E.smethod_9<string>(3561088094U);
    this.checkBox_2.Size = new Size(131, 17);
    this.checkBox_2.TabIndex = 7;
    this.checkBox_2.Text = \u003CModule\u003E.smethod_9<string>(1325443570U);
    this.checkBox_2.UseVisualStyleBackColor = true;
    this.groupBox_3.Controls.Add((Control) this.label_2);
    this.groupBox_3.Controls.Add((Control) this.textBox_1);
    this.groupBox_3.Controls.Add((Control) this.button_7);
    this.groupBox_3.Controls.Add((Control) this.button_8);
    this.groupBox_3.Controls.Add((Control) this.checkBox_1);
    this.groupBox_3.Location = new Point(17, 196);
    this.groupBox_3.Name = \u003CModule\u003E.smethod_9<string>(3129706756U);
    this.groupBox_3.Size = new Size(261, 121);
    this.groupBox_3.TabIndex = 126;
    this.groupBox_3.TabStop = false;
    this.groupBox_3.Text = \u003CModule\u003E.smethod_9<string>(3992469432U);
    this.label_2.AutoSize = true;
    this.label_2.Location = new Point(7, 21);
    this.label_2.Name = \u003CModule\u003E.smethod_8<string>(1683009441U);
    this.label_2.Size = new Size(225, 26);
    this.label_2.TabIndex = 6;
    this.label_2.Text = \u003CModule\u003E.smethod_5<string>(1092260188U);
    this.textBox_1.Location = new Point(10, 54);
    this.textBox_1.Name = \u003CModule\u003E.smethod_9<string>(31299556U);
    this.textBox_1.Size = new Size(148, 20);
    this.textBox_1.TabIndex = 5;
    this.button_7.FlatStyle = FlatStyle.Flat;
    this.button_7.Font = new Font(\u003CModule\u003E.smethod_9<string>(868744759U), 7f);
    this.button_7.Location = new Point(10, 83);
    this.button_7.Name = \u003CModule\u003E.smethod_6<string>(66655133U);
    this.button_7.Size = new Size(100, 29);
    this.button_7.TabIndex = 4;
    this.button_7.Text = \u003CModule\u003E.smethod_8<string>(3603478657U);
    this.button_7.UseVisualStyleBackColor = true;
    this.button_7.Click += new EventHandler(this.button_7_Click);
    this.button_8.FlatStyle = FlatStyle.Flat;
    this.button_8.Font = new Font(\u003CModule\u003E.smethod_8<string>(2058547965U), 7f);
    this.button_8.Location = new Point(116, 83);
    this.button_8.Name = \u003CModule\u003E.smethod_7<string>(2383105426U);
    this.button_8.Size = new Size(100, 29);
    this.button_8.TabIndex = 3;
    this.button_8.Text = \u003CModule\u003E.smethod_7<string>(1282128319U);
    this.button_8.UseVisualStyleBackColor = true;
    this.button_8.Click += new EventHandler(this.button_8_Click);
    this.checkBox_1.AutoSize = true;
    this.checkBox_1.Enabled = false;
    this.checkBox_1.ForeColor = Color.Black;
    this.checkBox_1.Location = new Point(164, 56);
    this.checkBox_1.Name = \u003CModule\u003E.smethod_5<string>(2861000565U);
    this.checkBox_1.Size = new Size(67, 17);
    this.checkBox_1.TabIndex = 2;
    this.checkBox_1.Text = \u003CModule\u003E.smethod_7<string>(461076172U);
    this.checkBox_1.UseVisualStyleBackColor = true;
    this.checkBox_1.CheckedChanged += new EventHandler(this.checkBox_1_CheckedChanged);
    this.groupBox_2.Controls.Add((Control) this.label_1);
    this.groupBox_2.Controls.Add((Control) this.label_0);
    this.groupBox_2.Controls.Add((Control) this.textBox_0);
    this.groupBox_2.Location = new Point(257, 18);
    this.groupBox_2.Name = \u003CModule\u003E.smethod_8<string>(1844802773U);
    this.groupBox_2.Size = new Size(514, 172);
    this.groupBox_2.TabIndex = 9;
    this.groupBox_2.TabStop = false;
    this.groupBox_2.Text = \u003CModule\u003E.smethod_8<string>(3525213337U);
    this.label_1.AutoSize = true;
    this.label_1.Location = new Point(322, 94);
    this.label_1.Name = \u003CModule\u003E.smethod_7<string>(3717292264U);
    this.label_1.Size = new Size(54, 13);
    this.label_1.TabIndex = 196;
    this.label_1.Text = \u003CModule\u003E.smethod_9<string>(1464073154U);
    this.label_0.AutoSize = true;
    this.label_0.Location = new Point(322, 33);
    this.label_0.Name = \u003CModule\u003E.smethod_6<string>(644862756U);
    this.label_0.Size = new Size(56, 13);
    this.label_0.TabIndex = 194;
    this.label_0.Text = \u003CModule\u003E.smethod_9<string>(4033515098U);
    this.textBox_0.Location = new Point(17, 33);
    this.textBox_0.Multiline = true;
    this.textBox_0.Name = \u003CModule\u003E.smethod_6<string>(2301381788U);
    this.textBox_0.ScrollBars = ScrollBars.Both;
    this.textBox_0.Size = new Size(288, 105);
    this.textBox_0.TabIndex = 193;
    this.groupBox_1.Controls.Add((Control) this.button_6);
    this.groupBox_1.Controls.Add((Control) this.numericUpDown_0);
    this.groupBox_1.Location = new Point(17, 112);
    this.groupBox_1.Name = \u003CModule\u003E.smethod_9<string>(4161044891U);
    this.groupBox_1.Size = new Size(222, 78);
    this.groupBox_1.TabIndex = 8;
    this.groupBox_1.TabStop = false;
    this.groupBox_1.Text = \u003CModule\u003E.smethod_6<string>(1603352293U);
    this.button_6.FlatStyle = FlatStyle.Flat;
    this.button_6.Font = new Font(\u003CModule\u003E.smethod_7<string>(1521212547U), 7f);
    this.button_6.Location = new Point(116, 32);
    this.button_6.Name = \u003CModule\u003E.smethod_8<string>(3178169579U);
    this.button_6.Size = new Size(100, 29);
    this.button_6.TabIndex = 2;
    this.button_6.Text = \u003CModule\u003E.smethod_7<string>(3934991321U);
    this.button_6.UseVisualStyleBackColor = true;
    this.button_6.Click += new EventHandler(this.button_6_Click);
    this.numericUpDown_0.Location = new Point(31, 36);
    this.numericUpDown_0.Maximum = new Decimal(new int[4]
    {
      999,
      0,
      0,
      0
    });
    this.numericUpDown_0.Name = \u003CModule\u003E.smethod_5<string>(167183480U);
    this.numericUpDown_0.Size = new Size(49, 20);
    this.numericUpDown_0.TabIndex = 1;
    this.groupBox_0.Controls.Add((Control) this.button_0);
    this.groupBox_0.Controls.Add((Control) this.button_1);
    this.groupBox_0.Controls.Add((Control) this.button_5);
    this.groupBox_0.Controls.Add((Control) this.button_2);
    this.groupBox_0.Location = new Point(17, 18);
    this.groupBox_0.Name = \u003CModule\u003E.smethod_7<string>(1499827376U);
    this.groupBox_0.Size = new Size(222, 88);
    this.groupBox_0.TabIndex = 7;
    this.groupBox_0.TabStop = false;
    this.groupBox_0.Text = \u003CModule\u003E.smethod_6<string>(2692071851U);
    this.button_0.FlatStyle = FlatStyle.Flat;
    this.button_0.Font = new Font(\u003CModule\u003E.smethod_9<string>(868744759U), 7f);
    this.button_0.Location = new Point(6, 50);
    this.button_0.Name = \u003CModule\u003E.smethod_6<string>(337523324U);
    this.button_0.Size = new Size(100, 29);
    this.button_0.TabIndex = 0;
    this.button_0.Text = \u003CModule\u003E.smethod_5<string>(2050665179U);
    this.button_0.UseVisualStyleBackColor = true;
    this.button_0.Click += new EventHandler(this.button_0_Click);
    this.button_1.FlatStyle = FlatStyle.Flat;
    this.button_1.Font = new Font(\u003CModule\u003E.smethod_5<string>(2184462853U), 7f);
    this.button_1.Location = new Point(6, 15);
    this.button_1.Name = \u003CModule\u003E.smethod_7<string>(3253901654U);
    this.button_1.Size = new Size(100, 29);
    this.button_1.TabIndex = 0;
    this.button_1.Text = \u003CModule\u003E.smethod_8<string>(2831125821U);
    this.button_1.UseVisualStyleBackColor = true;
    this.button_1.Click += new EventHandler(this.button_1_Click);
    this.button_5.FlatStyle = FlatStyle.Flat;
    this.button_5.Font = new Font(\u003CModule\u003E.smethod_8<string>(2058547965U), 7f);
    this.button_5.Location = new Point(116, 50);
    this.button_5.Name = \u003CModule\u003E.smethod_6<string>(1840372640U);
    this.button_5.Size = new Size(100, 29);
    this.button_5.TabIndex = 124;
    this.button_5.Text = \u003CModule\u003E.smethod_5<string>(404761007U);
    this.button_5.UseVisualStyleBackColor = true;
    this.button_5.Click += new EventHandler(this.button_5_Click);
    this.button_2.FlatStyle = FlatStyle.Flat;
    this.button_2.Font = new Font(\u003CModule\u003E.smethod_6<string>(2348004861U), 7f);
    this.button_2.Location = new Point(116, 15);
    this.button_2.Name = \u003CModule\u003E.smethod_5<string>(2520107394U);
    this.button_2.Size = new Size(100, 29);
    this.button_2.TabIndex = 0;
    this.button_2.Text = \u003CModule\u003E.smethod_7<string>(3471600711U);
    this.button_2.UseVisualStyleBackColor = true;
    this.button_2.Click += new EventHandler(this.button_2_Click);
    this.checkBox_0.AutoSize = true;
    this.checkBox_0.BackColor = Color.White;
    this.checkBox_0.ForeColor = Color.Black;
    this.checkBox_0.Location = new Point(794, 3);
    this.checkBox_0.Name = \u003CModule\u003E.smethod_8<string>(3311243125U);
    this.checkBox_0.Size = new Size(46, 19);
    this.checkBox_0.TabIndex = 4;
    this.checkBox_0.Text = \u003CModule\u003E.smethod_7<string>(3197916662U);
    this.checkBox_0.UseVisualStyleBackColor = false;
    this.checkBox_0.CheckedChanged += new EventHandler(this.checkBox_0_CheckedChanged);
    this.tabPage_0.Controls.Add((Control) this.panel_0);
    this.tabPage_0.Controls.Add((Control) this.panel_2);
    this.tabPage_0.Controls.Add((Control) this.toolStrip_0);
    this.tabPage_0.Location = new Point(4, 27);
    this.tabPage_0.Name = \u003CModule\u003E.smethod_5<string>(938477744U);
    this.tabPage_0.Size = new Size(842, 513);
    this.tabPage_0.TabIndex = 9;
    this.tabPage_0.Text = \u003CModule\u003E.smethod_8<string>(3737867876U);
    this.tabPage_0.UseVisualStyleBackColor = true;
    this.panel_0.Controls.Add((Control) this.listBox_0);
    this.panel_0.Controls.Add((Control) this.panel_1);
    this.panel_0.Dock = DockStyle.Fill;
    this.panel_0.Location = new Point(0, 25);
    this.panel_0.Name = \u003CModule\u003E.smethod_8<string>(2244023411U);
    this.panel_0.Size = new Size(842, 388);
    this.panel_0.TabIndex = 1;
    this.listBox_0.Dock = DockStyle.Fill;
    this.listBox_0.Font = new Font(\u003CModule\u003E.smethod_8<string>(2003964759U), 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.listBox_0.FormattingEnabled = true;
    this.listBox_0.ItemHeight = 14;
    this.listBox_0.Location = new Point(0, 0);
    this.listBox_0.Name = \u003CModule\u003E.smethod_9<string>(3328228090U);
    this.listBox_0.Size = new Size(544, 388);
    this.listBox_0.TabIndex = 0;
    this.listBox_0.SelectedIndexChanged += new EventHandler(this.listBox_0_SelectedIndexChanged);
    this.listBox_0.KeyDown += new KeyEventHandler(this.listBox_0_KeyDown);
    this.listBox_0.MouseDoubleClick += new MouseEventHandler(this.listBox_0_MouseDoubleClick);
    this.panel_1.Controls.Add((Control) this.richTextBox_0);
    this.panel_1.Controls.Add((Control) this.richTextBox_1);
    this.panel_1.Dock = DockStyle.Right;
    this.panel_1.Location = new Point(544, 0);
    this.panel_1.Name = \u003CModule\u003E.smethod_9<string>(2641787166U);
    this.panel_1.Size = new Size(298, 388);
    this.panel_1.TabIndex = 1;
    this.richTextBox_0.BackColor = SystemColors.Window;
    this.richTextBox_0.Dock = DockStyle.Fill;
    this.richTextBox_0.Font = new Font(\u003CModule\u003E.smethod_9<string>(826424189U), 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.richTextBox_0.Location = new Point(0, 0);
    this.richTextBox_0.Name = \u003CModule\u003E.smethod_5<string>(2615328155U);
    this.richTextBox_0.ReadOnly = true;
    this.richTextBox_0.ScrollBars = RichTextBoxScrollBars.ForcedVertical;
    this.richTextBox_0.Size = new Size(298, 292);
    this.richTextBox_0.TabIndex = 0;
    this.richTextBox_0.Text = "";
    this.richTextBox_1.BackColor = SystemColors.Window;
    this.richTextBox_1.Dock = DockStyle.Bottom;
    this.richTextBox_1.Font = new Font(\u003CModule\u003E.smethod_6<string>(574543671U), 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.richTextBox_1.Location = new Point(0, 292);
    this.richTextBox_1.Name = \u003CModule\u003E.smethod_6<string>(3416164438U);
    this.richTextBox_1.ReadOnly = true;
    this.richTextBox_1.ScrollBars = RichTextBoxScrollBars.ForcedVertical;
    this.richTextBox_1.Size = new Size(298, 96);
    this.richTextBox_1.TabIndex = 1;
    this.richTextBox_1.Text = "";
    this.panel_2.Controls.Add((Control) this.richTextBox_2);
    this.panel_2.Controls.Add((Control) this.panel_3);
    this.panel_2.Dock = DockStyle.Bottom;
    this.panel_2.Location = new Point(0, 413);
    this.panel_2.Name = \u003CModule\u003E.smethod_9<string>(2945638711U);
    this.panel_2.Size = new Size(842, 100);
    this.panel_2.TabIndex = 2;
    this.richTextBox_2.Dock = DockStyle.Fill;
    this.richTextBox_2.Font = new Font(\u003CModule\u003E.smethod_8<string>(2003964759U), 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.richTextBox_2.Location = new Point(0, 0);
    this.richTextBox_2.Name = \u003CModule\u003E.smethod_5<string>(3875585195U);
    this.richTextBox_2.Size = new Size(742, 100);
    this.richTextBox_2.TabIndex = 0;
    this.richTextBox_2.Text = "";
    this.panel_3.Controls.Add((Control) this.button_3);
    this.panel_3.Controls.Add((Control) this.button_4);
    this.panel_3.Dock = DockStyle.Right;
    this.panel_3.Location = new Point(742, 0);
    this.panel_3.Name = \u003CModule\u003E.smethod_5<string>(1695964286U);
    this.panel_3.Size = new Size(100, 100);
    this.panel_3.TabIndex = 1;
    this.button_3.Dock = DockStyle.Bottom;
    this.button_3.Location = new Point(0, 50);
    this.button_3.Name = \u003CModule\u003E.smethod_7<string>(3683058857U);
    this.button_3.Size = new Size(100, 50);
    this.button_3.TabIndex = 1;
    this.button_3.Text = \u003CModule\u003E.smethod_8<string>(27371644U);
    this.button_3.UseVisualStyleBackColor = true;
    this.button_3.Click += new EventHandler(this.button_3_Click);
    this.button_4.Dock = DockStyle.Top;
    this.button_4.Location = new Point(0, 0);
    this.button_4.Name = \u003CModule\u003E.smethod_9<string>(3024376545U);
    this.button_4.Size = new Size(100, 50);
    this.button_4.TabIndex = 0;
    this.button_4.Text = \u003CModule\u003E.smethod_5<string>(4280752888U);
    this.button_4.UseVisualStyleBackColor = true;
    this.button_4.Click += new EventHandler(this.button_4_Click);
    this.toolStrip_0.Items.AddRange(new ToolStripItem[7]
    {
      (ToolStripItem) this.toolStripLabel_0,
      (ToolStripItem) this.toolStripButton_0,
      (ToolStripItem) this.toolStripButton_1,
      (ToolStripItem) this.toolStripSeparator_0,
      (ToolStripItem) this.toolStripButton_2,
      (ToolStripItem) this.toolStripSeparator_1,
      (ToolStripItem) this.toolStripButton_3
    });
    this.toolStrip_0.Location = new Point(0, 0);
    this.toolStrip_0.Name = \u003CModule\u003E.smethod_9<string>(3710817469U);
    this.toolStrip_0.Size = new Size(842, 25);
    this.toolStrip_0.TabIndex = 0;
    this.toolStripLabel_0.Name = \u003CModule\u003E.smethod_7<string>(2784270133U);
    this.toolStripLabel_0.Size = new Size(30, 22);
    this.toolStripLabel_0.Text = \u003CModule\u003E.smethod_6<string>(2126895774U);
    this.toolStripButton_0.CheckOnClick = true;
    this.toolStripButton_0.DisplayStyle = ToolStripItemDisplayStyle.Text;
    this.toolStripButton_0.ImageTransparentColor = Color.Magenta;
    this.toolStripButton_0.Name = \u003CModule\u003E.smethod_8<string>(2187899512U);
    this.toolStripButton_0.Size = new Size(37, 22);
    this.toolStripButton_0.Text = \u003CModule\u003E.smethod_9<string>(3956287775U);
    this.toolStripButton_1.CheckOnClick = true;
    this.toolStripButton_1.DisplayStyle = ToolStripItemDisplayStyle.Text;
    this.toolStripButton_1.ImageTransparentColor = Color.Magenta;
    this.toolStripButton_1.Name = \u003CModule\u003E.smethod_6<string>(1428866279U);
    this.toolStripButton_1.Size = new Size(36, 22);
    this.toolStripButton_1.Text = \u003CModule\u003E.smethod_5<string>(1078452466U);
    this.toolStripSeparator_0.Name = \u003CModule\u003E.smethod_7<string>(3605322280U);
    this.toolStripSeparator_0.Size = new Size(6, 25);
    this.toolStripButton_2.DisplayStyle = ToolStripItemDisplayStyle.Text;
    this.toolStripButton_2.ImageTransparentColor = Color.Magenta;
    this.toolStripButton_2.Name = \u003CModule\u003E.smethod_5<string>(3856064634U);
    this.toolStripButton_2.Size = new Size(38, 22);
    this.toolStripButton_2.Text = \u003CModule\u003E.smethod_9<string>(1009452937U);
    this.toolStripButton_2.Click += new EventHandler(this.toolStripButton_2_Click);
    this.toolStripSeparator_1.Name = \u003CModule\u003E.smethod_8<string>(293518736U);
    this.toolStripSeparator_1.Size = new Size(6, 25);
    this.toolStripButton_3.CheckOnClick = true;
    this.toolStripButton_3.DisplayStyle = ToolStripItemDisplayStyle.Text;
    this.toolStripButton_3.ImageTransparentColor = Color.Magenta;
    this.toolStripButton_3.Name = \u003CModule\u003E.smethod_8<string>(2080914406U);
    this.toolStripButton_3.Size = new Size(82, 22);
    this.toolStripButton_3.Text = \u003CModule\u003E.smethod_8<string>(587069941U);
    this.toolStripButton_3.Click += new EventHandler(this.toolStripButton_3_Click);
    this.label_5.Location = new Point(407, 2);
    this.label_5.Name = \u003CModule\u003E.smethod_8<string>(1253753344U);
    this.label_5.Size = new Size(377, 18);
    this.label_5.TabIndex = 5;
    this.label_5.Text = \u003CModule\u003E.smethod_9<string>(741450573U);
    this.label_5.TextAlign = ContentAlignment.MiddleLeft;
    this.tabPage_2.Controls.Add((Control) this.groupBox_5);
    this.tabPage_2.Controls.Add((Control) this.groupBox_6);
    this.tabPage_2.Location = new Point(4, 22);
    this.tabPage_2.Name = \u003CModule\u003E.smethod_7<string>(3823021337U);
    this.tabPage_2.Size = new Size(842, 518);
    this.tabPage_2.TabIndex = 9;
    this.tabPage_2.Text = \u003CModule\u003E.smethod_7<string>(321113692U);
    this.tabPage_2.UseVisualStyleBackColor = true;
    this.groupBox_5.Controls.Add((Control) this.label_6);
    this.groupBox_5.Controls.Add((Control) this.label_7);
    this.groupBox_5.Controls.Add((Control) this.button_9);
    this.groupBox_5.Controls.Add((Control) this.label_8);
    this.groupBox_5.Location = new Point(21, 390);
    this.groupBox_5.Name = \u003CModule\u003E.smethod_8<string>(1547304549U);
    this.groupBox_5.Size = new Size(797, 125);
    this.groupBox_5.TabIndex = 13;
    this.groupBox_5.TabStop = false;
    this.groupBox_5.Text = \u003CModule\u003E.smethod_6<string>(4207952713U);
    this.label_6.AutoSize = true;
    this.label_6.Font = new Font(\u003CModule\u003E.smethod_5<string>(2184462853U), 11.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label_6.ForeColor = Color.Black;
    this.label_6.Location = new Point(118, 19);
    this.label_6.Name = \u003CModule\u003E.smethod_6<string>(1853404186U);
    this.label_6.Size = new Size(232, 100);
    this.label_6.TabIndex = 196;
    this.label_6.Text = \u003CModule\u003E.smethod_8<string>(1522531782U);
    this.label_6.TextAlign = ContentAlignment.MiddleLeft;
    this.label_7.AutoSize = true;
    this.label_7.Font = new Font(\u003CModule\u003E.smethod_8<string>(2058547965U), 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label_7.ForeColor = Color.Black;
    this.label_7.Location = new Point(356, 25);
    this.label_7.Name = \u003CModule\u003E.smethod_7<string>(3732802938U);
    this.label_7.Size = new Size(228, 90);
    this.label_7.TabIndex = 195;
    this.label_7.Text = \u003CModule\u003E.smethod_8<string>(3443000998U);
    this.label_7.TextAlign = ContentAlignment.MiddleLeft;
    this.button_9.FlatStyle = FlatStyle.Flat;
    this.button_9.ForeColor = Color.Black;
    this.button_9.Location = new Point(632, 41);
    this.button_9.Name = \u003CModule\u003E.smethod_6<string>(954825585U);
    this.button_9.Size = new Size(144, 47);
    this.button_9.TabIndex = 194;
    this.button_9.Text = \u003CModule\u003E.smethod_6<string>(2481114596U);
    this.button_9.UseVisualStyleBackColor = true;
    this.button_9.Click += new EventHandler(this.button_9_Click);
    this.label_8.AutoSize = true;
    this.label_8.Font = new Font(\u003CModule\u003E.smethod_7<string>(1521212547U), 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label_8.ForeColor = Color.Black;
    this.label_8.Location = new Point(11, 19);
    this.label_8.Name = \u003CModule\u003E.smethod_7<string>(2504345173U);
    this.label_8.Size = new Size(71, 90);
    this.label_8.TabIndex = 18;
    this.label_8.Text = \u003CModule\u003E.smethod_9<string>(3181852213U);
    this.label_8.TextAlign = ContentAlignment.MiddleLeft;
    this.groupBox_6.Controls.Add((Control) this.label_9);
    this.groupBox_6.Controls.Add((Control) this.checkBox_4);
    this.groupBox_6.Controls.Add((Control) this.button_10);
    this.groupBox_6.Controls.Add((Control) this.textBox_3);
    this.groupBox_6.Controls.Add((Control) this.checkBox_5);
    this.groupBox_6.Controls.Add((Control) this.button_11);
    this.groupBox_6.Controls.Add((Control) this.textBox_4);
    this.groupBox_6.Controls.Add((Control) this.checkBox_6);
    this.groupBox_6.Controls.Add((Control) this.button_12);
    this.groupBox_6.Controls.Add((Control) this.textBox_5);
    this.groupBox_6.Controls.Add((Control) this.checkBox_7);
    this.groupBox_6.Controls.Add((Control) this.button_13);
    this.groupBox_6.Controls.Add((Control) this.textBox_6);
    this.groupBox_6.Location = new Point(21, 14);
    this.groupBox_6.Name = \u003CModule\u003E.smethod_7<string>(370857773U);
    this.groupBox_6.Size = new Size(797, 370);
    this.groupBox_6.TabIndex = 12;
    this.groupBox_6.TabStop = false;
    this.groupBox_6.Text = \u003CModule\u003E.smethod_9<string>(1808970365U);
    this.label_9.AutoSize = true;
    this.label_9.Font = new Font(\u003CModule\u003E.smethod_6<string>(2348004861U), 11.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.label_9.ForeColor = Color.Red;
    this.label_9.Location = new Point(-2, 18);
    this.label_9.Name = \u003CModule\u003E.smethod_5<string>(3042398453U);
    this.label_9.Size = new Size(799, 20);
    this.label_9.TabIndex = 197;
    this.label_9.Text = \u003CModule\u003E.smethod_8<string>(1767853126U);
    this.label_9.TextAlign = ContentAlignment.MiddleLeft;
    this.checkBox_4.AutoSize = true;
    this.checkBox_4.Checked = true;
    this.checkBox_4.CheckState = CheckState.Checked;
    this.checkBox_4.Location = new Point(659, 346);
    this.checkBox_4.Name = \u003CModule\u003E.smethod_8<string>(2247970430U);
    this.checkBox_4.Size = new Size(90, 19);
    this.checkBox_4.TabIndex = 210;
    this.checkBox_4.Text = \u003CModule\u003E.smethod_7<string>(2796935162U);
    this.checkBox_4.UseVisualStyleBackColor = true;
    this.button_10.FlatStyle = FlatStyle.Flat;
    this.button_10.ForeColor = Color.Black;
    this.button_10.Location = new Point(626, 316);
    this.button_10.Name = \u003CModule\u003E.smethod_8<string>(3688322342U);
    this.button_10.Size = new Size(150, 24);
    this.button_10.TabIndex = 212;
    this.button_10.Text = \u003CModule\u003E.smethod_8<string>(3448263690U);
    this.button_10.UseVisualStyleBackColor = true;
    this.button_10.Click += new EventHandler(this.button_13_Click);
    this.textBox_3.Location = new Point(626, 48);
    this.textBox_3.Multiline = true;
    this.textBox_3.Name = \u003CModule\u003E.smethod_9<string>(3126353258U);
    this.textBox_3.Size = new Size(150, 262);
    this.textBox_3.TabIndex = 211;
    this.textBox_3.WordWrap = false;
    this.checkBox_5.AutoSize = true;
    this.checkBox_5.Checked = true;
    this.checkBox_5.CheckState = CheckState.Checked;
    this.checkBox_5.Location = new Point(464, 346);
    this.checkBox_5.Name = \u003CModule\u003E.smethod_7<string>(2277559560U);
    this.checkBox_5.Size = new Size(90, 19);
    this.checkBox_5.TabIndex = 204;
    this.checkBox_5.Text = \u003CModule\u003E.smethod_5<string>(3447566146U);
    this.checkBox_5.UseVisualStyleBackColor = true;
    this.button_11.FlatStyle = FlatStyle.Flat;
    this.button_11.ForeColor = Color.Black;
    this.button_11.Location = new Point(431, 316);
    this.button_11.Name = \u003CModule\u003E.smethod_9<string>(204267810U);
    this.button_11.Size = new Size(150, 24);
    this.button_11.TabIndex = 206;
    this.button_11.Text = \u003CModule\u003E.smethod_8<string>(2140985324U);
    this.button_11.UseVisualStyleBackColor = true;
    this.button_11.Click += new EventHandler(this.button_13_Click);
    this.textBox_4.Location = new Point(431, 48);
    this.textBox_4.Multiline = true;
    this.textBox_4.Name = \u003CModule\u003E.smethod_8<string>(1553882914U);
    this.textBox_4.Size = new Size(150, 262);
    this.textBox_4.TabIndex = 205;
    this.textBox_4.WordWrap = false;
    this.checkBox_6.AutoSize = true;
    this.checkBox_6.Checked = true;
    this.checkBox_6.CheckState = CheckState.Checked;
    this.checkBox_6.Location = new Point(261, 346);
    this.checkBox_6.Name = \u003CModule\u003E.smethod_5<string>(1569797286U);
    this.checkBox_6.Size = new Size(90, 19);
    this.checkBox_6.TabIndex = 198;
    this.checkBox_6.Text = \u003CModule\u003E.smethod_6<string>(3225938042U);
    this.checkBox_6.UseVisualStyleBackColor = true;
    this.button_12.FlatStyle = FlatStyle.Flat;
    this.button_12.ForeColor = Color.Black;
    this.button_12.Location = new Point(229, 316);
    this.button_12.Name = \u003CModule\u003E.smethod_8<string>(1073765610U);
    this.button_12.Size = new Size(150, 24);
    this.button_12.TabIndex = 200;
    this.button_12.Text = \u003CModule\u003E.smethod_5<string>(52442158U);
    this.button_12.UseVisualStyleBackColor = true;
    this.button_12.Click += new EventHandler(this.button_13_Click);
    this.textBox_5.Location = new Point(229, 48);
    this.textBox_5.Multiline = true;
    this.textBox_5.Name = \u003CModule\u003E.smethod_7<string>(1105086787U);
    this.textBox_5.Size = new Size(150, 262);
    this.textBox_5.TabIndex = 199;
    this.textBox_5.WordWrap = false;
    this.checkBox_7.AutoSize = true;
    this.checkBox_7.Checked = true;
    this.checkBox_7.CheckState = CheckState.Checked;
    this.checkBox_7.Location = new Point(58, 346);
    this.checkBox_7.Name = \u003CModule\u003E.smethod_6<string>(4291217905U);
    this.checkBox_7.Size = new Size(90, 19);
    this.checkBox_7.TabIndex = 158;
    this.checkBox_7.Text = \u003CModule\u003E.smethod_8<string>(3928380994U);
    this.checkBox_7.UseVisualStyleBackColor = true;
    this.button_13.FlatStyle = FlatStyle.Flat;
    this.button_13.ForeColor = Color.Black;
    this.button_13.Location = new Point(29, 316);
    this.button_13.Name = \u003CModule\u003E.smethod_5<string>(2039239501U);
    this.button_13.Size = new Size(150, 24);
    this.button_13.TabIndex = 193;
    this.button_13.Text = \u003CModule\u003E.smethod_6<string>(1652769641U);
    this.button_13.UseVisualStyleBackColor = true;
    this.button_13.Click += new EventHandler(this.button_13_Click);
    this.textBox_6.Location = new Point(29, 48);
    this.textBox_6.Multiline = true;
    this.textBox_6.Name = \u003CModule\u003E.smethod_8<string>(1206839156U);
    this.textBox_6.RightToLeft = RightToLeft.No;
    this.textBox_6.Size = new Size(150, 262);
    this.textBox_6.TabIndex = 192;
    this.textBox_6.WordWrap = false;
    this.tabPage_3.Controls.Add((Control) this.groupBox_47);
    this.tabPage_3.Controls.Add((Control) this.groupBox_7);
    this.tabPage_3.Controls.Add((Control) this.groupBox_8);
    this.tabPage_3.Controls.Add((Control) this.groupBox_9);
    this.tabPage_3.Controls.Add((Control) this.groupBox_10);
    this.tabPage_3.Location = new Point(4, 22);
    this.tabPage_3.Name = \u003CModule\u003E.smethod_6<string>(1368869904U);
    this.tabPage_3.Size = new Size(842, 518);
    this.tabPage_3.TabIndex = 11;
    this.tabPage_3.Text = \u003CModule\u003E.smethod_6<string>(2066899399U);
    this.tabPage_3.UseVisualStyleBackColor = true;
    this.groupBox_47.Controls.Add((Control) this.label_61);
    this.groupBox_47.Controls.Add((Control) this.button_71);
    this.groupBox_47.Location = new Point(9, 198);
    this.groupBox_47.Name = \u003CModule\u003E.smethod_7<string>(1322785844U);
    this.groupBox_47.Size = new Size(408, 88);
    this.groupBox_47.TabIndex = 158;
    this.groupBox_47.TabStop = false;
    this.groupBox_47.Text = \u003CModule\u003E.smethod_8<string>(3180800925U);
    this.label_61.AutoSize = true;
    this.label_61.Location = new Point(206, 32);
    this.label_61.Name = \u003CModule\u003E.smethod_7<string>(1670444790U);
    this.label_61.Size = new Size(177, 30);
    this.label_61.TabIndex = 156;
    this.label_61.Text = \u003CModule\u003E.smethod_9<string>(3351466969U);
    this.label_61.TextAlign = ContentAlignment.MiddleCenter;
    this.button_71.FlatStyle = FlatStyle.Flat;
    this.button_71.Font = new Font(\u003CModule\u003E.smethod_6<string>(2348004861U), 11.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.button_71.Location = new Point(25, 22);
    this.button_71.Name = \u003CModule\u003E.smethod_5<string>(175278363U);
    this.button_71.Size = new Size(132, 49);
    this.button_71.TabIndex = 2;
    this.button_71.Text = \u003CModule\u003E.smethod_5<string>(1564084447U);
    this.button_71.UseVisualStyleBackColor = true;
    this.button_71.Click += new EventHandler(this.button_71_Click);
    this.groupBox_7.Controls.Add((Control) this.label_10);
    this.groupBox_7.Controls.Add((Control) this.button_14);
    this.groupBox_7.Location = new Point(423, 104);
    this.groupBox_7.Name = \u003CModule\u003E.smethod_6<string>(3887496296U);
    this.groupBox_7.Size = new Size(408, 88);
    this.groupBox_7.TabIndex = 157;
    this.groupBox_7.TabStop = false;
    this.groupBox_7.Text = \u003CModule\u003E.smethod_5<string>(2226350228U);
    this.label_10.AutoSize = true;
    this.label_10.Location = new Point(224, 32);
    this.label_10.Name = \u003CModule\u003E.smethod_8<string>(1368632488U);
    this.label_10.Size = new Size(133, 30);
    this.label_10.TabIndex = 156;
    this.label_10.Text = \u003CModule\u003E.smethod_6<string>(2361207285U);
    this.label_10.TextAlign = ContentAlignment.MiddleCenter;
    this.button_14.FlatStyle = FlatStyle.Flat;
    this.button_14.Font = new Font(\u003CModule\u003E.smethod_5<string>(2184462853U), 11.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.button_14.Location = new Point(25, 22);
    this.button_14.Name = \u003CModule\u003E.smethod_6<string>(2207537569U);
    this.button_14.Size = new Size(132, 49);
    this.button_14.TabIndex = 2;
    this.button_14.Text = \u003CModule\u003E.smethod_6<string>(2929006759U);
    this.button_14.UseVisualStyleBackColor = true;
    this.button_14.Click += new EventHandler(this.button_14_Click);
    this.groupBox_8.Controls.Add((Control) this.label_11);
    this.groupBox_8.Controls.Add((Control) this.button_15);
    this.groupBox_8.Location = new Point(9, 104);
    this.groupBox_8.Name = \u003CModule\u003E.smethod_9<string>(2754863670U);
    this.groupBox_8.Size = new Size(408, 88);
    this.groupBox_8.TabIndex = 6;
    this.groupBox_8.TabStop = false;
    this.groupBox_8.Text = \u003CModule\u003E.smethod_7<string>(1260559941U);
    this.label_11.AutoSize = true;
    this.label_11.Location = new Point(225, 32);
    this.label_11.Name = \u003CModule\u003E.smethod_7<string>(3667731390U);
    this.label_11.Size = new Size(133, 30);
    this.label_11.TabIndex = 156;
    this.label_11.Text = \u003CModule\u003E.smethod_9<string>(1862155119U);
    this.label_11.TextAlign = ContentAlignment.MiddleCenter;
    this.button_15.FlatStyle = FlatStyle.Flat;
    this.button_15.Font = new Font(\u003CModule\u003E.smethod_7<string>(1521212547U), 11.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.button_15.Location = new Point(25, 22);
    this.button_15.Name = \u003CModule\u003E.smethod_8<string>(1021588730U);
    this.button_15.Size = new Size(132, 49);
    this.button_15.TabIndex = 2;
    this.button_15.Text = \u003CModule\u003E.smethod_9<string>(2803655629U);
    this.button_15.UseVisualStyleBackColor = true;
    this.button_15.Click += new EventHandler(this.button_15_Click);
    this.groupBox_9.Controls.Add((Control) this.label_12);
    this.groupBox_9.Controls.Add((Control) this.button_16);
    this.groupBox_9.Location = new Point(423, 10);
    this.groupBox_9.Name = \u003CModule\u003E.smethod_7<string>(1126838372U);
    this.groupBox_9.Size = new Size(408, 88);
    this.groupBox_9.TabIndex = 5;
    this.groupBox_9.TabStop = false;
    this.groupBox_9.Text = \u003CModule\u003E.smethod_9<string>(2087268830U);
    this.label_12.AutoSize = true;
    this.label_12.Location = new Point(176, 26);
    this.label_12.Name = \u003CModule\u003E.smethod_8<string>(2995550499U);
    this.label_12.Size = new Size(220, 45);
    this.label_12.TabIndex = 158;
    this.label_12.Text = \u003CModule\u003E.smethod_9<string>(3460150678U);
    this.label_12.TextAlign = ContentAlignment.MiddleCenter;
    this.button_16.FlatStyle = FlatStyle.Flat;
    this.button_16.Font = new Font(\u003CModule\u003E.smethod_9<string>(868744759U), 11.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.button_16.Location = new Point(25, 22);
    this.button_16.Name = \u003CModule\u003E.smethod_8<string>(2648506741U);
    this.button_16.Size = new Size(132, 49);
    this.button_16.TabIndex = 157;
    this.button_16.Text = \u003CModule\u003E.smethod_5<string>(1564084447U);
    this.button_16.UseVisualStyleBackColor = true;
    this.button_16.Click += new EventHandler(this.button_16_Click);
    this.groupBox_10.Controls.Add((Control) this.label_13);
    this.groupBox_10.Controls.Add((Control) this.button_17);
    this.groupBox_10.Location = new Point(9, 10);
    this.groupBox_10.Name = \u003CModule\u003E.smethod_5<string>(2611997360U);
    this.groupBox_10.Size = new Size(408, 88);
    this.groupBox_10.TabIndex = 4;
    this.groupBox_10.TabStop = false;
    this.groupBox_10.Text = \u003CModule\u003E.smethod_5<string>(3274263141U);
    this.label_13.AutoSize = true;
    this.label_13.Location = new Point(216, 33);
    this.label_13.Name = \u003CModule\u003E.smethod_6<string>(1592858705U);
    this.label_13.Size = new Size(150, 30);
    this.label_13.TabIndex = 156;
    this.label_13.Text = \u003CModule\u003E.smethod_5<string>(3936528922U);
    this.label_13.TextAlign = ContentAlignment.MiddleCenter;
    this.button_17.FlatStyle = FlatStyle.Flat;
    this.button_17.Font = new Font(\u003CModule\u003E.smethod_9<string>(868744759U), 11.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.button_17.Location = new Point(25, 22);
    this.button_17.Name = \u003CModule\u003E.smethod_8<string>(1979191992U);
    this.button_17.Size = new Size(132, 49);
    this.button_17.TabIndex = 2;
    this.button_17.Text = \u003CModule\u003E.smethod_6<string>(2929006759U);
    this.button_17.UseVisualStyleBackColor = true;
    this.button_17.Click += new EventHandler(this.button_17_Click);
    this.tabPage_4.Controls.Add((Control) this.checkBox_10);
    this.tabPage_4.Controls.Add((Control) this.checkBox_8);
    this.tabPage_4.Controls.Add((Control) this.checkBox_9);
    this.tabPage_4.Controls.Add((Control) this.textBox_7);
    this.tabPage_4.Controls.Add((Control) this.button_18);
    this.tabPage_4.Controls.Add((Control) this.checkBox_11);
    this.tabPage_4.Controls.Add((Control) this.checkBox_12);
    this.tabPage_4.Controls.Add((Control) this.groupBox_11);
    this.tabPage_4.Controls.Add((Control) this.groupBox_12);
    this.tabPage_4.Controls.Add((Control) this.groupBox_13);
    this.tabPage_4.Location = new Point(4, 22);
    this.tabPage_4.Name = \u003CModule\u003E.smethod_7<string>(3991159520U);
    this.tabPage_4.Size = new Size(842, 518);
    this.tabPage_4.TabIndex = 10;
    this.tabPage_4.Text = \u003CModule\u003E.smethod_9<string>(1666987283U);
    this.tabPage_4.UseVisualStyleBackColor = true;
    this.checkBox_10.AutoSize = true;
    this.checkBox_10.Font = new Font(\u003CModule\u003E.smethod_5<string>(2184462853U), 12f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.checkBox_10.Location = new Point(626, 409);
    this.checkBox_10.Name = \u003CModule\u003E.smethod_7<string>(1092604965U);
    this.checkBox_10.Size = new Size(76, 25);
    this.checkBox_10.TabIndex = 9;
    this.checkBox_10.Text = \u003CModule\u003E.smethod_9<string>(3471250469U);
    this.checkBox_10.UseVisualStyleBackColor = true;
    this.checkBox_8.AutoSize = true;
    this.checkBox_8.Font = new Font(\u003CModule\u003E.smethod_7<string>(1521212547U), 12f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.checkBox_8.Location = new Point(658, 252);
    this.checkBox_8.Name = \u003CModule\u003E.smethod_6<string>(3452550240U);
    this.checkBox_8.Size = new Size(132, 25);
    this.checkBox_8.TabIndex = 12;
    this.checkBox_8.Text = \u003CModule\u003E.smethod_5<string>(2642943599U);
    this.checkBox_8.UseVisualStyleBackColor = true;
    this.checkBox_9.AutoSize = true;
    this.checkBox_9.Font = new Font(\u003CModule\u003E.smethod_7<string>(1521212547U), 12f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.checkBox_9.Location = new Point(658, 221);
    this.checkBox_9.Name = \u003CModule\u003E.smethod_9<string>(755432648U);
    this.checkBox_9.Size = new Size(122, 25);
    this.checkBox_9.TabIndex = 11;
    this.checkBox_9.Text = \u003CModule\u003E.smethod_9<string>(68991724U);
    this.checkBox_9.UseVisualStyleBackColor = true;
    this.textBox_7.Location = new Point(708, 412);
    this.textBox_7.Name = \u003CModule\u003E.smethod_8<string>(1632148234U);
    this.textBox_7.Size = new Size(112, 23);
    this.textBox_7.TabIndex = 10;
    this.textBox_7.Enter += new EventHandler(this.textBox_20_Enter);
    this.textBox_7.Leave += new EventHandler(this.textBox_20_Leave);
    this.button_18.FlatStyle = FlatStyle.Flat;
    this.button_18.Location = new Point(658, 329);
    this.button_18.Name = \u003CModule\u003E.smethod_6<string>(1228231734U);
    this.button_18.Size = new Size(132, 49);
    this.button_18.TabIndex = 8;
    this.button_18.Text = \u003CModule\u003E.smethod_5<string>(3838926117U);
    this.button_18.UseVisualStyleBackColor = true;
    this.button_18.Click += new EventHandler(this.button_18_Click);
    this.checkBox_11.AutoSize = true;
    this.checkBox_11.Font = new Font(\u003CModule\u003E.smethod_8<string>(2058547965U), 12f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.checkBox_11.Location = new Point(658, 190);
    this.checkBox_11.Name = \u003CModule\u003E.smethod_8<string>(2592382842U);
    this.checkBox_11.Size = new Size(132, 25);
    this.checkBox_11.TabIndex = 7;
    this.checkBox_11.Text = \u003CModule\u003E.smethod_8<string>(751494619U);
    this.checkBox_11.UseVisualStyleBackColor = true;
    this.checkBox_12.AutoSize = true;
    this.checkBox_12.Font = new Font(\u003CModule\u003E.smethod_5<string>(2184462853U), 12f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.checkBox_12.Location = new Point(658, 159);
    this.checkBox_12.Name = \u003CModule\u003E.smethod_9<string>(774278732U);
    this.checkBox_12.Size = new Size(122, 25);
    this.checkBox_12.TabIndex = 6;
    this.checkBox_12.Text = \u003CModule\u003E.smethod_7<string>(4103129504U);
    this.checkBox_12.UseVisualStyleBackColor = true;
    this.groupBox_11.Location = new Point(23, 308);
    this.groupBox_11.Name = \u003CModule\u003E.smethod_8<string>(2965515040U);
    this.groupBox_11.Size = new Size(525, 191);
    this.groupBox_11.TabIndex = 5;
    this.groupBox_11.TabStop = false;
    this.groupBox_11.Text = \u003CModule\u003E.smethod_6<string>(920892302U);
    this.groupBox_12.Controls.Add((Control) this.label_14);
    this.groupBox_12.Controls.Add((Control) this.checkBox_13);
    this.groupBox_12.Controls.Add((Control) this.button_19);
    this.groupBox_12.Controls.Add((Control) this.checkBox_14);
    this.groupBox_12.Location = new Point(23, 23);
    this.groupBox_12.Name = \u003CModule\u003E.smethod_6<string>(636992565U);
    this.groupBox_12.Size = new Size(799, 95);
    this.groupBox_12.TabIndex = 4;
    this.groupBox_12.TabStop = false;
    this.groupBox_12.Text = \u003CModule\u003E.smethod_6<string>(1181352344U);
    this.label_14.AutoSize = true;
    this.label_14.Location = new Point(363, 56);
    this.label_14.Name = \u003CModule\u003E.smethod_5<string>(2559148516U);
    this.label_14.Size = new Size(224, 30);
    this.label_14.TabIndex = 6;
    this.label_14.Text = \u003CModule\u003E.smethod_6<string>(483322849U);
    this.label_14.TextAlign = ContentAlignment.MiddleCenter;
    this.checkBox_13.AutoSize = true;
    this.checkBox_13.Checked = true;
    this.checkBox_13.CheckState = CheckState.Checked;
    this.checkBox_13.Font = new Font(\u003CModule\u003E.smethod_8<string>(2058547965U), 12f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.checkBox_13.Location = new Point(403, 33);
    this.checkBox_13.Name = \u003CModule\u003E.smethod_9<string>(2402220166U);
    this.checkBox_13.Size = new Size(147, 25);
    this.checkBox_13.TabIndex = 132;
    this.checkBox_13.Text = \u003CModule\u003E.smethod_8<string>(1099854050U);
    this.checkBox_13.UseVisualStyleBackColor = true;
    this.button_19.FlatStyle = FlatStyle.Flat;
    this.button_19.Location = new Point(18, 22);
    this.button_19.Name = \u003CModule\u003E.smethod_8<string>(2887249720U);
    this.button_19.Size = new Size(132, 49);
    this.button_19.TabIndex = 1;
    this.button_19.Text = \u003CModule\u003E.smethod_9<string>(2803655629U);
    this.button_19.UseVisualStyleBackColor = true;
    this.button_19.Click += new EventHandler(this.button_19_Click);
    this.checkBox_14.AutoSize = true;
    this.checkBox_14.Font = new Font(\u003CModule\u003E.smethod_8<string>(2058547965U), 12f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.checkBox_14.Location = new Point(183, 33);
    this.checkBox_14.Name = \u003CModule\u003E.smethod_9<string>(3786201805U);
    this.checkBox_14.Size = new Size(190, 25);
    this.checkBox_14.TabIndex = 2;
    this.checkBox_14.Text = \u003CModule\u003E.smethod_9<string>(1599349240U);
    this.checkBox_14.UseVisualStyleBackColor = true;
    this.groupBox_13.Location = new Point(23, 135);
    this.groupBox_13.Name = \u003CModule\u003E.smethod_7<string>(3002152397U);
    this.groupBox_13.Size = new Size(525, 167);
    this.groupBox_13.TabIndex = 0;
    this.groupBox_13.TabStop = false;
    this.groupBox_13.Text = \u003CModule\u003E.smethod_6<string>(2020020009U);
    this.tabPage_5.BackColor = Color.White;
    this.tabPage_5.Controls.Add((Control) this.groupBox_48);
    this.tabPage_5.Controls.Add((Control) this.groupBox_46);
    this.tabPage_5.Controls.Add((Control) this.groupBox_45);
    this.tabPage_5.Controls.Add((Control) this.groupBox_14);
    this.tabPage_5.Controls.Add((Control) this.groupBox_15);
    this.tabPage_5.Controls.Add((Control) this.groupBox_16);
    this.tabPage_5.Controls.Add((Control) this.groupBox_17);
    this.tabPage_5.Controls.Add((Control) this.groupBox_18);
    this.tabPage_5.Controls.Add((Control) this.groupBox_19);
    this.tabPage_5.Controls.Add((Control) this.groupBox_20);
    this.tabPage_5.Controls.Add((Control) this.groupBox_21);
    this.tabPage_5.Location = new Point(4, 22);
    this.tabPage_5.Name = \u003CModule\u003E.smethod_5<string>(502363812U);
    this.tabPage_5.Size = new Size(842, 518);
    this.tabPage_5.TabIndex = 12;
    this.tabPage_5.Text = \u003CModule\u003E.smethod_9<string>(128883474U);
    this.groupBox_48.Controls.Add((Control) this.button_72);
    this.groupBox_48.Controls.Add((Control) this.label_62);
    this.groupBox_48.Location = new Point(634, 293);
    this.groupBox_48.Name = \u003CModule\u003E.smethod_6<string>(2848279525U);
    this.groupBox_48.Size = new Size(205, 100);
    this.groupBox_48.TabIndex = 10;
    this.groupBox_48.TabStop = false;
    this.groupBox_48.Text = \u003CModule\u003E.smethod_5<string>(3942241761U);
    this.button_72.BackColor = Color.White;
    this.button_72.FlatStyle = FlatStyle.Flat;
    this.button_72.Location = new Point(62, 31);
    this.button_72.Name = \u003CModule\u003E.smethod_8<string>(2726772061U);
    this.button_72.Size = new Size(75, 36);
    this.button_72.TabIndex = 8;
    this.button_72.Text = \u003CModule\u003E.smethod_7<string>(1332055607U);
    this.button_72.UseVisualStyleBackColor = false;
    this.button_72.Click += new EventHandler(this.button_72_Click);
    this.label_62.AutoSize = true;
    this.label_62.Location = new Point(4, 75);
    this.label_62.Name = \u003CModule\u003E.smethod_6<string>(2053696975U);
    this.label_62.Size = new Size(190, 15);
    this.label_62.TabIndex = 8;
    this.label_62.Text = \u003CModule\u003E.smethod_7<string>(4286595154U);
    this.groupBox_46.Controls.Add((Control) this.button_70);
    this.groupBox_46.Controls.Add((Control) this.checkBox_92);
    this.groupBox_46.Controls.Add((Control) this.comboBox_12);
    this.groupBox_46.Controls.Add((Control) this.button_69);
    this.groupBox_46.Location = new Point(3, 95);
    this.groupBox_46.Name = \u003CModule\u003E.smethod_5<string>(1530756164U);
    this.groupBox_46.Size = new Size(205, 86);
    this.groupBox_46.TabIndex = 11;
    this.groupBox_46.TabStop = false;
    this.groupBox_46.Text = \u003CModule\u003E.smethod_5<string>(2919562248U);
    this.button_70.BackColor = Color.White;
    this.button_70.FlatStyle = FlatStyle.Flat;
    this.button_70.Location = new Point(87, 22);
    this.button_70.Name = \u003CModule\u003E.smethod_8<string>(2193162204U);
    this.button_70.Size = new Size(112, 25);
    this.button_70.TabIndex = 167;
    this.button_70.Text = \u003CModule\u003E.smethod_7<string>(706950932U);
    this.button_70.UseVisualStyleBackColor = false;
    this.button_70.Click += new EventHandler(this.button_70_Click);
    this.checkBox_92.AutoSize = true;
    this.checkBox_92.Location = new Point(132, 55);
    this.checkBox_92.Name = \u003CModule\u003E.smethod_5<string>(2791013204U);
    this.checkBox_92.Size = new Size(69, 19);
    this.checkBox_92.TabIndex = 11;
    this.checkBox_92.Text = \u003CModule\u003E.smethod_6<string>(316621587U);
    this.checkBox_92.UseVisualStyleBackColor = true;
    this.comboBox_12.ForeColor = Color.Black;
    this.comboBox_12.FormattingEnabled = true;
    this.comboBox_12.Items.AddRange(new object[2]
    {
      (object) \u003CModule\u003E.smethod_5<string>(1273658076U),
      (object) \u003CModule\u003E.smethod_9<string>(4187637268U)
    });
    this.comboBox_12.Location = new Point(87, 53);
    this.comboBox_12.Name = \u003CModule\u003E.smethod_6<string>(446851608U);
    this.comboBox_12.Size = new Size(42, 23);
    this.comboBox_12.TabIndex = 157;
    this.comboBox_12.Text = \u003CModule\u003E.smethod_9<string>(1696933158U);
    this.button_69.BackColor = Color.White;
    this.button_69.FlatStyle = FlatStyle.Flat;
    this.button_69.Location = new Point(6, 31);
    this.button_69.Name = \u003CModule\u003E.smethod_7<string>(1963401193U);
    this.button_69.Size = new Size(75, 36);
    this.button_69.TabIndex = 9;
    this.button_69.Text = \u003CModule\u003E.smethod_6<string>(3629659651U);
    this.button_69.UseVisualStyleBackColor = false;
    this.button_69.Click += new EventHandler(this.button_69_Click);
    this.groupBox_45.Controls.Add((Control) this.checkBox_91);
    this.groupBox_45.Controls.Add((Control) this.checkBox_90);
    this.groupBox_45.Controls.Add((Control) this.textBox_22);
    this.groupBox_45.Controls.Add((Control) this.button_68);
    this.groupBox_45.Location = new Point(633, 194);
    this.groupBox_45.Name = \u003CModule\u003E.smethod_9<string>(1344289654U);
    this.groupBox_45.Size = new Size(205, 86);
    this.groupBox_45.TabIndex = 167;
    this.groupBox_45.TabStop = false;
    this.groupBox_45.Text = \u003CModule\u003E.smethod_7<string>(650965940U);
    this.checkBox_91.AutoSize = true;
    this.checkBox_91.Location = new Point(140, 24);
    this.checkBox_91.Name = \u003CModule\u003E.smethod_5<string>(290019685U);
    this.checkBox_91.Size = new Size(63, 19);
    this.checkBox_91.TabIndex = 167;
    this.checkBox_91.Text = \u003CModule\u003E.smethod_7<string>(2784453340U);
    this.checkBox_91.UseVisualStyleBackColor = true;
    this.checkBox_90.AutoSize = true;
    this.checkBox_90.Location = new Point(85, 24);
    this.checkBox_90.Name = \u003CModule\u003E.smethod_5<string>(3067631853U);
    this.checkBox_90.Size = new Size(56, 19);
    this.checkBox_90.TabIndex = 166;
    this.checkBox_90.Text = \u003CModule\u003E.smethod_8<string>(3612688368U);
    this.checkBox_90.UseVisualStyleBackColor = true;
    this.textBox_22.AcceptsReturn = true;
    this.textBox_22.BackColor = Color.White;
    this.textBox_22.ForeColor = Color.Black;
    this.textBox_22.Location = new Point(87, 50);
    this.textBox_22.Name = \u003CModule\u003E.smethod_7<string>(69364435U);
    this.textBox_22.Size = new Size(112, 23);
    this.textBox_22.TabIndex = 15;
    this.textBox_22.Enter += new EventHandler(this.textBox_20_Enter);
    this.textBox_22.KeyPress += new KeyPressEventHandler(this.textBox_22_KeyPress);
    this.textBox_22.Leave += new EventHandler(this.textBox_20_Leave);
    this.button_68.BackColor = Color.White;
    this.button_68.FlatStyle = FlatStyle.Flat;
    this.button_68.Location = new Point(6, 31);
    this.button_68.Name = \u003CModule\u003E.smethod_5<string>(2536297160U);
    this.button_68.Size = new Size(75, 36);
    this.button_68.TabIndex = 165;
    this.button_68.Text = \u003CModule\u003E.smethod_6<string>(2306543143U);
    this.button_68.UseVisualStyleBackColor = false;
    this.button_68.Click += new EventHandler(this.button_68_Click);
    this.groupBox_14.Controls.Add((Control) this.button_20);
    this.groupBox_14.Controls.Add((Control) this.button_21);
    this.groupBox_14.Controls.Add((Control) this.listBox_1);
    this.groupBox_14.Controls.Add((Control) this.button_22);
    this.groupBox_14.Controls.Add((Control) this.listBox_2);
    this.groupBox_14.Controls.Add((Control) this.button_23);
    this.groupBox_14.Location = new Point(3, 293);
    this.groupBox_14.Name = \u003CModule\u003E.smethod_9<string>(3014316051U);
    this.groupBox_14.Size = new Size(414, 220);
    this.groupBox_14.TabIndex = 16;
    this.groupBox_14.TabStop = false;
    this.groupBox_14.Text = \u003CModule\u003E.smethod_5<string>(2407748116U);
    this.button_20.FlatStyle = FlatStyle.Flat;
    this.button_20.Font = new Font(\u003CModule\u003E.smethod_7<string>(1521212547U), 12f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.button_20.Location = new Point(218, 174);
    this.button_20.Name = \u003CModule\u003E.smethod_6<string>(2152873427U);
    this.button_20.Size = new Size(42, 40);
    this.button_20.TabIndex = 162;
    this.button_20.Text = \u003CModule\u003E.smethod_5<string>(3732279678U);
    this.button_20.UseVisualStyleBackColor = true;
    this.button_20.Click += new EventHandler(this.button_20_Click);
    this.button_21.FlatStyle = FlatStyle.Flat;
    this.button_21.Font = new Font(\u003CModule\u003E.smethod_8<string>(2058547965U), 12f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.button_21.Location = new Point(218, 30);
    this.button_21.Name = \u003CModule\u003E.smethod_6<string>(2283103448U);
    this.button_21.Size = new Size(42, 40);
    this.button_21.TabIndex = 161;
    this.button_21.Text = \u003CModule\u003E.smethod_8<string>(998131636U);
    this.button_21.UseVisualStyleBackColor = true;
    this.button_21.Click += new EventHandler(this.button_21_Click);
    this.listBox_1.FormattingEnabled = true;
    this.listBox_1.HorizontalScrollbar = true;
    this.listBox_1.ItemHeight = 15;
    this.listBox_1.Items.AddRange(new object[71]
    {
      (object) \u003CModule\u003E.smethod_8<string>(526999023U),
      (object) \u003CModule\u003E.smethod_7<string>(1048735381U),
      (object) \u003CModule\u003E.smethod_7<string>(3048501212U),
      (object) \u003CModule\u003E.smethod_7<string>(199690738U),
      (object) \u003CModule\u003E.smethod_5<string>(2370624829U),
      (object) \u003CModule\u003E.smethod_6<string>(2764843455U),
      (object) \u003CModule\u003E.smethod_6<string>(3145125369U),
      (object) \u003CModule\u003E.smethod_7<string>(1680080967U),
      (object) \u003CModule\u003E.smethod_5<string>(2571543278U),
      (object) \u003CModule\u003E.smethod_9<string>(3241743963U),
      (object) \u003CModule\u003E.smethod_8<string>(2026106180U),
      (object) \u003CModule\u003E.smethod_5<string>(1958775213U),
      (object) \u003CModule\u003E.smethod_9<string>(1790124281U),
      (object) \u003CModule\u003E.smethod_6<string>(2475867802U),
      (object) \u003CModule\u003E.smethod_7<string>(1005415418U),
      (object) \u003CModule\u003E.smethod_9<string>(2045183867U),
      (object) \u003CModule\u003E.smethod_5<string>(2087324257U),
      (object) \u003CModule\u003E.smethod_8<string>(525683350U),
      (object) \u003CModule\u003E.smethod_7<string>(2361170634U),
      (object) \u003CModule\u003E.smethod_5<string>(1451260960U),
      (object) \u003CModule\u003E.smethod_8<string>(4288356462U),
      (object) \u003CModule\u003E.smethod_7<string>(2382922219U),
      (object) \u003CModule\u003E.smethod_8<string>(1889085615U),
      (object) \u003CModule\u003E.smethod_5<string>(165770520U),
      (object) \u003CModule\u003E.smethod_6<string>(3926505495U),
      (object) \u003CModule\u003E.smethod_7<string>(712825429U),
      (object) \u003CModule\u003E.smethod_6<string>(1879296400U),
      (object) \u003CModule\u003E.smethod_7<string>(3147989374U),
      (object) \u003CModule\u003E.smethod_7<string>(1869787528U),
      (object) \u003CModule\u003E.smethod_9<string>(3319678107U),
      (object) \u003CModule\u003E.smethod_6<string>(3582694822U),
      (object) \u003CModule\u003E.smethod_8<string>(3970032490U),
      (object) \u003CModule\u003E.smethod_8<string>(3033254976U),
      (object) \u003CModule\u003E.smethod_9<string>(4220132951U),
      (object) \u003CModule\u003E.smethod_9<string>(1024141833U),
      (object) \u003CModule\u003E.smethod_7<string>(2967918990U),
      (object) \u003CModule\u003E.smethod_5<string>(2390145390U),
      (object) \u003CModule\u003E.smethod_5<string>(797090062U),
      (object) \u003CModule\u003E.smethod_6<string>(2233515222U),
      (object) \u003CModule\u003E.smethod_9<string>(3473800277U),
      (object) \u003CModule\u003E.smethod_6<string>(790576842U),
      (object) \u003CModule\u003E.smethod_9<string>(2866097187U),
      (object) \u003CModule\u003E.smethod_7<string>(4102763090U),
      (object) \u003CModule\u003E.smethod_9<string>(1710582757U),
      (object) \u003CModule\u003E.smethod_5<string>(3703251274U),
      (object) \u003CModule\u003E.smethod_8<string>(3088063202U),
      (object) \u003CModule\u003E.smethod_7<string>(1456140999U),
      (object) \u003CModule\u003E.smethod_7<string>(3695357472U),
      (object) \u003CModule\u003E.smethod_6<string>(1926175790U),
      (object) \u003CModule\u003E.smethod_8<string>(45566046U),
      (object) \u003CModule\u003E.smethod_8<string>(819234555U),
      (object) \u003CModule\u003E.smethod_9<string>(1102879667U),
      (object) \u003CModule\u003E.smethod_9<string>(3113410480U),
      (object) \u003CModule\u003E.smethod_9<string>(2123118011U),
      (object) \u003CModule\u003E.smethod_9<string>(2768513269U),
      (object) \u003CModule\u003E.smethod_5<string>(2166375585U),
      (object) \u003CModule\u003E.smethod_5<string>(2473940473U),
      (object) \u003CModule\u003E.smethod_7<string>(2992516220U),
      (object) \u003CModule\u003E.smethod_7<string>(4059259920U),
      (object) \u003CModule\u003E.smethod_8<string>(898815548U),
      (object) \u003CModule\u003E.smethod_6<string>(199337673U),
      (object) \u003CModule\u003E.smethod_7<string>(3941049025U),
      (object) \u003CModule\u003E.smethod_5<string>(422868608U),
      (object) \u003CModule\u003E.smethod_9<string>(2063226261U),
      (object) \u003CModule\u003E.smethod_9<string>(2573345433U),
      (object) \u003CModule\u003E.smethod_9<string>(1298047503U),
      (object) \u003CModule\u003E.smethod_9<string>(1387885128U),
      (object) \u003CModule\u003E.smethod_7<string>(4276958977U),
      (object) \u003CModule\u003E.smethod_6<string>(2243923371U),
      (object) \u003CModule\u003E.smethod_9<string>(2719721310U),
      (object) \u003CModule\u003E.smethod_9<string>(2082072345U)
    });
    this.listBox_1.Location = new Point(87, 30);
    this.listBox_1.Name = \u003CModule\u003E.smethod_5<string>(2150650028U);
    this.listBox_1.Size = new Size(125, 184);
    this.listBox_1.Sorted = true;
    this.listBox_1.TabIndex = 160;
    this.button_22.FlatStyle = FlatStyle.Flat;
    this.button_22.Location = new Point(6, 73);
    this.button_22.Name = \u003CModule\u003E.smethod_6<string>(1301174216U);
    this.button_22.Size = new Size(75, 40);
    this.button_22.TabIndex = 159;
    this.button_22.Text = \u003CModule\u003E.smethod_7<string>(1655483737U);
    this.button_22.UseVisualStyleBackColor = true;
    this.button_22.Click += new EventHandler(this.button_22_Click);
    this.listBox_2.FormattingEnabled = true;
    this.listBox_2.HorizontalScrollbar = true;
    this.listBox_2.ItemHeight = 15;
    this.listBox_2.Location = new Point(266, 30);
    this.listBox_2.Name = \u003CModule\u003E.smethod_9<string>(729879568U);
    this.listBox_2.Size = new Size(142, 184);
    this.listBox_2.TabIndex = 133;
    this.button_23.FlatStyle = FlatStyle.Flat;
    this.button_23.Location = new Point(6, 31);
    this.button_23.Name = \u003CModule\u003E.smethod_5<string>(1957826462U);
    this.button_23.Size = new Size(75, 36);
    this.button_23.TabIndex = 158;
    this.button_23.Text = \u003CModule\u003E.smethod_7<string>(181334419U);
    this.button_23.UseVisualStyleBackColor = true;
    this.button_23.Click += new EventHandler(this.button_23_Click);
    this.groupBox_15.Controls.Add((Control) this.button_24);
    this.groupBox_15.Controls.Add((Control) this.textBox_8);
    this.groupBox_15.Controls.Add((Control) this.button_25);
    this.groupBox_15.Location = new Point(422, 194);
    this.groupBox_15.Name = \u003CModule\u003E.smethod_6<string>(1017274479U);
    this.groupBox_15.Size = new Size(205, 86);
    this.groupBox_15.TabIndex = 14;
    this.groupBox_15.TabStop = false;
    this.groupBox_15.Text = \u003CModule\u003E.smethod_5<string>(3905582683U);
    this.button_24.BackColor = Color.White;
    this.button_24.FlatStyle = FlatStyle.Flat;
    this.button_24.Location = new Point(87, 22);
    this.button_24.Name = \u003CModule\u003E.smethod_6<string>(1147504500U);
    this.button_24.Size = new Size(112, 25);
    this.button_24.TabIndex = 166;
    this.button_24.Text = \u003CModule\u003E.smethod_5<string>(1402207120U);
    this.button_24.UseVisualStyleBackColor = false;
    this.button_24.Click += new EventHandler(this.button_24_Click);
    this.textBox_8.AcceptsReturn = true;
    this.textBox_8.BackColor = Color.White;
    this.textBox_8.ForeColor = Color.Black;
    this.textBox_8.Location = new Point(87, 50);
    this.textBox_8.Name = \u003CModule\u003E.smethod_6<string>(863604763U);
    this.textBox_8.Size = new Size(112, 23);
    this.textBox_8.TabIndex = 15;
    this.textBox_8.Enter += new EventHandler(this.textBox_20_Enter);
    this.textBox_8.KeyPress += new KeyPressEventHandler(this.textBox_8_KeyPress);
    this.textBox_8.Leave += new EventHandler(this.textBox_20_Leave);
    this.button_25.BackColor = Color.White;
    this.button_25.FlatStyle = FlatStyle.Flat;
    this.button_25.Location = new Point(6, 31);
    this.button_25.Name = \u003CModule\u003E.smethod_9<string>(1180106990U);
    this.button_25.Size = new Size(75, 36);
    this.button_25.TabIndex = 165;
    this.button_25.Text = \u003CModule\u003E.smethod_5<string>(870872427U);
    this.button_25.UseVisualStyleBackColor = false;
    this.button_25.Click += new EventHandler(this.button_25_Click);
    this.groupBox_16.Controls.Add((Control) this.comboBox_0);
    this.groupBox_16.Controls.Add((Control) this.radioButton_2);
    this.groupBox_16.Controls.Add((Control) this.radioButton_3);
    this.groupBox_16.Controls.Add((Control) this.button_26);
    this.groupBox_16.Location = new Point(212, 194);
    this.groupBox_16.Name = \u003CModule\u003E.smethod_6<string>(2105994037U);
    this.groupBox_16.Size = new Size(205, 86);
    this.groupBox_16.TabIndex = 13;
    this.groupBox_16.TabStop = false;
    this.groupBox_16.Text = \u003CModule\u003E.smethod_9<string>(268552355U);
    this.comboBox_0.ForeColor = Color.Black;
    this.comboBox_0.FormattingEnabled = true;
    this.comboBox_0.Items.AddRange(new object[3]
    {
      (object) \u003CModule\u003E.smethod_7<string>(2013145274U),
      (object) \u003CModule\u003E.smethod_9<string>(3318167596U),
      (object) \u003CModule\u003E.smethod_8<string>(2331498442U)
    });
    this.comboBox_0.Location = new Point(87, 50);
    this.comboBox_0.Name = \u003CModule\u003E.smethod_8<string>(2758123193U);
    this.comboBox_0.Size = new Size(112, 23);
    this.comboBox_0.TabIndex = 151;
    this.comboBox_0.Text = \u003CModule\u003E.smethod_8<string>(2811615746U);
    this.comboBox_0.SelectedIndexChanged += new EventHandler(this.comboBox_0_SelectedIndexChanged);
    this.radioButton_2.AutoSize = true;
    this.radioButton_2.Location = new Point(148, 25);
    this.radioButton_2.Name = \u003CModule\u003E.smethod_9<string>(2376667086U);
    this.radioButton_2.Size = new Size(51, 19);
    this.radioButton_2.TabIndex = 11;
    this.radioButton_2.TabStop = true;
    this.radioButton_2.Text = \u003CModule\u003E.smethod_7<string>(2560513372U);
    this.radioButton_2.UseVisualStyleBackColor = true;
    this.radioButton_3.AutoSize = true;
    this.radioButton_3.Checked = true;
    this.radioButton_3.Location = new Point(87, 25);
    this.radioButton_3.Name = \u003CModule\u003E.smethod_6<string>(2910813858U);
    this.radioButton_3.Size = new Size(43, 19);
    this.radioButton_3.TabIndex = 10;
    this.radioButton_3.TabStop = true;
    this.radioButton_3.Text = \u003CModule\u003E.smethod_7<string>(946401574U);
    this.radioButton_3.UseVisualStyleBackColor = true;
    this.button_26.BackColor = Color.White;
    this.button_26.FlatStyle = FlatStyle.Flat;
    this.button_26.Location = new Point(6, 31);
    this.button_26.Name = \u003CModule\u003E.smethod_6<string>(3512461176U);
    this.button_26.Size = new Size(75, 36);
    this.button_26.TabIndex = 9;
    this.button_26.Text = \u003CModule\u003E.smethod_9<string>(3760648725U);
    this.button_26.UseVisualStyleBackColor = false;
    this.button_26.Click += new EventHandler(this.button_26_Click);
    this.groupBox_17.Controls.Add((Control) this.button_27);
    this.groupBox_17.Controls.Add((Control) this.button_28);
    this.groupBox_17.Controls.Add((Control) this.button_29);
    this.groupBox_17.Controls.Add((Control) this.button_30);
    this.groupBox_17.Location = new Point(425, 95);
    this.groupBox_17.Name = \u003CModule\u003E.smethod_7<string>(2252595916U);
    this.groupBox_17.Size = new Size(414, 86);
    this.groupBox_17.TabIndex = 12;
    this.groupBox_17.TabStop = false;
    this.groupBox_17.Text = \u003CModule\u003E.smethod_5<string>(1122257676U);
    this.button_27.BackColor = Color.White;
    this.button_27.FlatStyle = FlatStyle.Flat;
    this.button_27.Location = new Point(141, 22);
    this.button_27.Name = \u003CModule\u003E.smethod_5<string>(2511063760U);
    this.button_27.Size = new Size(115, 25);
    this.button_27.TabIndex = 164;
    this.button_27.Text = \u003CModule\u003E.smethod_8<string>(2973409078U);
    this.button_27.UseVisualStyleBackColor = false;
    this.button_27.Click += new EventHandler(this.button_27_Click);
    this.button_28.BackColor = Color.White;
    this.button_28.FlatStyle = FlatStyle.Flat;
    this.button_28.Location = new Point(271, 26);
    this.button_28.Name = \u003CModule\u003E.smethod_6<string>(1004242933U);
    this.button_28.Size = new Size(115, 47);
    this.button_28.TabIndex = 159;
    this.button_28.Text = \u003CModule\u003E.smethod_7<string>(63123524U);
    this.button_28.UseVisualStyleBackColor = false;
    this.button_28.Click += new EventHandler(this.button_28_Click);
    this.button_29.BackColor = Color.White;
    this.button_29.FlatStyle = FlatStyle.Flat;
    this.button_29.Location = new Point(141, 53);
    this.button_29.Name = \u003CModule\u003E.smethod_6<string>(3205121744U);
    this.button_29.Size = new Size(115, 25);
    this.button_29.TabIndex = 158;
    this.button_29.Text = \u003CModule\u003E.smethod_5<string>(1463150847U);
    this.button_29.UseVisualStyleBackColor = false;
    this.button_29.Click += new EventHandler(this.button_29_Click);
    this.button_30.BackColor = Color.White;
    this.button_30.FlatStyle = FlatStyle.Flat;
    this.button_30.Location = new Point(6, 31);
    this.button_30.Name = \u003CModule\u003E.smethod_8<string>(838969650U);
    this.button_30.Size = new Size(75, 36);
    this.button_30.TabIndex = 9;
    this.button_30.Text = \u003CModule\u003E.smethod_6<string>(4163611281U);
    this.button_30.UseVisualStyleBackColor = false;
    this.button_30.Click += new EventHandler(this.button_30_Click);
    this.groupBox_18.Controls.Add((Control) this.button_31);
    this.groupBox_18.Controls.Add((Control) this.label_15);
    this.groupBox_18.Controls.Add((Control) this.textBox_9);
    this.groupBox_18.Controls.Add((Control) this.button_32);
    this.groupBox_18.Controls.Add((Control) this.button_33);
    this.groupBox_18.Controls.Add((Control) this.button_34);
    this.groupBox_18.Location = new Point(425, 3);
    this.groupBox_18.Name = \u003CModule\u003E.smethod_8<string>(1372579507U);
    this.groupBox_18.Size = new Size(414, 86);
    this.groupBox_18.TabIndex = 11;
    this.groupBox_18.TabStop = false;
    this.groupBox_18.Text = \u003CModule\u003E.smethod_6<string>(2921222007U);
    this.button_31.BackColor = Color.White;
    this.button_31.FlatStyle = FlatStyle.Flat;
    this.button_31.Location = new Point(211, 19);
    this.button_31.Name = \u003CModule\u003E.smethod_9<string>(808617402U);
    this.button_31.Size = new Size(68, 60);
    this.button_31.TabIndex = 14;
    this.button_31.Text = \u003CModule\u003E.smethod_6<string>(282773743U);
    this.button_31.UseVisualStyleBackColor = false;
    this.button_31.Click += new EventHandler(this.button_31_Click);
    this.label_15.AutoSize = true;
    this.label_15.Location = new Point(329, 24);
    this.label_15.Name = \u003CModule\u003E.smethod_6<string>(2353422533U);
    this.label_15.Size = new Size(52, 15);
    this.label_15.TabIndex = 13;
    this.label_15.Text = \u003CModule\u003E.smethod_6<string>(543233785U);
    this.textBox_9.AcceptsReturn = true;
    this.textBox_9.BackColor = Color.White;
    this.textBox_9.ForeColor = Color.Black;
    this.textBox_9.Location = new Point(298, 50);
    this.textBox_9.Name = \u003CModule\u003E.smethod_6<string>(2483652554U);
    this.textBox_9.Size = new Size(112, 23);
    this.textBox_9.TabIndex = 12;
    this.textBox_9.Enter += new EventHandler(this.textBox_20_Enter);
    this.textBox_9.KeyPress += new KeyPressEventHandler(this.textBox_9_KeyPress);
    this.textBox_9.Leave += new EventHandler(this.textBox_20_Leave);
    this.button_32.BackColor = Color.White;
    this.button_32.FlatStyle = FlatStyle.Flat;
    this.button_32.Location = new Point(130, 50);
    this.button_32.Name = \u003CModule\u003E.smethod_7<string>(2939926494U);
    this.button_32.Size = new Size(75, 29);
    this.button_32.TabIndex = 11;
    this.button_32.Text = \u003CModule\u003E.smethod_5<string>(909913549U);
    this.button_32.UseVisualStyleBackColor = false;
    this.button_32.Click += new EventHandler(this.button_32_Click);
    this.button_33.BackColor = Color.White;
    this.button_33.FlatStyle = FlatStyle.Flat;
    this.button_33.Location = new Point(130, 19);
    this.button_33.Name = \u003CModule\u003E.smethod_6<string>(3856271849U);
    this.button_33.Size = new Size(75, 29);
    this.button_33.TabIndex = 10;
    this.button_33.Text = \u003CModule\u003E.smethod_6<string>(3028012333U);
    this.button_33.UseVisualStyleBackColor = false;
    this.button_33.Click += new EventHandler(this.button_33_Click);
    this.button_34.BackColor = Color.White;
    this.button_34.FlatStyle = FlatStyle.Flat;
    this.button_34.Location = new Point(6, 22);
    this.button_34.Name = \u003CModule\u003E.smethod_9<string>(2132707291U);
    this.button_34.Size = new Size(104, 50);
    this.button_34.TabIndex = 9;
    this.button_34.Text = \u003CModule\u003E.smethod_7<string>(3375324608U);
    this.button_34.UseVisualStyleBackColor = false;
    this.button_34.Click += new EventHandler(this.button_34_Click);
    this.groupBox_19.Controls.Add((Control) this.checkBox_88);
    this.groupBox_19.Controls.Add((Control) this.textBox_10);
    this.groupBox_19.Controls.Add((Control) this.button_35);
    this.groupBox_19.Location = new Point(3, 194);
    this.groupBox_19.Name = \u003CModule\u003E.smethod_8<string>(2652453760U);
    this.groupBox_19.Size = new Size(205, 86);
    this.groupBox_19.TabIndex = 7;
    this.groupBox_19.TabStop = false;
    this.groupBox_19.Text = \u003CModule\u003E.smethod_5<string>(4150790884U);
    this.checkBox_88.AutoSize = true;
    this.checkBox_88.Location = new Point(125, 24);
    this.checkBox_88.Name = \u003CModule\u003E.smethod_9<string>(2867940174U);
    this.checkBox_88.Size = new Size(47, 19);
    this.checkBox_88.TabIndex = 10;
    this.checkBox_88.Text = \u003CModule\u003E.smethod_8<string>(918550643U);
    this.checkBox_88.UseVisualStyleBackColor = true;
    this.textBox_10.AcceptsReturn = true;
    this.textBox_10.BackColor = Color.White;
    this.textBox_10.ForeColor = Color.Black;
    this.textBox_10.Location = new Point(87, 49);
    this.textBox_10.Name = \u003CModule\u003E.smethod_7<string>(2062889355U);
    this.textBox_10.Size = new Size(112, 23);
    this.textBox_10.TabIndex = 10;
    this.textBox_10.Enter += new EventHandler(this.textBox_20_Enter);
    this.textBox_10.KeyPress += new KeyPressEventHandler(this.textBox_10_KeyPress);
    this.textBox_10.Leave += new EventHandler(this.textBox_20_Leave);
    this.button_35.BackColor = Color.White;
    this.button_35.FlatStyle = FlatStyle.Flat;
    this.button_35.Location = new Point(6, 31);
    this.button_35.Name = \u003CModule\u003E.smethod_8<string>(1796572912U);
    this.button_35.Size = new Size(75, 36);
    this.button_35.TabIndex = 9;
    this.button_35.Text = \u003CModule\u003E.smethod_8<string>(3857784692U);
    this.button_35.UseVisualStyleBackColor = false;
    this.button_35.Click += new EventHandler(this.button_35_Click);
    this.groupBox_20.Controls.Add((Control) this.checkBox_15);
    this.groupBox_20.Controls.Add((Control) this.button_36);
    this.groupBox_20.Controls.Add((Control) this.checkBox_16);
    this.groupBox_20.Controls.Add((Control) this.textBox_11);
    this.groupBox_20.Controls.Add((Control) this.label_60);
    this.groupBox_20.Location = new Point(423, 293);
    this.groupBox_20.Name = \u003CModule\u003E.smethod_7<string>(3916451795U);
    this.groupBox_20.Size = new Size(205, 100);
    this.groupBox_20.TabIndex = 6;
    this.groupBox_20.TabStop = false;
    this.groupBox_20.Text = \u003CModule\u003E.smethod_7<string>(688228199U);
    this.checkBox_15.AutoSize = true;
    this.checkBox_15.Location = new Point(145, 24);
    this.checkBox_15.Name = \u003CModule\u003E.smethod_6<string>(4189674373U);
    this.checkBox_15.Size = new Size(58, 19);
    this.checkBox_15.TabIndex = 9;
    this.checkBox_15.Text = \u003CModule\u003E.smethod_7<string>(4218128340U);
    this.checkBox_15.UseVisualStyleBackColor = true;
    this.button_36.BackColor = Color.White;
    this.button_36.FlatStyle = FlatStyle.Flat;
    this.button_36.Location = new Point(6, 31);
    this.button_36.Name = \u003CModule\u003E.smethod_9<string>(3310421303U);
    this.button_36.Size = new Size(75, 36);
    this.button_36.TabIndex = 8;
    this.button_36.Text = \u003CModule\u003E.smethod_6<string>(985879154U);
    this.button_36.UseVisualStyleBackColor = false;
    this.button_36.Click += new EventHandler(this.button_36_Click);
    this.checkBox_16.AutoSize = true;
    this.checkBox_16.Location = new Point(87, 24);
    this.checkBox_16.Name = \u003CModule\u003E.smethod_6<string>(4036004657U);
    this.checkBox_16.Size = new Size(56, 19);
    this.checkBox_16.TabIndex = 1;
    this.checkBox_16.Text = \u003CModule\u003E.smethod_7<string>(343048484U);
    this.checkBox_16.UseVisualStyleBackColor = true;
    this.textBox_11.AcceptsReturn = true;
    this.textBox_11.BackColor = Color.White;
    this.textBox_11.ForeColor = Color.Black;
    this.textBox_11.Location = new Point(87, 49);
    this.textBox_11.Name = \u003CModule\u003E.smethod_7<string>(3123392144U);
    this.textBox_11.Size = new Size(112, 23);
    this.textBox_11.TabIndex = 0;
    this.textBox_11.Enter += new EventHandler(this.textBox_20_Enter);
    this.textBox_11.KeyPress += new KeyPressEventHandler(this.textBox_11_KeyPress);
    this.textBox_11.Leave += new EventHandler(this.textBox_20_Leave);
    this.label_60.AutoSize = true;
    this.label_60.Location = new Point(4, 75);
    this.label_60.Name = \u003CModule\u003E.smethod_9<string>(594603482U);
    this.label_60.Size = new Size(190, 15);
    this.label_60.TabIndex = 8;
    this.label_60.Text = \u003CModule\u003E.smethod_7<string>(4286595154U);
    this.groupBox_21.Controls.Add((Control) this.numericUpDown_1);
    this.groupBox_21.Controls.Add((Control) this.label_16);
    this.groupBox_21.Controls.Add((Control) this.numericUpDown_2);
    this.groupBox_21.Controls.Add((Control) this.label_17);
    this.groupBox_21.Controls.Add((Control) this.label_18);
    this.groupBox_21.Controls.Add((Control) this.label_19);
    this.groupBox_21.Controls.Add((Control) this.comboBox_1);
    this.groupBox_21.Controls.Add((Control) this.numericUpDown_3);
    this.groupBox_21.Controls.Add((Control) this.label_20);
    this.groupBox_21.Controls.Add((Control) this.button_37);
    this.groupBox_21.Location = new Point(3, 3);
    this.groupBox_21.Name = \u003CModule\u003E.smethod_7<string>(905927256U);
    this.groupBox_21.Size = new Size(414, 86);
    this.groupBox_21.TabIndex = 5;
    this.groupBox_21.TabStop = false;
    this.groupBox_21.Text = \u003CModule\u003E.smethod_7<string>(2246355005U);
    this.numericUpDown_1.ForeColor = Color.Black;
    this.numericUpDown_1.Location = new Point(351, 52);
    this.numericUpDown_1.Maximum = new Decimal(new int[4]
    {
      20,
      0,
      0,
      0
    });
    this.numericUpDown_1.Minimum = new Decimal(new int[4]
    {
      1,
      0,
      0,
      0
    });
    this.numericUpDown_1.Name = \u003CModule\u003E.smethod_9<string>(3771748516U);
    this.numericUpDown_1.Size = new Size(43, 23);
    this.numericUpDown_1.TabIndex = 156;
    this.numericUpDown_1.TextAlign = HorizontalAlignment.Center;
    this.numericUpDown_1.Value = new Decimal(new int[4]
    {
      1,
      0,
      0,
      0
    });
    this.label_16.AutoSize = true;
    this.label_16.Location = new Point(322, 55);
    this.label_16.Name = \u003CModule\u003E.smethod_5<string>(2670559043U);
    this.label_16.Size = new Size(23, 15);
    this.label_16.TabIndex = 155;
    this.label_16.Text = \u003CModule\u003E.smethod_6<string>(1941916172U);
    this.label_16.TextAlign = ContentAlignment.MiddleCenter;
    this.numericUpDown_2.ForeColor = Color.Black;
    this.numericUpDown_2.Location = new Point(273, 52);
    this.numericUpDown_2.Maximum = new Decimal(new int[4]
    {
      20,
      0,
      0,
      0
    });
    this.numericUpDown_2.Minimum = new Decimal(new int[4]
    {
      1,
      0,
      0,
      0
    });
    this.numericUpDown_2.Name = \u003CModule\u003E.smethod_6<string>(1527786414U);
    this.numericUpDown_2.Size = new Size(43, 23);
    this.numericUpDown_2.TabIndex = 154;
    this.numericUpDown_2.TextAlign = HorizontalAlignment.Center;
    this.numericUpDown_2.Value = new Decimal(new int[4]
    {
      7,
      0,
      0,
      0
    });
    this.label_17.AutoSize = true;
    this.label_17.Location = new Point(253, 55);
    this.label_17.Name = \u003CModule\u003E.smethod_8<string>(2943373619U);
    this.label_17.Size = new Size(14, 15);
    this.label_17.TabIndex = 153;
    this.label_17.Text = \u003CModule\u003E.smethod_5<string>(432860993U);
    this.label_17.TextAlign = ContentAlignment.MiddleCenter;
    this.label_18.AutoSize = true;
    this.label_18.Location = new Point(266, 22);
    this.label_18.Name = \u003CModule\u003E.smethod_8<string>(3957100780U);
    this.label_18.Size = new Size(94, 15);
    this.label_18.TabIndex = 152;
    this.label_18.Text = \u003CModule\u003E.smethod_8<string>(2356271209U);
    this.label_18.TextAlign = ContentAlignment.MiddleCenter;
    this.label_19.AutoSize = true;
    this.label_19.Location = new Point(116, 22);
    this.label_19.Name = \u003CModule\u003E.smethod_9<string>(613449566U);
    this.label_19.Size = new Size(75, 15);
    this.label_19.TabIndex = 151;
    this.label_19.Text = \u003CModule\u003E.smethod_7<string>(800198183U);
    this.label_19.TextAlign = ContentAlignment.MiddleCenter;
    this.comboBox_1.ForeColor = Color.Black;
    this.comboBox_1.FormattingEnabled = true;
    this.comboBox_1.Items.AddRange(new object[5]
    {
      (object) \u003CModule\u003E.smethod_7<string>(3207369632U),
      (object) \u003CModule\u003E.smethod_5<string>(3036685614U),
      (object) \u003CModule\u003E.smethod_6<string>(806317224U),
      (object) \u003CModule\u003E.smethod_5<string>(130524402U),
      (object) \u003CModule\u003E.smethod_7<string>(1101874728U)
    });
    this.comboBox_1.Location = new Point(197, 19);
    this.comboBox_1.Name = \u003CModule\u003E.smethod_7<string>(2715986526U);
    this.comboBox_1.Size = new Size(49, 23);
    this.comboBox_1.TabIndex = 150;
    this.comboBox_1.Text = \u003CModule\u003E.smethod_7<string>(3207369632U);
    this.numericUpDown_3.ForeColor = Color.Black;
    this.numericUpDown_3.Location = new Point(197, 50);
    this.numericUpDown_3.Maximum = new Decimal(new int[4]
    {
      20,
      0,
      0,
      0
    });
    this.numericUpDown_3.Minimum = new Decimal(new int[4]
    {
      1,
      0,
      0,
      0
    });
    this.numericUpDown_3.Name = \u003CModule\u003E.smethod_8<string>(3850115674U);
    this.numericUpDown_3.Size = new Size(39, 23);
    this.numericUpDown_3.TabIndex = 149;
    this.numericUpDown_3.TextAlign = HorizontalAlignment.Center;
    this.numericUpDown_3.Value = new Decimal(new int[4]
    {
      3,
      0,
      0,
      0
    });
    this.label_20.AutoSize = true;
    this.label_20.Location = new Point(122, 52);
    this.label_20.Name = \u003CModule\u003E.smethod_6<string>(3160865751U);
    this.label_20.Size = new Size(69, 15);
    this.label_20.TabIndex = 148;
    this.label_20.Text = \u003CModule\u003E.smethod_8<string>(2009227451U);
    this.label_20.TextAlign = ContentAlignment.MiddleCenter;
    this.button_37.BackColor = Color.White;
    this.button_37.FlatStyle = FlatStyle.Flat;
    this.button_37.Location = new Point(6, 22);
    this.button_37.Name = \u003CModule\u003E.smethod_5<string>(2053047223U);
    this.button_37.Size = new Size(104, 50);
    this.button_37.TabIndex = 1;
    this.button_37.Text = \u003CModule\u003E.smethod_5<string>(3260455419U);
    this.button_37.UseVisualStyleBackColor = false;
    this.button_37.Click += new EventHandler(this.button_37_Click);
    this.tabPage_6.Controls.Add((Control) this.groupBox_22);
    this.tabPage_6.Controls.Add((Control) this.groupBox_23);
    this.tabPage_6.Controls.Add((Control) this.groupBox_24);
    this.tabPage_6.Controls.Add((Control) this.groupBox_25);
    this.tabPage_6.Controls.Add((Control) this.groupBox_26);
    this.tabPage_6.Controls.Add((Control) this.groupBox_27);
    this.tabPage_6.ForeColor = Color.Black;
    this.tabPage_6.Location = new Point(4, 22);
    this.tabPage_6.Name = \u003CModule\u003E.smethod_6<string>(2593066277U);
    this.tabPage_6.Size = new Size(842, 518);
    this.tabPage_6.TabIndex = 8;
    this.tabPage_6.Text = \u003CModule\u003E.smethod_7<string>(470529142U);
    this.tabPage_6.UseVisualStyleBackColor = true;
    this.groupBox_22.Controls.Add((Control) this.textBox_12);
    this.groupBox_22.Location = new Point(6, 112);
    this.groupBox_22.Name = \u003CModule\u003E.smethod_6<string>(368747771U);
    this.groupBox_22.Size = new Size(222, 187);
    this.groupBox_22.TabIndex = 132;
    this.groupBox_22.TabStop = false;
    this.groupBox_22.Text = \u003CModule\u003E.smethod_5<string>(4039844566U);
    this.textBox_12.Location = new Point(14, 22);
    this.textBox_12.Multiline = true;
    this.textBox_12.Name = \u003CModule\u003E.smethod_8<string>(3503071916U);
    this.textBox_12.ScrollBars = ScrollBars.Both;
    this.textBox_12.Size = new Size(191, 154);
    this.textBox_12.TabIndex = 193;
    this.groupBox_23.Controls.Add((Control) this.checkBox_17);
    this.groupBox_23.Controls.Add((Control) this.checkBox_18);
    this.groupBox_23.Controls.Add((Control) this.button_38);
    this.groupBox_23.Controls.Add((Control) this.checkBox_19);
    this.groupBox_23.Controls.Add((Control) this.checkBox_20);
    this.groupBox_23.Controls.Add((Control) this.numericUpDown_4);
    this.groupBox_23.Controls.Add((Control) this.numericUpDown_5);
    this.groupBox_23.Controls.Add((Control) this.numericUpDown_6);
    this.groupBox_23.Controls.Add((Control) this.numericUpDown_7);
    this.groupBox_23.Controls.Add((Control) this.numericUpDown_8);
    this.groupBox_23.Controls.Add((Control) this.numericUpDown_9);
    this.groupBox_23.Controls.Add((Control) this.label_21);
    this.groupBox_23.Controls.Add((Control) this.numericUpDown_10);
    this.groupBox_23.Controls.Add((Control) this.numericUpDown_11);
    this.groupBox_23.Controls.Add((Control) this.numericUpDown_12);
    this.groupBox_23.Controls.Add((Control) this.numericUpDown_13);
    this.groupBox_23.Controls.Add((Control) this.numericUpDown_14);
    this.groupBox_23.Controls.Add((Control) this.numericUpDown_15);
    this.groupBox_23.Controls.Add((Control) this.numericUpDown_16);
    this.groupBox_23.Controls.Add((Control) this.label_22);
    this.groupBox_23.Controls.Add((Control) this.label_23);
    this.groupBox_23.Controls.Add((Control) this.label_24);
    this.groupBox_23.Controls.Add((Control) this.label_25);
    this.groupBox_23.Controls.Add((Control) this.label_26);
    this.groupBox_23.Controls.Add((Control) this.label_27);
    this.groupBox_23.Controls.Add((Control) this.label_28);
    this.groupBox_23.Controls.Add((Control) this.label_29);
    this.groupBox_23.Controls.Add((Control) this.label_30);
    this.groupBox_23.Controls.Add((Control) this.label_31);
    this.groupBox_23.Controls.Add((Control) this.label_32);
    this.groupBox_23.Controls.Add((Control) this.label_33);
    this.groupBox_23.Controls.Add((Control) this.label_34);
    this.groupBox_23.Controls.Add((Control) this.numericUpDown_17);
    this.groupBox_23.Location = new Point(6, 299);
    this.groupBox_23.Name = \u003CModule\u003E.smethod_5<string>(381909651U);
    this.groupBox_23.Size = new Size(450, 213);
    this.groupBox_23.TabIndex = 131;
    this.groupBox_23.TabStop = false;
    this.groupBox_23.Text = \u003CModule\u003E.smethod_6<string>(4153203132U);
    this.checkBox_17.AutoSize = true;
    this.checkBox_17.Checked = true;
    this.checkBox_17.CheckState = CheckState.Checked;
    this.checkBox_17.ForeColor = Color.Black;
    this.checkBox_17.Location = new Point(110, 165);
    this.checkBox_17.Name = \u003CModule\u003E.smethod_9<string>(1262198322U);
    this.checkBox_17.Size = new Size(112, 19);
    this.checkBox_17.TabIndex = 161;
    this.checkBox_17.Text = \u003CModule\u003E.smethod_6<string>(1514754868U);
    this.checkBox_17.UseVisualStyleBackColor = true;
    this.checkBox_18.AutoSize = true;
    this.checkBox_18.ForeColor = Color.Black;
    this.checkBox_18.Location = new Point(110, 188);
    this.checkBox_18.Name = \u003CModule\u003E.smethod_5<string>(1642166691U);
    this.checkBox_18.Size = new Size(93, 19);
    this.checkBox_18.TabIndex = 160;
    this.checkBox_18.Text = \u003CModule\u003E.smethod_9<string>(3242783260U);
    this.checkBox_18.UseVisualStyleBackColor = true;
    this.checkBox_18.CheckedChanged += new EventHandler(this.checkBox_18_CheckedChanged);
    this.button_38.FlatStyle = FlatStyle.Flat;
    this.button_38.Location = new Point(10, 146);
    this.button_38.Name = \u003CModule\u003E.smethod_8<string>(917234970U);
    this.button_38.Size = new Size(75, 32);
    this.button_38.TabIndex = 159;
    this.button_38.Text = \u003CModule\u003E.smethod_7<string>(1689167523U);
    this.button_38.UseVisualStyleBackColor = true;
    this.button_38.Click += new EventHandler(this.button_38_Click);
    this.checkBox_19.AutoSize = true;
    this.checkBox_19.ForeColor = Color.Black;
    this.checkBox_19.Location = new Point(110, 142);
    this.checkBox_19.Name = \u003CModule\u003E.smethod_6<string>(118695878U);
    this.checkBox_19.Size = new Size(95, 19);
    this.checkBox_19.TabIndex = 158;
    this.checkBox_19.Text = \u003CModule\u003E.smethod_9<string>(3449050887U);
    this.checkBox_19.UseVisualStyleBackColor = true;
    this.checkBox_19.CheckedChanged += new EventHandler(this.checkBox_19_CheckedChanged);
    this.checkBox_20.AutoSize = true;
    this.checkBox_20.ForeColor = Color.Black;
    this.checkBox_20.Location = new Point(17, 188);
    this.checkBox_20.Name = \u003CModule\u003E.smethod_8<string>(863742417U);
    this.checkBox_20.Size = new Size(68, 19);
    this.checkBox_20.TabIndex = 2;
    this.checkBox_20.Text = \u003CModule\u003E.smethod_8<string>(3904923900U);
    this.checkBox_20.UseVisualStyleBackColor = true;
    this.checkBox_20.CheckedChanged += new EventHandler(this.checkBox_20_CheckedChanged);
    this.numericUpDown_4.Location = new Point(395, 167);
    this.numericUpDown_4.Maximum = new Decimal(new int[4]
    {
      (int) byte.MaxValue,
      0,
      0,
      0
    });
    this.numericUpDown_4.Name = \u003CModule\u003E.smethod_9<string>(1389728115U);
    this.numericUpDown_4.Size = new Size(49, 23);
    this.numericUpDown_4.TabIndex = 157;
    this.numericUpDown_4.ValueChanged += new EventHandler(this.numericUpDown_4_ValueChanged);
    this.numericUpDown_5.Location = new Point(395, 138);
    this.numericUpDown_5.Maximum = new Decimal(new int[4]
    {
      1500,
      0,
      0,
      0
    });
    this.numericUpDown_5.Name = \u003CModule\u003E.smethod_6<string>(3147834205U);
    this.numericUpDown_5.Size = new Size(49, 23);
    this.numericUpDown_5.TabIndex = 156;
    this.numericUpDown_5.ValueChanged += new EventHandler(this.numericUpDown_5_ValueChanged);
    this.numericUpDown_6.Location = new Point(395, 109);
    this.numericUpDown_6.Maximum = new Decimal(new int[4]
    {
      (int) byte.MaxValue,
      0,
      0,
      0
    });
    this.numericUpDown_6.Name = \u003CModule\u003E.smethod_9<string>(144376060U);
    this.numericUpDown_6.Size = new Size(49, 23);
    this.numericUpDown_6.TabIndex = 155;
    this.numericUpDown_6.ValueChanged += new EventHandler(this.numericUpDown_6_ValueChanged);
    this.numericUpDown_7.Location = new Point(395, 80);
    this.numericUpDown_7.Maximum = new Decimal(new int[4]
    {
      1500,
      0,
      0,
      0
    });
    this.numericUpDown_7.Name = \u003CModule\u003E.smethod_7<string>(3390835282U);
    this.numericUpDown_7.Size = new Size(49, 23);
    this.numericUpDown_7.TabIndex = 154;
    this.numericUpDown_7.ValueChanged += new EventHandler(this.numericUpDown_7_ValueChanged);
    this.numericUpDown_8.Location = new Point(395, 51);
    this.numericUpDown_8.Maximum = new Decimal(new int[4]
    {
      (int) byte.MaxValue,
      0,
      0,
      0
    });
    this.numericUpDown_8.Name = \u003CModule\u003E.smethod_7<string>(3117151233U);
    this.numericUpDown_8.Size = new Size(49, 23);
    this.numericUpDown_8.TabIndex = 153;
    this.numericUpDown_8.ValueChanged += new EventHandler(this.numericUpDown_8_ValueChanged);
    this.numericUpDown_9.Location = new Point(395, 22);
    this.numericUpDown_9.Maximum = new Decimal(new int[4]
    {
      1500,
      0,
      0,
      0
    });
    this.numericUpDown_9.Name = \u003CModule\u003E.smethod_9<string>(3036515633U);
    this.numericUpDown_9.Size = new Size(49, 23);
    this.numericUpDown_9.TabIndex = 152;
    this.numericUpDown_9.ValueChanged += new EventHandler(this.numericUpDown_9_ValueChanged);
    this.label_21.AutoSize = true;
    this.label_21.Location = new Point(9, 82);
    this.label_21.Name = \u003CModule\u003E.smethod_8<string>(2010543124U);
    this.label_21.Size = new Size(36, 15);
    this.label_21.TabIndex = 144;
    this.label_21.Text = \u003CModule\u003E.smethod_8<string>(1770484472U);
    this.label_21.TextAlign = ContentAlignment.MiddleCenter;
    this.numericUpDown_10.Location = new Point(173, 109);
    this.numericUpDown_10.Maximum = new Decimal(new int[4]
    {
      (int) byte.MaxValue,
      0,
      0,
      0
    });
    this.numericUpDown_10.Name = \u003CModule\u003E.smethod_6<string>(3822424005U);
    this.numericUpDown_10.Size = new Size(49, 23);
    this.numericUpDown_10.TabIndex = 151;
    this.numericUpDown_10.ValueChanged += new EventHandler(this.numericUpDown_10_ValueChanged);
    this.numericUpDown_11.Location = new Point(57, 80);
    this.numericUpDown_11.Maximum = new Decimal(new int[4]
    {
      (int) byte.MaxValue,
      0,
      0,
      0
    });
    this.numericUpDown_11.Name = \u003CModule\u003E.smethod_9<string>(2095015123U);
    this.numericUpDown_11.Size = new Size(49, 23);
    this.numericUpDown_11.TabIndex = 148;
    this.numericUpDown_11.ValueChanged += new EventHandler(this.numericUpDown_11_ValueChanged);
    this.numericUpDown_12.Location = new Point(173, 80);
    this.numericUpDown_12.Maximum = new Decimal(new int[4]
    {
      1500,
      0,
      0,
      0
    });
    this.numericUpDown_12.Name = \u003CModule\u003E.smethod_7<string>(3832474307U);
    this.numericUpDown_12.Size = new Size(49, 23);
    this.numericUpDown_12.TabIndex = 150;
    this.numericUpDown_12.ValueChanged += new EventHandler(this.numericUpDown_12_ValueChanged);
    this.numericUpDown_13.Location = new Point(173, 51);
    this.numericUpDown_13.Maximum = new Decimal(new int[4]
    {
      (int) byte.MaxValue,
      0,
      0,
      0
    });
    this.numericUpDown_13.Name = \u003CModule\u003E.smethod_7<string>(604250711U);
    this.numericUpDown_13.Size = new Size(49, 23);
    this.numericUpDown_13.TabIndex = 149;
    this.numericUpDown_13.ValueChanged += new EventHandler(this.numericUpDown_13_ValueChanged);
    this.numericUpDown_14.Location = new Point(173, 22);
    this.numericUpDown_14.Maximum = new Decimal(new int[4]
    {
      1500,
      0,
      0,
      0
    });
    this.numericUpDown_14.Name = \u003CModule\u003E.smethod_9<string>(2908985840U);
    this.numericUpDown_14.Size = new Size(49, 23);
    this.numericUpDown_14.TabIndex = 147;
    this.numericUpDown_14.ValueChanged += new EventHandler(this.numericUpDown_14_ValueChanged);
    this.numericUpDown_15.Location = new Point(57, 109);
    this.numericUpDown_15.Maximum = new Decimal(new int[4]
    {
      (int) byte.MaxValue,
      0,
      0,
      0
    });
    this.numericUpDown_15.Name = \u003CModule\u003E.smethod_5<string>(1494097086U);
    this.numericUpDown_15.Size = new Size(49, 23);
    this.numericUpDown_15.TabIndex = 146;
    this.numericUpDown_15.ValueChanged += new EventHandler(this.numericUpDown_15_ValueChanged);
    this.numericUpDown_16.Location = new Point(57, 51);
    this.numericUpDown_16.Maximum = new Decimal(new int[4]
    {
      1500,
      0,
      0,
      0
    });
    this.numericUpDown_16.Name = \u003CModule\u003E.smethod_6<string>(616176267U);
    this.numericUpDown_16.Size = new Size(49, 23);
    this.numericUpDown_16.TabIndex = 145;
    this.numericUpDown_16.ValueChanged += new EventHandler(this.numericUpDown_16_ValueChanged);
    this.label_22.AutoSize = true;
    this.label_22.Location = new Point(10, 53);
    this.label_22.Name = \u003CModule\u003E.smethod_9<string>(2301282750U);
    this.label_22.Size = new Size(35, 15);
    this.label_22.TabIndex = 143;
    this.label_22.Text = \u003CModule\u003E.smethod_5<string>(2092088345U);
    this.label_22.TextAlign = ContentAlignment.MiddleCenter;
    this.label_23.AutoSize = true;
    this.label_23.Location = new Point(120, 111);
    this.label_23.Name = \u003CModule\u003E.smethod_8<string>(2437167875U);
    this.label_23.Size = new Size(39, 15);
    this.label_23.TabIndex = 142;
    this.label_23.Text = \u003CModule\u003E.smethod_8<string>(2197109223U);
    this.label_23.TextAlign = ContentAlignment.MiddleCenter;
    this.label_24.AutoSize = true;
    this.label_24.Location = new Point(107, 82);
    this.label_24.Name = \u003CModule\u003E.smethod_9<string>(241959978U);
    this.label_24.Size = new Size(51, 15);
    this.label_24.TabIndex = 141;
    this.label_24.Text = \u003CModule\u003E.smethod_5<string>(2690079604U);
    this.label_24.TextAlign = ContentAlignment.MiddleCenter;
    this.label_25.AutoSize = true;
    this.label_25.Location = new Point(122, 53);
    this.label_25.Name = \u003CModule\u003E.smethod_5<string>(3352345385U);
    this.label_25.Size = new Size(37, 15);
    this.label_25.TabIndex = 140;
    this.label_25.Text = \u003CModule\u003E.smethod_9<string>(4105545936U);
    this.label_25.TextAlign = ContentAlignment.MiddleCenter;
    this.label_26.AutoSize = true;
    this.label_26.Location = new Point(118, 24);
    this.label_26.Name = \u003CModule\u003E.smethod_5<string>(3288070863U);
    this.label_26.Size = new Size(41, 15);
    this.label_26.TabIndex = 139;
    this.label_26.Text = \u003CModule\u003E.smethod_6<string>(1757107448U);
    this.label_26.TextAlign = ContentAlignment.MiddleCenter;
    this.label_27.AutoSize = true;
    this.label_27.Location = new Point(247, 169);
    this.label_27.Name = \u003CModule\u003E.smethod_9<string>(1649416103U);
    this.label_27.Size = new Size(94, 15);
    this.label_27.TabIndex = 138;
    this.label_27.Text = \u003CModule\u003E.smethod_5<string>(3483276473U);
    this.label_27.TextAlign = ContentAlignment.MiddleCenter;
    this.label_28.AutoSize = true;
    this.label_28.Location = new Point((int) byte.MaxValue, 111);
    this.label_28.Name = \u003CModule\u003E.smethod_5<string>(1303655564U);
    this.label_28.Size = new Size(86, 15);
    this.label_28.TabIndex = 137;
    this.label_28.Text = \u003CModule\u003E.smethod_5<string>(2692461648U);
    this.label_28.TextAlign = ContentAlignment.MiddleCenter;
    this.label_29.AutoSize = true;
    this.label_29.Location = new Point((int) byte.MaxValue, 53);
    this.label_29.Name = \u003CModule\u003E.smethod_8<string>(2416342127U);
    this.label_29.Size = new Size(87, 15);
    this.label_29.TabIndex = 136;
    this.label_29.Text = \u003CModule\u003E.smethod_6<string>(3957986259U);
    this.label_29.TextAlign = ContentAlignment.MiddleCenter;
    this.label_30.AutoSize = true;
    this.label_30.Location = new Point(279, 140);
    this.label_30.Name = \u003CModule\u003E.smethod_9<string>(4012590420U);
    this.label_30.Size = new Size(62, 15);
    this.label_30.TabIndex = 135;
    this.label_30.Text = \u003CModule\u003E.smethod_5<string>(1773097779U);
    this.label_30.TextAlign = ContentAlignment.MiddleCenter;
    this.label_31.AutoSize = true;
    this.label_31.Location = new Point(287, 82);
    this.label_31.Name = \u003CModule\u003E.smethod_9<string>(1041713013U);
    this.label_31.Size = new Size(54, 15);
    this.label_31.TabIndex = 134;
    this.label_31.Text = \u003CModule\u003E.smethod_9<string>(1855683730U);
    this.label_31.TextAlign = ContentAlignment.MiddleCenter;
    this.label_32.AutoSize = true;
    this.label_32.Location = new Point(287, 24);
    this.label_32.Name = \u003CModule\u003E.smethod_8<string>(869005109U);
    this.label_32.Size = new Size(55, 15);
    this.label_32.TabIndex = 133;
    this.label_32.Text = \u003CModule\u003E.smethod_5<string>(2371089038U);
    this.label_32.TextAlign = ContentAlignment.MiddleCenter;
    this.label_33.AutoSize = true;
    this.label_33.Location = new Point(11, 112);
    this.label_33.Name = \u003CModule\u003E.smethod_5<string>(3033354819U);
    this.label_33.Size = new Size(34, 15);
    this.label_33.TabIndex = 132;
    this.label_33.Text = \u003CModule\u003E.smethod_6<string>(2278027532U);
    this.label_33.TextAlign = ContentAlignment.MiddleCenter;
    this.label_34.AutoSize = true;
    this.label_34.Location = new Point(14, 24);
    this.label_34.Name = \u003CModule\u003E.smethod_6<string>(1863897774U);
    this.label_34.Size = new Size(31, 15);
    this.label_34.TabIndex = 131;
    this.label_34.Text = \u003CModule\u003E.smethod_8<string>(4096752691U);
    this.label_34.TextAlign = ContentAlignment.MiddleCenter;
    this.numericUpDown_17.Location = new Point(57, 22);
    this.numericUpDown_17.Maximum = new Decimal(new int[4]
    {
      (int) byte.MaxValue,
      0,
      0,
      0
    });
    this.numericUpDown_17.Name = \u003CModule\u003E.smethod_7<string>(567171659U);
    this.numericUpDown_17.Size = new Size(49, 23);
    this.numericUpDown_17.TabIndex = 0;
    this.numericUpDown_17.ValueChanged += new EventHandler(this.numericUpDown_17_ValueChanged);
    this.groupBox_24.Controls.Add((Control) this.button_39);
    this.groupBox_24.Controls.Add((Control) this.label_35);
    this.groupBox_24.Controls.Add((Control) this.listBox_3);
    this.groupBox_24.Controls.Add((Control) this.button_40);
    this.groupBox_24.Controls.Add((Control) this.textBox_13);
    this.groupBox_24.Controls.Add((Control) this.comboBox_2);
    this.groupBox_24.Location = new Point(462, 300);
    this.groupBox_24.Name = \u003CModule\u003E.smethod_6<string>(3520416806U);
    this.groupBox_24.Size = new Size(375, 213);
    this.groupBox_24.TabIndex = 129;
    this.groupBox_24.TabStop = false;
    this.groupBox_24.Text = \u003CModule\u003E.smethod_8<string>(3269591629U);
    this.button_39.FlatStyle = FlatStyle.Flat;
    this.button_39.Location = new Point(301, 34);
    this.button_39.Name = \u003CModule\u003E.smethod_5<string>(3463755912U);
    this.button_39.Size = new Size(68, 56);
    this.button_39.TabIndex = 132;
    this.button_39.Text = \u003CModule\u003E.smethod_9<string>(988528259U);
    this.button_39.UseVisualStyleBackColor = true;
    this.button_39.Click += new EventHandler(this.button_39_Click);
    this.label_35.AutoSize = true;
    this.label_35.Location = new Point(75, 133);
    this.label_35.Name = \u003CModule\u003E.smethod_8<string>(521961351U);
    this.label_35.Size = new Size(220, 45);
    this.label_35.TabIndex = 130;
    this.label_35.Text = \u003CModule\u003E.smethod_8<string>(2202371915U);
    this.label_35.TextAlign = ContentAlignment.MiddleCenter;
    this.listBox_3.FormattingEnabled = true;
    this.listBox_3.ItemHeight = 15;
    this.listBox_3.Location = new Point(7, 22);
    this.listBox_3.Name = \u003CModule\u003E.smethod_9<string>(1953267648U);
    this.listBox_3.Size = new Size(288, 79);
    this.listBox_3.TabIndex = 130;
    this.button_40.FlatStyle = FlatStyle.Flat;
    this.button_40.Location = new Point(301, 107);
    this.button_40.Name = \u003CModule\u003E.smethod_5<string>(1625028174U);
    this.button_40.Size = new Size(68, 23);
    this.button_40.TabIndex = 131;
    this.button_40.Text = \u003CModule\u003E.smethod_5<string>(3013834258U);
    this.button_40.UseVisualStyleBackColor = true;
    this.button_40.Click += new EventHandler(this.button_40_Click);
    this.textBox_13.Location = new Point(185, 107);
    this.textBox_13.Name = \u003CModule\u003E.smethod_6<string>(2645277900U);
    this.textBox_13.Size = new Size(110, 23);
    this.textBox_13.TabIndex = 130;
    this.textBox_13.Enter += new EventHandler(this.textBox_20_Enter);
    this.textBox_13.Leave += new EventHandler(this.textBox_20_Leave);
    this.comboBox_2.FormattingEnabled = true;
    this.comboBox_2.Location = new Point(7, 107);
    this.comboBox_2.Name = \u003CModule\u003E.smethod_9<string>(1011767138U);
    this.comboBox_2.Size = new Size(172, 23);
    this.comboBox_2.TabIndex = 128;
    this.comboBox_2.Text = \u003CModule\u003E.smethod_6<string>(6829636U);
    this.groupBox_25.Controls.Add((Control) this.checkBox_21);
    this.groupBox_25.Controls.Add((Control) this.numericUpDown_18);
    this.groupBox_25.Controls.Add((Control) this.checkBox_22);
    this.groupBox_25.Controls.Add((Control) this.checkBox_23);
    this.groupBox_25.Location = new Point(462, 6);
    this.groupBox_25.Name = \u003CModule\u003E.smethod_5<string>(1471245730U);
    this.groupBox_25.Size = new Size(222, 100);
    this.groupBox_25.TabIndex = 5;
    this.groupBox_25.TabStop = false;
    this.groupBox_25.Text = \u003CModule\u003E.smethod_8<string>(2364165247U);
    this.checkBox_21.AutoSize = true;
    this.checkBox_21.ForeColor = Color.Black;
    this.checkBox_21.Location = new Point(8, 72);
    this.checkBox_21.Name = \u003CModule\u003E.smethod_9<string>(1150396722U);
    this.checkBox_21.Size = new Size(86, 19);
    this.checkBox_21.TabIndex = 9;
    this.checkBox_21.Text = \u003CModule\u003E.smethod_9<string>(1709307853U);
    this.checkBox_21.UseVisualStyleBackColor = true;
    this.checkBox_21.CheckedChanged += new EventHandler(this.checkBox_21_CheckedChanged);
    this.numericUpDown_18.ForeColor = Color.Black;
    this.numericUpDown_18.Location = new Point(108, 43);
    this.numericUpDown_18.Maximum = new Decimal(new int[4]
    {
      1000,
      0,
      0,
      0
    });
    this.numericUpDown_18.Name = \u003CModule\u003E.smethod_8<string>(3564458507U);
    this.numericUpDown_18.Size = new Size(43, 23);
    this.numericUpDown_18.TabIndex = 8;
    this.numericUpDown_18.TextAlign = HorizontalAlignment.Center;
    this.numericUpDown_18.Value = new Decimal(new int[4]
    {
      1,
      0,
      0,
      0
    });
    this.numericUpDown_18.ValueChanged += new EventHandler(this.numericUpDown_18_ValueChanged);
    this.checkBox_22.AutoSize = true;
    this.checkBox_22.ForeColor = Color.Black;
    this.checkBox_22.Location = new Point(8, 45);
    this.checkBox_22.Name = \u003CModule\u003E.smethod_5<string>(1278422164U);
    this.checkBox_22.Size = new Size(101, 19);
    this.checkBox_22.TabIndex = 7;
    this.checkBox_22.Text = \u003CModule\u003E.smethod_8<string>(1056886881U);
    this.checkBox_22.UseVisualStyleBackColor = true;
    this.checkBox_22.CheckedChanged += new EventHandler(this.checkBox_22_CheckedChanged);
    this.checkBox_23.AutoSize = true;
    this.checkBox_23.ForeColor = Color.Black;
    this.checkBox_23.Location = new Point(8, 20);
    this.checkBox_23.Name = \u003CModule\u003E.smethod_9<string>(767807343U);
    this.checkBox_23.Size = new Size(123, 19);
    this.checkBox_23.TabIndex = 1;
    this.checkBox_23.Text = \u003CModule\u003E.smethod_5<string>(3265219507U);
    this.checkBox_23.UseVisualStyleBackColor = true;
    this.checkBox_23.CheckedChanged += new EventHandler(this.checkBox_23_CheckedChanged);
    this.groupBox_26.Controls.Add((Control) this.checkBox_24);
    this.groupBox_26.Controls.Add((Control) this.checkBox_25);
    this.groupBox_26.Controls.Add((Control) this.checkBox_26);
    this.groupBox_26.Controls.Add((Control) this.checkBox_27);
    this.groupBox_26.Controls.Add((Control) this.checkBox_28);
    this.groupBox_26.Location = new Point(234, 6);
    this.groupBox_26.Name = \u003CModule\u003E.smethod_8<string>(2017121489U);
    this.groupBox_26.Size = new Size(222, 100);
    this.groupBox_26.TabIndex = 1;
    this.groupBox_26.TabStop = false;
    this.groupBox_26.Text = \u003CModule\u003E.smethod_6<string>(4181975060U);
    this.checkBox_24.AutoSize = true;
    this.checkBox_24.Enabled = false;
    this.checkBox_24.ForeColor = Color.Gray;
    this.checkBox_24.Location = new Point(6, 72);
    this.checkBox_24.Name = \u003CModule\u003E.smethod_6<string>(1957656554U);
    this.checkBox_24.Size = new Size(73, 19);
    this.checkBox_24.TabIndex = 5;
    this.checkBox_24.Text = \u003CModule\u003E.smethod_6<string>(1129397038U);
    this.checkBox_24.UseVisualStyleBackColor = true;
    this.checkBox_24.CheckedChanged += new EventHandler(this.checkBox_24_CheckedChanged);
    this.checkBox_25.AutoSize = true;
    this.checkBox_25.Enabled = false;
    this.checkBox_25.ForeColor = Color.Gray;
    this.checkBox_25.Location = new Point(6, 47);
    this.checkBox_25.Name = \u003CModule\u003E.smethod_5<string>(3008121419U);
    this.checkBox_25.Size = new Size(55, 19);
    this.checkBox_25.TabIndex = 1;
    this.checkBox_25.Text = \u003CModule\u003E.smethod_6<string>(431367543U);
    this.checkBox_25.UseVisualStyleBackColor = true;
    this.checkBox_25.CheckedChanged += new EventHandler(this.checkBox_25_CheckedChanged);
    this.checkBox_26.AutoSize = true;
    this.checkBox_26.Enabled = false;
    this.checkBox_26.ForeColor = Color.Gray;
    this.checkBox_26.Location = new Point(98, 72);
    this.checkBox_26.Name = \u003CModule\u003E.smethod_8<string>(122740713U);
    this.checkBox_26.Size = new Size(91, 19);
    this.checkBox_26.TabIndex = 4;
    this.checkBox_26.Text = \u003CModule\u003E.smethod_5<string>(3567071556U);
    this.checkBox_26.UseVisualStyleBackColor = true;
    this.checkBox_26.CheckedChanged += new EventHandler(this.checkBox_26_CheckedChanged);
    this.checkBox_27.AutoSize = true;
    this.checkBox_27.Enabled = false;
    this.checkBox_27.ForeColor = Color.Gray;
    this.checkBox_27.Location = new Point(98, 47);
    this.checkBox_27.Name = \u003CModule\u003E.smethod_6<string>(3046376112U);
    this.checkBox_27.Size = new Size(90, 19);
    this.checkBox_27.TabIndex = 3;
    this.checkBox_27.Text = \u003CModule\u003E.smethod_9<string>(2365802902U);
    this.checkBox_27.UseVisualStyleBackColor = true;
    this.checkBox_27.CheckedChanged += new EventHandler(this.checkBox_27_CheckedChanged);
    this.checkBox_28.AutoSize = true;
    this.checkBox_28.ForeColor = Color.Black;
    this.checkBox_28.Location = new Point(6, 22);
    this.checkBox_28.Name = \u003CModule\u003E.smethod_8<string>(69248160U);
    this.checkBox_28.Size = new Size(61, 19);
    this.checkBox_28.TabIndex = 0;
    this.checkBox_28.Text = \u003CModule\u003E.smethod_9<string>(2803655629U);
    this.checkBox_28.UseVisualStyleBackColor = true;
    this.checkBox_28.CheckedChanged += new EventHandler(this.checkBox_28_CheckedChanged);
    this.groupBox_27.Controls.Add((Control) this.checkBox_29);
    this.groupBox_27.Controls.Add((Control) this.checkBox_30);
    this.groupBox_27.Controls.Add((Control) this.checkBox_31);
    this.groupBox_27.Controls.Add((Control) this.checkBox_32);
    this.groupBox_27.Controls.Add((Control) this.checkBox_33);
    this.groupBox_27.Controls.Add((Control) this.checkBox_34);
    this.groupBox_27.Location = new Point(6, 6);
    this.groupBox_27.Name = \u003CModule\u003E.smethod_8<string>(1856643830U);
    this.groupBox_27.Size = new Size(222, 100);
    this.groupBox_27.TabIndex = 0;
    this.groupBox_27.TabStop = false;
    this.groupBox_27.Text = \u003CModule\u003E.smethod_8<string>(362799365U);
    this.checkBox_29.AutoSize = true;
    this.checkBox_29.ForeColor = Color.Black;
    this.checkBox_29.Location = new Point(98, 47);
    this.checkBox_29.Name = \u003CModule\u003E.smethod_7<string>(1521945375U);
    this.checkBox_29.Size = new Size(83, 19);
    this.checkBox_29.TabIndex = 4;
    this.checkBox_29.Text = \u003CModule\u003E.smethod_9<string>(2189481150U);
    this.checkBox_29.UseVisualStyleBackColor = true;
    this.checkBox_29.CheckedChanged += new EventHandler(this.checkBox_29_CheckedChanged);
    this.checkBox_30.AutoSize = true;
    this.checkBox_30.ForeColor = Color.Black;
    this.checkBox_30.Location = new Point(6, 72);
    this.checkBox_30.Name = \u003CModule\u003E.smethod_8<string>(549365464U);
    this.checkBox_30.Size = new Size(79, 19);
    this.checkBox_30.TabIndex = 2;
    this.checkBox_30.Text = \u003CModule\u003E.smethod_5<string>(3117149902U);
    this.checkBox_30.UseVisualStyleBackColor = true;
    this.checkBox_30.CheckedChanged += new EventHandler(this.checkBox_30_CheckedChanged);
    this.checkBox_31.AutoSize = true;
    this.checkBox_31.Enabled = false;
    this.checkBox_31.ForeColor = Color.Gray;
    this.checkBox_31.Location = new Point(98, 72);
    this.checkBox_31.Name = \u003CModule\u003E.smethod_9<string>(1375510433U);
    this.checkBox_31.Size = new Size(112, 19);
    this.checkBox_31.TabIndex = 5;
    this.checkBox_31.Text = \u003CModule\u003E.smethod_7<string>(3683425271U);
    this.checkBox_31.UseVisualStyleBackColor = true;
    this.checkBox_31.CheckedChanged += new EventHandler(this.checkBox_31_CheckedChanged);
    this.checkBox_32.AutoSize = true;
    this.checkBox_32.ForeColor = Color.Black;
    this.checkBox_32.Location = new Point(98, 22);
    this.checkBox_32.Name = \u003CModule\u003E.smethod_6<string>(3567296196U);
    this.checkBox_32.Size = new Size(107, 19);
    this.checkBox_32.TabIndex = 3;
    this.checkBox_32.Text = \u003CModule\u003E.smethod_8<string>(1133836528U);
    this.checkBox_32.UseVisualStyleBackColor = true;
    this.checkBox_32.CheckedChanged += new EventHandler(this.checkBox_32_CheckedChanged);
    this.checkBox_33.AutoSize = true;
    this.checkBox_33.Checked = true;
    this.checkBox_33.CheckState = CheckState.Checked;
    this.checkBox_33.ForeColor = Color.Black;
    this.checkBox_33.Location = new Point(6, 47);
    this.checkBox_33.Name = \u003CModule\u003E.smethod_7<string>(3649191864U);
    this.checkBox_33.Size = new Size(86, 19);
    this.checkBox_33.TabIndex = 1;
    this.checkBox_33.Text = \u003CModule\u003E.smethod_6<string>(2113949667U);
    this.checkBox_33.UseVisualStyleBackColor = true;
    this.checkBox_33.CheckedChanged += new EventHandler(this.checkBox_33_CheckedChanged);
    this.checkBox_34.AutoSize = true;
    this.checkBox_34.Checked = true;
    this.checkBox_34.CheckState = CheckState.Checked;
    this.checkBox_34.ForeColor = Color.Black;
    this.checkBox_34.Location = new Point(6, 22);
    this.checkBox_34.Name = \u003CModule\u003E.smethod_8<string>(3454842055U);
    this.checkBox_34.Size = new Size(72, 19);
    this.checkBox_34.TabIndex = 0;
    this.checkBox_34.Text = \u003CModule\u003E.smethod_5<string>(1823564579U);
    this.checkBox_34.UseVisualStyleBackColor = true;
    this.checkBox_34.CheckedChanged += new EventHandler(this.checkBox_34_CheckedChanged);
    this.tabPage_7.Controls.Add((Control) this.tabControl_0);
    this.tabPage_7.ForeColor = Color.Black;
    this.tabPage_7.Location = new Point(4, 24);
    this.tabPage_7.Margin = new Padding(0);
    this.tabPage_7.Name = \u003CModule\u003E.smethod_8<string>(1854012484U);
    this.tabPage_7.Size = new Size(842, 516);
    this.tabPage_7.TabIndex = 2;
    this.tabPage_7.Text = \u003CModule\u003E.smethod_8<string>(360168019U);
    this.tabPage_7.UseVisualStyleBackColor = true;
    this.tabControl_0.Controls.Add((Control) this.tabPage_8);
    this.tabControl_0.Location = new Point(0, 0);
    this.tabControl_0.Margin = new Padding(0);
    this.tabControl_0.Name = \u003CModule\u003E.smethod_8<string>(1373895180U);
    this.tabControl_0.Padding = new Point(0, 0);
    this.tabControl_0.SelectedIndex = 0;
    this.tabControl_0.Size = new Size(846, 520);
    this.tabControl_0.TabIndex = 0;
    this.tabControl_0.SelectedIndexChanged += new EventHandler(this.tabControl_0_SelectedIndexChanged);
    this.tabPage_8.BackColor = Color.White;
    this.tabPage_8.Controls.Add((Control) this.tableLayoutPanel_0);
    this.tabPage_8.Location = new Point(4, 24);
    this.tabPage_8.Margin = new Padding(0);
    this.tabPage_8.Name = \u003CModule\u003E.smethod_8<string>(786792770U);
    this.tabPage_8.Size = new Size(838, 492);
    this.tabPage_8.TabIndex = 1;
    this.tabPage_8.Text = \u003CModule\u003E.smethod_5<string>(3019547097U);
    this.tableLayoutPanel_0.ColumnCount = 3;
    this.tableLayoutPanel_0.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33333f));
    this.tableLayoutPanel_0.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33334f));
    this.tableLayoutPanel_0.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33334f));
    this.tableLayoutPanel_0.Location = new Point(0, 0);
    this.tableLayoutPanel_0.Name = \u003CModule\u003E.smethod_9<string>(1033966720U);
    this.tableLayoutPanel_0.RowCount = 3;
    this.tableLayoutPanel_0.RowStyles.Add(new RowStyle(SizeType.Percent, 33.33333f));
    this.tableLayoutPanel_0.RowStyles.Add(new RowStyle(SizeType.Percent, 33.33333f));
    this.tableLayoutPanel_0.RowStyles.Add(new RowStyle(SizeType.Percent, 33.33333f));
    this.tableLayoutPanel_0.Size = new Size(838, 492);
    this.tableLayoutPanel_0.TabIndex = 0;
    this.tabPage_9.Controls.Add((Control) this.tabControl_1);
    this.tabPage_9.ForeColor = Color.Black;
    this.tabPage_9.Location = new Point(4, 24);
    this.tabPage_9.Margin = new Padding(3, 0, 0, 0);
    this.tabPage_9.Name = \u003CModule\u003E.smethod_7<string>(1214027919U);
    this.tabPage_9.Size = new Size(842, 516);
    this.tabPage_9.TabIndex = 1;
    this.tabPage_9.Text = \u003CModule\u003E.smethod_7<string>(3621199368U);
    this.tabPage_9.UseVisualStyleBackColor = true;
    this.tabControl_1.Controls.Add((Control) this.tabPage_10);
    this.tabControl_1.Controls.Add((Control) this.tabPage_11);
    this.tabControl_1.Location = new Point(0, 0);
    this.tabControl_1.Margin = new Padding(0);
    this.tabControl_1.Name = \u003CModule\u003E.smethod_8<string>(253182913U);
    this.tabControl_1.Padding = new Point(0, 0);
    this.tabControl_1.SelectedIndex = 0;
    this.tabControl_1.Size = new Size(846, 520);
    this.tabControl_1.TabIndex = 0;
    this.tabControl_1.SelectedIndexChanged += new EventHandler(this.tabControl_1_SelectedIndexChanged);
    this.tabControl_1.ControlAdded += new ControlEventHandler(this.tabControl_1_ControlAdded);
    this.tabPage_10.BackColor = Color.White;
    this.tabPage_10.Controls.Add((Control) this.groupBox_44);
    this.tabPage_10.Controls.Add((Control) this.groupBox_28);
    this.tabPage_10.Controls.Add((Control) this.groupBox_29);
    this.tabPage_10.Controls.Add((Control) this.groupBox_30);
    this.tabPage_10.Controls.Add((Control) this.groupBox_31);
    this.tabPage_10.Controls.Add((Control) this.groupBox_32);
    this.tabPage_10.Controls.Add((Control) this.groupBox_33);
    this.tabPage_10.Controls.Add((Control) this.groupBox_34);
    this.tabPage_10.Controls.Add((Control) this.groupBox_35);
    this.tabPage_10.Controls.Add((Control) this.groupBox_36);
    this.tabPage_10.Controls.Add((Control) this.groupBox_37);
    this.tabPage_10.ForeColor = Color.Black;
    this.tabPage_10.Location = new Point(4, 24);
    this.tabPage_10.Name = \u003CModule\u003E.smethod_5<string>(4215529615U);
    this.tabPage_10.Size = new Size(838, 492);
    this.tabPage_10.TabIndex = 0;
    this.tabPage_10.Text = \u003CModule\u003E.smethod_5<string>(1996867584U);
    this.groupBox_44.Controls.Add((Control) this.textBox_21);
    this.groupBox_44.Controls.Add((Control) this.checkBox_89);
    this.groupBox_44.Location = new Point(388, 272);
    this.groupBox_44.Name = \u003CModule\u003E.smethod_9<string>(366371880U);
    this.groupBox_44.Size = new Size(219, 211);
    this.groupBox_44.TabIndex = 12;
    this.groupBox_44.TabStop = false;
    this.groupBox_44.Text = \u003CModule\u003E.smethod_5<string>(2133511511U);
    this.textBox_21.BackColor = Color.White;
    this.textBox_21.ForeColor = Color.Black;
    this.textBox_21.Location = new Point(125, 20);
    this.textBox_21.Name = \u003CModule\u003E.smethod_7<string>(1080306350U);
    this.textBox_21.Size = new Size(76, 23);
    this.textBox_21.TabIndex = 19;
    this.textBox_21.Text = \u003CModule\u003E.smethod_8<string>(2227144682U);
    this.textBox_21.TextAlign = HorizontalAlignment.Center;
    this.checkBox_89.AutoSize = true;
    this.checkBox_89.ForeColor = Color.Black;
    this.checkBox_89.Location = new Point(7, 22);
    this.checkBox_89.Name = \u003CModule\u003E.smethod_8<string>(3000813191U);
    this.checkBox_89.Size = new Size(104, 19);
    this.checkBox_89.TabIndex = 19;
    this.checkBox_89.Text = \u003CModule\u003E.smethod_7<string>(2996094693U);
    this.checkBox_89.UseVisualStyleBackColor = true;
    this.groupBox_28.Controls.Add((Control) this.label_36);
    this.groupBox_28.Controls.Add((Control) this.numericUpDown_19);
    this.groupBox_28.Controls.Add((Control) this.button_41);
    this.groupBox_28.Controls.Add((Control) this.checkBox_35);
    this.groupBox_28.Controls.Add((Control) this.button_42);
    this.groupBox_28.Controls.Add((Control) this.button_43);
    this.groupBox_28.Controls.Add((Control) this.textBox_14);
    this.groupBox_28.Controls.Add((Control) this.listBox_4);
    this.groupBox_28.Location = new Point(613, 272);
    this.groupBox_28.Name = \u003CModule\u003E.smethod_6<string>(1369040782U);
    this.groupBox_28.Size = new Size(219, 211);
    this.groupBox_28.TabIndex = 11;
    this.groupBox_28.TabStop = false;
    this.groupBox_28.Text = \u003CModule\u003E.smethod_9<string>(3160927535U);
    this.label_36.AutoSize = true;
    this.label_36.ForeColor = Color.Black;
    this.label_36.Location = new Point(143, 35);
    this.label_36.Name = \u003CModule\u003E.smethod_5<string>(3064301058U);
    this.label_36.Size = new Size(55, 15);
    this.label_36.TabIndex = 21;
    this.label_36.Text = \u003CModule\u003E.smethod_6<string>(3286019856U);
    this.numericUpDown_19.ForeColor = Color.Black;
    this.numericUpDown_19.Location = new Point(152, 53);
    this.numericUpDown_19.Name = \u003CModule\u003E.smethod_7<string>(1543696960U);
    this.numericUpDown_19.Size = new Size(43, 23);
    this.numericUpDown_19.TabIndex = 20;
    this.numericUpDown_19.TextAlign = HorizontalAlignment.Center;
    this.numericUpDown_19.Value = new Decimal(new int[4]
    {
      10,
      0,
      0,
      0
    });
    this.button_41.FlatStyle = FlatStyle.Flat;
    this.button_41.ForeColor = Color.Black;
    this.button_41.Location = new Point(132, 81);
    this.button_41.Name = \u003CModule\u003E.smethod_8<string>(1292998514U);
    this.button_41.Size = new Size(81, 44);
    this.button_41.TabIndex = 19;
    this.button_41.Text = \u003CModule\u003E.smethod_9<string>(2425694652U);
    this.button_41.UseVisualStyleBackColor = true;
    this.button_41.Click += new EventHandler(this.button_41_Click);
    this.checkBox_35.AutoSize = true;
    this.checkBox_35.ForeColor = Color.Black;
    this.checkBox_35.Location = new Point(153, 14);
    this.checkBox_35.Name = \u003CModule\u003E.smethod_6<string>(3002120119U);
    this.checkBox_35.Size = new Size(61, 19);
    this.checkBox_35.TabIndex = 18;
    this.checkBox_35.Text = \u003CModule\u003E.smethod_5<string>(1564084447U);
    this.checkBox_35.UseVisualStyleBackColor = true;
    this.button_42.FlatStyle = FlatStyle.Flat;
    this.button_42.ForeColor = Color.Black;
    this.button_42.Location = new Point(132, 132);
    this.button_42.Name = \u003CModule\u003E.smethod_5<string>(602348661U);
    this.button_42.Size = new Size(81, 44);
    this.button_42.TabIndex = 17;
    this.button_42.Text = \u003CModule\u003E.smethod_7<string>(470712349U);
    this.button_42.UseVisualStyleBackColor = true;
    this.button_42.Click += new EventHandler(this.button_42_Click);
    this.button_43.FlatStyle = FlatStyle.Flat;
    this.button_43.ForeColor = Color.Black;
    this.button_43.Location = new Point(132, 181);
    this.button_43.Name = \u003CModule\u003E.smethod_5<string>(2653420526U);
    this.button_43.Size = new Size(81, 23);
    this.button_43.TabIndex = 16;
    this.button_43.Text = \u003CModule\u003E.smethod_5<string>(1862605701U);
    this.button_43.UseVisualStyleBackColor = true;
    this.button_43.Click += new EventHandler(this.button_43_Click);
    this.textBox_14.AcceptsReturn = true;
    this.textBox_14.ForeColor = Color.Black;
    this.textBox_14.Location = new Point(6, 181);
    this.textBox_14.MaxLength = 25;
    this.textBox_14.Name = \u003CModule\u003E.smethod_6<string>(811649457U);
    this.textBox_14.Size = new Size(120, 23);
    this.textBox_14.TabIndex = 10;
    this.textBox_14.TextAlign = HorizontalAlignment.Center;
    this.textBox_14.Enter += new EventHandler(this.textBox_20_Enter);
    this.textBox_14.KeyPress += new KeyPressEventHandler(this.textBox_14_KeyPress);
    this.textBox_14.Leave += new EventHandler(this.textBox_20_Leave);
    this.listBox_4.BackColor = Color.White;
    this.listBox_4.ForeColor = Color.Black;
    this.listBox_4.FormattingEnabled = true;
    this.listBox_4.ItemHeight = 15;
    this.listBox_4.Location = new Point(6, 22);
    this.listBox_4.Name = \u003CModule\u003E.smethod_7<string>(4246304043U);
    this.listBox_4.SelectionMode = SelectionMode.MultiExtended;
    this.listBox_4.Size = new Size(120, 154);
    this.listBox_4.TabIndex = 1;
    this.groupBox_29.Controls.Add((Control) this.checkBox_36);
    this.groupBox_29.Controls.Add((Control) this.checkBox_37);
    this.groupBox_29.Controls.Add((Control) this.checkBox_38);
    this.groupBox_29.Controls.Add((Control) this.checkBox_39);
    this.groupBox_29.Controls.Add((Control) this.checkBox_40);
    this.groupBox_29.Controls.Add((Control) this.checkBox_41);
    this.groupBox_29.Location = new Point(388, 60);
    this.groupBox_29.Name = \u003CModule\u003E.smethod_9<string>(711269091U);
    this.groupBox_29.Size = new Size(219, 100);
    this.groupBox_29.TabIndex = 9;
    this.groupBox_29.TabStop = false;
    this.groupBox_29.Text = \u003CModule\u003E.smethod_8<string>(441064685U);
    this.checkBox_36.AutoSize = true;
    this.checkBox_36.ForeColor = Color.Black;
    this.checkBox_36.Location = new Point(11, 72);
    this.checkBox_36.Name = \u003CModule\u003E.smethod_9<string>(3760884332U);
    this.checkBox_36.Size = new Size(74, 19);
    this.checkBox_36.TabIndex = 21;
    this.checkBox_36.Text = \u003CModule\u003E.smethod_6<string>(3296428005U);
    this.checkBox_36.UseVisualStyleBackColor = true;
    this.checkBox_37.AutoSize = true;
    this.checkBox_37.Checked = true;
    this.checkBox_37.CheckState = CheckState.Checked;
    this.checkBox_37.ForeColor = Color.Black;
    this.checkBox_37.Location = new Point(11, 45);
    this.checkBox_37.Name = \u003CModule\u003E.smethod_7<string>(2821898806U);
    this.checkBox_37.Size = new Size(100, 19);
    this.checkBox_37.TabIndex = 20;
    this.checkBox_37.Text = \u003CModule\u003E.smethod_9<string>(1574031767U);
    this.checkBox_37.UseVisualStyleBackColor = true;
    this.checkBox_38.AutoSize = true;
    this.checkBox_38.ForeColor = Color.Black;
    this.checkBox_38.Location = new Point(116, 72);
    this.checkBox_38.Name = \u003CModule\u003E.smethod_8<string>(147513480U);
    this.checkBox_38.Size = new Size(85, 19);
    this.checkBox_38.TabIndex = 19;
    this.checkBox_38.Text = \u003CModule\u003E.smethod_5<string>(3592304956U);
    this.checkBox_38.UseVisualStyleBackColor = true;
    this.checkBox_39.AutoSize = true;
    this.checkBox_39.ForeColor = Color.Black;
    this.checkBox_39.Location = new Point(116, 20);
    this.checkBox_39.Name = \u003CModule\u003E.smethod_7<string>(2470478180U);
    this.checkBox_39.Size = new Size(64, 19);
    this.checkBox_39.TabIndex = 18;
    this.checkBox_39.Text = \u003CModule\u003E.smethod_6<string>(3556888047U);
    this.checkBox_39.UseVisualStyleBackColor = true;
    this.checkBox_40.AutoSize = true;
    this.checkBox_40.ForeColor = Color.Black;
    this.checkBox_40.Location = new Point(116, 45);
    this.checkBox_40.Name = \u003CModule\u003E.smethod_5<string>(1971634184U);
    this.checkBox_40.Size = new Size(102, 19);
    this.checkBox_40.TabIndex = 16;
    this.checkBox_40.Text = \u003CModule\u003E.smethod_8<string>(3908870919U);
    this.checkBox_40.UseVisualStyleBackColor = true;
    this.checkBox_41.AutoSize = true;
    this.checkBox_41.ForeColor = Color.Black;
    this.checkBox_41.Location = new Point(11, 20);
    this.checkBox_41.Name = \u003CModule\u003E.smethod_7<string>(4112582474U);
    this.checkBox_41.Size = new Size(99, 19);
    this.checkBox_41.TabIndex = 15;
    this.checkBox_41.Text = \u003CModule\u003E.smethod_6<string>(3533448352U);
    this.checkBox_41.UseVisualStyleBackColor = true;
    this.groupBox_30.Controls.Add((Control) this.checkBox_42);
    this.groupBox_30.Controls.Add((Control) this.checkBox_43);
    this.groupBox_30.Controls.Add((Control) this.checkBox_44);
    this.groupBox_30.ForeColor = Color.Black;
    this.groupBox_30.Location = new Point(507, 166);
    this.groupBox_30.Name = \u003CModule\u003E.smethod_9<string>(1847937437U);
    this.groupBox_30.Size = new Size(100, 100);
    this.groupBox_30.TabIndex = 7;
    this.groupBox_30.TabStop = false;
    this.groupBox_30.Text = \u003CModule\u003E.smethod_5<string>(261455490U);
    this.checkBox_42.AutoSize = true;
    this.checkBox_42.ForeColor = Color.Black;
    this.checkBox_42.Location = new Point(6, 22);
    this.checkBox_42.Name = \u003CModule\u003E.smethod_7<string>(3754920937U);
    this.checkBox_42.Size = new Size(75, 19);
    this.checkBox_42.TabIndex = 14;
    this.checkBox_42.Text = \u003CModule\u003E.smethod_9<string>(2181734857U);
    this.checkBox_42.UseVisualStyleBackColor = true;
    this.checkBox_43.AutoSize = true;
    this.checkBox_43.ForeColor = Color.Black;
    this.checkBox_43.Location = new Point(6, 72);
    this.checkBox_43.Name = \u003CModule\u003E.smethod_5<string>(1585987052U);
    this.checkBox_43.Size = new Size(93, 19);
    this.checkBox_43.TabIndex = 11;
    this.checkBox_43.Text = \u003CModule\u003E.smethod_7<string>(2716169733U);
    this.checkBox_43.UseVisualStyleBackColor = true;
    this.checkBox_44.AutoSize = true;
    this.checkBox_44.ForeColor = Color.Black;
    this.checkBox_44.Location = new Point(6, 47);
    this.checkBox_44.Name = \u003CModule\u003E.smethod_5<string>(2183978311U);
    this.checkBox_44.Size = new Size(84, 19);
    this.checkBox_44.TabIndex = 9;
    this.checkBox_44.Text = \u003CModule\u003E.smethod_8<string>(467153125U);
    this.checkBox_44.UseVisualStyleBackColor = true;
    this.groupBox_31.Controls.Add((Control) this.textBox_15);
    this.groupBox_31.Controls.Add((Control) this.comboBox_3);
    this.groupBox_31.Controls.Add((Control) this.checkBox_45);
    this.groupBox_31.Controls.Add((Control) this.checkBox_46);
    this.groupBox_31.Controls.Add((Control) this.checkBox_47);
    this.groupBox_31.Controls.Add((Control) this.checkBox_48);
    this.groupBox_31.Controls.Add((Control) this.checkBox_49);
    this.groupBox_31.Controls.Add((Control) this.checkBox_50);
    this.groupBox_31.Controls.Add((Control) this.checkBox_51);
    this.groupBox_31.Controls.Add((Control) this.checkBox_52);
    this.groupBox_31.Controls.Add((Control) this.textBox_16);
    this.groupBox_31.Controls.Add((Control) this.checkBox_53);
    this.groupBox_31.Controls.Add((Control) this.checkBox_54);
    this.groupBox_31.Controls.Add((Control) this.checkBox_55);
    this.groupBox_31.Controls.Add((Control) this.checkBox_56);
    this.groupBox_31.Controls.Add((Control) this.checkBox_57);
    this.groupBox_31.Controls.Add((Control) this.checkBox_58);
    this.groupBox_31.Controls.Add((Control) this.checkBox_59);
    this.groupBox_31.Controls.Add((Control) this.checkBox_60);
    this.groupBox_31.Controls.Add((Control) this.checkBox_61);
    this.groupBox_31.Controls.Add((Control) this.checkBox_62);
    this.groupBox_31.Controls.Add((Control) this.checkBox_63);
    this.groupBox_31.Controls.Add((Control) this.checkBox_64);
    this.groupBox_31.ForeColor = Color.Black;
    this.groupBox_31.Location = new Point(174, 166);
    this.groupBox_31.Name = \u003CModule\u003E.smethod_6<string>(2340561865U);
    this.groupBox_31.Size = new Size(327, 100);
    this.groupBox_31.TabIndex = 3;
    this.groupBox_31.TabStop = false;
    this.groupBox_31.Text = \u003CModule\u003E.smethod_8<string>(793371135U);
    this.textBox_15.BackColor = Color.White;
    this.textBox_15.ForeColor = Color.Black;
    this.textBox_15.Location = new Point(221, 70);
    this.textBox_15.Name = \u003CModule\u003E.smethod_9<string>(1184735392U);
    this.textBox_15.Size = new Size(76, 23);
    this.textBox_15.TabIndex = 18;
    this.textBox_15.Text = \u003CModule\u003E.smethod_9<string>(3547909709U);
    this.textBox_15.TextAlign = HorizontalAlignment.Center;
    this.textBox_15.Visible = false;
    this.textBox_15.Enter += new EventHandler(this.textBox_20_Enter);
    this.textBox_15.Leave += new EventHandler(this.textBox_20_Leave);
    this.comboBox_3.BackColor = Color.White;
    this.comboBox_3.ForeColor = Color.Black;
    this.comboBox_3.FormattingEnabled = true;
    this.comboBox_3.Items.AddRange(new object[2]
    {
      (object) \u003CModule\u003E.smethod_8<string>(4261177369U),
      (object) \u003CModule\u003E.smethod_9<string>(1361057144U)
    });
    this.comboBox_3.Location = new Point(121, 70);
    this.comboBox_3.Name = \u003CModule\u003E.smethod_8<string>(1753605743U);
    this.comboBox_3.Size = new Size(86, 23);
    this.comboBox_3.TabIndex = 17;
    this.comboBox_3.Text = \u003CModule\u003E.smethod_7<string>(822132975U);
    this.comboBox_3.Visible = false;
    this.checkBox_45.AutoSize = true;
    this.checkBox_45.Location = new Point(6, 72);
    this.checkBox_45.Name = \u003CModule\u003E.smethod_7<string>(274764877U);
    this.checkBox_45.Size = new Size(104, 19);
    this.checkBox_45.TabIndex = 12;
    this.checkBox_45.Text = \u003CModule\u003E.smethod_5<string>(850887657U);
    this.checkBox_45.UseVisualStyleBackColor = true;
    this.checkBox_45.Visible = false;
    this.checkBox_46.AutoSize = true;
    this.checkBox_46.ForeColor = Color.Black;
    this.checkBox_46.Location = new Point(121, 47);
    this.checkBox_46.Name = \u003CModule\u003E.smethod_5<string>(2057811311U);
    this.checkBox_46.Size = new Size(93, 19);
    this.checkBox_46.TabIndex = 15;
    this.checkBox_46.Text = \u003CModule\u003E.smethod_5<string>(4173157698U);
    this.checkBox_46.UseVisualStyleBackColor = true;
    this.checkBox_46.Visible = false;
    this.checkBox_47.AutoSize = true;
    this.checkBox_47.ForeColor = Color.Black;
    this.checkBox_47.Location = new Point(121, 22);
    this.checkBox_47.Name = \u003CModule\u003E.smethod_9<string>(321972716U);
    this.checkBox_47.Size = new Size(87, 19);
    this.checkBox_47.TabIndex = 4;
    this.checkBox_47.Text = \u003CModule\u003E.smethod_8<string>(1633238887U);
    this.checkBox_47.UseVisualStyleBackColor = true;
    this.checkBox_47.Visible = false;
    this.checkBox_48.AutoSize = true;
    this.checkBox_48.ForeColor = Color.Black;
    this.checkBox_48.Location = new Point(121, 22);
    this.checkBox_48.Name = \u003CModule\u003E.smethod_7<string>(3938386587U);
    this.checkBox_48.Size = new Size(94, 19);
    this.checkBox_48.TabIndex = 12;
    this.checkBox_48.Text = \u003CModule\u003E.smethod_7<string>(2380259781U);
    this.checkBox_48.UseVisualStyleBackColor = true;
    this.checkBox_48.Visible = false;
    this.checkBox_49.AutoSize = true;
    this.checkBox_49.ForeColor = Color.Black;
    this.checkBox_49.Location = new Point(121, 22);
    this.checkBox_49.Name = \u003CModule\u003E.smethod_8<string>(3674074959U);
    this.checkBox_49.Size = new Size(92, 19);
    this.checkBox_49.TabIndex = 13;
    this.checkBox_49.Text = \u003CModule\u003E.smethod_8<string>(1166503333U);
    this.checkBox_49.UseVisualStyleBackColor = true;
    this.checkBox_49.Visible = false;
    this.checkBox_50.AutoSize = true;
    this.checkBox_50.ForeColor = Color.Black;
    this.checkBox_50.Location = new Point(221, 47);
    this.checkBox_50.Name = \u003CModule\u003E.smethod_7<string>(906110463U);
    this.checkBox_50.Size = new Size(103, 19);
    this.checkBox_50.TabIndex = 7;
    this.checkBox_50.Text = \u003CModule\u003E.smethod_8<string>(1593128084U);
    this.checkBox_50.UseVisualStyleBackColor = true;
    this.checkBox_50.Visible = false;
    this.checkBox_51.AutoSize = true;
    this.checkBox_51.ForeColor = Color.Black;
    this.checkBox_51.Location = new Point(121, 47);
    this.checkBox_51.Name = \u003CModule\u003E.smethod_7<string>(358742365U);
    this.checkBox_51.Size = new Size(95, 19);
    this.checkBox_51.TabIndex = 10;
    this.checkBox_51.Text = \u003CModule\u003E.smethod_7<string>(2765913814U);
    this.checkBox_51.UseVisualStyleBackColor = true;
    this.checkBox_51.Visible = false;
    this.checkBox_52.AutoSize = true;
    this.checkBox_52.ForeColor = Color.Black;
    this.checkBox_52.Location = new Point(121, 47);
    this.checkBox_52.Name = \u003CModule\u003E.smethod_5<string>(4282186181U);
    this.checkBox_52.Size = new Size(105, 19);
    this.checkBox_52.TabIndex = 16;
    this.checkBox_52.Text = \u003CModule\u003E.smethod_5<string>(4217911659U);
    this.checkBox_52.UseVisualStyleBackColor = true;
    this.checkBox_52.Visible = false;
    this.textBox_16.BackColor = Color.White;
    this.textBox_16.ForeColor = Color.Black;
    this.textBox_16.Location = new Point(221, 20);
    this.textBox_16.Name = \u003CModule\u003E.smethod_8<string>(4100699710U);
    this.textBox_16.Size = new Size(76, 23);
    this.textBox_16.TabIndex = 8;
    this.textBox_16.Text = \u003CModule\u003E.smethod_5<string>(1247475925U);
    this.textBox_16.TextAlign = HorizontalAlignment.Center;
    this.textBox_16.Visible = false;
    this.textBox_16.Enter += new EventHandler(this.textBox_20_Enter);
    this.textBox_16.Leave += new EventHandler(this.textBox_20_Leave);
    this.checkBox_53.AutoSize = true;
    this.checkBox_53.ForeColor = Color.Black;
    this.checkBox_53.Location = new Point(6, 47);
    this.checkBox_53.Name = \u003CModule\u003E.smethod_9<string>(978467765U);
    this.checkBox_53.Size = new Size(87, 19);
    this.checkBox_53.TabIndex = 7;
    this.checkBox_53.Text = \u003CModule\u003E.smethod_6<string>(1986343043U);
    this.checkBox_53.UseVisualStyleBackColor = true;
    this.checkBox_53.Visible = false;
    this.checkBox_54.AutoSize = true;
    this.checkBox_54.ForeColor = Color.Black;
    this.checkBox_54.Location = new Point(121, 22);
    this.checkBox_54.Name = \u003CModule\u003E.smethod_8<string>(1779694183U);
    this.checkBox_54.Size = new Size(86, 19);
    this.checkBox_54.TabIndex = 5;
    this.checkBox_54.Text = \u003CModule\u003E.smethod_7<string>(3832657514U);
    this.checkBox_54.UseVisualStyleBackColor = true;
    this.checkBox_54.Visible = false;
    this.checkBox_55.AutoSize = true;
    this.checkBox_55.ForeColor = Color.Black;
    this.checkBox_55.Location = new Point(121, 72);
    this.checkBox_55.Name = \u003CModule\u003E.smethod_6<string>(874183790U);
    this.checkBox_55.Size = new Size(51, 19);
    this.checkBox_55.TabIndex = 1;
    this.checkBox_55.Text = \u003CModule\u003E.smethod_9<string>(2339446132U);
    this.checkBox_55.UseVisualStyleBackColor = true;
    this.checkBox_55.Visible = false;
    this.checkBox_56.AutoSize = true;
    this.checkBox_56.ForeColor = Color.Black;
    this.checkBox_56.Location = new Point(6, 72);
    this.checkBox_56.Name = \u003CModule\u003E.smethod_6<string>(1004413811U);
    this.checkBox_56.Size = new Size(96, 19);
    this.checkBox_56.TabIndex = 10;
    this.checkBox_56.Text = \u003CModule\u003E.smethod_9<string>(3900553213U);
    this.checkBox_56.UseVisualStyleBackColor = true;
    this.checkBox_56.Visible = false;
    this.checkBox_57.AutoSize = true;
    this.checkBox_57.ForeColor = Color.Black;
    this.checkBox_57.Location = new Point(6, 47);
    this.checkBox_57.Name = \u003CModule\u003E.smethod_9<string>(303126632U);
    this.checkBox_57.Size = new Size(75, 19);
    this.checkBox_57.TabIndex = 4;
    this.checkBox_57.Text = \u003CModule\u003E.smethod_7<string>(296516462U);
    this.checkBox_57.UseVisualStyleBackColor = true;
    this.checkBox_57.Visible = false;
    this.checkBox_58.AutoSize = true;
    this.checkBox_58.ForeColor = Color.Black;
    this.checkBox_58.Location = new Point(6, 22);
    this.checkBox_58.Name = \u003CModule\u003E.smethod_6<string>(2848450403U);
    this.checkBox_58.Size = new Size(95, 19);
    this.checkBox_58.TabIndex = 4;
    this.checkBox_58.Text = \u003CModule\u003E.smethod_5<string>(3016216302U);
    this.checkBox_58.UseVisualStyleBackColor = true;
    this.checkBox_58.Visible = false;
    this.checkBox_59.AutoSize = true;
    this.checkBox_59.ForeColor = Color.Black;
    this.checkBox_59.Location = new Point(6, 72);
    this.checkBox_59.Name = \u003CModule\u003E.smethod_9<string>(1852330232U);
    this.checkBox_59.Size = new Size(87, 19);
    this.checkBox_59.TabIndex = 5;
    this.checkBox_59.Text = \u003CModule\u003E.smethod_6<string>(2280650929U);
    this.checkBox_59.UseVisualStyleBackColor = true;
    this.checkBox_59.Visible = false;
    this.checkBox_60.AutoSize = true;
    this.checkBox_60.ForeColor = Color.Black;
    this.checkBox_60.Location = new Point(6, 22);
    this.checkBox_60.Name = \u003CModule\u003E.smethod_6<string>(1452391413U);
    this.checkBox_60.Size = new Size(86, 19);
    this.checkBox_60.TabIndex = 2;
    this.checkBox_60.Text = \u003CModule\u003E.smethod_7<string>(1854643268U);
    this.checkBox_60.UseVisualStyleBackColor = true;
    this.checkBox_60.Visible = false;
    this.checkBox_61.AutoSize = true;
    this.checkBox_61.ForeColor = Color.Black;
    this.checkBox_61.Location = new Point(6, 22);
    this.checkBox_61.Name = \u003CModule\u003E.smethod_7<string>(2921386968U);
    this.checkBox_61.Size = new Size(96, 19);
    this.checkBox_61.TabIndex = 8;
    this.checkBox_61.Text = \u003CModule\u003E.smethod_8<string>(1285104476U);
    this.checkBox_61.UseVisualStyleBackColor = true;
    this.checkBox_61.Visible = false;
    this.checkBox_62.AutoSize = true;
    this.checkBox_62.ForeColor = Color.Black;
    this.checkBox_62.Location = new Point(121, 47);
    this.checkBox_62.Name = \u003CModule\u003E.smethod_9<string>(1627216521U);
    this.checkBox_62.Size = new Size(49, 19);
    this.checkBox_62.TabIndex = 3;
    this.checkBox_62.Text = \u003CModule\u003E.smethod_6<string>(2825010708U);
    this.checkBox_62.UseVisualStyleBackColor = true;
    this.checkBox_62.Visible = false;
    this.checkBox_63.AutoSize = true;
    this.checkBox_63.ForeColor = Color.Black;
    this.checkBox_63.Location = new Point(6, 47);
    this.checkBox_63.Name = \u003CModule\u003E.smethod_7<string>(2374018870U);
    this.checkBox_63.Size = new Size(108, 19);
    this.checkBox_63.TabIndex = 9;
    this.checkBox_63.Text = \u003CModule\u003E.smethod_8<string>(1540951204U);
    this.checkBox_63.UseVisualStyleBackColor = true;
    this.checkBox_63.Visible = false;
    this.checkBox_64.AutoSize = true;
    this.checkBox_64.ForeColor = Color.Black;
    this.checkBox_64.Location = new Point(6, 22);
    this.checkBox_64.Name = \u003CModule\u003E.smethod_6<string>(4197630003U);
    this.checkBox_64.Size = new Size(94, 19);
    this.checkBox_64.TabIndex = 6;
    this.checkBox_64.Text = \u003CModule\u003E.smethod_9<string>(3735331252U);
    this.checkBox_64.UseVisualStyleBackColor = true;
    this.checkBox_64.Visible = false;
    this.groupBox_32.Controls.Add((Control) this.checkBox_65);
    this.groupBox_32.Controls.Add((Control) this.checkBox_66);
    this.groupBox_32.Controls.Add((Control) this.checkBox_67);
    this.groupBox_32.Controls.Add((Control) this.label_37);
    this.groupBox_32.Controls.Add((Control) this.label_38);
    this.groupBox_32.Controls.Add((Control) this.label_39);
    this.groupBox_32.Controls.Add((Control) this.trackBar_0);
    this.groupBox_32.Controls.Add((Control) this.button_44);
    this.groupBox_32.Controls.Add((Control) this.button_45);
    this.groupBox_32.Controls.Add((Control) this.comboBox_4);
    this.groupBox_32.Controls.Add((Control) this.label_40);
    this.groupBox_32.Controls.Add((Control) this.numericUpDown_20);
    this.groupBox_32.Controls.Add((Control) this.label_41);
    this.groupBox_32.Controls.Add((Control) this.textBox_17);
    this.groupBox_32.Controls.Add((Control) this.checkBox_68);
    this.groupBox_32.ForeColor = Color.Black;
    this.groupBox_32.Location = new Point(6, 323);
    this.groupBox_32.Name = \u003CModule\u003E.smethod_7<string>(3636710042U);
    this.groupBox_32.Size = new Size(376, 160);
    this.groupBox_32.TabIndex = 6;
    this.groupBox_32.TabStop = false;
    this.groupBox_32.Text = \u003CModule\u003E.smethod_6<string>(3085470750U);
    this.checkBox_65.AutoSize = true;
    this.checkBox_65.ForeColor = Color.Black;
    this.checkBox_65.Location = new Point(143, 52);
    this.checkBox_65.Name = \u003CModule\u003E.smethod_6<string>(1689411760U);
    this.checkBox_65.Size = new Size(88, 19);
    this.checkBox_65.TabIndex = 22;
    this.checkBox_65.Text = \u003CModule\u003E.smethod_5<string>(1543615135U);
    this.checkBox_65.UseVisualStyleBackColor = true;
    this.checkBox_66.AutoSize = true;
    this.checkBox_66.ForeColor = Color.Black;
    this.checkBox_66.Location = new Point(32, 52);
    this.checkBox_66.Name = \u003CModule\u003E.smethod_7<string>(2324274789U);
    this.checkBox_66.Size = new Size(95, 19);
    this.checkBox_66.TabIndex = 21;
    this.checkBox_66.Text = \u003CModule\u003E.smethod_5<string>(752800310U);
    this.checkBox_66.UseVisualStyleBackColor = true;
    this.checkBox_67.AutoSize = true;
    this.checkBox_67.Checked = true;
    this.checkBox_67.CheckState = CheckState.Checked;
    this.checkBox_67.FlatStyle = FlatStyle.Flat;
    this.checkBox_67.Font = new Font(\u003CModule\u003E.smethod_9<string>(868744759U), 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.checkBox_67.ForeColor = Color.Red;
    this.checkBox_67.Location = new Point(234, 128);
    this.checkBox_67.Name = \u003CModule\u003E.smethod_8<string>(953848794U);
    this.checkBox_67.Size = new Size(109, 21);
    this.checkBox_67.TabIndex = 20;
    this.checkBox_67.Text = \u003CModule\u003E.smethod_9<string>(3960444963U);
    this.checkBox_67.UseVisualStyleBackColor = true;
    this.label_37.AutoSize = true;
    this.label_37.ForeColor = Color.Black;
    this.label_37.Location = new Point(281, 114);
    this.label_37.Name = \u003CModule\u003E.smethod_8<string>(126687732U);
    this.label_37.Size = new Size(25, 15);
    this.label_37.TabIndex = 19;
    this.label_37.Text = \u003CModule\u003E.smethod_8<string>(4181596376U);
    this.label_38.AutoSize = true;
    this.label_38.ForeColor = Color.Black;
    this.label_38.Location = new Point(336, 114);
    this.label_38.Name = \u003CModule\u003E.smethod_5<string>(3401863434U);
    this.label_38.Size = new Size(28, 15);
    this.label_38.TabIndex = 18;
    this.label_38.Text = \u003CModule\u003E.smethod_6<string>(4116731891U);
    this.label_39.AutoSize = true;
    this.label_39.ForeColor = Color.Black;
    this.label_39.Location = new Point(217, 114);
    this.label_39.Name = \u003CModule\u003E.smethod_8<string>(1674024750U);
    this.label_39.Size = new Size(32, 15);
    this.label_39.TabIndex = 17;
    this.label_39.Text = \u003CModule\u003E.smethod_9<string>(655770136U);
    this.trackBar_0.AutoSize = false;
    this.trackBar_0.LargeChange = 25;
    this.trackBar_0.Location = new Point(212, 68);
    this.trackBar_0.Maximum = 1500;
    this.trackBar_0.Minimum = 150;
    this.trackBar_0.Name = \u003CModule\u003E.smethod_9<string>(1773592398U);
    this.trackBar_0.RightToLeft = RightToLeft.Yes;
    this.trackBar_0.RightToLeftLayout = true;
    this.trackBar_0.Size = new Size(156, 41);
    this.trackBar_0.TabIndex = 16;
    this.trackBar_0.TickFrequency = 200;
    this.trackBar_0.TickStyle = TickStyle.Both;
    this.trackBar_0.Value = 420;
    this.trackBar_0.Scroll += new EventHandler(this.trackBar_0_Scroll);
    this.button_44.FlatStyle = FlatStyle.Flat;
    this.button_44.ForeColor = Color.Black;
    this.button_44.Location = new Point(6, 115);
    this.button_44.Name = \u003CModule\u003E.smethod_8<string>(3888045171U);
    this.button_44.Size = new Size(202, 30);
    this.button_44.TabIndex = 15;
    this.button_44.Text = \u003CModule\u003E.smethod_8<string>(1484827305U);
    this.button_44.UseVisualStyleBackColor = true;
    this.button_44.Click += new EventHandler(this.button_44_Click);
    this.button_45.BackColor = Color.White;
    this.button_45.FlatStyle = FlatStyle.Flat;
    this.button_45.ForeColor = Color.Black;
    this.button_45.Location = new Point(133, 77);
    this.button_45.Name = \u003CModule\u003E.smethod_8<string>(3272222975U);
    this.button_45.Size = new Size(75, 33);
    this.button_45.TabIndex = 14;
    this.button_45.Text = \u003CModule\u003E.smethod_5<string>(3787510566U);
    this.button_45.UseVisualStyleBackColor = false;
    this.button_45.Click += new EventHandler(this.button_45_Click);
    this.comboBox_4.ForeColor = Color.Black;
    this.comboBox_4.FormattingEnabled = true;
    this.comboBox_4.Items.AddRange(new object[35]
    {
      (object) \u003CModule\u003E.smethod_7<string>(3820175692U),
      (object) \u003CModule\u003E.smethod_5<string>(4287899020U),
      (object) \u003CModule\u003E.smethod_9<string>(2343603320U),
      (object) \u003CModule\u003E.smethod_6<string>(3939793358U),
      (object) \u003CModule\u003E.smethod_7<string>(4121852237U),
      (object) \u003CModule\u003E.smethod_9<string>(1784692189U),
      (object) \u003CModule\u003E.smethod_5<string>(462373939U),
      (object) \u003CModule\u003E.smethod_7<string>(16591502U),
      (object) \u003CModule\u003E.smethod_9<string>(2118489609U),
      (object) \u003CModule\u003E.smethod_6<string>(733545620U),
      (object) \u003CModule\u003E.smethod_8<string>(2098018155U),
      (object) \u003CModule\u003E.smethod_9<string>(1608370437U),
      (object) \u003CModule\u003E.smethod_5<string>(2384896760U),
      (object) \u003CModule\u003E.smethod_7<string>(3518499147U),
      (object) \u003CModule\u003E.smethod_5<string>(2320622238U),
      (object) \u003CModule\u003E.smethod_7<string>(2072342325U),
      (object) \u003CModule\u003E.smethod_9<string>(3814069086U),
      (object) \u003CModule\u003E.smethod_8<string>(1804466950U),
      (object) \u003CModule\u003E.smethod_5<string>(699951466U),
      (object) \u003CModule\u003E.smethod_5<string>(2088757550U),
      (object) \u003CModule\u003E.smethod_5<string>(3477563634U),
      (object) \u003CModule\u003E.smethod_5<string>(571402422U),
      (object) \u003CModule\u003E.smethod_5<string>(1960208506U),
      (object) \u003CModule\u003E.smethod_8<string>(2284584254U),
      (object) \u003CModule\u003E.smethod_8<string>(3964994818U),
      (object) \u003CModule\u003E.smethod_5<string>(1831659462U),
      (object) \u003CModule\u003E.smethod_5<string>(3220465546U),
      (object) \u003CModule\u003E.smethod_7<string>(2262048886U),
      (object) \u003CModule\u003E.smethod_7<string>(3384777578U),
      (object) \u003CModule\u003E.smethod_8<string>(1403930639U),
      (object) \u003CModule\u003E.smethod_5<string>(185755290U),
      (object) \u003CModule\u003E.smethod_7<string>(122320575U),
      (object) \u003CModule\u003E.smethod_9<string>(1285672808U),
      (object) \u003CModule\u003E.smethod_8<string>(1912767729U),
      (object) \u003CModule\u003E.smethod_9<string>(2658554656U)
    });
    this.comboBox_4.Location = new Point(6, 77);
    this.comboBox_4.Name = \u003CModule\u003E.smethod_5<string>(31972846U);
    this.comboBox_4.Size = new Size(121, 23);
    this.comboBox_4.TabIndex = 13;
    this.comboBox_4.Text = \u003CModule\u003E.smethod_7<string>(1217056771U);
    this.comboBox_4.SelectedIndexChanged += new EventHandler(this.comboBox_4_SelectedIndexChanged);
    this.label_40.AutoSize = true;
    this.label_40.ForeColor = Color.Black;
    this.label_40.Location = new Point(312, 23);
    this.label_40.Name = \u003CModule\u003E.smethod_5<string>(1356504408U);
    this.label_40.Size = new Size(28, 15);
    this.label_40.TabIndex = 12;
    this.label_40.Text = \u003CModule\u003E.smethod_6<string>(2921392885U);
    this.numericUpDown_20.ForeColor = Color.Black;
    this.numericUpDown_20.Location = new Point(272, 20);
    this.numericUpDown_20.Name = \u003CModule\u003E.smethod_7<string>(2010116422U);
    this.numericUpDown_20.Size = new Size(34, 23);
    this.numericUpDown_20.TabIndex = 11;
    this.numericUpDown_20.TextAlign = HorizontalAlignment.Center;
    this.numericUpDown_20.Value = new Decimal(new int[4]
    {
      1,
      0,
      0,
      0
    });
    this.label_41.AutoSize = true;
    this.label_41.ForeColor = Color.Black;
    this.label_41.Location = new Point(191, 23);
    this.label_41.Name = \u003CModule\u003E.smethod_8<string>(3059568436U);
    this.label_41.Size = new Size(78, 15);
    this.label_41.TabIndex = 5;
    this.label_41.Text = \u003CModule\u003E.smethod_6<string>(827304400U);
    this.textBox_17.ForeColor = Color.Black;
    this.textBox_17.Location = new Point(107, 20);
    this.textBox_17.Name = \u003CModule\u003E.smethod_7<string>(585711185U);
    this.textBox_17.Size = new Size(78, 23);
    this.textBox_17.TabIndex = 4;
    this.textBox_17.Enter += new EventHandler(this.textBox_20_Enter);
    this.textBox_17.Leave += new EventHandler(this.textBox_20_Leave);
    this.checkBox_68.AutoSize = true;
    this.checkBox_68.ForeColor = Color.Black;
    this.checkBox_68.Location = new Point(6, 22);
    this.checkBox_68.Name = \u003CModule\u003E.smethod_9<string>(2786084449U);
    this.checkBox_68.Size = new Size(95, 19);
    this.checkBox_68.TabIndex = 3;
    this.checkBox_68.Text = \u003CModule\u003E.smethod_5<string>(308591495U);
    this.checkBox_68.UseVisualStyleBackColor = true;
    this.groupBox_33.Controls.Add((Control) this.checkBox_69);
    this.groupBox_33.Controls.Add((Control) this.checkBox_70);
    this.groupBox_33.Controls.Add((Control) this.checkBox_71);
    this.groupBox_33.Controls.Add((Control) this.checkBox_72);
    this.groupBox_33.Controls.Add((Control) this.checkBox_73);
    this.groupBox_33.ForeColor = Color.Black;
    this.groupBox_33.Location = new Point(6, 6);
    this.groupBox_33.Name = \u003CModule\u003E.smethod_9<string>(1109351056U);
    this.groupBox_33.Size = new Size(601, 48);
    this.groupBox_33.TabIndex = 5;
    this.groupBox_33.TabStop = false;
    this.groupBox_33.Text = \u003CModule\u003E.smethod_8<string>(1938856169U);
    this.checkBox_69.AutoSize = true;
    this.checkBox_69.ForeColor = Color.Black;
    this.checkBox_69.Location = new Point(393, 20);
    this.checkBox_69.Name = \u003CModule\u003E.smethod_9<string>(3187519912U);
    this.checkBox_69.Size = new Size(98, 19);
    this.checkBox_69.TabIndex = 21;
    this.checkBox_69.Text = \u003CModule\u003E.smethod_7<string>(2367777959U);
    this.checkBox_69.TextAlign = ContentAlignment.MiddleCenter;
    this.checkBox_69.UseVisualStyleBackColor = true;
    this.checkBox_70.AutoSize = true;
    this.checkBox_70.ForeColor = Color.Black;
    this.checkBox_70.Location = new Point(262, 20);
    this.checkBox_70.Name = \u003CModule\u003E.smethod_5<string>(738992588U);
    this.checkBox_70.Size = new Size(97, 19);
    this.checkBox_70.TabIndex = 20;
    this.checkBox_70.Text = \u003CModule\u003E.smethod_8<string>(631577803U);
    this.checkBox_70.UseVisualStyleBackColor = true;
    this.checkBox_71.AutoSize = true;
    this.checkBox_71.ForeColor = Color.Black;
    this.checkBox_71.Location = new Point(498, 12);
    this.checkBox_71.Name = \u003CModule\u003E.smethod_8<string>(3672759286U);
    this.checkBox_71.Size = new Size(96, 34);
    this.checkBox_71.TabIndex = 19;
    this.checkBox_71.Text = \u003CModule\u003E.smethod_6<string>(3288643253U);
    this.checkBox_71.TextAlign = ContentAlignment.MiddleCenter;
    this.checkBox_71.UseVisualStyleBackColor = true;
    this.checkBox_72.AutoSize = true;
    this.checkBox_72.ForeColor = Color.Black;
    this.checkBox_72.Location = new Point(133, 20);
    this.checkBox_72.Name = \u003CModule\u003E.smethod_7<string>(1245049267U);
    this.checkBox_72.Size = new Size(105, 19);
    this.checkBox_72.TabIndex = 1;
    this.checkBox_72.Text = \u003CModule\u003E.smethod_6<string>(1194554768U);
    this.checkBox_72.UseVisualStyleBackColor = true;
    this.checkBox_73.AutoSize = true;
    this.checkBox_73.Checked = true;
    this.checkBox_73.CheckState = CheckState.Checked;
    this.checkBox_73.ForeColor = Color.Black;
    this.checkBox_73.Location = new Point(7, 20);
    this.checkBox_73.Name = \u003CModule\u003E.smethod_9<string>(3825168877U);
    this.checkBox_73.Size = new Size(115, 19);
    this.checkBox_73.TabIndex = 0;
    this.checkBox_73.Text = \u003CModule\u003E.smethod_5<string>(3195232146U);
    this.checkBox_73.UseVisualStyleBackColor = true;
    this.groupBox_34.Controls.Add((Control) this.checkBox_74);
    this.groupBox_34.Controls.Add((Control) this.checkBox_75);
    this.groupBox_34.Controls.Add((Control) this.checkBox_76);
    this.groupBox_34.ForeColor = Color.Black;
    this.groupBox_34.Location = new Point(6, 272);
    this.groupBox_34.Name = \u003CModule\u003E.smethod_6<string>(212625536U);
    this.groupBox_34.Size = new Size(376, 45);
    this.groupBox_34.TabIndex = 0;
    this.groupBox_34.TabStop = false;
    this.groupBox_34.Text = \u003CModule\u003E.smethod_6<string>(3679333316U);
    this.checkBox_74.AutoSize = true;
    this.checkBox_74.ForeColor = Color.Black;
    this.checkBox_74.Location = new Point(262, 22);
    this.checkBox_74.Name = \u003CModule\u003E.smethod_7<string>(3481420095U);
    this.checkBox_74.Size = new Size(89, 19);
    this.checkBox_74.TabIndex = 10;
    this.checkBox_74.Text = \u003CModule\u003E.smethod_7<string>(253196499U);
    this.checkBox_74.TextAlign = ContentAlignment.MiddleCenter;
    this.checkBox_74.UseVisualStyleBackColor = true;
    this.checkBox_75.AutoSize = true;
    this.checkBox_75.ForeColor = Color.Black;
    this.checkBox_75.Location = new Point(133, 22);
    this.checkBox_75.Name = \u003CModule\u003E.smethod_5<string>(2535348409U);
    this.checkBox_75.Size = new Size(74, 19);
    this.checkBox_75.TabIndex = 9;
    this.checkBox_75.Text = \u003CModule\u003E.smethod_5<string>(3924154493U);
    this.checkBox_75.UseVisualStyleBackColor = true;
    this.checkBox_76.AutoSize = true;
    this.checkBox_76.ForeColor = Color.Black;
    this.checkBox_76.Location = new Point(6, 22);
    this.checkBox_76.Name = \u003CModule\u003E.smethod_7<string>(1046256150U);
    this.checkBox_76.Size = new Size(73, 19);
    this.checkBox_76.TabIndex = 8;
    this.checkBox_76.Text = \u003CModule\u003E.smethod_5<string>(291452978U);
    this.checkBox_76.UseVisualStyleBackColor = true;
    this.groupBox_35.Controls.Add((Control) this.checkBox_77);
    this.groupBox_35.Controls.Add((Control) this.button_46);
    this.groupBox_35.Controls.Add((Control) this.button_47);
    this.groupBox_35.Controls.Add((Control) this.checkBox_78);
    this.groupBox_35.Controls.Add((Control) this.checkBox_79);
    this.groupBox_35.Controls.Add((Control) this.label_42);
    this.groupBox_35.Controls.Add((Control) this.label_43);
    this.groupBox_35.Controls.Add((Control) this.textBox_18);
    this.groupBox_35.Controls.Add((Control) this.listBox_5);
    this.groupBox_35.ForeColor = Color.Black;
    this.groupBox_35.Location = new Point(613, 6);
    this.groupBox_35.Name = \u003CModule\u003E.smethod_5<string>(953718759U);
    this.groupBox_35.Size = new Size(219, 260);
    this.groupBox_35.TabIndex = 2;
    this.groupBox_35.TabStop = false;
    this.groupBox_35.Text = \u003CModule\u003E.smethod_7<string>(2962044493U);
    this.checkBox_77.AutoSize = true;
    this.checkBox_77.ForeColor = Color.Black;
    this.checkBox_77.Location = new Point(146, 111);
    this.checkBox_77.Name = \u003CModule\u003E.smethod_5<string>(162903934U);
    this.checkBox_77.Size = new Size(53, 34);
    this.checkBox_77.TabIndex = 17;
    this.checkBox_77.Text = \u003CModule\u003E.smethod_5<string>(3667056405U);
    this.checkBox_77.UseVisualStyleBackColor = true;
    this.button_46.FlatStyle = FlatStyle.Flat;
    this.button_46.ForeColor = Color.Black;
    this.button_46.Location = new Point(132, 180);
    this.button_46.Name = \u003CModule\u003E.smethod_8<string>(4078558289U);
    this.button_46.Size = new Size(81, 44);
    this.button_46.TabIndex = 16;
    this.button_46.Text = \u003CModule\u003E.smethod_5<string>(538074139U);
    this.button_46.UseVisualStyleBackColor = true;
    this.button_46.Click += new EventHandler(this.button_46_Click);
    this.button_47.FlatStyle = FlatStyle.Flat;
    this.button_47.ForeColor = Color.Black;
    this.button_47.Location = new Point(132, 230);
    this.button_47.Name = \u003CModule\u003E.smethod_7<string>(3671126656U);
    this.button_47.Size = new Size(81, 23);
    this.button_47.TabIndex = 15;
    this.button_47.Text = \u003CModule\u003E.smethod_9<string>(2396788074U);
    this.button_47.UseVisualStyleBackColor = true;
    this.button_47.Click += new EventHandler(this.button_47_Click);
    this.checkBox_78.AutoSize = true;
    this.checkBox_78.ForeColor = Color.Black;
    this.checkBox_78.Location = new Point(146, 69);
    this.checkBox_78.Name = \u003CModule\u003E.smethod_6<string>(696988940U);
    this.checkBox_78.Size = new Size(55, 19);
    this.checkBox_78.TabIndex = 13;
    this.checkBox_78.Text = \u003CModule\u003E.smethod_5<string>(261455490U);
    this.checkBox_78.UseVisualStyleBackColor = true;
    this.checkBox_79.AutoSize = true;
    this.checkBox_79.ForeColor = Color.Black;
    this.checkBox_79.Location = new Point(146, 44);
    this.checkBox_79.Name = \u003CModule\u003E.smethod_9<string>(720054681U);
    this.checkBox_79.Size = new Size(51, 19);
    this.checkBox_79.TabIndex = 12;
    this.checkBox_79.Text = \u003CModule\u003E.smethod_7<string>(1018263654U);
    this.checkBox_79.UseVisualStyleBackColor = true;
    this.label_42.AutoSize = true;
    this.label_42.ForeColor = Color.Black;
    this.label_42.Location = new Point(149, 22);
    this.label_42.Name = \u003CModule\u003E.smethod_9<string>(1552871482U);
    this.label_42.Size = new Size(46, 15);
    this.label_42.TabIndex = 11;
    this.label_42.Text = \u003CModule\u003E.smethod_9<string>(2111782613U);
    this.label_43.AutoSize = true;
    this.label_43.ForeColor = Color.Black;
    this.label_43.Location = new Point(50, 22);
    this.label_43.Name = \u003CModule\u003E.smethod_5<string>(2515827848U);
    this.label_43.Size = new Size(36, 15);
    this.label_43.TabIndex = 10;
    this.label_43.Text = \u003CModule\u003E.smethod_5<string>(3904633932U);
    this.textBox_18.AcceptsReturn = true;
    this.textBox_18.ForeColor = Color.Black;
    this.textBox_18.Location = new Point(6, 230);
    this.textBox_18.MaxLength = 25;
    this.textBox_18.Name = \u003CModule\u003E.smethod_7<string>(3621382575U);
    this.textBox_18.Size = new Size(120, 23);
    this.textBox_18.TabIndex = 9;
    this.textBox_18.TextAlign = HorizontalAlignment.Center;
    this.textBox_18.Enter += new EventHandler(this.textBox_20_Enter);
    this.textBox_18.KeyPress += new KeyPressEventHandler(this.textBox_18_KeyPress);
    this.textBox_18.Leave += new EventHandler(this.textBox_20_Leave);
    this.listBox_5.BackColor = Color.White;
    this.listBox_5.ForeColor = Color.Black;
    this.listBox_5.FormattingEnabled = true;
    this.listBox_5.ItemHeight = 15;
    this.listBox_5.Items.AddRange(new object[27]
    {
      (object) \u003CModule\u003E.smethod_7<string>(3708022501U),
      (object) \u003CModule\u003E.smethod_6<string>(301052083U),
      (object) \u003CModule\u003E.smethod_7<string>(2311609760U),
      (object) \u003CModule\u003E.smethod_6<string>(1934131420U),
      (object) \u003CModule\u003E.smethod_7<string>(3266383476U),
      (object) \u003CModule\u003E.smethod_7<string>(1076911084U),
      (object) \u003CModule\u003E.smethod_7<string>(283851433U),
      (object) \u003CModule\u003E.smethod_9<string>(2881354166U),
      (object) \u003CModule\u003E.smethod_7<string>(2009933215U),
      (object) \u003CModule\u003E.smethod_5<string>(3828449190U),
      (object) \u003CModule\u003E.smethod_8<string>(1783416182U),
      (object) \u003CModule\u003E.smethod_8<string>(2185268166U),
      (object) \u003CModule\u003E.smethod_5<string>(1160834589U),
      (object) \u003CModule\u003E.smethod_6<string>(4038628054U),
      (object) \u003CModule\u003E.smethod_7<string>(2557301313U),
      (object) \u003CModule\u003E.smethod_5<string>(1925446930U),
      (object) \u003CModule\u003E.smethod_7<string>(4171413111U),
      (object) \u003CModule\u003E.smethod_6<string>(2218031157U),
      (object) \u003CModule\u003E.smethod_7<string>(2445331329U),
      (object) \u003CModule\u003E.smethod_9<string>(2978938084U),
      (object) \u003CModule\u003E.smethod_7<string>(389580506U),
      (object) \u003CModule\u003E.smethod_5<string>(4072708640U),
      (object) \u003CModule\u003E.smethod_9<string>(1058244896U),
      (object) \u003CModule\u003E.smethod_7<string>(3680030005U),
      (object) \u003CModule\u003E.smethod_7<string>(38159880U),
      (object) \u003CModule\u003E.smethod_8<string>(3517319299U),
      (object) \u003CModule\u003E.smethod_8<string>(2904353469U)
    });
    this.listBox_5.Location = new Point(6, 40);
    this.listBox_5.Name = \u003CModule\u003E.smethod_5<string>(3049544585U);
    this.listBox_5.SelectionMode = SelectionMode.MultiExtended;
    this.listBox_5.Size = new Size(120, 184);
    this.listBox_5.Sorted = true;
    this.listBox_5.TabIndex = 0;
    this.groupBox_36.Controls.Add((Control) this.checkBox_80);
    this.groupBox_36.Controls.Add((Control) this.checkBox_81);
    this.groupBox_36.Controls.Add((Control) this.checkBox_82);
    this.groupBox_36.Controls.Add((Control) this.checkBox_83);
    this.groupBox_36.Controls.Add((Control) this.numericUpDown_21);
    this.groupBox_36.Controls.Add((Control) this.comboBox_5);
    this.groupBox_36.Controls.Add((Control) this.numericUpDown_22);
    this.groupBox_36.Controls.Add((Control) this.comboBox_6);
    this.groupBox_36.Controls.Add((Control) this.label_44);
    this.groupBox_36.Controls.Add((Control) this.comboBox_7);
    this.groupBox_36.ForeColor = Color.Black;
    this.groupBox_36.Location = new Point(6, 60);
    this.groupBox_36.Name = \u003CModule\u003E.smethod_7<string>(2526646379U);
    this.groupBox_36.Size = new Size(376, 100);
    this.groupBox_36.TabIndex = 1;
    this.groupBox_36.TabStop = false;
    this.groupBox_36.Text = \u003CModule\u003E.smethod_5<string>(2258729760U);
    this.checkBox_80.AutoSize = true;
    this.checkBox_80.ForeColor = Color.Black;
    this.checkBox_80.Location = new Point(262, 76);
    this.checkBox_80.Name = \u003CModule\u003E.smethod_5<string>(1467914935U);
    this.checkBox_80.Size = new Size(77, 19);
    this.checkBox_80.TabIndex = 13;
    this.checkBox_80.Text = \u003CModule\u003E.smethod_9<string>(1072698185U);
    this.checkBox_80.UseVisualStyleBackColor = true;
    this.checkBox_81.AutoSize = true;
    this.checkBox_81.Location = new Point(262, 51);
    this.checkBox_81.Name = \u003CModule\u003E.smethod_5<string>(4245527103U);
    this.checkBox_81.Size = new Size(102, 19);
    this.checkBox_81.TabIndex = 12;
    this.checkBox_81.Text = \u003CModule\u003E.smethod_6<string>(3004658077U);
    this.checkBox_81.UseVisualStyleBackColor = true;
    this.checkBox_82.AutoSize = true;
    this.checkBox_82.Location = new Point(6, 67);
    this.checkBox_82.Name = \u003CModule\u003E.smethod_5<string>(2001631672U);
    this.checkBox_82.Size = new Size(15, 14);
    this.checkBox_82.TabIndex = 12;
    this.checkBox_82.UseVisualStyleBackColor = true;
    this.checkBox_83.AutoSize = true;
    this.checkBox_83.Location = new Point(6, 26);
    this.checkBox_83.Name = \u003CModule\u003E.smethod_7<string>(2470661387U);
    this.checkBox_83.Size = new Size(15, 14);
    this.checkBox_83.TabIndex = 11;
    this.checkBox_83.UseVisualStyleBackColor = true;
    this.numericUpDown_21.ForeColor = Color.Black;
    this.numericUpDown_21.Location = new Point(154, 63);
    this.numericUpDown_21.Name = \u003CModule\u003E.smethod_7<string>(1130233638U);
    this.numericUpDown_21.Size = new Size(43, 23);
    this.numericUpDown_21.TabIndex = 10;
    this.numericUpDown_21.TextAlign = HorizontalAlignment.Center;
    this.numericUpDown_21.Value = new Decimal(new int[4]
    {
      80,
      0,
      0,
      0
    });
    this.comboBox_5.ForeColor = Color.Black;
    this.comboBox_5.FormattingEnabled = true;
    this.comboBox_5.Items.AddRange(new object[7]
    {
      (object) \u003CModule\u003E.smethod_7<string>(638300911U),
      (object) \u003CModule\u003E.smethod_9<string>(1113979458U),
      (object) \u003CModule\u003E.smethod_9<string>(3683421402U),
      (object) \u003CModule\u003E.smethod_8<string>(790514769U),
      (object) \u003CModule\u003E.smethod_7<string>(6955325U),
      (object) \u003CModule\u003E.smethod_9<string>(74895030U),
      (object) \u003CModule\u003E.smethod_6<string>(3791028680U)
    });
    this.comboBox_5.Location = new Point(27, 63);
    this.comboBox_5.Name = \u003CModule\u003E.smethod_6<string>(3322405658U);
    this.comboBox_5.Size = new Size(121, 23);
    this.comboBox_5.TabIndex = 6;
    this.comboBox_5.Text = \u003CModule\u003E.smethod_6<string>(3400338617U);
    this.numericUpDown_22.ForeColor = Color.Black;
    this.numericUpDown_22.Location = new Point(321, 22);
    this.numericUpDown_22.Name = \u003CModule\u003E.smethod_6<string>(2494146142U);
    this.numericUpDown_22.Size = new Size(43, 23);
    this.numericUpDown_22.TabIndex = 5;
    this.numericUpDown_22.TextAlign = HorizontalAlignment.Center;
    this.numericUpDown_22.Value = new Decimal(new int[4]
    {
      80,
      0,
      0,
      0
    });
    this.comboBox_6.ForeColor = Color.Black;
    this.comboBox_6.FormattingEnabled = true;
    this.comboBox_6.Items.AddRange(new object[5]
    {
      (object) \u003CModule\u003E.smethod_7<string>(4050539778U),
      (object) \u003CModule\u003E.smethod_9<string>(2074090445U),
      (object) \u003CModule\u003E.smethod_6<string>(4280895195U),
      (object) \u003CModule\u003E.smethod_7<string>(3011788574U),
      (object) \u003CModule\u003E.smethod_7<string>(4078532274U)
    });
    this.comboBox_6.Location = new Point(194, 22);
    this.comboBox_6.Name = \u003CModule\u003E.smethod_5<string>(3770372049U);
    this.comboBox_6.Size = new Size(121, 23);
    this.comboBox_6.TabIndex = 4;
    this.comboBox_6.Text = \u003CModule\u003E.smethod_6<string>(683957394U);
    this.comboBox_6.SelectedIndexChanged += new EventHandler(this.comboBox_6_SelectedIndexChanged);
    this.label_44.AutoSize = true;
    this.label_44.ForeColor = Color.Black;
    this.label_44.Location = new Point(154, 25);
    this.label_44.Name = \u003CModule\u003E.smethod_6<string>(944417436U);
    this.label_44.Size = new Size(39, 15);
    this.label_44.TabIndex = 3;
    this.label_44.Text = \u003CModule\u003E.smethod_9<string>(2711739410U);
    this.comboBox_7.ForeColor = Color.Black;
    this.comboBox_7.FormattingEnabled = true;
    this.comboBox_7.Items.AddRange(new object[7]
    {
      (object) \u003CModule\u003E.smethod_9<string>(3644689937U),
      (object) \u003CModule\u003E.smethod_5<string>(2089242092U),
      (object) \u003CModule\u003E.smethod_8<string>(2007686758U),
      (object) \u003CModule\u003E.smethod_9<string>(779946431U),
      (object) \u003CModule\u003E.smethod_5<string>(3606597220U),
      (object) \u003CModule\u003E.smethod_6<string>(1350591564U),
      (object) \u003CModule\u003E.smethod_6<string>(2731166489U)
    });
    this.comboBox_7.Location = new Point(27, 22);
    this.comboBox_7.Name = \u003CModule\u003E.smethod_6<string>(4257455500U);
    this.comboBox_7.Size = new Size(121, 23);
    this.comboBox_7.TabIndex = 1;
    this.comboBox_7.Text = \u003CModule\u003E.smethod_7<string>(4112032853U);
    this.groupBox_37.Controls.Add((Control) this.checkBox_84);
    this.groupBox_37.Controls.Add((Control) this.checkBox_85);
    this.groupBox_37.Controls.Add((Control) this.comboBox_8);
    this.groupBox_37.Controls.Add((Control) this.comboBox_9);
    this.groupBox_37.ForeColor = Color.Black;
    this.groupBox_37.Location = new Point(6, 166);
    this.groupBox_37.Name = \u003CModule\u003E.smethod_8<string>(638156168U);
    this.groupBox_37.Size = new Size(162, 100);
    this.groupBox_37.TabIndex = 0;
    this.groupBox_37.TabStop = false;
    this.groupBox_37.Text = \u003CModule\u003E.smethod_6<string>(1619007236U);
    this.checkBox_84.AutoSize = true;
    this.checkBox_84.Location = new Point(6, 65);
    this.checkBox_84.Name = \u003CModule\u003E.smethod_5<string>(1230337408U);
    this.checkBox_84.Size = new Size(15, 14);
    this.checkBox_84.TabIndex = 3;
    this.checkBox_84.UseVisualStyleBackColor = true;
    this.checkBox_85.AutoSize = true;
    this.checkBox_85.Location = new Point(6, 26);
    this.checkBox_85.Name = \u003CModule\u003E.smethod_7<string>(141226515U);
    this.checkBox_85.Size = new Size(15, 14);
    this.checkBox_85.TabIndex = 2;
    this.checkBox_85.UseVisualStyleBackColor = true;
    this.comboBox_8.ForeColor = Color.Black;
    this.comboBox_8.FormattingEnabled = true;
    this.comboBox_8.Items.AddRange(new object[4]
    {
      (object) \u003CModule\u003E.smethod_5<string>(3799420786U),
      (object) \u003CModule\u003E.smethod_5<string>(1684074399U),
      (object) \u003CModule\u003E.smethod_7<string>(2006537949U),
      (object) \u003CModule\u003E.smethod_9<string>(516336862U)
    });
    this.comboBox_8.Location = new Point(27, 61);
    this.comboBox_8.Name = \u003CModule\u003E.smethod_8<string>(3865903750U);
    this.comboBox_8.Size = new Size(121, 23);
    this.comboBox_8.TabIndex = 1;
    this.comboBox_8.Text = \u003CModule\u003E.smethod_9<string>(947718200U);
    this.comboBox_9.ForeColor = Color.Black;
    this.comboBox_9.FormattingEnabled = true;
    this.comboBox_9.Items.AddRange(new object[4]
    {
      (object) \u003CModule\u003E.smethod_5<string>(3265704049U),
      (object) \u003CModule\u003E.smethod_6<string>(3053989986U),
      (object) \u003CModule\u003E.smethod_8<string>(3421950230U),
      (object) \u003CModule\u003E.smethod_9<string>(3292046433U)
    });
    this.comboBox_9.Location = new Point(27, 22);
    this.comboBox_9.Name = \u003CModule\u003E.smethod_7<string>(4162509762U);
    this.comboBox_9.Size = new Size(121, 23);
    this.comboBox_9.TabIndex = 0;
    this.comboBox_9.Text = \u003CModule\u003E.smethod_6<string>(2770090249U);
    this.tabPage_11.Controls.Add((Control) this.tableLayoutPanel_1);
    this.tabPage_11.Location = new Point(4, 22);
    this.tabPage_11.Name = \u003CModule\u003E.smethod_6<string>(222948246U);
    this.tabPage_11.Size = new Size(838, 494);
    this.tabPage_11.TabIndex = 100;
    this.tabPage_11.Text = \u003CModule\u003E.smethod_6<string>(564220961U);
    this.tabPage_11.UseVisualStyleBackColor = true;
    this.tableLayoutPanel_1.ColumnCount = 6;
    this.tableLayoutPanel_1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.66667f));
    this.tableLayoutPanel_1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.66667f));
    this.tableLayoutPanel_1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.66667f));
    this.tableLayoutPanel_1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.66667f));
    this.tableLayoutPanel_1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.66667f));
    this.tableLayoutPanel_1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.66667f));
    this.tableLayoutPanel_1.Location = new Point(0, 0);
    this.tableLayoutPanel_1.Margin = new Padding(0);
    this.tableLayoutPanel_1.Name = \u003CModule\u003E.smethod_5<string>(3152860229U);
    this.tableLayoutPanel_1.RowCount = 3;
    this.tableLayoutPanel_1.RowStyles.Add(new RowStyle(SizeType.Percent, 33.33333f));
    this.tableLayoutPanel_1.RowStyles.Add(new RowStyle(SizeType.Percent, 33.33334f));
    this.tableLayoutPanel_1.RowStyles.Add(new RowStyle(SizeType.Percent, 33.33333f));
    this.tableLayoutPanel_1.Size = new Size(838, 492);
    this.tableLayoutPanel_1.TabIndex = 0;
    this.tabPage_12.BackColor = Color.White;
    this.tabPage_12.Controls.Add((Control) this.groupBox_38);
    this.tabPage_12.Controls.Add((Control) this.label_46);
    this.tabPage_12.Controls.Add((Control) this.label_47);
    this.tabPage_12.Controls.Add((Control) this.groupBox_39);
    this.tabPage_12.Controls.Add((Control) this.class27_0);
    this.tabPage_12.Controls.Add((Control) this.groupBox_40);
    this.tabPage_12.Controls.Add((Control) this.groupBox_41);
    this.tabPage_12.Controls.Add((Control) this.groupBox_42);
    this.tabPage_12.Controls.Add((Control) this.groupBox_43);
    this.tabPage_12.ForeColor = Color.Black;
    this.tabPage_12.Location = new Point(4, 24);
    this.tabPage_12.Name = \u003CModule\u003E.smethod_8<string>(2558625384U);
    this.tabPage_12.Size = new Size(842, 516);
    this.tabPage_12.TabIndex = 0;
    this.tabPage_12.Text = \u003CModule\u003E.smethod_8<string>(2318566732U);
    this.groupBox_38.Controls.Add((Control) this.label_45);
    this.groupBox_38.Location = new Point(638, 468);
    this.groupBox_38.Name = \u003CModule\u003E.smethod_8<string>(717737161U);
    this.groupBox_38.Size = new Size(201, 39);
    this.groupBox_38.TabIndex = 134;
    this.groupBox_38.TabStop = false;
    this.groupBox_38.Text = \u003CModule\u003E.smethod_7<string>(1425669272U);
    this.label_45.ForeColor = Color.Black;
    this.label_45.Location = new Point(11, 16);
    this.label_45.Name = \u003CModule\u003E.smethod_7<string>(3039781070U);
    this.label_45.Size = new Size(179, 15);
    this.label_45.TabIndex = 2;
    this.label_45.Text = \u003CModule\u003E.smethod_7<string>(2218728923U);
    this.label_45.TextAlign = ContentAlignment.MiddleCenter;
    this.label_46.BackColor = Color.MidnightBlue;
    this.label_46.BorderStyle = BorderStyle.FixedSingle;
    this.label_46.Font = new Font(\u003CModule\u003E.smethod_6<string>(2348004861U), 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.label_46.ForeColor = Color.White;
    this.label_46.Location = new Point(6, 484);
    this.label_46.Margin = new Padding(3);
    this.label_46.Name = \u003CModule\u003E.smethod_5<string>(2169221838U);
    this.label_46.Size = new Size(109, 23);
    this.label_46.TabIndex = 20;
    this.label_46.Text = \u003CModule\u003E.smethod_6<string>(1842910598U);
    this.label_46.TextAlign = ContentAlignment.MiddleCenter;
    this.label_47.BackColor = Color.Crimson;
    this.label_47.BorderStyle = BorderStyle.FixedSingle;
    this.label_47.Font = new Font(\u003CModule\u003E.smethod_5<string>(2184462853U), 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.label_47.ForeColor = Color.White;
    this.label_47.Location = new Point(6, 253);
    this.label_47.Margin = new Padding(3, 0, 3, 3);
    this.label_47.Name = \u003CModule\u003E.smethod_7<string>(660602117U);
    this.label_47.Size = new Size(109, 23);
    this.label_47.TabIndex = 19;
    this.label_47.Text = \u003CModule\u003E.smethod_8<string>(3153396812U);
    this.label_47.TextAlign = ContentAlignment.MiddleCenter;
    this.groupBox_39.Controls.Add((Control) this.button_48);
    this.groupBox_39.Controls.Add((Control) this.button_49);
    this.groupBox_39.Controls.Add((Control) this.button_50);
    this.groupBox_39.Controls.Add((Control) this.button_51);
    this.groupBox_39.Controls.Add((Control) this.listBox_6);
    this.groupBox_39.Location = new Point(635, 9);
    this.groupBox_39.Name = \u003CModule\u003E.smethod_8<string>(424185956U);
    this.groupBox_39.Size = new Size(172, 238);
    this.groupBox_39.TabIndex = 18;
    this.groupBox_39.TabStop = false;
    this.groupBox_39.Text = \u003CModule\u003E.smethod_8<string>(184127304U);
    this.button_48.FlatStyle = FlatStyle.Flat;
    this.button_48.ForeColor = Color.Black;
    this.button_48.Location = new Point(102, 128);
    this.button_48.Name = \u003CModule\u003E.smethod_7<string>(2246721419U);
    this.button_48.Size = new Size(64, 49);
    this.button_48.TabIndex = 4;
    this.button_48.Text = \u003CModule\u003E.smethod_5<string>(538074139U);
    this.button_48.UseVisualStyleBackColor = true;
    this.button_48.Click += new EventHandler(this.button_48_Click);
    this.button_49.FlatStyle = FlatStyle.Flat;
    this.button_49.ForeColor = Color.Black;
    this.button_49.Location = new Point(102, 183);
    this.button_49.Name = \u003CModule\u003E.smethod_9<string>(633570554U);
    this.button_49.Size = new Size(64, 49);
    this.button_49.TabIndex = 3;
    this.button_49.Text = \u003CModule\u003E.smethod_9<string>(1192481685U);
    this.button_49.UseVisualStyleBackColor = true;
    this.button_49.Click += new EventHandler(this.button_49_Click);
    this.button_50.FlatStyle = FlatStyle.Flat;
    this.button_50.ForeColor = Color.Black;
    this.button_50.Location = new Point(102, 73);
    this.button_50.Name = \u003CModule\u003E.smethod_7<string>(3826599810U);
    this.button_50.Size = new Size(64, 49);
    this.button_50.TabIndex = 2;
    this.button_50.Text = \u003CModule\u003E.smethod_5<string>(2328717121U);
    this.button_50.UseVisualStyleBackColor = true;
    this.button_50.Click += new EventHandler(this.button_50_Click);
    this.button_51.FlatStyle = FlatStyle.Flat;
    this.button_51.ForeColor = Color.Black;
    this.button_51.Location = new Point(102, 18);
    this.button_51.Name = \u003CModule\u003E.smethod_9<string>(378510968U);
    this.button_51.Size = new Size(64, 49);
    this.button_51.TabIndex = 1;
    this.button_51.Text = \u003CModule\u003E.smethod_8<string>(1302208225U);
    this.button_51.UseVisualStyleBackColor = true;
    this.button_51.Click += new EventHandler(this.button_51_Click);
    this.listBox_6.ForeColor = Color.Black;
    this.listBox_6.FormattingEnabled = true;
    this.listBox_6.ItemHeight = 15;
    this.listBox_6.Location = new Point(6, 18);
    this.listBox_6.Name = \u003CModule\u003E.smethod_6<string>(1491400612U);
    this.listBox_6.SelectionMode = SelectionMode.MultiExtended;
    this.listBox_6.Size = new Size(90, 214);
    this.listBox_6.Sorted = true;
    this.listBox_6.TabIndex = 0;
    this.class27_0.BorderStyle = BorderStyle.FixedSingle;
    this.class27_0.Font = new Font(\u003CModule\u003E.smethod_8<string>(2058547965U), 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.class27_0.ForeColor = Color.Black;
    this.class27_0.Location = new Point(121, 484);
    this.class27_0.MaxLength = 53;
    this.class27_0.Name = \u003CModule\u003E.smethod_8<string>(1728832976U);
    this.class27_0.Size = new Size(508, 23);
    this.class27_0.TabIndex = 13;
    this.class27_0.TabStop = false;
    this.class27_0.Enter += new EventHandler(this.class27_0_Enter);
    this.class27_0.KeyDown += new KeyEventHandler(this.class27_0_KeyDown);
    this.class27_0.KeyPress += new KeyPressEventHandler(this.class27_0_KeyPress);
    this.class27_0.Leave += new EventHandler(this.class27_0_Leave);
    this.groupBox_40.Controls.Add((Control) this.button_52);
    this.groupBox_40.Controls.Add((Control) this.button_53);
    this.groupBox_40.Controls.Add((Control) this.button_54);
    this.groupBox_40.Controls.Add((Control) this.button_55);
    this.groupBox_40.Controls.Add((Control) this.listBox_7);
    this.groupBox_40.Location = new Point(220, 9);
    this.groupBox_40.Name = \u003CModule\u003E.smethod_9<string>(4193304967U);
    this.groupBox_40.Size = new Size(172, 238);
    this.groupBox_40.TabIndex = 11;
    this.groupBox_40.TabStop = false;
    this.groupBox_40.Text = \u003CModule\u003E.smethod_5<string>(2798159336U);
    this.button_52.FlatStyle = FlatStyle.Flat;
    this.button_52.ForeColor = Color.Black;
    this.button_52.Location = new Point(102, 128);
    this.button_52.Name = \u003CModule\u003E.smethod_7<string>(3223246720U);
    this.button_52.Size = new Size(64, 49);
    this.button_52.TabIndex = 4;
    this.button_52.Text = \u003CModule\u003E.smethod_6<string>(2994249928U);
    this.button_52.UseVisualStyleBackColor = true;
    this.button_52.Click += new EventHandler(this.button_52_Click);
    this.button_53.FlatStyle = FlatStyle.Flat;
    this.button_53.ForeColor = Color.Black;
    this.button_53.Location = new Point(102, 73);
    this.button_53.Name = \u003CModule\u003E.smethod_8<string>(2449008932U);
    this.button_53.Size = new Size(64, 49);
    this.button_53.TabIndex = 3;
    this.button_53.Text = \u003CModule\u003E.smethod_5<string>(2605335770U);
    this.button_53.UseVisualStyleBackColor = true;
    this.button_53.Click += new EventHandler(this.button_53_Click);
    this.button_54.FlatStyle = FlatStyle.Flat;
    this.button_54.ForeColor = Color.Black;
    this.button_54.Location = new Point(102, 183);
    this.button_54.Name = \u003CModule\u003E.smethod_6<string>(3952739465U);
    this.button_54.Size = new Size(64, 49);
    this.button_54.TabIndex = 2;
    this.button_54.Text = \u003CModule\u003E.smethod_9<string>(1192481685U);
    this.button_54.UseVisualStyleBackColor = true;
    this.button_54.Click += new EventHandler(this.button_54_Click);
    this.button_55.FlatStyle = FlatStyle.Flat;
    this.button_55.ForeColor = Color.Black;
    this.button_55.Location = new Point(102, 18);
    this.button_55.Name = \u003CModule\u003E.smethod_7<string>(1531398345U);
    this.button_55.Size = new Size(64, 49);
    this.button_55.TabIndex = 1;
    this.button_55.Text = \u003CModule\u003E.smethod_7<string>(900052759U);
    this.button_55.UseVisualStyleBackColor = true;
    this.button_55.Click += new EventHandler(this.button_55_Click);
    this.listBox_7.ForeColor = Color.Black;
    this.listBox_7.FormattingEnabled = true;
    this.listBox_7.ItemHeight = 15;
    this.listBox_7.Location = new Point(6, 18);
    this.listBox_7.Name = \u003CModule\u003E.smethod_8<string>(901671914U);
    this.listBox_7.SelectionMode = SelectionMode.MultiExtended;
    this.listBox_7.Size = new Size(90, 214);
    this.listBox_7.TabIndex = 0;
    this.groupBox_41.Controls.Add((Control) this.button_67);
    this.groupBox_41.Controls.Add((Control) this.button_56);
    this.groupBox_41.Controls.Add((Control) this.button_57);
    this.groupBox_41.Controls.Add((Control) this.listBox_8);
    this.groupBox_41.Location = new Point(425, 9);
    this.groupBox_41.Name = \u003CModule\u003E.smethod_9<string>(1417595396U);
    this.groupBox_41.Size = new Size(172, 238);
    this.groupBox_41.TabIndex = 10;
    this.groupBox_41.TabStop = false;
    this.groupBox_41.Text = \u003CModule\u003E.smethod_5<string>(856115954U);
    this.button_67.FlatStyle = FlatStyle.Flat;
    this.button_67.ForeColor = Color.Black;
    this.button_67.Location = new Point(102, 73);
    this.button_67.Name = \u003CModule\u003E.smethod_9<string>(348565093U);
    this.button_67.Size = new Size(64, 49);
    this.button_67.TabIndex = 4;
    this.button_67.Text = \u003CModule\u003E.smethod_6<string>(4236639202U);
    this.button_67.UseVisualStyleBackColor = true;
    this.button_67.Click += new EventHandler(this.button_67_Click);
    this.button_56.FlatStyle = FlatStyle.Flat;
    this.button_56.ForeColor = Color.Black;
    this.button_56.Location = new Point(102, 18);
    this.button_56.Name = \u003CModule\u003E.smethod_8<string>(1861906522U);
    this.button_56.Size = new Size(64, 49);
    this.button_56.TabIndex = 2;
    this.button_56.Text = \u003CModule\u003E.smethod_8<string>(1621847870U);
    this.button_56.UseVisualStyleBackColor = true;
    this.button_56.Click += new EventHandler(this.button_56_Click);
    this.button_57.FlatStyle = FlatStyle.Flat;
    this.button_57.ForeColor = Color.Black;
    this.button_57.Location = new Point(102, 128);
    this.button_57.Name = \u003CModule\u003E.smethod_7<string>(1749097402U);
    this.button_57.Size = new Size(64, 49);
    this.button_57.TabIndex = 1;
    this.button_57.Text = \u003CModule\u003E.smethod_5<string>(1325558169U);
    this.button_57.UseVisualStyleBackColor = true;
    this.button_57.Click += new EventHandler(this.button_57_Click);
    this.listBox_8.ForeColor = Color.Black;
    this.listBox_8.FormattingEnabled = true;
    this.listBox_8.ItemHeight = 15;
    this.listBox_8.Location = new Point(6, 18);
    this.listBox_8.Name = \u003CModule\u003E.smethod_9<string>(123451382U);
    this.listBox_8.SelectionMode = SelectionMode.MultiExtended;
    this.listBox_8.Size = new Size(90, 214);
    this.listBox_8.Sorted = true;
    this.listBox_8.TabIndex = 0;
    this.groupBox_42.Controls.Add((Control) this.button_66);
    this.groupBox_42.Controls.Add((Control) this.label_48);
    this.groupBox_42.Controls.Add((Control) this.label_49);
    this.groupBox_42.Controls.Add((Control) this.label_50);
    this.groupBox_42.Controls.Add((Control) this.label_51);
    this.groupBox_42.Controls.Add((Control) this.label_52);
    this.groupBox_42.Controls.Add((Control) this.button_58);
    this.groupBox_42.Controls.Add((Control) this.button_59);
    this.groupBox_42.Controls.Add((Control) this.textBox_19);
    this.groupBox_42.Controls.Add((Control) this.button_60);
    this.groupBox_42.Controls.Add((Control) this.textBox_20);
    this.groupBox_42.Controls.Add((Control) this.button_61);
    this.groupBox_42.Controls.Add((Control) this.button_62);
    this.groupBox_42.Location = new Point(6, 6);
    this.groupBox_42.Name = \u003CModule\u003E.smethod_9<string>(986214058U);
    this.groupBox_42.Size = new Size(177, 241);
    this.groupBox_42.TabIndex = 9;
    this.groupBox_42.TabStop = false;
    this.groupBox_42.Text = \u003CModule\u003E.smethod_8<string>(741194255U);
    this.button_66.Enabled = false;
    this.button_66.FlatStyle = FlatStyle.Flat;
    this.button_66.Font = new Font(\u003CModule\u003E.smethod_5<string>(2184462853U), 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.button_66.ForeColor = Color.Black;
    this.button_66.Location = new Point(9, 203);
    this.button_66.Margin = new Padding(5);
    this.button_66.Name = \u003CModule\u003E.smethod_7<string>(2570149549U);
    this.button_66.Size = new Size(50, 30);
    this.button_66.TabIndex = 9;
    this.button_66.Text = \u003CModule\u003E.smethod_7<string>(3636893249U);
    this.button_66.UseVisualStyleBackColor = true;
    this.button_66.Click += new EventHandler(this.button_66_Click);
    this.label_48.ForeColor = Color.Black;
    this.label_48.Location = new Point(86, (int) sbyte.MaxValue);
    this.label_48.Name = \u003CModule\u003E.smethod_7<string>(2809600191U);
    this.label_48.Size = new Size(85, 15);
    this.label_48.TabIndex = 2;
    this.label_48.Text = \u003CModule\u003E.smethod_6<string>(1608599087U);
    this.label_48.TextAlign = ContentAlignment.MiddleRight;
    this.label_49.AutoSize = true;
    this.label_49.ForeColor = Color.Black;
    this.label_49.Location = new Point(65, 156);
    this.label_49.Margin = new Padding(3);
    this.label_49.Name = \u003CModule\u003E.smethod_7<string>(1988548044U);
    this.label_49.Size = new Size(51, 15);
    this.label_49.TabIndex = 8;
    this.label_49.Text = \u003CModule\u003E.smethod_9<string>(3056636621U);
    this.label_50.ForeColor = Color.Black;
    this.label_50.Location = new Point(9, 110);
    this.label_50.Name = \u003CModule\u003E.smethod_6<string>(4223607656U);
    this.label_50.Size = new Size(158, 15);
    this.label_50.TabIndex = 1;
    this.label_50.Text = \u003CModule\u003E.smethod_9<string>(183343132U);
    this.label_50.TextAlign = ContentAlignment.MiddleCenter;
    this.label_51.AutoSize = true;
    this.label_51.ForeColor = Color.Black;
    this.label_51.Location = new Point(65, 19);
    this.label_51.Margin = new Padding(3);
    this.label_51.Name = \u003CModule\u003E.smethod_6<string>(3111448403U);
    this.label_51.Size = new Size(35, 15);
    this.label_51.TabIndex = 7;
    this.label_51.Text = \u003CModule\u003E.smethod_6<string>(342770118U);
    this.label_52.AutoSize = true;
    this.label_52.ForeColor = Color.Black;
    this.label_52.Location = new Point(6, (int) sbyte.MaxValue);
    this.label_52.Name = \u003CModule\u003E.smethod_7<string>(1739094811U);
    this.label_52.Size = new Size(21, 15);
    this.label_52.TabIndex = 0;
    this.label_52.Text = \u003CModule\u003E.smethod_6<string>(473000139U);
    this.label_52.TextAlign = ContentAlignment.MiddleLeft;
    this.button_58.FlatStyle = FlatStyle.Flat;
    this.button_58.ForeColor = Color.Black;
    this.button_58.Location = new Point(68, 66);
    this.button_58.Margin = new Padding(5);
    this.button_58.Name = \u003CModule\u003E.smethod_7<string>(3820358899U);
    this.button_58.Size = new Size(100, 30);
    this.button_58.TabIndex = 5;
    this.button_58.Text = \u003CModule\u003E.smethod_6<string>(2543648929U);
    this.button_58.UseVisualStyleBackColor = true;
    this.button_58.Click += new EventHandler(this.button_58_Click);
    this.button_59.FlatStyle = FlatStyle.Flat;
    this.button_59.ForeColor = Color.Black;
    this.button_59.Location = new Point(9, 66);
    this.button_59.Margin = new Padding(5);
    this.button_59.Name = \u003CModule\u003E.smethod_7<string>(3546674850U);
    this.button_59.Size = new Size(50, 30);
    this.button_59.TabIndex = 4;
    this.button_59.Text = \u003CModule\u003E.smethod_8<string>(3944169070U);
    this.button_59.UseVisualStyleBackColor = true;
    this.button_59.Click += new EventHandler(this.button_59_Click);
    this.textBox_19.BackColor = Color.White;
    this.textBox_19.BorderStyle = BorderStyle.FixedSingle;
    this.textBox_19.ForeColor = Color.Black;
    this.textBox_19.Location = new Point(68, 37);
    this.textBox_19.Margin = new Padding(0);
    this.textBox_19.MaxLength = 12;
    this.textBox_19.Name = \u003CModule\u003E.smethod_8<string>(2343339499U);
    this.textBox_19.Size = new Size(100, 23);
    this.textBox_19.TabIndex = 1;
    this.textBox_19.TextAlign = HorizontalAlignment.Center;
    this.textBox_19.Enter += new EventHandler(this.textBox_20_Enter);
    this.textBox_19.KeyPress += new KeyPressEventHandler(this.textBox_19_KeyPress);
    this.textBox_19.Leave += new EventHandler(this.textBox_20_Leave);
    this.button_60.FlatStyle = FlatStyle.Flat;
    this.button_60.ForeColor = Color.Black;
    this.button_60.Location = new Point(9, 31);
    this.button_60.Margin = new Padding(0);
    this.button_60.Name = \u003CModule\u003E.smethod_7<string>(2507923646U);
    this.button_60.Size = new Size(50, 30);
    this.button_60.TabIndex = 0;
    this.button_60.Text = \u003CModule\u003E.smethod_5<string>(1917836589U);
    this.button_60.UseVisualStyleBackColor = true;
    this.button_60.Click += new EventHandler(this.button_60_Click);
    this.textBox_20.BackColor = Color.White;
    this.textBox_20.BorderStyle = BorderStyle.FixedSingle;
    this.textBox_20.ForeColor = Color.Black;
    this.textBox_20.Location = new Point(67, 174);
    this.textBox_20.Margin = new Padding(0);
    this.textBox_20.MaxLength = 12;
    this.textBox_20.Name = \u003CModule\u003E.smethod_7<string>(3300983297U);
    this.textBox_20.Size = new Size(100, 23);
    this.textBox_20.TabIndex = 3;
    this.textBox_20.TextAlign = HorizontalAlignment.Center;
    this.textBox_20.Enter += new EventHandler(this.textBox_20_Enter);
    this.textBox_20.KeyPress += new KeyPressEventHandler(this.textBox_20_KeyPress);
    this.textBox_20.Leave += new EventHandler(this.textBox_20_Leave);
    this.button_61.FlatStyle = FlatStyle.Flat;
    this.button_61.ForeColor = Color.Black;
    this.button_61.Location = new Point(9, 168);
    this.button_61.Margin = new Padding(0);
    this.button_61.Name = \u003CModule\u003E.smethod_7<string>(1581142426U);
    this.button_61.Size = new Size(50, 30);
    this.button_61.TabIndex = 2;
    this.button_61.Text = \u003CModule\u003E.smethod_6<string>(579790465U);
    this.button_61.UseVisualStyleBackColor = true;
    this.button_61.Click += new EventHandler(this.button_61_Click);
    this.button_62.FlatStyle = FlatStyle.Flat;
    this.button_62.ForeColor = Color.Black;
    this.button_62.Location = new Point(67, 203);
    this.button_62.Margin = new Padding(5);
    this.button_62.Name = \u003CModule\u003E.smethod_6<string>(2520209234U);
    this.button_62.Size = new Size(100, 30);
    this.button_62.TabIndex = 6;
    this.button_62.Text = \u003CModule\u003E.smethod_8<string>(1222627232U);
    this.button_62.UseVisualStyleBackColor = true;
    this.button_62.Click += new EventHandler(this.button_62_Click);
    this.groupBox_43.Controls.Add((Control) this.label_53);
    this.groupBox_43.Controls.Add((Control) this.label_54);
    this.groupBox_43.Controls.Add((Control) this.label_55);
    this.groupBox_43.Controls.Add((Control) this.label_56);
    this.groupBox_43.Controls.Add((Control) this.label_57);
    this.groupBox_43.Controls.Add((Control) this.button_63);
    this.groupBox_43.Controls.Add((Control) this.button_64);
    this.groupBox_43.Controls.Add((Control) this.checkBox_86);
    this.groupBox_43.Controls.Add((Control) this.checkBox_87);
    this.groupBox_43.Controls.Add((Control) this.button_65);
    this.groupBox_43.Controls.Add((Control) this.comboBox_10);
    this.groupBox_43.Controls.Add((Control) this.comboBox_11);
    this.groupBox_43.Controls.Add((Control) this.label_58);
    this.groupBox_43.Controls.Add((Control) this.label_59);
    this.groupBox_43.Location = new Point(635, 253);
    this.groupBox_43.Name = \u003CModule\u003E.smethod_5<string>(895157076U);
    this.groupBox_43.Size = new Size(201, 209);
    this.groupBox_43.TabIndex = 6;
    this.groupBox_43.TabStop = false;
    this.groupBox_43.Text = \u003CModule\u003E.smethod_9<string>(1653808898U);
    this.label_53.ForeColor = Color.Black;
    this.label_53.Location = new Point(6, 19);
    this.label_53.Name = \u003CModule\u003E.smethod_6<string>(1538280002U);
    this.label_53.Size = new Size(139, 15);
    this.label_53.TabIndex = 28;
    this.label_53.Text = \u003CModule\u003E.smethod_7<string>(514398726U);
    this.label_53.TextAlign = ContentAlignment.MiddleLeft;
    this.label_54.ForeColor = Color.Black;
    this.label_54.Location = new Point(6, 79);
    this.label_54.Name = \u003CModule\u003E.smethod_6<string>(840250507U);
    this.label_54.Size = new Size(125, 15);
    this.label_54.TabIndex = 27;
    this.label_54.Text = \u003CModule\u003E.smethod_6<string>(11990991U);
    this.label_54.TextAlign = ContentAlignment.MiddleLeft;
    this.label_55.ForeColor = Color.Black;
    this.label_55.Location = new Point(6, 64);
    this.label_55.Name = \u003CModule\u003E.smethod_7<string>(2044533036U);
    this.label_55.Size = new Size(125, 15);
    this.label_55.TabIndex = 26;
    this.label_55.Text = \u003CModule\u003E.smethod_5<string>(638058988U);
    this.label_55.TextAlign = ContentAlignment.MiddleLeft;
    this.label_56.AutoSize = true;
    this.label_56.ForeColor = Color.Black;
    this.label_56.Location = new Point(6, 161);
    this.label_56.Name = \u003CModule\u003E.smethod_9<string>(232135091U);
    this.label_56.Size = new Size(37, 15);
    this.label_56.TabIndex = 25;
    this.label_56.Text = \u003CModule\u003E.smethod_7<string>(3960321379U);
    this.label_57.AutoSize = true;
    this.label_57.ForeColor = Color.Black;
    this.label_57.Location = new Point(6, 111);
    this.label_57.Name = \u003CModule\u003E.smethod_5<string>(1236050247U);
    this.label_57.Size = new Size(50, 15);
    this.label_57.TabIndex = 24;
    this.label_57.Text = \u003CModule\u003E.smethod_6<string>(1514840307U);
    this.button_63.FlatStyle = FlatStyle.Flat;
    this.button_63.ForeColor = Color.Black;
    this.button_63.Location = new Point(158, 178);
    this.button_63.Name = \u003CModule\u003E.smethod_5<string>(1898316028U);
    this.button_63.Size = new Size(43, 23);
    this.button_63.TabIndex = 23;
    this.button_63.Text = \u003CModule\u003E.smethod_8<string>(961742832U);
    this.button_63.UseVisualStyleBackColor = true;
    this.button_63.Click += new EventHandler(this.button_63_Click);
    this.button_64.FlatStyle = FlatStyle.Flat;
    this.button_64.ForeColor = Color.Black;
    this.button_64.Location = new Point(158, 134);
    this.button_64.Name = \u003CModule\u003E.smethod_6<string>(2699942042U);
    this.button_64.Size = new Size(43, 23);
    this.button_64.TabIndex = 22;
    this.button_64.Text = \u003CModule\u003E.smethod_6<string>(3114071800U);
    this.button_64.UseVisualStyleBackColor = true;
    this.button_64.Click += new EventHandler(this.button_64_Click);
    this.checkBox_86.AutoSize = true;
    this.checkBox_86.ForeColor = Color.Black;
    this.checkBox_86.Location = new Point(102, 181);
    this.checkBox_86.Name = \u003CModule\u003E.smethod_8<string>(2749138502U);
    this.checkBox_86.Size = new Size(52, 19);
    this.checkBox_86.TabIndex = 21;
    this.checkBox_86.Text = \u003CModule\u003E.smethod_5<string>(3482327722U);
    this.checkBox_86.UseVisualStyleBackColor = true;
    this.checkBox_87.AutoSize = true;
    this.checkBox_87.ForeColor = Color.Black;
    this.checkBox_87.Location = new Point(100, 137);
    this.checkBox_87.Name = \u003CModule\u003E.smethod_7<string>(2831351776U);
    this.checkBox_87.Size = new Size(52, 19);
    this.checkBox_87.TabIndex = 18;
    this.checkBox_87.Text = \u003CModule\u003E.smethod_7<string>(3378719874U);
    this.checkBox_87.UseVisualStyleBackColor = true;
    this.button_65.FlatStyle = FlatStyle.Flat;
    this.button_65.ForeColor = Color.Black;
    this.button_65.Location = new Point(145, 8);
    this.button_65.Name = \u003CModule\u003E.smethod_9<string>(480487681U);
    this.button_65.Size = new Size(56, 38);
    this.button_65.TabIndex = 4;
    this.button_65.Text = \u003CModule\u003E.smethod_5<string>(2627238375U);
    this.button_65.UseVisualStyleBackColor = true;
    this.button_65.Click += new EventHandler(this.button_65_Click);
    this.comboBox_10.ForeColor = Color.Black;
    this.comboBox_10.FormattingEnabled = true;
    this.comboBox_10.Items.AddRange(new object[2]
    {
      (object) \u003CModule\u003E.smethod_5<string>(1900698072U),
      (object) \u003CModule\u003E.smethod_8<string>(1201801484U)
    });
    this.comboBox_10.Location = new Point(6, 179);
    this.comboBox_10.Name = \u003CModule\u003E.smethod_8<string>(2882212048U);
    this.comboBox_10.Size = new Size(88, 23);
    this.comboBox_10.TabIndex = 3;
    this.comboBox_10.Text = \u003CModule\u003E.smethod_6<string>(3788661600U);
    this.comboBox_11.ForeColor = Color.Black;
    this.comboBox_11.FormattingEnabled = true;
    this.comboBox_11.Items.AddRange(new object[6]
    {
      (object) \u003CModule\u003E.smethod_5<string>(3887495415U),
      (object) \u003CModule\u003E.smethod_8<string>(1148308931U),
      (object) \u003CModule\u003E.smethod_7<string>(3049050833U),
      (object) \u003CModule\u003E.smethod_9<string>(431695722U),
      (object) \u003CModule\u003E.smethod_6<string>(3634991884U),
      (object) \u003CModule\u003E.smethod_5<string>(126244856U)
    });
    this.comboBox_11.Location = new Point(6, 135);
    this.comboBox_11.Name = \u003CModule\u003E.smethod_7<string>(2803359280U);
    this.comboBox_11.Size = new Size(88, 23);
    this.comboBox_11.TabIndex = 2;
    this.comboBox_11.Text = \u003CModule\u003E.smethod_8<string>(1388367583U);
    this.label_58.ForeColor = Color.Black;
    this.label_58.Location = new Point(6, 49);
    this.label_58.Name = \u003CModule\u003E.smethod_6<string>(712643883U);
    this.label_58.Size = new Size(125, 15);
    this.label_58.TabIndex = 1;
    this.label_58.Text = \u003CModule\u003E.smethod_5<string>(620920471U);
    this.label_58.TextAlign = ContentAlignment.MiddleLeft;
    this.label_59.ForeColor = Color.Black;
    this.label_59.Location = new Point(6, 34);
    this.label_59.Name = \u003CModule\u003E.smethod_6<string>(842873904U);
    this.label_59.Size = new Size(139, 15);
    this.label_59.TabIndex = 0;
    this.label_59.Text = \u003CModule\u003E.smethod_9<string>(1519572109U);
    this.label_59.TextAlign = ContentAlignment.MiddleLeft;
    this.tabControl_2.Controls.Add((Control) this.tabPage_12);
    this.tabControl_2.Controls.Add((Control) this.tabPage_9);
    this.tabControl_2.Controls.Add((Control) this.tabPage_7);
    this.tabControl_2.Controls.Add((Control) this.tabPage_13);
    this.tabControl_2.Controls.Add((Control) this.tabPage_6);
    this.tabControl_2.Controls.Add((Control) this.tabPage_5);
    this.tabControl_2.Controls.Add((Control) this.tabPage_4);
    this.tabControl_2.Controls.Add((Control) this.tabPage_3);
    this.tabControl_2.Controls.Add((Control) this.tabPage_2);
    this.tabControl_2.ForeColor = Color.Black;
    this.tabControl_2.HotTrack = true;
    this.tabControl_2.Location = new Point(0, 24);
    this.tabControl_2.Margin = new Padding(0);
    this.tabControl_2.Name = \u003CModule\u003E.smethod_5<string>(2671992336U);
    this.tabControl_2.Padding = new Point(0, 0);
    this.tabControl_2.SelectedIndex = 0;
    this.tabControl_2.Size = new Size(850, 544);
    this.tabControl_2.TabIndex = 2;
    this.tabPage_13.Controls.Add((Control) this.label_65);
    this.tabPage_13.Controls.Add((Control) this.groupBox_54);
    this.tabPage_13.Controls.Add((Control) this.groupBox_49);
    this.tabPage_13.Controls.Add((Control) this.groupBox_50);
    this.tabPage_13.Controls.Add((Control) this.groupBox_51);
    this.tabPage_13.Controls.Add((Control) this.groupBox_52);
    this.tabPage_13.Controls.Add((Control) this.groupBox_53);
    this.tabPage_13.Controls.Add((Control) this.button_73);
    this.tabPage_13.Location = new Point(4, 22);
    this.tabPage_13.Name = \u003CModule\u003E.smethod_5<string>(1881177511U);
    this.tabPage_13.Padding = new Padding(3);
    this.tabPage_13.Size = new Size(842, 518);
    this.tabPage_13.TabIndex = 13;
    this.tabPage_13.Text = \u003CModule\u003E.smethod_5<string>(3269983595U);
    this.tabPage_13.UseVisualStyleBackColor = true;
    this.label_65.AutoSize = true;
    this.label_65.Font = new Font(\u003CModule\u003E.smethod_9<string>(868744759U), 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.label_65.ForeColor = Color.Red;
    this.label_65.Location = new Point(332, 16);
    this.label_65.Name = \u003CModule\u003E.smethod_6<string>(313827312U);
    this.label_65.Size = new Size(345, 15);
    this.label_65.TabIndex = 166;
    this.label_65.Text = \u003CModule\u003E.smethod_6<string>(3327652452U);
    this.label_65.TextAlign = ContentAlignment.MiddleCenter;
    this.groupBox_54.Controls.Add((Control) this.textBox_25);
    this.groupBox_54.Controls.Add((Control) this.checkBox_101);
    this.groupBox_54.Controls.Add((Control) this.textBox_24);
    this.groupBox_54.Controls.Add((Control) this.checkBox_93);
    this.groupBox_54.Location = new Point(165, 233);
    this.groupBox_54.Name = \u003CModule\u003E.smethod_5<string>(961813642U);
    this.groupBox_54.Size = new Size(213, 82);
    this.groupBox_54.TabIndex = 183;
    this.groupBox_54.TabStop = false;
    this.groupBox_54.Text = \u003CModule\u003E.smethod_6<string>(1931593462U);
    this.textBox_25.Location = new Point(82, 49);
    this.textBox_25.Name = \u003CModule\u003E.smethod_5<string>(3012885507U);
    this.textBox_25.Size = new Size(118, 23);
    this.textBox_25.TabIndex = 183;
    this.checkBox_101.AutoSize = true;
    this.checkBox_101.Location = new Point(6, 51);
    this.checkBox_101.Name = \u003CModule\u003E.smethod_9<string>(4137806012U);
    this.checkBox_101.Size = new Size(70, 19);
    this.checkBox_101.TabIndex = 182;
    this.checkBox_101.Text = \u003CModule\u003E.smethod_5<string>(2222070682U);
    this.checkBox_101.UseVisualStyleBackColor = true;
    this.textBox_24.Location = new Point(82, 20);
    this.textBox_24.Name = \u003CModule\u003E.smethod_9<string>(4265335805U);
    this.textBox_24.Size = new Size(118, 23);
    this.textBox_24.TabIndex = 181;
    this.checkBox_93.AutoSize = true;
    this.checkBox_93.Location = new Point(6, 22);
    this.checkBox_93.Name = \u003CModule\u003E.smethod_5<string>(2196837282U);
    this.checkBox_93.Size = new Size(70, 19);
    this.checkBox_93.TabIndex = 179;
    this.checkBox_93.Text = \u003CModule\u003E.smethod_7<string>(2088036206U);
    this.checkBox_93.UseVisualStyleBackColor = true;
    this.groupBox_49.Controls.Add((Control) this.checkBox_94);
    this.groupBox_49.Controls.Add((Control) this.checkBox_95);
    this.groupBox_49.Controls.Add((Control) this.checkBox_96);
    this.groupBox_49.Location = new Point(6, 116);
    this.groupBox_49.Name = \u003CModule\u003E.smethod_6<string>(1267411811U);
    this.groupBox_49.Size = new Size(153, 148);
    this.groupBox_49.TabIndex = 182;
    this.groupBox_49.TabStop = false;
    this.groupBox_49.Text = \u003CModule\u003E.smethod_9<string>(108998093U);
    this.checkBox_94.AutoSize = true;
    this.checkBox_94.Location = new Point(11, 72);
    this.checkBox_94.Name = \u003CModule\u003E.smethod_9<string>(971760769U);
    this.checkBox_94.Size = new Size(71, 19);
    this.checkBox_94.TabIndex = 178;
    this.checkBox_94.Text = \u003CModule\u003E.smethod_7<string>(775600953U);
    this.checkBox_94.UseVisualStyleBackColor = true;
    this.checkBox_95.AutoSize = true;
    this.checkBox_95.Location = new Point(11, 22);
    this.checkBox_95.Name = \u003CModule\u003E.smethod_6<string>(285482579U);
    this.checkBox_95.Size = new Size(119, 19);
    this.checkBox_95.TabIndex = 176;
    this.checkBox_95.Text = \u003CModule\u003E.smethod_5<string>(1875464672U);
    this.checkBox_95.UseVisualStyleBackColor = true;
    this.checkBox_96.AutoSize = true;
    this.checkBox_96.Location = new Point(11, 47);
    this.checkBox_96.Name = \u003CModule\u003E.smethod_8<string>(1282698150U);
    this.checkBox_96.Size = new Size(113, 19);
    this.checkBox_96.TabIndex = 177;
    this.checkBox_96.Text = \u003CModule\u003E.smethod_7<string>(2551426816U);
    this.checkBox_96.UseVisualStyleBackColor = true;
    this.groupBox_50.Controls.Add((Control) this.label_63);
    this.groupBox_50.Controls.Add((Control) this.numericUpDown_23);
    this.groupBox_50.Controls.Add((Control) this.radioButton_4);
    this.groupBox_50.Controls.Add((Control) this.checkBox_97);
    this.groupBox_50.Controls.Add((Control) this.radioButton_5);
    this.groupBox_50.Controls.Add((Control) this.textBox_23);
    this.groupBox_50.Location = new Point(520, 233);
    this.groupBox_50.Name = \u003CModule\u003E.smethod_5<string>(956100803U);
    this.groupBox_50.Size = new Size(188, 168);
    this.groupBox_50.TabIndex = 181;
    this.groupBox_50.TabStop = false;
    this.groupBox_50.Text = \u003CModule\u003E.smethod_5<string>(2344906887U);
    this.label_63.AutoSize = true;
    this.label_63.Location = new Point(144, 134);
    this.label_63.Name = \u003CModule\u003E.smethod_5<string>(2280632365U);
    this.label_63.Size = new Size(33, 15);
    this.label_63.TabIndex = 174;
    this.label_63.Text = \u003CModule\u003E.smethod_8<string>(1762815454U);
    this.label_63.TextAlign = ContentAlignment.MiddleCenter;
    this.numericUpDown_23.ForeColor = Color.Black;
    this.numericUpDown_23.Location = new Point(95, 131);
    this.numericUpDown_23.Maximum = new Decimal(new int[4]
    {
      1000,
      0,
      0,
      0
    });
    this.numericUpDown_23.Name = \u003CModule\u003E.smethod_9<string>(1324404273U);
    this.numericUpDown_23.Size = new Size(43, 23);
    this.numericUpDown_23.TabIndex = 175;
    this.numericUpDown_23.TextAlign = HorizontalAlignment.Center;
    this.numericUpDown_23.Value = new Decimal(new int[4]
    {
      8,
      0,
      0,
      0
    });
    this.radioButton_4.AutoSize = true;
    this.radioButton_4.Location = new Point(10, 132);
    this.radioButton_4.Name = \u003CModule\u003E.smethod_7<string>(2200006190U);
    this.radioButton_4.Size = new Size(85, 19);
    this.radioButton_4.TabIndex = 174;
    this.radioButton_4.Text = \u003CModule\u003E.smethod_9<string>(765493142U);
    this.radioButton_4.UseVisualStyleBackColor = true;
    this.checkBox_97.AutoSize = true;
    this.checkBox_97.ForeColor = Color.Black;
    this.checkBox_97.Location = new Point(32, 22);
    this.checkBox_97.Name = \u003CModule\u003E.smethod_6<string>(1764892200U);
    this.checkBox_97.Size = new Size(125, 34);
    this.checkBox_97.TabIndex = 170;
    this.checkBox_97.Text = \u003CModule\u003E.smethod_9<string>(2187166949U);
    this.checkBox_97.UseVisualStyleBackColor = true;
    this.radioButton_5.AutoSize = true;
    this.radioButton_5.Checked = true;
    this.radioButton_5.Location = new Point(10, 107);
    this.radioButton_5.Name = \u003CModule\u003E.smethod_9<string>(1275612314U);
    this.radioButton_5.Size = new Size(103, 19);
    this.radioButton_5.TabIndex = 173;
    this.radioButton_5.TabStop = true;
    this.radioButton_5.Text = \u003CModule\u003E.smethod_9<string>(3079875500U);
    this.radioButton_5.UseVisualStyleBackColor = true;
    this.textBox_23.BackColor = Color.White;
    this.textBox_23.BorderStyle = BorderStyle.FixedSingle;
    this.textBox_23.ForeColor = Color.Black;
    this.textBox_23.Location = new Point(39, 69);
    this.textBox_23.Margin = new Padding(0);
    this.textBox_23.MaxLength = 12;
    this.textBox_23.Name = \u003CModule\u003E.smethod_6<string>(3551641253U);
    this.textBox_23.Size = new Size(114, 23);
    this.textBox_23.TabIndex = 169;
    this.textBox_23.TextAlign = HorizontalAlignment.Center;
    this.groupBox_51.Controls.Add((Control) this.checkBox_98);
    this.groupBox_51.Controls.Add((Control) this.numericUpDown_24);
    this.groupBox_51.Controls.Add((Control) this.label_64);
    this.groupBox_51.Location = new Point(6, 6);
    this.groupBox_51.Name = \u003CModule\u003E.smethod_5<string>(2389660848U);
    this.groupBox_51.Size = new Size(153, 104);
    this.groupBox_51.TabIndex = 180;
    this.groupBox_51.TabStop = false;
    this.groupBox_51.Text = \u003CModule\u003E.smethod_7<string>(557901896U);
    this.checkBox_98.AutoSize = true;
    this.checkBox_98.ForeColor = Color.Black;
    this.checkBox_98.Location = new Point(11, 47);
    this.checkBox_98.Name = \u003CModule\u003E.smethod_5<string>(2987652107U);
    this.checkBox_98.Size = new Size(84, 19);
    this.checkBox_98.TabIndex = 165;
    this.checkBox_98.Text = \u003CModule\u003E.smethod_9<string>(1706993652U);
    this.checkBox_98.UseVisualStyleBackColor = true;
    this.numericUpDown_24.ForeColor = Color.Black;
    this.numericUpDown_24.Location = new Point(104, 22);
    this.numericUpDown_24.Maximum = new Decimal(new int[4]
    {
      1000,
      0,
      0,
      0
    });
    this.numericUpDown_24.Name = \u003CModule\u003E.smethod_9<string>(1159182312U);
    this.numericUpDown_24.Size = new Size(43, 23);
    this.numericUpDown_24.TabIndex = 163;
    this.numericUpDown_24.TextAlign = HorizontalAlignment.Center;
    this.numericUpDown_24.Value = new Decimal(new int[4]
    {
      5,
      0,
      0,
      0
    });
    this.label_64.AutoSize = true;
    this.label_64.Location = new Point(8, 24);
    this.label_64.Name = \u003CModule\u003E.smethod_8<string>(933023046U);
    this.label_64.Size = new Size(94, 15);
    this.label_64.TabIndex = 164;
    this.label_64.Text = \u003CModule\u003E.smethod_7<string>(1590412189U);
    this.label_64.TextAlign = ContentAlignment.MiddleCenter;
    this.groupBox_52.Controls.Add((Control) this.checkBox_99);
    this.groupBox_52.Controls.Add((Control) this.checkBox_100);
    this.groupBox_52.Location = new Point(384, 233);
    this.groupBox_52.Name = \u003CModule\u003E.smethod_7<string>(3997583638U);
    this.groupBox_52.Size = new Size(130, 82);
    this.groupBox_52.TabIndex = 179;
    this.groupBox_52.TabStop = false;
    this.groupBox_52.Text = \u003CModule\u003E.smethod_5<string>(3275696434U);
    this.checkBox_99.AutoSize = true;
    this.checkBox_99.ForeColor = Color.Black;
    this.checkBox_99.Location = new Point(6, 51);
    this.checkBox_99.Name = \u003CModule\u003E.smethod_5<string>(3937962215U);
    this.checkBox_99.Size = new Size(103, 19);
    this.checkBox_99.TabIndex = 162;
    this.checkBox_99.Text = \u003CModule\u003E.smethod_5<string>(1758341306U);
    this.checkBox_99.UseVisualStyleBackColor = true;
    this.checkBox_100.AutoSize = true;
    this.checkBox_100.ForeColor = Color.Black;
    this.checkBox_100.Location = new Point(6, 22);
    this.checkBox_100.Name = \u003CModule\u003E.smethod_9<string>(2914653539U);
    this.checkBox_100.Size = new Size(88, 19);
    this.checkBox_100.TabIndex = 1;
    this.checkBox_100.Text = \u003CModule\u003E.smethod_6<string>(1790955292U);
    this.checkBox_100.UseVisualStyleBackColor = true;
    this.groupBox_53.Location = new Point(165, 34);
    this.groupBox_53.Name = \u003CModule\u003E.smethod_6<string>(4275733840U);
    this.groupBox_53.Size = new Size(671, 193);
    this.groupBox_53.TabIndex = 178;
    this.groupBox_53.TabStop = false;
    this.groupBox_53.Text = \u003CModule\u003E.smethod_7<string>(2109787791U);
    this.button_73.FlatStyle = FlatStyle.Flat;
    this.button_73.Image = (Image) Class9.Bitmap_12;
    this.button_73.ImageAlign = ContentAlignment.MiddleLeft;
    this.button_73.Location = new Point(619, 450);
    this.button_73.Name = \u003CModule\u003E.smethod_7<string>(769360042U);
    this.button_73.Size = new Size(217, 60);
    this.button_73.TabIndex = 177;
    this.button_73.Text = \u003CModule\u003E.smethod_8<string>(3813726870U);
    this.button_73.UseVisualStyleBackColor = true;
    this.button_73.Click += new EventHandler(this.button_73_Click);
    this.BackColor = Color.White;
    this.Controls.Add((Control) this.label_5);
    this.Controls.Add((Control) this.checkBox_0);
    this.Controls.Add((Control) this.menuStrip_0);
    this.Controls.Add((Control) this.tabControl_2);
    this.DoubleBuffered = true;
    this.Font = new Font(\u003CModule\u003E.smethod_6<string>(2348004861U), 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.ForeColor = Color.Black;
    this.Margin = new Padding(0);
    this.Name = \u003CModule\u003E.smethod_8<string>(2319882405U);
    this.Size = new Size(850, 568);
    this.Load += new EventHandler(this.Control2_Load);
    this.MouseEnter += new EventHandler(this.Control2_MouseEnter);
    this.menuStrip_0.ResumeLayout(false);
    this.menuStrip_0.PerformLayout();
    this.tabPage_1.ResumeLayout(false);
    this.groupBox_4.ResumeLayout(false);
    this.groupBox_4.PerformLayout();
    this.groupBox_3.ResumeLayout(false);
    this.groupBox_3.PerformLayout();
    this.groupBox_2.ResumeLayout(false);
    this.groupBox_2.PerformLayout();
    this.groupBox_1.ResumeLayout(false);
    this.numericUpDown_0.EndInit();
    this.groupBox_0.ResumeLayout(false);
    this.tabPage_0.ResumeLayout(false);
    this.tabPage_0.PerformLayout();
    this.panel_0.ResumeLayout(false);
    this.panel_1.ResumeLayout(false);
    this.panel_2.ResumeLayout(false);
    this.panel_3.ResumeLayout(false);
    this.toolStrip_0.ResumeLayout(false);
    this.toolStrip_0.PerformLayout();
    this.tabPage_2.ResumeLayout(false);
    this.groupBox_5.ResumeLayout(false);
    this.groupBox_5.PerformLayout();
    this.groupBox_6.ResumeLayout(false);
    this.groupBox_6.PerformLayout();
    this.tabPage_3.ResumeLayout(false);
    this.groupBox_47.ResumeLayout(false);
    this.groupBox_47.PerformLayout();
    this.groupBox_7.ResumeLayout(false);
    this.groupBox_7.PerformLayout();
    this.groupBox_8.ResumeLayout(false);
    this.groupBox_8.PerformLayout();
    this.groupBox_9.ResumeLayout(false);
    this.groupBox_9.PerformLayout();
    this.groupBox_10.ResumeLayout(false);
    this.groupBox_10.PerformLayout();
    this.tabPage_4.ResumeLayout(false);
    this.tabPage_4.PerformLayout();
    this.groupBox_12.ResumeLayout(false);
    this.groupBox_12.PerformLayout();
    this.tabPage_5.ResumeLayout(false);
    this.groupBox_48.ResumeLayout(false);
    this.groupBox_48.PerformLayout();
    this.groupBox_46.ResumeLayout(false);
    this.groupBox_46.PerformLayout();
    this.groupBox_45.ResumeLayout(false);
    this.groupBox_45.PerformLayout();
    this.groupBox_14.ResumeLayout(false);
    this.groupBox_15.ResumeLayout(false);
    this.groupBox_15.PerformLayout();
    this.groupBox_16.ResumeLayout(false);
    this.groupBox_16.PerformLayout();
    this.groupBox_17.ResumeLayout(false);
    this.groupBox_18.ResumeLayout(false);
    this.groupBox_18.PerformLayout();
    this.groupBox_19.ResumeLayout(false);
    this.groupBox_19.PerformLayout();
    this.groupBox_20.ResumeLayout(false);
    this.groupBox_20.PerformLayout();
    this.groupBox_21.ResumeLayout(false);
    this.groupBox_21.PerformLayout();
    this.numericUpDown_1.EndInit();
    this.numericUpDown_2.EndInit();
    this.numericUpDown_3.EndInit();
    this.tabPage_6.ResumeLayout(false);
    this.groupBox_22.ResumeLayout(false);
    this.groupBox_22.PerformLayout();
    this.groupBox_23.ResumeLayout(false);
    this.groupBox_23.PerformLayout();
    this.numericUpDown_4.EndInit();
    this.numericUpDown_5.EndInit();
    this.numericUpDown_6.EndInit();
    this.numericUpDown_7.EndInit();
    this.numericUpDown_8.EndInit();
    this.numericUpDown_9.EndInit();
    this.numericUpDown_10.EndInit();
    this.numericUpDown_11.EndInit();
    this.numericUpDown_12.EndInit();
    this.numericUpDown_13.EndInit();
    this.numericUpDown_14.EndInit();
    this.numericUpDown_15.EndInit();
    this.numericUpDown_16.EndInit();
    this.numericUpDown_17.EndInit();
    this.groupBox_24.ResumeLayout(false);
    this.groupBox_24.PerformLayout();
    this.groupBox_25.ResumeLayout(false);
    this.groupBox_25.PerformLayout();
    this.numericUpDown_18.EndInit();
    this.groupBox_26.ResumeLayout(false);
    this.groupBox_26.PerformLayout();
    this.groupBox_27.ResumeLayout(false);
    this.groupBox_27.PerformLayout();
    this.tabPage_7.ResumeLayout(false);
    this.tabControl_0.ResumeLayout(false);
    this.tabPage_8.ResumeLayout(false);
    this.tabPage_9.ResumeLayout(false);
    this.tabControl_1.ResumeLayout(false);
    this.tabPage_10.ResumeLayout(false);
    this.groupBox_44.ResumeLayout(false);
    this.groupBox_44.PerformLayout();
    this.groupBox_28.ResumeLayout(false);
    this.groupBox_28.PerformLayout();
    this.numericUpDown_19.EndInit();
    this.groupBox_29.ResumeLayout(false);
    this.groupBox_29.PerformLayout();
    this.groupBox_30.ResumeLayout(false);
    this.groupBox_30.PerformLayout();
    this.groupBox_31.ResumeLayout(false);
    this.groupBox_31.PerformLayout();
    this.groupBox_32.ResumeLayout(false);
    this.groupBox_32.PerformLayout();
    this.trackBar_0.EndInit();
    this.numericUpDown_20.EndInit();
    this.groupBox_33.ResumeLayout(false);
    this.groupBox_33.PerformLayout();
    this.groupBox_34.ResumeLayout(false);
    this.groupBox_34.PerformLayout();
    this.groupBox_35.ResumeLayout(false);
    this.groupBox_35.PerformLayout();
    this.groupBox_36.ResumeLayout(false);
    this.groupBox_36.PerformLayout();
    this.numericUpDown_21.EndInit();
    this.numericUpDown_22.EndInit();
    this.groupBox_37.ResumeLayout(false);
    this.groupBox_37.PerformLayout();
    this.tabPage_11.ResumeLayout(false);
    this.tabPage_12.ResumeLayout(false);
    this.tabPage_12.PerformLayout();
    this.groupBox_38.ResumeLayout(false);
    this.groupBox_39.ResumeLayout(false);
    this.groupBox_40.ResumeLayout(false);
    this.groupBox_41.ResumeLayout(false);
    this.groupBox_42.ResumeLayout(false);
    this.groupBox_42.PerformLayout();
    this.groupBox_43.ResumeLayout(false);
    this.groupBox_43.PerformLayout();
    this.tabControl_2.ResumeLayout(false);
    this.tabPage_13.ResumeLayout(false);
    this.tabPage_13.PerformLayout();
    this.groupBox_54.ResumeLayout(false);
    this.groupBox_54.PerformLayout();
    this.groupBox_49.ResumeLayout(false);
    this.groupBox_49.PerformLayout();
    this.groupBox_50.ResumeLayout(false);
    this.groupBox_50.PerformLayout();
    this.numericUpDown_23.EndInit();
    this.groupBox_51.ResumeLayout(false);
    this.groupBox_51.PerformLayout();
    this.numericUpDown_24.EndInit();
    this.groupBox_52.ResumeLayout(false);
    this.groupBox_52.PerformLayout();
    this.ResumeLayout(false);
    this.PerformLayout();
  }

  void ContainerControl.Dispose([In] bool obj0)
  {
    if (obj0 && this.icontainer_0 != null)
      this.icontainer_0.Dispose();
    // ISSUE: explicit non-virtual call
    __nonvirtual (((ContainerControl) this).Dispose(obj0));
  }

  private void Control2_Load(object sender, EventArgs e)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Control2.Class44 class44 = new Control2.Class44();
    // ISSUE: reference to a compiler-generated field
    class44.control2_0 = this;
    // ISSUE: reference to a compiler-generated field
    class44.object_0 = sender;
    // ISSUE: reference to a compiler-generated field
    class44.eventArgs_0 = e;
    if (this.class29_0.Class112_0.form5_0.class178_0 == null)
      this.class29_0.Class72_0 = (Class72) null;
    if (this.InvokeRequired)
    {
      // ISSUE: reference to a compiler-generated method
      this.Invoke((Delegate) new Action(class44.method_0));
    }
    else
    {
      // ISSUE: reference to a compiler-generated method
      ThreadPool.QueueUserWorkItem(new WaitCallback(class44.method_1));
      this.class29_0.timer_0.Start();
      this.form3_0.DesktopLocation = this.Location;
      if (this.class29_0.Class112_0.dictionary_5.ContainsKey(this.class29_0.String_0) && this.class29_0.Class112_0.dictionary_7.ContainsKey(this.class29_0.String_0))
      {
        this.comboBox_4.Text = this.class29_0.Class112_0.dictionary_5[this.class29_0.String_0];
        this.trackBar_0.Value = this.class29_0.Class112_0.dictionary_7[this.class29_0.String_0];
        this.trackBar_0_Scroll((object) this.class29_0.Control2_0.trackBar_0, new EventArgs());
        this.button_45.Text = \u003CModule\u003E.smethod_5<string>(3838461908U);
        this.toolStripMenuItem_2_Click(new object(), new EventArgs());
        this.class29_0.Class112_0.dictionary_5.Remove(this.class29_0.String_0);
        this.class29_0.Class112_0.dictionary_7.Remove(this.class29_0.String_0);
      }
      else if (this.class29_0.Class112_0.dictionary_6.ContainsKey(this.class29_0.String_0) && this.class29_0.Class112_0.dictionary_7.ContainsKey(this.class29_0.String_0))
      {
        if (this.class29_0.Class112_0.dictionary_6[this.class29_0.String_0] == \u003CModule\u003E.smethod_8<string>(3399808809U))
        {
          this.button_17.Text = \u003CModule\u003E.smethod_5<string>(3530897020U);
        }
        else
        {
          this.textBox_17.Text = this.class29_0.Class112_0.dictionary_6[this.class29_0.String_0];
          this.checkBox_68.Checked = true;
        }
        this.trackBar_0.Value = this.class29_0.Class112_0.dictionary_7[this.class29_0.String_0];
        this.trackBar_0_Scroll((object) this.class29_0.Control2_0.trackBar_0, new EventArgs());
        this.toolStripMenuItem_2_Click(new object(), new EventArgs());
        this.class29_0.Class112_0.dictionary_6.Remove(this.class29_0.String_0);
        this.class29_0.Class112_0.dictionary_7.Remove(this.class29_0.String_0);
      }
      if (!Directory.Exists(this.string_1))
        Directory.CreateDirectory(this.string_1);
      if (Directory.Exists(this.string_2))
        return;
      Directory.CreateDirectory(this.string_2);
    }
  }

  internal void method_1()
  {
    string path = AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_9<string>(3619940547U) + this.class29_0.String_0.ToLower();
    if (!Directory.Exists(path))
    {
      Directory.CreateDirectory(path);
    }
    else
    {
      try
      {
        File.WriteAllLines(path + \u003CModule\u003E.smethod_9<string>(2933499623U), this.class29_0.Class21_0.Select<Class76, string>((Func<Class76, string>) (obj0 => obj0.String_0)));
      }
      catch
      {
      }
    }
    if (this.string_1 == null)
      Thread.Sleep(1000);
    foreach (string str in ((IEnumerable<string>) Directory.GetFiles(this.string_1, \u003CModule\u003E.smethod_5<string>(1205104008U))).Select<string, string>(new Func<string, string>(Path.GetFileNameWithoutExtension)))
    {
      List<string> list1 = this.list_1;
      // ISSUE: explicit non-virtual call
      if ((list1 != null ? (!__nonvirtual (list1.Contains(str)) ? 1 : 0) : 0) != 0)
        this.list_1.Add(str);
    }
    foreach (string str in ((IEnumerable<string>) Directory.GetFiles(this.string_2)).Select<string, string>(new Func<string, string>(Path.GetFileName)))
    {
      BindingList<string> bindingList0 = this.bindingList_0;
      // ISSUE: explicit non-virtual call
      if ((bindingList0 != null ? (!__nonvirtual (bindingList0.Contains(str)) ? 1 : 0) : 0) != 0)
        this.method_8(this.bindingList_0, this.form3_0.listBox_1, str);
    }
  }

  private void checkBox_0_CheckedChanged(object string_4, [In] EventArgs obj1)
  {
    if ((string_4 as CheckBox).Checked)
    {
      this.tabControl_2.TabPages.Add(this.tabPage_1);
      this.tabControl_2.TabPages.Add(this.tabPage_0);
    }
    else
    {
      this.tabControl_2.TabPages.Remove(this.tabPage_1);
      this.tabControl_2.TabPages.Remove(this.tabPage_0);
    }
  }

  internal void method_2()
  {
    if (!(this.toolStripMenuItem_2.Text == \u003CModule\u003E.smethod_8<string>(4223022852U)))
      return;
    this.class29_0.Class25_0.method_1();
  }

  internal void toolStripMenuItem_2_Click(object string_4, [In] EventArgs obj1)
  {
    if (this.toolStripMenuItem_2.Text == \u003CModule\u003E.smethod_8<string>(50828738U))
    {
      this.toolStripMenuItem_2.Text = \u003CModule\u003E.smethod_5<string>(3838461908U);
      if (this.class29_0.Class25_0 != this.class29_0.Class26_0)
      {
        this.class29_0.Class25_0 = (Class25) this.class29_0.Class26_0;
        this.class29_0.Class25_0.Class29_0 = this.class29_0;
        this.class29_0.Class25_0.Class112_0 = this.class29_0.Class112_0;
        this.class29_0.Int32_1 = 0;
      }
      this.class29_0.Class25_0.method_0();
      if (this.class29_0.Control2_0.checkBox_21.Checked)
        return;
      this.class29_0.method_75((byte) 1, \u003CModule\u003E.smethod_7<string>(1155014075U));
    }
    else
    {
      if (!(this.toolStripMenuItem_2.Text == \u003CModule\u003E.smethod_9<string>(591721198U)))
        return;
      this.toolStripMenuItem_2.Text = \u003CModule\u003E.smethod_5<string>(2903372482U);
      this.class29_0.Class25_0.method_1();
      if (!this.class29_0.Control2_0.checkBox_21.Checked)
        this.class29_0.method_75((byte) 1, \u003CModule\u003E.smethod_8<string>(665560281U));
      this.class29_0.Boolean_4 = false;
      this.class29_0.Boolean_3 = false;
      this.class29_0.Class26_0.bool_6 = false;
      this.class29_0.Class26_0.bool_7 = false;
      this.class29_0.bool_37 = false;
    }
  }

  private void method_3()
  {
    bool flag1 = this.checkBox_20.Checked;
    bool flag2 = this.checkBox_19.Checked;
    foreach (Control control1 in (ArrangedElementCollection) this.Controls)
    {
      if (control1 is CheckBox)
        (control1 as CheckBox).Checked = false;
      if (control1 is ComboBox)
        (control1 as ComboBox).Text = (control1 as ComboBox).Items[0].ToString();
      if (control1.Controls != null)
      {
        foreach (Control control2 in (ArrangedElementCollection) control1.Controls)
        {
          if (control2 is CheckBox)
            (control2 as CheckBox).Checked = false;
          if (control2 is ComboBox)
            (control2 as ComboBox).Text = (control1 as ComboBox).Items[0].ToString();
          if (control2.Controls != null)
          {
            foreach (Control control3 in (ArrangedElementCollection) control2.Controls)
            {
              if (control3 is CheckBox)
                (control3 as CheckBox).Checked = false;
              if (control3 is ComboBox)
                (control3 as ComboBox).Text = (control3 as ComboBox).Items[0].ToString();
              if (control3.Controls != null)
              {
                foreach (Control control4 in (ArrangedElementCollection) control3.Controls)
                {
                  if (control4 is CheckBox)
                    (control4 as CheckBox).Checked = false;
                  if (control4 is ComboBox)
                    (control4 as ComboBox).Text = (control4 as ComboBox).Items[0].ToString();
                  if (control4.Controls != null)
                  {
                    foreach (Control control5 in (ArrangedElementCollection) control4.Controls)
                    {
                      if (control5 is CheckBox)
                        (control5 as CheckBox).Checked = false;
                      if (control5 is ComboBox)
                        (control5 as ComboBox).Text = (control5 as ComboBox).Items[0].ToString();
                      if (control4.Controls != null)
                      {
                        foreach (Control control6 in (ArrangedElementCollection) control5.Controls)
                        {
                          if (control6 is CheckBox)
                            (control6 as CheckBox).Checked = false;
                          if (control6 is ComboBox)
                            (control6 as ComboBox).Text = (control6 as ComboBox).Items[0].ToString();
                          if (control6.Controls != null)
                          {
                            foreach (Control control7 in (ArrangedElementCollection) control6.Controls)
                            {
                              if (control7 is CheckBox)
                                (control7 as CheckBox).Checked = false;
                              if (control7 is ComboBox)
                                (control7 as ComboBox).Text = (control7 as ComboBox).Items[0].ToString();
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    this.checkBox_20.Checked = flag1;
    this.checkBox_19.Checked = flag2;
    this.checkBox_67.Checked = true;
    this.comboBox_2.Text = \u003CModule\u003E.smethod_9<string>(325326214U);
    this.checkBox_73.Checked = true;
    this.checkBox_33.Checked = true;
    this.checkBox_34.Checked = true;
    this.checkBox_37.Checked = true;
    this.listBox_5.DataSource = (object) null;
    BindingList<string> bindingList = new BindingList<string>();
    bindingList.Add(\u003CModule\u003E.smethod_7<string>(283851433U));
    bindingList.Add(\u003CModule\u003E.smethod_8<string>(930166680U));
    bindingList.Add(\u003CModule\u003E.smethod_5<string>(2735782316U));
    bindingList.Add(\u003CModule\u003E.smethod_7<string>(3266383476U));
    bindingList.Add(\u003CModule\u003E.smethod_9<string>(3057675918U));
    bindingList.Add(\u003CModule\u003E.smethod_7<string>(1378587629U));
    bindingList.Add(\u003CModule\u003E.smethod_5<string>(1816418447U));
    bindingList.Add(\u003CModule\u003E.smethod_7<string>(3680030005U));
    bindingList.Add(\u003CModule\u003E.smethod_5<string>(3828449190U));
    bindingList.Add(\u003CModule\u003E.smethod_9<string>(3586641174U));
    bindingList.Add(\u003CModule\u003E.smethod_6<string>(975641883U));
    bindingList.Add(\u003CModule\u003E.smethod_5<string>(793738934U));
    bindingList.Add(\u003CModule\u003E.smethod_8<string>(289571717U));
    bindingList.Add(\u003CModule\u003E.smethod_5<string>(1391730193U));
    bindingList.Add(\u003CModule\u003E.smethod_8<string>(716196468U));
    bindingList.Add(\u003CModule\u003E.smethod_9<string>(2420026953U));
    bindingList.Add(\u003CModule\u003E.smethod_9<string>(2978938084U));
    bindingList.Add(\u003CModule\u003E.smethod_5<string>(1925446930U));
    bindingList.Add(\u003CModule\u003E.smethod_9<string>(1478526443U));
    bindingList.Add(\u003CModule\u003E.smethod_5<string>(1070357583U));
    bindingList.Add(\u003CModule\u003E.smethod_9<string>(3980330344U));
    bindingList.Add(\u003CModule\u003E.smethod_7<string>(1456324206U));
    bindingList.Add(\u003CModule\u003E.smethod_6<string>(2314242456U));
    bindingList.Add(\u003CModule\u003E.smethod_9<string>(303362239U));
    bindingList.Add(\u003CModule\u003E.smethod_7<string>(2523067906U));
    bindingList.Add(\u003CModule\u003E.smethod_7<string>(3589811606U));
    this.bindingList_3 = bindingList;
    this.listBox_5.DataSource = (object) this.bindingList_3;
    this.listBox_4.Items.Clear();
    this.numericUpDown_18.Value = 1M;
    this.numericUpDown_20.Value = 1M;
    this.numericUpDown_22.Value = 80M;
    this.numericUpDown_21.Value = 80M;
    this.textBox_16.Text = \u003CModule\u003E.smethod_6<string>(4210661549U);
    this.button_45.Text = \u003CModule\u003E.smethod_8<string>(233672838U);
    this.textBox_6.Clear();
    this.textBox_5.Clear();
    this.textBox_4.Clear();
    this.textBox_3.Clear();
    foreach (TabPage tabPage in this.tabControl_1.TabPages)
    {
      if (tabPage != this.tabPage_10 && tabPage.Controls.OfType<Control3>().Count<Control3>() > 0)
        tabPage.Controls.OfType<Control3>().First<Control3>().button_0_Click(new object(), new EventArgs());
    }
    foreach (TabPage tabPage in this.tabControl_0.TabPages)
    {
      if (tabPage != this.tabPage_8 && tabPage.Controls.OfType<Control4>().Count<Control4>() > 0)
        tabPage.Controls.OfType<Control4>().First<Control4>().button_0_Click(new object(), new EventArgs());
    }
  }

  private void toolStripMenuItem_1_Click([In] object obj0, EventArgs e) => this.method_3();

  private void toolStripMenuItem_0_MouseEnter([In] object obj0, EventArgs e)
  {
    while (this.toolStripMenuItem_0.DropDownItems.Count > 0)
      this.toolStripMenuItem_0.DropDownItems[0].Dispose();
    foreach (string str in this.list_1)
      this.toolStripMenuItem_0.DropDownItems.Add((ToolStripItem) new ToolStripMenuItem(str, (Image) null, new EventHandler(this.method_4), str));
    this.toolStripMenuItem_0.DropDownClosed += new EventHandler(this.toolStripMenuItem_11_DropDownClosed);
  }

  private void method_4([In] object obj0, EventArgs e) => this.method_11((obj0 as ToolStripMenuItem).Text);

  private void toolStripMenuItem_4_MouseEnter([In] object obj0, EventArgs e)
  {
    while (this.toolStripMenuItem_4.DropDownItems.Count > 0)
      this.toolStripMenuItem_4.DropDownItems[0].Dispose();
    this.toolStripMenuItem_4.DropDown.Items.Add((ToolStripItem) new ToolStripMenuItem(\u003CModule\u003E.smethod_9<string>(187735927U), (Image) null, new EventHandler(this.method_5)));
    foreach (string text in this.comboBox_4.Items)
      this.toolStripMenuItem_4.DropDown.Items.Add((ToolStripItem) new ToolStripMenuItem(text, (Image) null, new EventHandler(this.method_6)));
    this.toolStripMenuItem_4.DropDownClosed += new EventHandler(this.toolStripMenuItem_11_DropDownClosed);
  }

  private void method_5([In] object obj0, EventArgs e) => this.button_45.Text = \u003CModule\u003E.smethod_5<string>(3787510566U);

  private void method_6([In] object obj0, EventArgs e)
  {
    this.comboBox_4.Text = (obj0 as ToolStripMenuItem).Text;
    this.button_45.Text = \u003CModule\u003E.smethod_8<string>(4223022852U);
  }

  private void toolStripMenuItem_3_MouseEnter([In] object obj0, EventArgs e)
  {
    while (this.toolStripMenuItem_3.DropDownItems.Count > 0)
      this.toolStripMenuItem_3.DropDownItems[0].Dispose();
    this.toolStripMenuItem_3.DropDown.Items.Add((ToolStripItem) new ToolStripMenuItem(\u003CModule\u003E.smethod_8<string>(2452955951U), (Image) null, new EventHandler(this.method_43)));
    foreach (string text in (Collection<string>) this.bindingList_0)
      this.toolStripMenuItem_3.DropDown.Items.Add((ToolStripItem) new ToolStripMenuItem(text, (Image) null, new EventHandler(this.method_7)));
    this.toolStripMenuItem_3.DropDownClosed += new EventHandler(this.toolStripMenuItem_11_DropDownClosed);
  }

  private void method_7([In] object obj0, EventArgs e)
  {
    this.form3_0.listBox_1.SelectedIndex = this.bindingList_0.IndexOf((obj0 as ToolStripMenuItem).Text);
    this.form3_0.button_4_Click(new object(), new EventArgs());
  }

  internal void toolStripMenuItem_11_DropDownClosed([In] object obj0, EventArgs e) => (obj0 as ToolStripDropDownItem).DropDown.Close();

  internal void method_8([In] BindingList<string> obj0, ListBox e, [In] string obj2)
  {
    if (string.IsNullOrEmpty(obj2) || e == null)
      return;
    if (obj0.Count != 0)
    {
      obj0.Add(obj2);
    }
    else
    {
      e.DataSource = (object) null;
      obj0.Add(obj2);
      e.DataSource = (object) obj0;
    }
  }

  private void tabControl_0_SelectedIndexChanged(object sender, EventArgs e)
  {
    if ((sender as TabControl).SelectedTab != this.tabPage_8)
      return;
    this.class29_0.method_105(false);
  }

  private void tabControl_1_SelectedIndexChanged(object sender, EventArgs e)
  {
    if ((sender as TabControl).SelectedTab != this.tabPage_11)
      return;
    this.class29_0.method_105(false);
  }

  private void tabControl_1_ControlAdded(object sender, ControlEventArgs e)
  {
    TabControl tabControl = sender as TabControl;
    tabControl.ControlAdded -= new ControlEventHandler(this.tabControl_1_ControlAdded);
    tabControl.TabPages.Remove(this.tabPage_11);
    tabControl.TabPages.Add(this.tabPage_11);
    tabControl.ControlAdded += new ControlEventHandler(this.tabControl_1_ControlAdded);
  }

  internal void method_9()
  {
    foreach (string str in this.class29_0.HashSet_3)
    {
      if (this.class29_0.Class26_0.control3_1 == null || this.class29_0.Class112_0.method_75(str) == null)
      {
        if (this.class29_0.Class26_0.method_44(str))
        {
          if (this.tabControl_1.TabPages.ContainsKey(str))
            this.tabControl_1.TabPages[str].Dispose();
          this.class29_0.Class26_0.method_43(str);
        }
        this.class29_0.Class26_0.method_42(new Class145(str)
        {
          Control3_0 = this.class29_0.Class26_0.control3_0
        });
      }
    }
  }

  private void checkBox_23_CheckedChanged(object sender, EventArgs e) => this.class29_0.Boolean_12 = this.checkBox_23.Checked;

  internal void button_40_Click(object string_4, [In] EventArgs obj1)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Control2.Class46 class46_1 = new Control2.Class46();
    // ISSUE: reference to a compiler-generated field
    class46_1.control2_0 = this;
    string str = this.textBox_13.Text + \u003CModule\u003E.smethod_7<string>(1624095975U) + this.comboBox_2.Text;
    // ISSUE: variable of a compiler-generated type
    Control2.Class46 class46_2 = class46_1;
    List<Class24> list4 = this.class29_0.list_4;
    // ISSUE: reference to a compiler-generated method
    Class24 class24 = new Class24(list4 != null ? list4.FirstOrDefault<Class24>(new Func<Class24, bool>(class46_1.method_0)) : (Class24) null);
    // ISSUE: reference to a compiler-generated field
    class46_2.class24_0 = class24;
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    if (class46_1.class24_0 == null || class46_1.class24_0 == new Class24())
      return;
    // ISSUE: reference to a compiler-generated field
    class46_1.class24_0.String_0 = this.textBox_13.Text;
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated method
    foreach (Class76 class76 in this.class29_0.Class21_0.Where<Class76>(class46_1.func_0 ?? (class46_1.func_0 = new Func<Class76, bool>(class46_1.method_1))))
    {
      class76.Boolean_0 = true;
      // ISSUE: reference to a compiler-generated field
      class76.Class24_0 = class46_1.class24_0;
    }
    this.textBox_13.Clear();
    // ISSUE: reference to a compiler-generated field
    if (!this.class29_0.list_4.Contains(class46_1.class24_0))
    {
      // ISSUE: reference to a compiler-generated field
      this.class29_0.list_4.Add(class46_1.class24_0);
    }
    if (this.listBox_3.Items.Contains((object) str))
      return;
    this.listBox_3.Items.Add((object) str);
    if (this.bool_0)
      return;
    string path = Settings.Default.DarkAgesPath.Replace(\u003CModule\u003E.smethod_6<string>(975385566U), this.class29_0.String_0 + \u003CModule\u003E.smethod_9<string>(3440265297U));
    List<string> list = this.listBox_3.Items.OfType<string>().ToList<string>();
    if (!Directory.Exists(path))
      Directory.CreateDirectory(path);
    File.WriteAllLines(path + \u003CModule\u003E.smethod_7<string>(1730374669U), (IEnumerable<string>) list);
  }

  private void button_39_Click(object sender, EventArgs e)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Control2.Class47 class47_1 = new Control2.Class47();
    // ISSUE: variable of a compiler-generated type
    Control2.Class47 class47_2 = class47_1;
    object selectedItem = this.listBox_3.SelectedItem;
    List<string> stringList;
    if (selectedItem == null)
      stringList = (List<string>) null;
    else
      stringList = ((IEnumerable<string>) selectedItem.ToString().Split(new string[1]
      {
        \u003CModule\u003E.smethod_6<string>(3947321793U)
      }, StringSplitOptions.None)).ToList<string>();
    // ISSUE: reference to a compiler-generated field
    class47_2.list_0 = stringList;
    // ISSUE: reference to a compiler-generated field
    if (class47_1.list_0 == null)
      return;
    // ISSUE: reference to a compiler-generated method
    if (this.class29_0.list_4.Any<Class24>(new Func<Class24, bool>(class47_1.method_0)))
    {
      // ISSUE: reference to a compiler-generated method
      this.class29_0.list_4.Remove(this.class29_0.list_4.First<Class24>(new Func<Class24, bool>(class47_1.method_1)));
    }
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated method
    using (IEnumerator<Class76> enumerator = this.class29_0.Class21_0.Where<Class76>(class47_1.func_0 ?? (class47_1.func_0 = new Func<Class76, bool>(class47_1.method_2))).GetEnumerator())
    {
      if (enumerator.MoveNext())
      {
        Class76 current = enumerator.Current;
        current.Boolean_0 = false;
        current.Class24_0 = (Class24) null;
      }
    }
    this.listBox_3.Items.Remove(this.listBox_3.SelectedItem);
    string path = Settings.Default.DarkAgesPath.Replace(\u003CModule\u003E.smethod_6<string>(975385566U), this.class29_0.String_0 + \u003CModule\u003E.smethod_6<string>(3921429579U));
    List<string> list = this.listBox_3.Items.OfType<string>().ToList<string>();
    if (!Directory.Exists(path))
      Directory.CreateDirectory(path);
    File.WriteAllLines(path + \u003CModule\u003E.smethod_9<string>(442795513U), (IEnumerable<string>) list);
  }

  private void checkBox_34_CheckedChanged(object sender, EventArgs e)
  {
    if (this.checkBox_34.Checked)
      this.class29_0.method_18(Enum0.NoBlind);
    else
      this.class29_0.method_18(Enum0.NoBlind);
    this.class29_0.method_20(Enum9.Secondary);
  }

  private void checkBox_33_CheckedChanged(object sender, EventArgs e)
  {
    if (this.class29_0.Class26_0.bool_16)
      return;
    if (this.checkBox_33.Checked)
      this.class29_0.method_18(Enum0.SeeHidden);
    else
      this.class29_0.method_19(Enum0.SeeHidden);
    foreach (Class143 class143 in this.class29_0.method_125())
      this.class29_0.method_66(class143);
  }

  private void checkBox_32_CheckedChanged(object sender, EventArgs e)
  {
    if (this.checkBox_32.Checked)
      this.class29_0.method_18(Enum0.ZoomableMap);
    else
      this.class29_0.method_19(Enum0.ZoomableMap);
    this.class29_0.method_65();
  }

  private void checkBox_31_CheckedChanged(object string_4, EventArgs image_0 = null)
  {
    byte[] numArray = new byte[5];
    Class77.smethod_0(Process.GetProcessById(this.class29_0.int_4), this.class29_0.int_0, numArray);
    if ((int) numArray[0] == (int) this.class29_0.byte_1[0])
      Class77.smethod_1(Process.GetProcessById(this.class29_0.int_4), this.class29_0.int_0, this.class29_0.byte_0);
    else
      Class77.smethod_1(Process.GetProcessById(this.class29_0.int_4), this.class29_0.int_0, this.class29_0.byte_1);
    this.class29_0.method_105(true);
  }

  private void checkBox_30_CheckedChanged(object ushort_0, [In] EventArgs obj1)
  {
    if (this.checkBox_30.Checked)
      this.class29_0.method_18(Enum0.GmMode);
    else
      this.class29_0.method_19(Enum0.GmMode);
    this.class29_0.method_20(Enum9.None);
  }

  private void checkBox_29_CheckedChanged([In] object obj0, EventArgs string_4)
  {
    if (this.checkBox_29.Checked)
    {
      this.class29_0.method_18(Enum0.SeeGhosts);
      foreach (Class143 byte_9 in this.class29_0.Dictionary_2.Values)
        this.class29_0.method_67(byte_9);
    }
    else
    {
      this.class29_0.method_19(Enum0.SeeGhosts);
      foreach (Class139 class139 in this.class29_0.Dictionary_2.Values)
        this.class29_0.method_71(class139.Int32_0);
    }
  }

  private void checkBox_28_CheckedChanged(object sender, EventArgs e)
  {
    this.class29_0.Boolean_8 = this.checkBox_28.Checked;
    this.checkBox_25.Enabled = this.checkBox_28.Checked;
    this.checkBox_27.Enabled = this.checkBox_28.Checked;
    this.checkBox_26.Enabled = this.checkBox_28.Checked;
    this.class29_0.method_105(true);
  }

  private void checkBox_25_CheckedChanged(object sender, EventArgs e)
  {
    if (this.checkBox_25.Checked)
      this.class29_0.method_15(Enum5.Snow);
    else
      this.class29_0.method_16(Enum5.Snow);
    this.class29_0.method_105(true);
  }

  private void checkBox_27_CheckedChanged(object class88_0, [In] EventArgs obj1)
  {
    if (this.checkBox_27.Checked)
      this.class29_0.method_15(Enum5.NoTabMap);
    else
      this.class29_0.method_16(Enum5.NoTabMap);
    this.class29_0.method_105(true);
  }

  private void checkBox_26_CheckedChanged(object sender, EventArgs e)
  {
    if (this.checkBox_26.Checked)
      this.class29_0.method_15(Enum5.SnowTileset);
    else
      this.class29_0.method_16(Enum5.SnowTileset);
    this.class29_0.method_105(true);
  }

  private void checkBox_24_CheckedChanged(object sender, EventArgs e)
  {
    if (this.checkBox_24.Checked)
      this.class29_0.method_15(Enum5.Darkness);
    else
      this.class29_0.method_16(Enum5.Darkness);
    this.class29_0.method_105(true);
  }

  private void button_38_Click(object sender, EventArgs e)
  {
    string path = Settings.Default.DarkAgesPath.Replace(\u003CModule\u003E.smethod_5<string>(197665510U), this.class29_0.String_0 + \u003CModule\u003E.smethod_7<string>(3512075029U));
    List<string> contents = new List<string>();
    foreach (NumericUpDown numericUpDown in this.groupBox_23.Controls.OfType<NumericUpDown>())
      contents.Add(numericUpDown.Value.ToString());
    contents.Add(this.checkBox_19.Checked.ToString());
    contents.Add(this.checkBox_20.Checked.ToString());
    if (!Directory.Exists(path))
      Directory.CreateDirectory(path);
    File.WriteAllLines(path + \u003CModule\u003E.smethod_9<string>(4051321885U), (IEnumerable<string>) contents);
  }

  private void checkBox_19_CheckedChanged(object sender, EventArgs e) => this.class29_0.method_66(this.class29_0.Class143_0);

  private void method_10(string sender)
  {
    if (string.IsNullOrEmpty(sender))
      return;
    if (Regex.Match(sender, \u003CModule\u003E.smethod_9<string>(4257589512U)).Success)
    {
      int num1 = (int) Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_9<string>(1335504064U), (IWin32Window) null, true);
    }
    else
    {
      string path = Settings.Default.DarkAgesPath.Replace(\u003CModule\u003E.smethod_6<string>(975385566U), this.class29_0.String_0 + \u003CModule\u003E.smethod_5<string>(3597069044U));
      if (!Directory.Exists(path))
        Directory.CreateDirectory(path);
      FileStream output = File.Create(path + sender + \u003CModule\u003E.smethod_5<string>(690907832U));
      XmlWriterSettings settings = new XmlWriterSettings()
      {
        Indent = true,
        NewLineOnAttributes = true
      };
      using (XmlWriter xmlWriter1 = XmlWriter.Create((Stream) output, settings))
      {
        xmlWriter1.WriteStartDocument();
        xmlWriter1.WriteStartElement(\u003CModule\u003E.smethod_8<string>(3119639354U));
        foreach (string line in this.textBox_6.Lines)
          xmlWriter1.WriteElementString(this.textBox_6.Name, line);
        foreach (string line in this.textBox_5.Lines)
          xmlWriter1.WriteElementString(this.textBox_5.Name, line);
        foreach (string line in this.textBox_4.Lines)
          xmlWriter1.WriteElementString(this.textBox_4.Name, line);
        foreach (string line in this.textBox_3.Lines)
          xmlWriter1.WriteElementString(this.textBox_3.Name, line);
        xmlWriter1.WriteElementString(this.button_13.Name, this.button_13.Text);
        xmlWriter1.WriteElementString(this.button_12.Name, this.button_12.Text);
        xmlWriter1.WriteElementString(this.button_11.Name, this.button_11.Text);
        xmlWriter1.WriteElementString(this.button_10.Name, this.button_10.Text);
        xmlWriter1.WriteElementString(this.checkBox_7.Name, this.checkBox_7.Checked.ToString());
        xmlWriter1.WriteElementString(this.checkBox_6.Name, this.checkBox_6.Checked.ToString());
        xmlWriter1.WriteElementString(this.checkBox_5.Name, this.checkBox_5.Checked.ToString());
        xmlWriter1.WriteElementString(this.checkBox_4.Name, this.checkBox_4.Checked.ToString());
        xmlWriter1.WriteElementString(this.comboBox_11.Name, this.comboBox_11.Text);
        xmlWriter1.WriteElementString(this.checkBox_87.Name, this.checkBox_87.Checked.ToString());
        xmlWriter1.WriteElementString(this.comboBox_10.Name, this.comboBox_10.Text);
        xmlWriter1.WriteElementString(this.checkBox_86.Name, this.checkBox_86.Checked.ToString());
        XmlWriter xmlWriter2 = xmlWriter1;
        string name1 = this.checkBox_73.Name;
        bool flag1 = this.checkBox_73.Checked;
        string str1 = flag1.ToString();
        xmlWriter2.WriteElementString(name1, str1);
        XmlWriter xmlWriter3 = xmlWriter1;
        string name2 = this.checkBox_72.Name;
        flag1 = this.checkBox_72.Checked;
        string str2 = flag1.ToString();
        xmlWriter3.WriteElementString(name2, str2);
        XmlWriter xmlWriter4 = xmlWriter1;
        string name3 = this.checkBox_22.Name;
        flag1 = this.checkBox_22.Checked;
        string str3 = flag1.ToString();
        xmlWriter4.WriteElementString(name3, str3);
        xmlWriter1.WriteElementString(this.numericUpDown_18.Name, this.numericUpDown_18.Value.ToString());
        XmlWriter xmlWriter5 = xmlWriter1;
        string name4 = this.checkBox_71.Name;
        flag1 = this.checkBox_71.Checked;
        string str4 = flag1.ToString();
        xmlWriter5.WriteElementString(name4, str4);
        XmlWriter xmlWriter6 = xmlWriter1;
        string name5 = this.checkBox_70.Name;
        flag1 = this.checkBox_70.Checked;
        string str5 = flag1.ToString();
        xmlWriter6.WriteElementString(name5, str5);
        XmlWriter xmlWriter7 = xmlWriter1;
        string name6 = this.checkBox_83.Name;
        flag1 = this.checkBox_83.Checked;
        string str6 = flag1.ToString();
        xmlWriter7.WriteElementString(name6, str6);
        xmlWriter1.WriteElementString(this.comboBox_7.Name, this.comboBox_7.Text);
        xmlWriter1.WriteElementString(this.comboBox_6.Name, this.comboBox_6.Text);
        xmlWriter1.WriteElementString(this.numericUpDown_22.Name, this.numericUpDown_22.Value.ToString());
        XmlWriter xmlWriter8 = xmlWriter1;
        string name7 = this.checkBox_82.Name;
        flag1 = this.checkBox_82.Checked;
        string str7 = flag1.ToString();
        xmlWriter8.WriteElementString(name7, str7);
        xmlWriter1.WriteElementString(this.comboBox_5.Name, this.comboBox_5.Text);
        xmlWriter1.WriteElementString(this.numericUpDown_21.Name, this.numericUpDown_21.Value.ToString());
        XmlWriter xmlWriter9 = xmlWriter1;
        string name8 = this.checkBox_81.Name;
        flag1 = this.checkBox_81.Checked;
        string str8 = flag1.ToString();
        xmlWriter9.WriteElementString(name8, str8);
        XmlWriter xmlWriter10 = xmlWriter1;
        string name9 = this.checkBox_80.Name;
        flag1 = this.checkBox_80.Checked;
        string str9 = flag1.ToString();
        xmlWriter10.WriteElementString(name9, str9);
        XmlWriter xmlWriter11 = xmlWriter1;
        string name10 = this.checkBox_41.Name;
        flag1 = this.checkBox_41.Checked;
        string str10 = flag1.ToString();
        xmlWriter11.WriteElementString(name10, str10);
        XmlWriter xmlWriter12 = xmlWriter1;
        string name11 = this.checkBox_37.Name;
        flag1 = this.checkBox_37.Checked;
        string str11 = flag1.ToString();
        xmlWriter12.WriteElementString(name11, str11);
        XmlWriter xmlWriter13 = xmlWriter1;
        string name12 = this.checkBox_40.Name;
        flag1 = this.checkBox_40.Checked;
        string str12 = flag1.ToString();
        xmlWriter13.WriteElementString(name12, str12);
        XmlWriter xmlWriter14 = xmlWriter1;
        string name13 = this.checkBox_39.Name;
        flag1 = this.checkBox_39.Checked;
        string str13 = flag1.ToString();
        xmlWriter14.WriteElementString(name13, str13);
        XmlWriter xmlWriter15 = xmlWriter1;
        string name14 = this.checkBox_38.Name;
        flag1 = this.checkBox_38.Checked;
        string str14 = flag1.ToString();
        xmlWriter15.WriteElementString(name14, str14);
        XmlWriter xmlWriter16 = xmlWriter1;
        string name15 = this.checkBox_36.Name;
        flag1 = this.checkBox_36.Checked;
        string str15 = flag1.ToString();
        xmlWriter16.WriteElementString(name15, str15);
        XmlWriter xmlWriter17 = xmlWriter1;
        string name16 = this.checkBox_85.Name;
        flag1 = this.checkBox_85.Checked;
        string str16 = flag1.ToString();
        xmlWriter17.WriteElementString(name16, str16);
        xmlWriter1.WriteElementString(this.comboBox_9.Name, this.comboBox_9.Text);
        XmlWriter xmlWriter18 = xmlWriter1;
        string name17 = this.checkBox_84.Name;
        flag1 = this.checkBox_84.Checked;
        string str17 = flag1.ToString();
        xmlWriter18.WriteElementString(name17, str17);
        xmlWriter1.WriteElementString(this.comboBox_8.Name, this.comboBox_8.Text);
        XmlWriter xmlWriter19 = xmlWriter1;
        string name18 = this.checkBox_58.Name;
        flag1 = this.checkBox_58.Checked;
        string str18 = flag1.ToString();
        xmlWriter19.WriteElementString(name18, str18);
        XmlWriter xmlWriter20 = xmlWriter1;
        string name19 = this.checkBox_47.Name;
        flag1 = this.checkBox_47.Checked;
        string str19 = flag1.ToString();
        xmlWriter20.WriteElementString(name19, str19);
        XmlWriter xmlWriter21 = xmlWriter1;
        string name20 = this.checkBox_55.Name;
        flag1 = this.checkBox_55.Checked;
        string str20 = flag1.ToString();
        xmlWriter21.WriteElementString(name20, str20);
        XmlWriter xmlWriter22 = xmlWriter1;
        string name21 = this.checkBox_60.Name;
        flag1 = this.checkBox_60.Checked;
        string str21 = flag1.ToString();
        xmlWriter22.WriteElementString(name21, str21);
        XmlWriter xmlWriter23 = xmlWriter1;
        string name22 = this.checkBox_62.Name;
        flag1 = this.checkBox_62.Checked;
        string str22 = flag1.ToString();
        xmlWriter23.WriteElementString(name22, str22);
        XmlWriter xmlWriter24 = xmlWriter1;
        string name23 = this.checkBox_57.Name;
        flag1 = this.checkBox_57.Checked;
        string str23 = flag1.ToString();
        xmlWriter24.WriteElementString(name23, str23);
        XmlWriter xmlWriter25 = xmlWriter1;
        string name24 = this.checkBox_54.Name;
        flag1 = this.checkBox_54.Checked;
        string str24 = flag1.ToString();
        xmlWriter25.WriteElementString(name24, str24);
        XmlWriter xmlWriter26 = xmlWriter1;
        string name25 = this.checkBox_59.Name;
        flag1 = this.checkBox_59.Checked;
        string str25 = flag1.ToString();
        xmlWriter26.WriteElementString(name25, str25);
        XmlWriter xmlWriter27 = xmlWriter1;
        string name26 = this.checkBox_64.Name;
        flag1 = this.checkBox_64.Checked;
        string str26 = flag1.ToString();
        xmlWriter27.WriteElementString(name26, str26);
        XmlWriter xmlWriter28 = xmlWriter1;
        string name27 = this.checkBox_50.Name;
        flag1 = this.checkBox_50.Checked;
        string str27 = flag1.ToString();
        xmlWriter28.WriteElementString(name27, str27);
        XmlWriter xmlWriter29 = xmlWriter1;
        string name28 = this.checkBox_53.Name;
        flag1 = this.checkBox_53.Checked;
        string str28 = flag1.ToString();
        xmlWriter29.WriteElementString(name28, str28);
        xmlWriter1.WriteElementString(this.textBox_16.Name, this.textBox_16.Text);
        XmlWriter xmlWriter30 = xmlWriter1;
        string name29 = this.checkBox_61.Name;
        flag1 = this.checkBox_61.Checked;
        string str29 = flag1.ToString();
        xmlWriter30.WriteElementString(name29, str29);
        XmlWriter xmlWriter31 = xmlWriter1;
        string name30 = this.checkBox_63.Name;
        flag1 = this.checkBox_63.Checked;
        string str30 = flag1.ToString();
        xmlWriter31.WriteElementString(name30, str30);
        XmlWriter xmlWriter32 = xmlWriter1;
        string name31 = this.checkBox_51.Name;
        flag1 = this.checkBox_51.Checked;
        string str31 = flag1.ToString();
        xmlWriter32.WriteElementString(name31, str31);
        XmlWriter xmlWriter33 = xmlWriter1;
        string name32 = this.checkBox_56.Name;
        flag1 = this.checkBox_56.Checked;
        string str32 = flag1.ToString();
        xmlWriter33.WriteElementString(name32, str32);
        XmlWriter xmlWriter34 = xmlWriter1;
        string name33 = this.checkBox_48.Name;
        flag1 = this.checkBox_48.Checked;
        string str33 = flag1.ToString();
        xmlWriter34.WriteElementString(name33, str33);
        XmlWriter xmlWriter35 = xmlWriter1;
        string name34 = this.checkBox_49.Name;
        flag1 = this.checkBox_49.Checked;
        string str34 = flag1.ToString();
        xmlWriter35.WriteElementString(name34, str34);
        XmlWriter xmlWriter36 = xmlWriter1;
        string name35 = this.checkBox_46.Name;
        flag1 = this.checkBox_46.Checked;
        string str35 = flag1.ToString();
        xmlWriter36.WriteElementString(name35, str35);
        XmlWriter xmlWriter37 = xmlWriter1;
        string name36 = this.checkBox_52.Name;
        flag1 = this.checkBox_52.Checked;
        string str36 = flag1.ToString();
        xmlWriter37.WriteElementString(name36, str36);
        XmlWriter xmlWriter38 = xmlWriter1;
        string name37 = this.checkBox_45.Name;
        flag1 = this.checkBox_45.Checked;
        string str37 = flag1.ToString();
        xmlWriter38.WriteElementString(name37, str37);
        xmlWriter1.WriteElementString(this.comboBox_3.Name, this.comboBox_3.Text);
        xmlWriter1.WriteElementString(this.textBox_15.Name, this.textBox_15.Text);
        XmlWriter xmlWriter39 = xmlWriter1;
        string name38 = this.checkBox_42.Name;
        flag1 = this.checkBox_42.Checked;
        string str38 = flag1.ToString();
        xmlWriter39.WriteElementString(name38, str38);
        XmlWriter xmlWriter40 = xmlWriter1;
        string name39 = this.checkBox_44.Name;
        flag1 = this.checkBox_44.Checked;
        string str39 = flag1.ToString();
        xmlWriter40.WriteElementString(name39, str39);
        XmlWriter xmlWriter41 = xmlWriter1;
        string name40 = this.checkBox_43.Name;
        flag1 = this.checkBox_43.Checked;
        string str40 = flag1.ToString();
        xmlWriter41.WriteElementString(name40, str40);
        XmlWriter xmlWriter42 = xmlWriter1;
        string name41 = this.checkBox_76.Name;
        flag1 = this.checkBox_76.Checked;
        string str41 = flag1.ToString();
        xmlWriter42.WriteElementString(name41, str41);
        XmlWriter xmlWriter43 = xmlWriter1;
        string name42 = this.checkBox_75.Name;
        flag1 = this.checkBox_75.Checked;
        string str42 = flag1.ToString();
        xmlWriter43.WriteElementString(name42, str42);
        XmlWriter xmlWriter44 = xmlWriter1;
        string name43 = this.checkBox_74.Name;
        flag1 = this.checkBox_74.Checked;
        string str43 = flag1.ToString();
        xmlWriter44.WriteElementString(name43, str43);
        XmlWriter xmlWriter45 = xmlWriter1;
        string name44 = this.checkBox_68.Name;
        flag1 = this.checkBox_68.Checked;
        string str44 = flag1.ToString();
        xmlWriter45.WriteElementString(name44, str44);
        xmlWriter1.WriteElementString(this.textBox_17.Name, this.textBox_17.Text);
        xmlWriter1.WriteElementString(this.numericUpDown_20.Name, this.numericUpDown_20.Value.ToString());
        xmlWriter1.WriteElementString(this.trackBar_0.Name, this.trackBar_0.Value.ToString());
        XmlWriter xmlWriter46 = xmlWriter1;
        string name45 = this.checkBox_66.Name;
        flag1 = this.checkBox_66.Checked;
        string str45 = flag1.ToString();
        xmlWriter46.WriteElementString(name45, str45);
        XmlWriter xmlWriter47 = xmlWriter1;
        string name46 = this.checkBox_65.Name;
        flag1 = this.checkBox_65.Checked;
        string str46 = flag1.ToString();
        xmlWriter47.WriteElementString(name46, str46);
        XmlWriter xmlWriter48 = xmlWriter1;
        string name47 = this.checkBox_67.Name;
        flag1 = this.checkBox_67.Checked;
        string str47 = flag1.ToString();
        xmlWriter48.WriteElementString(name47, str47);
        XmlWriter xmlWriter49 = xmlWriter1;
        string name48 = this.checkBox_79.Name;
        flag1 = this.checkBox_79.Checked;
        string str48 = flag1.ToString();
        xmlWriter49.WriteElementString(name48, str48);
        XmlWriter xmlWriter50 = xmlWriter1;
        string name49 = this.checkBox_78.Name;
        flag1 = this.checkBox_78.Checked;
        string str49 = flag1.ToString();
        xmlWriter50.WriteElementString(name49, str49);
        XmlWriter xmlWriter51 = xmlWriter1;
        string name50 = this.checkBox_77.Name;
        flag1 = this.checkBox_77.Checked;
        string str50 = flag1.ToString();
        xmlWriter51.WriteElementString(name50, str50);
        foreach (string str51 in (Collection<string>) this.bindingList_3)
          xmlWriter1.WriteElementString(this.listBox_5.Name, str51);
        xmlWriter1.WriteElementString(this.checkBox_34.Name, this.checkBox_34.Checked.ToString());
        XmlWriter xmlWriter52 = xmlWriter1;
        string name51 = this.checkBox_32.Name;
        bool flag2 = this.checkBox_32.Checked;
        string str52 = flag2.ToString();
        xmlWriter52.WriteElementString(name51, str52);
        XmlWriter xmlWriter53 = xmlWriter1;
        string name52 = this.checkBox_33.Name;
        flag2 = this.checkBox_33.Checked;
        string str53 = flag2.ToString();
        xmlWriter53.WriteElementString(name52, str53);
        XmlWriter xmlWriter54 = xmlWriter1;
        string name53 = this.checkBox_29.Name;
        flag2 = this.checkBox_29.Checked;
        string str54 = flag2.ToString();
        xmlWriter54.WriteElementString(name53, str54);
        XmlWriter xmlWriter55 = xmlWriter1;
        string name54 = this.checkBox_30.Name;
        flag2 = this.checkBox_30.Checked;
        string str55 = flag2.ToString();
        xmlWriter55.WriteElementString(name54, str55);
        XmlWriter xmlWriter56 = xmlWriter1;
        string name55 = this.checkBox_31.Name;
        flag2 = this.checkBox_31.Checked;
        string str56 = flag2.ToString();
        xmlWriter56.WriteElementString(name55, str56);
        XmlWriter xmlWriter57 = xmlWriter1;
        string name56 = this.checkBox_28.Name;
        flag2 = this.checkBox_28.Checked;
        string str57 = flag2.ToString();
        xmlWriter57.WriteElementString(name56, str57);
        XmlWriter xmlWriter58 = xmlWriter1;
        string name57 = this.checkBox_25.Name;
        flag2 = this.checkBox_25.Checked;
        string str58 = flag2.ToString();
        xmlWriter58.WriteElementString(name57, str58);
        XmlWriter xmlWriter59 = xmlWriter1;
        string name58 = this.checkBox_27.Name;
        flag2 = this.checkBox_27.Checked;
        string str59 = flag2.ToString();
        xmlWriter59.WriteElementString(name58, str59);
        XmlWriter xmlWriter60 = xmlWriter1;
        string name59 = this.checkBox_26.Name;
        flag2 = this.checkBox_26.Checked;
        string str60 = flag2.ToString();
        xmlWriter60.WriteElementString(name59, str60);
        XmlWriter xmlWriter61 = xmlWriter1;
        string name60 = this.checkBox_23.Name;
        flag2 = this.checkBox_23.Checked;
        string str61 = flag2.ToString();
        xmlWriter61.WriteElementString(name60, str61);
        foreach (object obj in this.listBox_4.Items)
          xmlWriter1.WriteElementString(this.listBox_4.Name, obj.ToString());
        xmlWriter1.WriteElementString(this.checkBox_35.Name, this.checkBox_35.Checked.ToString());
        XmlWriter xmlWriter62 = xmlWriter1;
        string name61 = this.numericUpDown_19.Name;
        Decimal num2 = this.numericUpDown_19.Value;
        string str62 = num2.ToString();
        xmlWriter62.WriteElementString(name61, str62);
        xmlWriter1.WriteElementString(this.checkBox_89.Name, this.checkBox_89.Checked.ToString());
        xmlWriter1.WriteElementString(this.textBox_21.Name, this.textBox_21.Text);
        xmlWriter1.WriteElementString(this.checkBox_100.Name, this.checkBox_100.Checked.ToString());
        xmlWriter1.WriteElementString(this.checkBox_99.Name, this.checkBox_99.Checked.ToString());
        XmlWriter xmlWriter63 = xmlWriter1;
        string name62 = this.numericUpDown_24.Name;
        num2 = this.numericUpDown_24.Value;
        string str63 = num2.ToString();
        xmlWriter63.WriteElementString(name62, str63);
        xmlWriter1.WriteElementString(this.checkBox_98.Name, this.checkBox_98.Checked.ToString());
        XmlWriter xmlWriter64 = xmlWriter1;
        string name63 = this.checkBox_95.Name;
        bool flag3 = this.checkBox_95.Checked;
        string str64 = flag3.ToString();
        xmlWriter64.WriteElementString(name63, str64);
        XmlWriter xmlWriter65 = xmlWriter1;
        string name64 = this.checkBox_96.Name;
        flag3 = this.checkBox_96.Checked;
        string str65 = flag3.ToString();
        xmlWriter65.WriteElementString(name64, str65);
        XmlWriter xmlWriter66 = xmlWriter1;
        string name65 = this.checkBox_97.Name;
        flag3 = this.checkBox_97.Checked;
        string str66 = flag3.ToString();
        xmlWriter66.WriteElementString(name65, str66);
        xmlWriter1.WriteElementString(this.textBox_23.Name, this.textBox_23.Text);
        XmlWriter xmlWriter67 = xmlWriter1;
        string name66 = this.radioButton_5.Name;
        flag3 = this.radioButton_5.Checked;
        string str67 = flag3.ToString();
        xmlWriter67.WriteElementString(name66, str67);
        XmlWriter xmlWriter68 = xmlWriter1;
        string name67 = this.radioButton_4.Name;
        flag3 = this.radioButton_4.Checked;
        string str68 = flag3.ToString();
        xmlWriter68.WriteElementString(name67, str68);
        XmlWriter xmlWriter69 = xmlWriter1;
        string name68 = this.numericUpDown_23.Name;
        num2 = this.numericUpDown_23.Value;
        string str69 = num2.ToString();
        xmlWriter69.WriteElementString(name68, str69);
        XmlWriter xmlWriter70 = xmlWriter1;
        string name69 = this.checkBox_94.Name;
        flag3 = this.checkBox_94.Checked;
        string str70 = flag3.ToString();
        xmlWriter70.WriteElementString(name69, str70);
        XmlWriter xmlWriter71 = xmlWriter1;
        string name70 = this.checkBox_93.Name;
        flag3 = this.checkBox_93.Checked;
        string str71 = flag3.ToString();
        xmlWriter71.WriteElementString(name70, str71);
        XmlWriter xmlWriter72 = xmlWriter1;
        string name71 = this.checkBox_101.Name;
        flag3 = this.checkBox_101.Checked;
        string str72 = flag3.ToString();
        xmlWriter72.WriteElementString(name71, str72);
        xmlWriter1.WriteElementString(this.textBox_24.Name, this.textBox_24.Text);
        xmlWriter1.WriteElementString(this.textBox_25.Name, this.textBox_25.Text);
        foreach (string str73 in this.class29_0.Control2_0.list_4)
          xmlWriter1.WriteElementString(\u003CModule\u003E.smethod_8<string>(3893307863U), str73.ToString());
        foreach (TabPage tabPage in this.tabControl_1.TabPages)
        {
          if (tabPage.Name != \u003CModule\u003E.smethod_8<string>(2040578583U) && tabPage.Name != \u003CModule\u003E.smethod_9<string>(926322308U))
          {
            Control3 control3 = tabPage.Controls.OfType<Control3>().First<Control3>();
            xmlWriter1.WriteStartElement(\u003CModule\u003E.smethod_9<string>(1650455400U));
            xmlWriter1.WriteElementString(\u003CModule\u003E.smethod_9<string>(4013629717U), tabPage.Text);
            xmlWriter1.WriteElementString(control3.checkBox_0.Name, control3.checkBox_0.Checked.ToString());
            xmlWriter1.WriteElementString(control3.comboBox_0.Name, control3.comboBox_0.Text);
            xmlWriter1.WriteElementString(control3.checkBox_3.Name, control3.checkBox_3.Checked.ToString());
            xmlWriter1.WriteElementString(control3.comboBox_1.Name, control3.comboBox_1.Text);
            xmlWriter1.WriteElementString(control3.checkBox_4.Name, control3.checkBox_4.Checked.ToString());
            xmlWriter1.WriteElementString(control3.comboBox_2.Name, control3.comboBox_2.Text);
            xmlWriter1.WriteElementString(control3.numericUpDown_0.Name, control3.numericUpDown_0.Value.ToString());
            xmlWriter1.WriteElementString(control3.checkBox_1.Name, control3.checkBox_1.Checked.ToString());
            xmlWriter1.WriteElementString(control3.checkBox_2.Name, control3.checkBox_2.Checked.ToString());
            xmlWriter1.WriteElementString(control3.checkBox_5.Name, control3.checkBox_5.Checked.ToString());
            xmlWriter1.WriteElementString(control3.checkBox_8.Name, control3.checkBox_8.Checked.ToString());
            xmlWriter1.WriteElementString(control3.checkBox_6.Name, control3.checkBox_6.Checked.ToString());
            xmlWriter1.WriteElementString(control3.checkBox_7.Name, control3.checkBox_7.Checked.ToString());
            xmlWriter1.WriteElementString(control3.checkBox_9.Name, control3.checkBox_9.Checked.ToString());
            xmlWriter1.WriteElementString(control3.textBox_0.Name, control3.textBox_0.Text);
            xmlWriter1.WriteElementString(control3.radioButton_3.Name, control3.radioButton_3.Checked.ToString());
            xmlWriter1.WriteElementString(control3.radioButton_0.Name, control3.radioButton_0.Checked.ToString());
            xmlWriter1.WriteElementString(control3.radioButton_1.Name, control3.radioButton_1.Checked.ToString());
            xmlWriter1.WriteElementString(control3.radioButton_2.Name, control3.radioButton_2.Checked.ToString());
            xmlWriter1.WriteEndElement();
          }
        }
        foreach (TabPage tabPage in this.tabControl_0.TabPages)
        {
          if (tabPage.Name != \u003CModule\u003E.smethod_8<string>(786792770U))
          {
            Control4 control4 = tabPage.Controls.OfType<Control4>().First<Control4>();
            xmlWriter1.WriteStartElement(\u003CModule\u003E.smethod_9<string>(3582248379U));
            xmlWriter1.WriteElementString(\u003CModule\u003E.smethod_8<string>(2854807935U), tabPage.Text);
            xmlWriter1.WriteElementString(control4.checkBox_11.Name, control4.checkBox_11.Checked.ToString());
            xmlWriter1.WriteElementString(control4.comboBox_3.Name, control4.comboBox_3.Text);
            xmlWriter1.WriteElementString(control4.checkBox_12.Name, control4.checkBox_12.Checked.ToString());
            xmlWriter1.WriteElementString(control4.comboBox_4.Name, control4.comboBox_4.Text);
            xmlWriter1.WriteElementString(control4.checkBox_10.Name, control4.checkBox_10.Checked.ToString());
            xmlWriter1.WriteElementString(control4.comboBox_2.Name, control4.comboBox_2.Text);
            XmlWriter xmlWriter73 = xmlWriter1;
            string name72 = control4.checkBox_13.Name;
            bool flag4 = control4.checkBox_13.Checked;
            string str74 = flag4.ToString();
            xmlWriter73.WriteElementString(name72, str74);
            xmlWriter1.WriteElementString(control4.comboBox_5.Name, control4.comboBox_5.Text);
            XmlWriter xmlWriter74 = xmlWriter1;
            string name73 = control4.checkBox_14.Name;
            flag4 = control4.checkBox_14.Checked;
            string str75 = flag4.ToString();
            xmlWriter74.WriteElementString(name73, str75);
            XmlWriter xmlWriter75 = xmlWriter1;
            string name74 = control4.checkBox_15.Name;
            flag4 = control4.checkBox_15.Checked;
            string str76 = flag4.ToString();
            xmlWriter75.WriteElementString(name74, str76);
            XmlWriter xmlWriter76 = xmlWriter1;
            string name75 = control4.checkBox_0.Name;
            flag4 = control4.checkBox_0.Checked;
            string str77 = flag4.ToString();
            xmlWriter76.WriteElementString(name75, str77);
            xmlWriter1.WriteElementString(control4.comboBox_0.Name, control4.comboBox_0.Text);
            XmlWriter xmlWriter77 = xmlWriter1;
            string name76 = control4.checkBox_1.Name;
            flag4 = control4.checkBox_1.Checked;
            string str78 = flag4.ToString();
            xmlWriter77.WriteElementString(name76, str78);
            xmlWriter1.WriteElementString(control4.comboBox_1.Name, control4.comboBox_1.Text);
            XmlWriter xmlWriter78 = xmlWriter1;
            string name77 = control4.radioButton_4.Name;
            flag4 = control4.radioButton_4.Checked;
            string str79 = flag4.ToString();
            xmlWriter78.WriteElementString(name77, str79);
            XmlWriter xmlWriter79 = xmlWriter1;
            string name78 = control4.radioButton_2.Name;
            flag4 = control4.radioButton_2.Checked;
            string str80 = flag4.ToString();
            xmlWriter79.WriteElementString(name78, str80);
            XmlWriter xmlWriter80 = xmlWriter1;
            string name79 = control4.radioButton_0.Name;
            flag4 = control4.radioButton_0.Checked;
            string str81 = flag4.ToString();
            xmlWriter80.WriteElementString(name79, str81);
            XmlWriter xmlWriter81 = xmlWriter1;
            string name80 = control4.radioButton_1.Name;
            flag4 = control4.radioButton_1.Checked;
            string str82 = flag4.ToString();
            xmlWriter81.WriteElementString(name80, str82);
            XmlWriter xmlWriter82 = xmlWriter1;
            string name81 = control4.radioButton_3.Name;
            flag4 = control4.radioButton_3.Checked;
            string str83 = flag4.ToString();
            xmlWriter82.WriteElementString(name81, str83);
            XmlWriter xmlWriter83 = xmlWriter1;
            string name82 = control4.radioButton_5.Name;
            flag4 = control4.radioButton_5.Checked;
            string str84 = flag4.ToString();
            xmlWriter83.WriteElementString(name82, str84);
            XmlWriter xmlWriter84 = xmlWriter1;
            string name83 = control4.checkBox_8.Name;
            flag4 = control4.checkBox_8.Checked;
            string str85 = flag4.ToString();
            xmlWriter84.WriteElementString(name83, str85);
            XmlWriter xmlWriter85 = xmlWriter1;
            string name84 = control4.checkBox_9.Name;
            flag4 = control4.checkBox_9.Checked;
            string str86 = flag4.ToString();
            xmlWriter85.WriteElementString(name84, str86);
            XmlWriter xmlWriter86 = xmlWriter1;
            string name85 = control4.checkBox_4.Name;
            flag4 = control4.checkBox_4.Checked;
            string str87 = flag4.ToString();
            xmlWriter86.WriteElementString(name85, str87);
            XmlWriter xmlWriter87 = xmlWriter1;
            string name86 = control4.checkBox_6.Name;
            flag4 = control4.checkBox_6.Checked;
            string str88 = flag4.ToString();
            xmlWriter87.WriteElementString(name86, str88);
            XmlWriter xmlWriter88 = xmlWriter1;
            string name87 = control4.checkBox_3.Name;
            flag4 = control4.checkBox_3.Checked;
            string str89 = flag4.ToString();
            xmlWriter88.WriteElementString(name87, str89);
            XmlWriter xmlWriter89 = xmlWriter1;
            string name88 = control4.checkBox_5.Name;
            flag4 = control4.checkBox_5.Checked;
            string str90 = flag4.ToString();
            xmlWriter89.WriteElementString(name88, str90);
            xmlWriter1.WriteElementString(control4.numericUpDown_0.Name, control4.numericUpDown_0.Value.ToString());
            XmlWriter xmlWriter90 = xmlWriter1;
            string name89 = control4.checkBox_7.Name;
            flag4 = control4.checkBox_7.Checked;
            string str91 = flag4.ToString();
            xmlWriter90.WriteElementString(name89, str91);
            foreach (object obj in control4.listBox_1.Items)
              xmlWriter1.WriteElementString(control4.listBox_1.Name, obj.ToString());
            xmlWriter1.WriteEndElement();
          }
        }
        xmlWriter1.WriteEndElement();
        xmlWriter1.WriteEndDocument();
      }
      if (!this.list_1.Contains<string>(sender, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase))
        this.list_1.Add(sender);
      this.string_3 = sender;
    }
  }

  private void method_11([In] string obj0)
  {
    if (string.IsNullOrEmpty(obj0))
      return;
    this.string_3 = obj0;
    if (!Monitor.TryEnter(Class112.object_0, 2000))
      return;
    try
    {
      this.method_2();
      string str1 = Settings.Default.DarkAgesPath.Replace(\u003CModule\u003E.smethod_8<string>(2112040518U), this.class29_0.String_0 + \u003CModule\u003E.smethod_5<string>(3597069044U) + obj0 + \u003CModule\u003E.smethod_9<string>(394003554U));
      if (!File.Exists(str1))
        return;
      this.method_3();
      this.bool_1 = true;
      XDocument xdocument = XDocument.Load(str1);
      try
      {
        this.comboBox_11.Text = xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.comboBox_11.Name).Value;
        this.checkBox_87.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.checkBox_87.Name).Value);
        this.comboBox_10.Text = xdocument.Element((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Element((XName) this.comboBox_10.Name).Value;
        this.checkBox_86.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_9<string>(2884707664U)).Element((XName) this.checkBox_86.Name).Value);
        this.checkBox_73.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_9<string>(2884707664U)).Element((XName) this.checkBox_73.Name).Value);
        this.checkBox_72.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Element((XName) this.checkBox_72.Name).Value);
        this.checkBox_22.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Element((XName) this.checkBox_22.Name).Value);
        this.numericUpDown_18.Value = (Decimal) Convert.ToInt32(xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.numericUpDown_18.Name).Value);
        this.checkBox_83.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_6<string>(3246925218U)).Element((XName) this.checkBox_83.Name).Value);
        this.comboBox_7.Text = xdocument.Element((XName) \u003CModule\u003E.smethod_6<string>(3246925218U)).Element((XName) this.comboBox_7.Name).Value;
        this.comboBox_6.Text = xdocument.Element((XName) \u003CModule\u003E.smethod_6<string>(3246925218U)).Element((XName) this.comboBox_6.Name).Value;
        this.numericUpDown_22.Value = (Decimal) Convert.ToInt32(xdocument.Element((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Element((XName) this.numericUpDown_22.Name).Value);
        this.checkBox_82.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_9<string>(2884707664U)).Element((XName) this.checkBox_82.Name).Value);
        this.comboBox_5.Text = xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.comboBox_5.Name).Value;
        this.numericUpDown_21.Value = (Decimal) Convert.ToInt32(xdocument.Element((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Element((XName) this.numericUpDown_21.Name).Value);
        this.checkBox_81.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Element((XName) this.checkBox_81.Name).Value);
        this.checkBox_80.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_6<string>(3246925218U)).Element((XName) this.checkBox_80.Name).Value);
        this.checkBox_41.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Element((XName) this.checkBox_41.Name).Value);
        this.checkBox_40.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Element((XName) this.checkBox_40.Name).Value);
        this.checkBox_39.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_9<string>(2884707664U)).Element((XName) this.checkBox_39.Name).Value);
        this.checkBox_38.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Element((XName) this.checkBox_38.Name).Value);
        this.checkBox_85.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Element((XName) this.checkBox_85.Name).Value);
        this.comboBox_9.Text = xdocument.Element((XName) \u003CModule\u003E.smethod_9<string>(2884707664U)).Element((XName) this.comboBox_9.Name).Value;
        this.checkBox_84.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Element((XName) this.checkBox_84.Name).Value);
        this.comboBox_8.Text = xdocument.Element((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Element((XName) this.comboBox_8.Name).Value;
        this.checkBox_58.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Element((XName) this.checkBox_58.Name).Value);
        this.checkBox_47.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Element((XName) this.checkBox_47.Name).Value);
        this.checkBox_55.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_6<string>(3246925218U)).Element((XName) this.checkBox_55.Name).Value);
        this.checkBox_60.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Element((XName) this.checkBox_60.Name).Value);
        this.checkBox_62.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.checkBox_62.Name).Value);
        this.checkBox_57.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.checkBox_57.Name).Value);
        this.checkBox_54.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.checkBox_54.Name).Value);
        this.checkBox_59.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_9<string>(2884707664U)).Element((XName) this.checkBox_59.Name).Value);
        this.checkBox_64.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_9<string>(2884707664U)).Element((XName) this.checkBox_64.Name).Value);
        this.checkBox_50.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Element((XName) this.checkBox_50.Name).Value);
        this.checkBox_53.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.checkBox_53.Name).Value);
        this.textBox_16.Text = xdocument.Element((XName) \u003CModule\u003E.smethod_6<string>(3246925218U)).Element((XName) this.textBox_16.Name).Value;
        this.checkBox_61.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.checkBox_61.Name).Value);
        this.checkBox_63.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Element((XName) this.checkBox_63.Name).Value);
        this.checkBox_51.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.checkBox_51.Name).Value);
        this.checkBox_56.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_6<string>(3246925218U)).Element((XName) this.checkBox_56.Name).Value);
        this.checkBox_48.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Element((XName) this.checkBox_48.Name).Value);
        this.checkBox_49.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.checkBox_49.Name).Value);
        this.checkBox_46.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.checkBox_46.Name).Value);
        this.checkBox_52.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.checkBox_52.Name).Value);
        this.checkBox_45.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Element((XName) this.checkBox_45.Name).Value);
        this.checkBox_42.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.checkBox_42.Name).Value);
        this.checkBox_44.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_9<string>(2884707664U)).Element((XName) this.checkBox_44.Name).Value);
        this.checkBox_43.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_6<string>(3246925218U)).Element((XName) this.checkBox_43.Name).Value);
        this.checkBox_76.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Element((XName) this.checkBox_76.Name).Value);
        this.checkBox_75.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_6<string>(3246925218U)).Element((XName) this.checkBox_75.Name).Value);
        this.checkBox_74.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Element((XName) this.checkBox_74.Name).Value);
        this.checkBox_68.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Element((XName) this.checkBox_68.Name).Value);
        this.textBox_17.Text = xdocument.Element((XName) \u003CModule\u003E.smethod_6<string>(3246925218U)).Element((XName) this.textBox_17.Name).Value;
        this.numericUpDown_20.Value = (Decimal) Convert.ToInt32(xdocument.Element((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Element((XName) this.numericUpDown_20.Name).Value);
        int int32_1 = Convert.ToInt32(xdocument.Element((XName) \u003CModule\u003E.smethod_6<string>(3246925218U)).Element((XName) this.trackBar_0.Name).Value);
        this.trackBar_0.Value = int32_1 < 150 ? 150 : (int32_1 > 2000 ? 2000 : int32_1);
        this.trackBar_0_Scroll((object) this.trackBar_0, new EventArgs());
        this.checkBox_79.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_6<string>(3246925218U)).Element((XName) this.checkBox_79.Name).Value);
        this.checkBox_78.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Element((XName) this.checkBox_78.Name).Value);
        this.checkBox_77.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Element((XName) this.checkBox_77.Name).Value);
        this.bindingList_3.Clear();
        foreach (XElement element in xdocument.Elements((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Elements<XElement>((XName) this.listBox_5.Name))
          this.method_8(this.bindingList_3, this.listBox_5, element.Value);
        this.checkBox_34.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.checkBox_34.Name).Value);
        this.checkBox_32.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.checkBox_32.Name).Value);
        this.checkBox_33.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.checkBox_33.Name).Value);
        this.checkBox_29.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.checkBox_29.Name).Value);
        this.checkBox_30.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.checkBox_30.Name).Value);
        this.checkBox_31.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_9<string>(2884707664U)).Element((XName) this.checkBox_31.Name).Value);
        this.checkBox_28.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Element((XName) this.checkBox_28.Name).Value);
        this.checkBox_25.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Element((XName) this.checkBox_25.Name).Value);
        this.checkBox_27.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.checkBox_27.Name).Value);
        this.checkBox_26.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Element((XName) this.checkBox_26.Name).Value);
        this.checkBox_23.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Element((XName) this.checkBox_23.Name).Value);
        this.checkBox_89.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Element((XName) this.checkBox_89.Name)?.Value);
        this.textBox_21.Text = xdocument.Element((XName) \u003CModule\u003E.smethod_9<string>(2884707664U)).Element((XName) this.textBox_21.Name)?.Value;
        CheckBox checkBox100 = this.checkBox_100;
        XElement xelement1 = xdocument.Element((XName) \u003CModule\u003E.smethod_9<string>(2884707664U)).Element((XName) this.checkBox_100.Name);
        string str2;
        if (xelement1 == null)
        {
          str2 = (string) null;
        }
        else
        {
          str2 = xelement1.Value;
          if (str2 != null)
            goto label_16;
        }
        str2 = \u003CModule\u003E.smethod_8<string>(347236309U);
label_16:
        int num1 = Convert.ToBoolean(str2) ? 1 : 0;
        checkBox100.Checked = num1 != 0;
        CheckBox checkBox99 = this.checkBox_99;
        XElement xelement2 = xdocument.Element((XName) \u003CModule\u003E.smethod_6<string>(3246925218U)).Element((XName) this.checkBox_99.Name);
        string str3;
        if (xelement2 == null)
        {
          str3 = (string) null;
        }
        else
        {
          str3 = xelement2.Value;
          if (str3 != null)
            goto label_20;
        }
        str3 = \u003CModule\u003E.smethod_8<string>(347236309U);
label_20:
        int num2 = Convert.ToBoolean(str3) ? 1 : 0;
        checkBox99.Checked = num2 != 0;
        NumericUpDown numericUpDown24 = this.numericUpDown_24;
        XElement xelement3 = xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.numericUpDown_24.Name);
        string str4;
        if (xelement3 == null)
        {
          str4 = (string) null;
        }
        else
        {
          str4 = xelement3.Value;
          if (str4 != null)
            goto label_24;
        }
        str4 = this.numericUpDown_24.Value.ToString();
label_24:
        Decimal int32_2 = (Decimal) Convert.ToInt32(str4);
        numericUpDown24.Value = int32_2;
        CheckBox checkBox98 = this.checkBox_98;
        XElement xelement4 = xdocument.Element((XName) \u003CModule\u003E.smethod_6<string>(3246925218U)).Element((XName) this.checkBox_98.Name);
        string str5;
        if (xelement4 == null)
        {
          str5 = (string) null;
        }
        else
        {
          str5 = xelement4.Value;
          if (str5 != null)
            goto label_28;
        }
        str5 = \u003CModule\u003E.smethod_5<string>(4105552381U);
label_28:
        int num3 = Convert.ToBoolean(str5) ? 1 : 0;
        checkBox98.Checked = num3 != 0;
        CheckBox checkBox95 = this.checkBox_95;
        XElement xelement5 = xdocument.Element((XName) \u003CModule\u003E.smethod_6<string>(3246925218U)).Element((XName) this.checkBox_95.Name);
        string str6;
        if (xelement5 == null)
        {
          str6 = (string) null;
        }
        else
        {
          str6 = xelement5.Value;
          if (str6 != null)
            goto label_32;
        }
        str6 = \u003CModule\u003E.smethod_5<string>(4105552381U);
label_32:
        int num4 = Convert.ToBoolean(str6) ? 1 : 0;
        checkBox95.Checked = num4 != 0;
        CheckBox checkBox96 = this.checkBox_96;
        XElement xelement6 = xdocument.Element((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Element((XName) this.checkBox_96.Name);
        string str7;
        if (xelement6 == null)
        {
          str7 = (string) null;
        }
        else
        {
          str7 = xelement6.Value;
          if (str7 != null)
            goto label_36;
        }
        str7 = \u003CModule\u003E.smethod_6<string>(2322283525U);
label_36:
        int num5 = Convert.ToBoolean(str7) ? 1 : 0;
        checkBox96.Checked = num5 != 0;
        CheckBox checkBox97 = this.checkBox_97;
        XElement xelement7 = xdocument.Element((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Element((XName) this.checkBox_97.Name);
        string str8;
        if (xelement7 == null)
        {
          str8 = (string) null;
        }
        else
        {
          str8 = xelement7.Value;
          if (str8 != null)
            goto label_40;
        }
        str8 = \u003CModule\u003E.smethod_7<string>(819104123U);
label_40:
        int num6 = Convert.ToBoolean(str8) ? 1 : 0;
        checkBox97.Checked = num6 != 0;
        TextBox textBox23 = this.textBox_23;
        XElement xelement8 = xdocument.Element((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Element((XName) this.textBox_23.Name);
        string str9;
        if (xelement8 == null)
        {
          str9 = (string) null;
        }
        else
        {
          str9 = xelement8.Value;
          if (str9 != null)
            goto label_44;
        }
        str9 = string.Empty;
label_44:
        textBox23.Text = str9;
        RadioButton radioButton5 = this.radioButton_5;
        XElement xelement9 = xdocument.Element((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Element((XName) this.radioButton_5.Name);
        string str10;
        if (xelement9 == null)
        {
          str10 = (string) null;
        }
        else
        {
          str10 = xelement9.Value;
          if (str10 != null)
            goto label_48;
        }
        str10 = \u003CModule\u003E.smethod_8<string>(347236309U);
label_48:
        int num7 = Convert.ToBoolean(str10) ? 1 : 0;
        radioButton5.Checked = num7 != 0;
        RadioButton radioButton4 = this.radioButton_4;
        XElement xelement10 = xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.radioButton_4.Name);
        string str11;
        if (xelement10 == null)
        {
          str11 = (string) null;
        }
        else
        {
          str11 = xelement10.Value;
          if (str11 != null)
            goto label_52;
        }
        str11 = \u003CModule\u003E.smethod_9<string>(2895807455U);
label_52:
        int num8 = Convert.ToBoolean(str11) ? 1 : 0;
        radioButton4.Checked = num8 != 0;
        NumericUpDown numericUpDown23 = this.numericUpDown_23;
        XElement xelement11 = xdocument.Element((XName) \u003CModule\u003E.smethod_9<string>(2884707664U)).Element((XName) this.numericUpDown_23.Name);
        string str12;
        if (xelement11 == null)
        {
          str12 = (string) null;
        }
        else
        {
          str12 = xelement11.Value;
          if (str12 != null)
            goto label_56;
        }
        str12 = this.numericUpDown_23.Value.ToString();
label_56:
        Decimal int32_3 = (Decimal) Convert.ToInt32(str12);
        numericUpDown23.Value = int32_3;
        CheckBox checkBox94 = this.checkBox_94;
        XElement xelement12 = xdocument.Element((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Element((XName) this.checkBox_94.Name);
        string str13;
        if (xelement12 == null)
        {
          str13 = (string) null;
        }
        else
        {
          str13 = xelement12.Value;
          if (str13 != null)
            goto label_60;
        }
        str13 = \u003CModule\u003E.smethod_6<string>(2322283525U);
label_60:
        int num9 = Convert.ToBoolean(str13) ? 1 : 0;
        checkBox94.Checked = num9 != 0;
        CheckBox checkBox93 = this.checkBox_93;
        XElement xelement13 = xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.checkBox_93.Name);
        string str14;
        if (xelement13 == null)
        {
          str14 = (string) null;
        }
        else
        {
          str14 = xelement13.Value;
          if (str14 != null)
            goto label_64;
        }
        str14 = \u003CModule\u003E.smethod_8<string>(347236309U);
label_64:
        int num10 = Convert.ToBoolean(str14) ? 1 : 0;
        checkBox93.Checked = num10 != 0;
        CheckBox checkBox101 = this.checkBox_101;
        XElement xelement14 = xdocument.Element((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Element((XName) this.checkBox_101.Name);
        string str15;
        if (xelement14 == null)
        {
          str15 = (string) null;
        }
        else
        {
          str15 = xelement14.Value;
          if (str15 != null)
            goto label_68;
        }
        str15 = \u003CModule\u003E.smethod_9<string>(2895807455U);
label_68:
        int num11 = Convert.ToBoolean(str15) ? 1 : 0;
        checkBox101.Checked = num11 != 0;
        TextBox textBox24 = this.textBox_24;
        XElement xelement15 = xdocument.Element((XName) \u003CModule\u003E.smethod_6<string>(3246925218U)).Element((XName) this.textBox_24.Name);
        string str16;
        if (xelement15 == null)
        {
          str16 = (string) null;
        }
        else
        {
          str16 = xelement15.Value;
          if (str16 != null)
            goto label_72;
        }
        str16 = string.Empty;
label_72:
        textBox24.Text = str16;
        TextBox textBox25 = this.textBox_25;
        XElement xelement16 = xdocument.Element((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Element((XName) this.textBox_25.Name);
        string str17;
        if (xelement16 == null)
        {
          str17 = (string) null;
        }
        else
        {
          str17 = xelement16.Value;
          if (str17 != null)
            goto label_76;
        }
        str17 = string.Empty;
label_76:
        textBox25.Text = str17;
        List<string> list = xdocument.Elements((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Elements<XElement>((XName) \u003CModule\u003E.smethod_5<string>(4195060303U)).Select<XElement, string>((Func<XElement, string>) (class29_0 => class29_0.Value)).ToList<string>();
        foreach (Button button in this.groupBox_53.Controls.OfType<Button>())
        {
          if (button != null && list.Contains(button.Name))
          {
            if (this.tabControl_2.SelectedTab != this.tabControl_2.TabPages[\u003CModule\u003E.smethod_8<string>(4269071407U)])
              this.tabControl_2.SelectedTab = this.tabPage_13;
            button.PerformClick();
          }
        }
        foreach (XElement descendant in xdocument.Descendants((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Descendants<XElement>((XName) \u003CModule\u003E.smethod_7<string>(573412570U)))
        {
          string str18 = descendant.Element((XName) \u003CModule\u003E.smethod_9<string>(4013629717U)).Value;
          if (str18 == \u003CModule\u003E.smethod_7<string>(3773643670U))
            this.button_59_Click(new object(), new EventArgs());
          else if (str18 == \u003CModule\u003E.smethod_9<string>(1954306945U))
          {
            this.button_58_Click(new object(), new EventArgs());
          }
          else
          {
            this.textBox_19.Text = str18;
            this.button_60_Click(new object(), new EventArgs());
          }
          Control3 control3 = this.tabControl_1.TabPages[this.tabControl_1.TabPages.Count - 2].Controls.OfType<Control3>().First<Control3>();
          control3.checkBox_0.Checked = Convert.ToBoolean(descendant.Element((XName) control3.checkBox_0.Name).Value);
          control3.comboBox_0.Text = descendant.Element((XName) control3.comboBox_0.Name).Value;
          control3.checkBox_3.Checked = Convert.ToBoolean(descendant.Element((XName) control3.checkBox_3.Name).Value);
          control3.comboBox_1.Text = descendant.Element((XName) control3.comboBox_1.Name).Value;
          control3.checkBox_4.Checked = Convert.ToBoolean(descendant.Element((XName) control3.checkBox_4.Name).Value);
          control3.comboBox_2.Text = descendant.Element((XName) control3.comboBox_2.Name).Value;
          control3.numericUpDown_0.Value = (Decimal) Convert.ToInt32(descendant.Element((XName) control3.numericUpDown_0.Name).Value);
          control3.checkBox_1.Checked = Convert.ToBoolean(descendant.Element((XName) control3.checkBox_1.Name).Value);
          control3.checkBox_2.Checked = Convert.ToBoolean(descendant.Element((XName) control3.checkBox_2.Name).Value);
          control3.checkBox_5.Checked = Convert.ToBoolean(descendant.Element((XName) control3.checkBox_5.Name).Value);
          control3.checkBox_8.Checked = Convert.ToBoolean(descendant.Element((XName) control3.checkBox_8.Name).Value);
          control3.checkBox_6.Checked = Convert.ToBoolean(descendant.Element((XName) control3.checkBox_6.Name).Value);
          control3.checkBox_7.Checked = Convert.ToBoolean(descendant.Element((XName) control3.checkBox_7.Name).Value);
          control3.checkBox_9.Checked = Convert.ToBoolean(descendant.Element((XName) control3.checkBox_9.Name).Value);
          control3.textBox_0.Text = descendant.Element((XName) control3.textBox_0.Name).Value;
          control3.radioButton_3.Checked = Convert.ToBoolean(descendant.Element((XName) control3.radioButton_3.Name).Value);
          control3.radioButton_0.Checked = Convert.ToBoolean(descendant.Element((XName) control3.radioButton_0.Name).Value);
          control3.radioButton_1.Checked = Convert.ToBoolean(descendant.Element((XName) control3.radioButton_1.Name).Value);
          control3.radioButton_2.Checked = Convert.ToBoolean(descendant.Element((XName) control3.radioButton_2.Name).Value);
        }
        foreach (XElement descendant in xdocument.Descendants((XName) \u003CModule\u003E.smethod_6<string>(3246925218U)).Descendants<XElement>((XName) \u003CModule\u003E.smethod_9<string>(3582248379U)))
        {
          string str19 = descendant.Element((XName) \u003CModule\u003E.smethod_7<string>(299728521U)).Value;
          if (str19 == \u003CModule\u003E.smethod_7<string>(3008576515U))
          {
            this.button_62_Click(new object(), new EventArgs());
          }
          else
          {
            this.textBox_20.Text = str19;
            this.button_61_Click(new object(), new EventArgs());
          }
          Control4 control4 = this.tabControl_0.TabPages[this.tabControl_0.TabPages.Count - 1].Controls.OfType<Control4>().First<Control4>();
          control4.checkBox_11.Checked = Convert.ToBoolean(descendant.Element((XName) control4.checkBox_11.Name).Value);
          control4.comboBox_3.Text = descendant.Element((XName) control4.comboBox_3.Name).Value;
          control4.checkBox_12.Checked = Convert.ToBoolean(descendant.Element((XName) control4.checkBox_12.Name).Value);
          control4.comboBox_4.Text = descendant.Element((XName) control4.comboBox_4.Name).Value;
          control4.checkBox_10.Checked = Convert.ToBoolean(descendant.Element((XName) control4.checkBox_10.Name).Value);
          control4.comboBox_2.Text = descendant.Element((XName) control4.comboBox_2.Name).Value;
          control4.checkBox_13.Checked = Convert.ToBoolean(descendant.Element((XName) control4.checkBox_13.Name).Value);
          control4.comboBox_5.Text = descendant.Element((XName) control4.comboBox_5.Name).Value;
          control4.checkBox_14.Checked = Convert.ToBoolean(descendant.Element((XName) control4.checkBox_14.Name).Value);
          control4.checkBox_15.Checked = Convert.ToBoolean(descendant.Element((XName) control4.checkBox_15.Name).Value);
          control4.checkBox_0.Checked = Convert.ToBoolean(descendant.Element((XName) control4.checkBox_0.Name).Value);
          control4.comboBox_0.Text = descendant.Element((XName) control4.comboBox_0.Name).Value;
          control4.checkBox_1.Checked = Convert.ToBoolean(descendant.Element((XName) control4.checkBox_1.Name).Value);
          control4.comboBox_1.Text = descendant.Element((XName) control4.comboBox_1.Name).Value;
          control4.radioButton_4.Checked = Convert.ToBoolean(descendant.Element((XName) control4.radioButton_4.Name).Value);
          control4.radioButton_2.Checked = Convert.ToBoolean(descendant.Element((XName) control4.radioButton_2.Name).Value);
          control4.radioButton_0.Checked = Convert.ToBoolean(descendant.Element((XName) control4.radioButton_0.Name).Value);
          control4.radioButton_1.Checked = Convert.ToBoolean(descendant.Element((XName) control4.radioButton_1.Name).Value);
          control4.radioButton_3.Checked = Convert.ToBoolean(descendant.Element((XName) control4.radioButton_3.Name).Value);
          control4.radioButton_5.Checked = Convert.ToBoolean(descendant.Element((XName) control4.radioButton_5.Name).Value);
          control4.checkBox_8.Checked = Convert.ToBoolean(descendant.Element((XName) control4.checkBox_8.Name).Value);
          CheckBox checkBox4 = control4.checkBox_4;
          XElement xelement17 = descendant.Element((XName) control4.checkBox_4.Name);
          string str20;
          if (xelement17 == null)
          {
            str20 = (string) null;
          }
          else
          {
            str20 = xelement17.Value;
            if (str20 != null)
              goto label_107;
          }
          str20 = \u003CModule\u003E.smethod_7<string>(819104123U);
label_107:
          int num12 = Convert.ToBoolean(str20) ? 1 : 0;
          checkBox4.Checked = num12 != 0;
          CheckBox checkBox6 = control4.checkBox_6;
          XElement xelement18 = descendant.Element((XName) control4.checkBox_6.Name);
          string str21;
          if (xelement18 == null)
          {
            str21 = (string) null;
          }
          else
          {
            str21 = xelement18.Value;
            if (str21 != null)
              goto label_111;
          }
          str21 = \u003CModule\u003E.smethod_6<string>(2322283525U);
label_111:
          int num13 = Convert.ToBoolean(str21) ? 1 : 0;
          checkBox6.Checked = num13 != 0;
          CheckBox checkBox3 = control4.checkBox_3;
          XElement xelement19 = descendant.Element((XName) control4.checkBox_3.Name);
          string str22;
          if (xelement19 == null)
          {
            str22 = (string) null;
          }
          else
          {
            str22 = xelement19.Value;
            if (str22 != null)
              goto label_115;
          }
          str22 = \u003CModule\u003E.smethod_8<string>(347236309U);
label_115:
          int num14 = Convert.ToBoolean(str22) ? 1 : 0;
          checkBox3.Checked = num14 != 0;
          CheckBox checkBox5 = control4.checkBox_5;
          XElement xelement20 = descendant.Element((XName) control4.checkBox_5.Name);
          string str23;
          if (xelement20 == null)
          {
            str23 = (string) null;
          }
          else
          {
            str23 = xelement20.Value;
            if (str23 != null)
              goto label_119;
          }
          str23 = \u003CModule\u003E.smethod_8<string>(347236309U);
label_119:
          int num15 = Convert.ToBoolean(str23) ? 1 : 0;
          checkBox5.Checked = num15 != 0;
          CheckBox checkBox9 = control4.checkBox_9;
          XElement xelement21 = descendant.Element((XName) control4.checkBox_9.Name);
          string str24;
          if (xelement21 == null)
          {
            str24 = (string) null;
          }
          else
          {
            str24 = xelement21.Value;
            if (str24 != null)
              goto label_123;
          }
          str24 = \u003CModule\u003E.smethod_8<string>(347236309U);
label_123:
          int num16 = Convert.ToBoolean(str24) ? 1 : 0;
          checkBox9.Checked = num16 != 0;
          NumericUpDown numericUpDown0 = control4.numericUpDown_0;
          XElement xelement22 = descendant.Element((XName) control4.numericUpDown_0.Name);
          string str25;
          if (xelement22 == null)
          {
            str25 = (string) null;
          }
          else
          {
            str25 = xelement22.Value;
            if (str25 != null)
              goto label_127;
          }
          str25 = \u003CModule\u003E.smethod_9<string>(836484683U);
label_127:
          Decimal num17 = Convert.ToDecimal(str25);
          numericUpDown0.Value = num17;
          CheckBox checkBox7 = control4.checkBox_7;
          XElement xelement23 = descendant.Element((XName) control4.checkBox_7.Name);
          string str26;
          if (xelement23 == null)
          {
            str26 = (string) null;
          }
          else
          {
            str26 = xelement23.Value;
            if (str26 != null)
              goto label_131;
          }
          str26 = \u003CModule\u003E.smethod_9<string>(2895807455U);
label_131:
          int num18 = Convert.ToBoolean(str26) ? 1 : 0;
          checkBox7.Checked = num18 != 0;
          foreach (XElement element in descendant.Elements((XName) control4.listBox_1.Name))
            control4.listBox_1.Items.Add((object) element.Value);
          if (!control4.class177_0.Boolean_0)
            control4.comboBox_5.Text = \u003CModule\u003E.smethod_8<string>(3574983891U);
        }
        this.checkBox_71.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Element((XName) this.checkBox_71.Name)?.Value);
        this.checkBox_37.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Element((XName) this.checkBox_37.Name)?.Value);
        this.checkBox_67.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_6<string>(3246925218U)).Element((XName) this.checkBox_67.Name)?.Value);
        this.comboBox_3.Text = xdocument.Element((XName) \u003CModule\u003E.smethod_6<string>(3246925218U)).Element((XName) this.comboBox_3.Name)?.Value;
        this.textBox_15.Text = xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.textBox_15.Name)?.Value;
        this.checkBox_70.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.checkBox_70.Name)?.Value);
        this.numericUpDown_19.Value = (Decimal) Convert.ToInt32(xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.numericUpDown_19.Name)?.Value);
        this.checkBox_35.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.checkBox_35.Name)?.Value);
        foreach (XElement element in xdocument.Elements((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Elements<XElement>((XName) this.listBox_4.Name))
          this.listBox_4.Items.Add((object) element.Value);
        this.checkBox_36.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Element((XName) this.checkBox_36.Name)?.Value);
        foreach (XElement element in xdocument.Elements((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Elements<XElement>((XName) this.textBox_6.Name))
          this.textBox_6.AppendText(element.Value + \u003CModule\u003E.smethod_8<string>(293743756U));
        foreach (XElement element in xdocument.Elements((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Elements<XElement>((XName) this.textBox_5.Name))
          this.textBox_5.AppendText(element.Value + \u003CModule\u003E.smethod_6<string>(3694902820U));
        foreach (XElement element in xdocument.Elements((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Elements<XElement>((XName) this.textBox_4.Name))
          this.textBox_4.AppendText(element.Value + \u003CModule\u003E.smethod_5<string>(1797382428U));
        foreach (XElement element in xdocument.Elements((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Elements<XElement>((XName) this.textBox_3.Name))
          this.textBox_3.AppendText(element.Value + \u003CModule\u003E.smethod_6<string>(3694902820U));
        if (((IEnumerable<string>) this.textBox_6.Lines).Count<string>() > 0)
          this.textBox_6.Lines = ((IEnumerable<string>) this.textBox_6.Lines).Take<string>(((IEnumerable<string>) this.textBox_6.Lines).Count<string>() - 1).ToArray<string>();
        if (((IEnumerable<string>) this.textBox_5.Lines).Count<string>() > 0)
          this.textBox_5.Lines = ((IEnumerable<string>) this.textBox_5.Lines).Take<string>(((IEnumerable<string>) this.textBox_5.Lines).Count<string>() - 1).ToArray<string>();
        if (((IEnumerable<string>) this.textBox_4.Lines).Count<string>() > 0)
          this.textBox_4.Lines = ((IEnumerable<string>) this.textBox_4.Lines).Take<string>(((IEnumerable<string>) this.textBox_4.Lines).Count<string>() - 1).ToArray<string>();
        if (((IEnumerable<string>) this.textBox_3.Lines).Count<string>() > 0)
          this.textBox_3.Lines = ((IEnumerable<string>) this.textBox_3.Lines).Take<string>(((IEnumerable<string>) this.textBox_3.Lines).Count<string>() - 1).ToArray<string>();
        this.button_13.Text = xdocument.Element((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Element((XName) this.button_13.Name)?.Value;
        this.button_12.Text = xdocument.Element((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Element((XName) this.button_12.Name)?.Value;
        this.button_11.Text = xdocument.Element((XName) \u003CModule\u003E.smethod_9<string>(2884707664U)).Element((XName) this.button_11.Name)?.Value;
        this.button_10.Text = xdocument.Element((XName) \u003CModule\u003E.smethod_6<string>(3246925218U)).Element((XName) this.button_10.Name)?.Value;
        this.class29_0.bool_8 = this.button_13.Text.Contains(\u003CModule\u003E.smethod_7<string>(2099785200U));
        this.class29_0.bool_9 = this.button_12.Text.Contains(\u003CModule\u003E.smethod_5<string>(3530897020U));
        this.class29_0.bool_10 = this.button_11.Text.Contains(\u003CModule\u003E.smethod_7<string>(2099785200U));
        this.class29_0.bool_11 = this.button_10.Text.Contains(\u003CModule\u003E.smethod_6<string>(2384646980U));
        this.checkBox_7.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Element((XName) this.checkBox_7.Name)?.Value);
        this.checkBox_6.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_8<string>(3119639354U)).Element((XName) this.checkBox_6.Name)?.Value);
        this.checkBox_5.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_9<string>(2884707664U)).Element((XName) this.checkBox_5.Name)?.Value);
        this.checkBox_4.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_9<string>(2884707664U)).Element((XName) this.checkBox_4.Name)?.Value);
        this.checkBox_66.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_7<string>(3014817426U)).Element((XName) this.checkBox_66.Name)?.Value);
        this.checkBox_65.Checked = Convert.ToBoolean(xdocument.Element((XName) \u003CModule\u003E.smethod_5<string>(3532794522U)).Element((XName) this.checkBox_65.Name)?.Value);
      }
      catch (Exception ex)
      {
      }
      this.bool_1 = false;
      if (!(this.toolStripMenuItem_2.Text == \u003CModule\u003E.smethod_7<string>(1365922600U)))
        return;
      this.class29_0.Class25_0.method_0();
    }
    finally
    {
      Monitor.Exit(Class112.object_0);
    }
  }

  private void method_12(string sender)
  {
    try
    {
      string path = Settings.Default.DarkAgesPath.Replace(\u003CModule\u003E.smethod_9<string>(3055597324U), this.class29_0.String_0 + \u003CModule\u003E.smethod_6<string>(1176276428U) + sender + \u003CModule\u003E.smethod_7<string>(1400705628U));
      if (File.Exists(path))
        File.Delete(path);
      if (!this.list_1.Contains<string>(sender, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase))
        return;
      this.list_1.Remove(sender);
    }
    catch
    {
    }
  }

  private void checkBox_20_CheckedChanged([In] object obj0, EventArgs e)
  {
    this.class29_0.method_66(this.class29_0.Class143_0);
    if ((obj0 as CheckBox).Checked)
      return;
    this.class29_0.method_105(false);
    Class180 stream_1 = new Class180(Enum14.DMUResponse);
    stream_1.method_27(this.class29_0.String_0);
    stream_1.method_19(false);
    this.class29_0.Class112_0.form5_0.class178_0.method_2(stream_1);
  }

  private void numericUpDown_17_ValueChanged([In] object obj0, EventArgs e) => this.class29_0.method_66(this.class29_0.Class143_0);

  private void numericUpDown_16_ValueChanged([In] object obj0, EventArgs e) => this.class29_0.method_66(this.class29_0.Class143_0);

  private void numericUpDown_15_ValueChanged([In] object obj0, EventArgs e) => this.class29_0.method_66(this.class29_0.Class143_0);

  private void numericUpDown_14_ValueChanged([In] object obj0, EventArgs e) => this.class29_0.method_66(this.class29_0.Class143_0);

  private void numericUpDown_11_ValueChanged([In] object obj0, EventArgs e) => this.class29_0.method_66(this.class29_0.Class143_0);

  private void numericUpDown_13_ValueChanged([In] object obj0, EventArgs e) => this.class29_0.method_66(this.class29_0.Class143_0);

  private void numericUpDown_12_ValueChanged([In] object obj0, EventArgs e) => this.class29_0.method_66(this.class29_0.Class143_0);

  private void numericUpDown_10_ValueChanged([In] object obj0, EventArgs e) => this.class29_0.method_66(this.class29_0.Class143_0);

  private void numericUpDown_9_ValueChanged([In] object obj0, EventArgs e) => this.class29_0.method_66(this.class29_0.Class143_0);

  private void numericUpDown_7_ValueChanged([In] object obj0, EventArgs e) => this.class29_0.method_66(this.class29_0.Class143_0);

  private void numericUpDown_5_ValueChanged([In] object obj0, EventArgs e) => this.class29_0.method_66(this.class29_0.Class143_0);

  private void numericUpDown_8_ValueChanged([In] object obj0, EventArgs e) => this.class29_0.method_66(this.class29_0.Class143_0);

  private void numericUpDown_6_ValueChanged([In] object obj0, EventArgs e) => this.class29_0.method_66(this.class29_0.Class143_0);

  private void numericUpDown_4_ValueChanged([In] object obj0, EventArgs e) => this.class29_0.method_66(this.class29_0.Class143_0);

  private bool method_13([In] string obj0)
  {
    if (string.IsNullOrEmpty(obj0))
    {
      int num = (int) Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_6<string>(3280773062U), (IWin32Window) null, true);
      return false;
    }
    if (!obj0.All<char>(new Func<char, bool>(char.IsLetter)))
    {
      int num = (int) Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_7<string>(1036803180U), (IWin32Window) null, true);
      return false;
    }
    if (this.class29_0.Class26_0.method_44(obj0))
    {
      int num = (int) Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_5<string>(3655630727U), (IWin32Window) null, true);
      return false;
    }
    if (!obj0.Equals(this.class29_0.String_0, StringComparison.CurrentCultureIgnoreCase))
      return true;
    int num1 = (int) Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_6<string>(1731044356U), (IWin32Window) null, true);
    return false;
  }

  private bool method_14(ushort sender)
  {
    if (sender >= (ushort) 1 && sender <= (ushort) 1000)
    {
      if (!this.class29_0.Class26_0.method_41(sender) && this.class29_0.Class26_0.control4_0 == null)
        return true;
      int num = (int) Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_8<string>(2587345170U), (IWin32Window) null, true);
      this.textBox_20.Clear();
      return false;
    }
    int num1 = (int) Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_5<string>(4150306342U), (IWin32Window) null, true);
    this.textBox_20.Clear();
    return false;
  }

  private void button_60_Click([In] object obj0, EventArgs e)
  {
    string text = this.textBox_19.Text;
    if (!this.bool_1 && !this.method_13(text))
      return;
    this.method_15(text, (Image) null);
    this.textBox_19.Clear();
    if (this.bool_1 || Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_6<string>(2121734419U), (IWin32Window) null, true) != DialogResult.OK)
      return;
    this.tabControl_1.SelectTab(this.tabControl_1.TabPages.IndexOfKey(text));
    this.tabControl_2.SelectTab(1);
  }

  private void button_61_Click([In] object obj0, EventArgs e)
  {
    ushort result;
    if ((!ushort.TryParse(this.textBox_20.Text, out result) || !this.bool_1) && !this.method_14(result))
      return;
    this.method_16(result);
    this.textBox_20.Clear();
    if (this.bool_1 || Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_5<string>(1777861867U), (IWin32Window) null, true) != DialogResult.OK)
      return;
    this.tabControl_0.SelectTab(this.tabControl_0.TabPages.IndexOfKey(result.ToString()));
    this.tabControl_2.SelectTab(2);
  }

  private void button_66_Click([In] object obj0, EventArgs e)
  {
  }

  private void button_62_Click([In] object obj0, EventArgs e)
  {
    if (!this.bool_1 && this.class29_0.Class26_0.control4_0 != null)
    {
      int num = (int) Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_8<string>(2587345170U), (IWin32Window) null, true);
    }
    else
    {
      Control4 control4 = new Control4(new Class177(\u003CModule\u003E.smethod_6<string>(3978802557U)), this.class29_0);
      control4.pictureBox_0.Visible = false;
      control4.groupBox_5.Visible = true;
      control4.checkBox_3.Visible = true;
      control4.groupBox_4.Visible = true;
      TabPage tabPage = new TabPage(\u003CModule\u003E.smethod_6<string>(3978802557U));
      tabPage.Controls.Add((Control) control4);
      this.method_39();
      this.tabControl_0.TabPages.Remove(this.tabPage_8);
      while (this.tabControl_0.TabPages.Count > 0)
        this.tabControl_0.TabPages[0]?.Dispose();
      foreach (object obj in this.class29_0.Class26_0.method_3())
        this.class29_0.Class26_0.method_40(obj.ToString());
      this.tabControl_0.TabPages.Add(tabPage);
      foreach (Class142 class142 in this.class29_0.method_119(12))
      {
        if (!this.class29_0.Class26_0.method_41(class142.UInt16_0))
          this.class29_0.Class26_0.method_39(new Class177(class142.UInt16_0)
          {
            Control4_0 = control4
          });
      }
      if (!this.bool_1 && Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_5<string>(1777861867U), (IWin32Window) null, true) == DialogResult.OK)
      {
        this.tabControl_2.SelectTab(2);
        this.tabControl_0.SelectTab(tabPage);
      }
      this.class29_0.Class26_0.control4_0 = control4;
    }
  }

  internal void method_15([In] string obj0, Image e)
  {
    if (this.class29_0.Class26_0.method_44(obj0))
      return;
    Class145 class142_4 = new Class145(obj0);
    class142_4.Control3_0 = new Control3(class142_4, this.class29_0);
    TabPage tabPage1 = new TabPage(((object) class142_4).ToString());
    tabPage1.Name = obj0;
    TabPage tabPage2 = tabPage1;
    tabPage2.Controls.Add((Control) class142_4.Control3_0);
    class142_4.Control3_0.pictureBox_0.Image = e;
    this.tabControl_1.TabPages.Add(tabPage2);
    this.method_34(obj0);
    this.method_36();
    this.class29_0.Class26_0.method_42(class142_4);
  }

  internal void method_16(ushort sender)
  {
    if (this.class29_0.Class26_0.method_41(sender))
      return;
    Class177 class177 = new Class177(sender);
    class177.Control4_0 = new Control4(class177, this.class29_0);
    TabPage tabPage1 = new TabPage(sender.ToString());
    tabPage1.Name = sender.ToString();
    TabPage tabPage2 = tabPage1;
    tabPage2.Controls.Add((Control) class177.Control4_0);
    this.tabControl_0.TabPages.Add(tabPage2);
    this.method_35(sender);
    this.method_37();
    this.class29_0.Class26_0.method_39(class177);
  }

  internal void method_17([In] Color obj0, string e)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Control2.Class48 class48 = new Control2.Class48();
    // ISSUE: reference to a compiler-generated field
    class48.control2_0 = this;
    // ISSUE: reference to a compiler-generated field
    class48.color_0 = obj0;
    // ISSUE: reference to a compiler-generated field
    class48.string_0 = e;
    if (this.InvokeRequired)
    {
      // ISSUE: reference to a compiler-generated method
      this.Invoke((Delegate) new Action(class48.method_0));
    }
    else
    {
      if (this.gclass25_0.TextLength != 0)
      {
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        class48.string_0 = Environment.NewLine + class48.string_0;
      }
      MatchCollection matchCollection;
      // ISSUE: reference to a compiler-generated field
      if ((matchCollection = Regex.Matches(class48.string_0, \u003CModule\u003E.smethod_5<string>(987047042U))).Count > 0)
      {
        foreach (Match match in matchCollection)
        {
          if (match.Success)
          {
            foreach (Group group in match.Groups)
            {
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              class48.string_0 = class48.string_0.Replace(group.Value, "");
            }
          }
        }
      }
      int length = this.gclass25_0.Text.Length;
      bool flag = this.gclass25_0.method_8();
      // ISSUE: reference to a compiler-generated field
      this.method_18(class48.color_0);
      Match match1;
      string str;
      string[] strArray;
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      for (; (match1 = Regex.Match(class48.string_0, \u003CModule\u003E.smethod_9<string>(4062421676U))).Success || (match1 = Regex.Match(class48.string_0, \u003CModule\u003E.smethod_9<string>(4189951469U))).Success; class48.string_0 = class48.string_0.Replace(strArray[0] + str, ""))
      {
        str = match1.Groups[1].Value;
        // ISSUE: reference to a compiler-generated field
        strArray = class48.string_0.Split(new string[1]
        {
          str
        }, StringSplitOptions.None);
        this.gclass25_0.AppendText(strArray[0]);
        if (!str.StartsWith(\u003CModule\u003E.smethod_8<string>(2326460770U)) && !str.StartsWith(\u003CModule\u003E.smethod_7<string>(216947815U), StringComparison.CurrentCultureIgnoreCase) && !str.StartsWith(\u003CModule\u003E.smethod_6<string>(4280211683U), StringComparison.CurrentCultureIgnoreCase) && !str.StartsWith(\u003CModule\u003E.smethod_5<string>(414309516U), StringComparison.CurrentCultureIgnoreCase))
          this.gclass25_0.method_2(str, \u003CModule\u003E.smethod_7<string>(216947815U) + str);
        else
          this.gclass25_0.method_2(str, str);
      }
      // ISSUE: reference to a compiler-generated field
      if (!string.IsNullOrWhiteSpace(class48.string_0))
      {
        // ISSUE: reference to a compiler-generated field
        this.gclass25_0.AppendText(class48.string_0);
      }
      this.method_18(this.gclass25_0.ForeColor);
      if (!flag)
        return;
      this.gclass25_0.ScrollToCaret();
    }
  }

  internal void method_18(Color class100_0)
  {
    this.gclass25_0.SelectionStart = this.gclass25_0.TextLength;
    this.gclass25_0.SelectionLength = 0;
    this.gclass25_0.SelectionColor = class100_0;
  }

  private void gclass25_0_LinkClicked(object sender, LinkClickedEventArgs e) => Process.Start(((IEnumerable<string>) e.LinkText.Split('#')).Last<string>());

  internal void method_19()
  {
    this.label_53.ForeColor = this.class29_0.UInt32_7 > 4250000000U ? Color.Red : Color.Black;
    Label label53 = this.label_53;
    string str1 = \u003CModule\u003E.smethod_8<string>(2272968217U);
    double num1 = Math.Truncate((double) this.class29_0.UInt32_7);
    string str2 = num1.ToString(\u003CModule\u003E.smethod_8<string>(3286695378U));
    string str3 = str1 + str2;
    label53.Text = str3;
    Label label59 = this.label_59;
    string str4 = \u003CModule\u003E.smethod_7<string>(518624360U);
    num1 = Math.Truncate((double) this.ulong_0);
    string str5 = num1.ToString(\u003CModule\u003E.smethod_7<string>(1065992458U));
    string str6 = str4 + str5;
    label59.Text = str6;
    TimeSpan elapsed;
    if (this.stopwatch_0.IsRunning)
    {
      Label label58 = this.label_58;
      string str7 = \u003CModule\u003E.smethod_7<string>(1585368060U);
      double ulong0 = (double) this.ulong_0;
      elapsed = this.stopwatch_0.Elapsed;
      double totalHours = elapsed.TotalHours;
      num1 = Math.Truncate(ulong0 / totalHours);
      string str8 = num1.ToString(\u003CModule\u003E.smethod_5<string>(350034994U));
      string str9 = str7 + str8;
      label58.Text = str9;
    }
    else if (this.ulong_0 > 0UL)
      this.stopwatch_0.Start();
    if (this.class29_0.UInt32_9 < this.uint_2)
    {
      this.uint_2 = this.class29_0.UInt32_9;
      this.uint_0 = 0U;
      this.stopwatch_1.Reset();
    }
    else if (this.uint_0 == 0U)
    {
      this.uint_0 = this.class29_0.UInt32_9;
      this.stopwatch_1.Start();
    }
    else if (this.stopwatch_1.IsRunning)
    {
      Label label55 = this.label_55;
      string str10 = \u003CModule\u003E.smethod_8<string>(1552792261U);
      double num2 = (double) (this.class29_0.UInt32_9 - this.uint_0);
      elapsed = this.stopwatch_1.Elapsed;
      double totalHours = elapsed.TotalHours;
      num1 = Math.Truncate(num2 / totalHours);
      string str11 = num1.ToString(\u003CModule\u003E.smethod_5<string>(350034994U));
      string str12 = str10 + str11;
      label55.Text = str12;
    }
    if (this.class29_0.UInt32_12 < this.uint_3)
    {
      this.uint_3 = this.class29_0.UInt32_12;
      this.uint_1 = 0U;
      this.stopwatch_2.Reset();
    }
    else if (this.uint_1 == 0U)
    {
      this.uint_1 = this.class29_0.UInt32_12;
      this.stopwatch_2.Start();
    }
    else
    {
      if (!this.stopwatch_2.IsRunning)
        return;
      Label label54 = this.label_54;
      string str13 = \u003CModule\u003E.smethod_6<string>(529604166U);
      double num3 = (double) (this.class29_0.UInt32_12 - this.uint_1);
      elapsed = this.stopwatch_2.Elapsed;
      double totalHours = elapsed.TotalHours;
      num1 = Math.Truncate(num3 / totalHours);
      string str14 = num1.ToString(\u003CModule\u003E.smethod_8<string>(3286695378U));
      string str15 = str13 + str14;
      label54.Text = str15;
    }
  }

  private void button_65_Click(object sender, EventArgs e)
  {
    this.label_59.Text = \u003CModule\u003E.smethod_9<string>(1519572109U);
    this.label_58.Text = \u003CModule\u003E.smethod_8<string>(3308836799U);
    this.ulong_0 = 0UL;
    this.uint_0 = 0U;
    this.uint_1 = 0U;
    this.stopwatch_0.Reset();
    this.stopwatch_1.Reset();
    this.stopwatch_2.Reset();
  }

  internal void method_20()
  {
    this.label_47.Text = this.class29_0.UInt32_5.ToString();
    this.label_46.Text = this.class29_0.UInt32_6.ToString();
    this.class28_1.Value = this.class29_0.Int32_2;
    this.class28_0.Value = this.class29_0.Int32_3;
  }

  internal void method_21(Class88 sender) => this.label_45.Text = \u003CModule\u003E.smethod_9<string>(867234248U) + this.class29_0.Struct16_1.ToString() + \u003CModule\u003E.smethod_7<string>(434646872U) + sender.Byte_0.ToString() + \u003CModule\u003E.smethod_5<string>(819477209U) + sender.Byte_1.ToString() + \u003CModule\u003E.smethod_9<string>(994764041U) + sender.Int16_0.ToString();

  internal void method_22([In] Class139 obj0)
  {
    this.label_52.Text = \u003CModule\u003E.smethod_6<string>(4256771988U) + obj0.Int32_0.ToString();
    this.label_50.Text = obj0.String_0 ?? "";
    if (!(obj0 is Class140))
      return;
    this.label_48.Text = \u003CModule\u003E.smethod_9<string>(3733017051U) + (obj0 as Class140).UInt16_0.ToString();
  }

  internal void method_23()
  {
    lock (this.object_0)
    {
      DateTime utcNow;
      if (this.class29_0.method_23(\u003CModule\u003E.smethod_6<string>(1387062805U)))
      {
        utcNow = DateTime.UtcNow;
        if (utcNow.Subtract(this.class29_0.Class133_0[\u003CModule\u003E.smethod_8<string>(566019173U)].DateTime_0).TotalMilliseconds < 1500.0)
          return;
      }
      if (this.class29_0.method_22(\u003CModule\u003E.smethod_5<string>(2178750014U)))
      {
        utcNow = DateTime.UtcNow;
        if (utcNow.Subtract(this.class29_0.Class21_0.method_2(\u003CModule\u003E.smethod_9<string>(1142886036U)).DateTime_0).TotalMilliseconds < 1500.0)
          return;
      }
      List<string> list1 = this.class29_0.method_125().Select<Class143, string>((Func<Class143, string>) (obj0 => obj0.String_5)).ToList<string>();
      List<string> list2 = this.class29_0.HashSet_3.Concat<string>((IEnumerable<string>) this.class29_0.Class112_0.form5_0.bindingList_0).ToList<string>();
      foreach (string str in new List<string>((IEnumerable<string>) this.bindingList_1))
      {
        if (list2.Contains<string>(str, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase) || !list1.Contains<string>(str, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase))
          this.bindingList_1.Remove(str);
      }
      foreach (string str in list1)
      {
        if (!list2.Contains<string>(str, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase) && !this.bindingList_1.Contains<string>(str, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase))
          this.method_8(this.bindingList_1, this.listBox_7, str);
      }
      foreach (string key in new List<string>((IEnumerable<string>) this.bindingList_1))
      {
        if (!string.IsNullOrEmpty(key))
          this.dictionary_0[key] = DateTime.UtcNow;
      }
      this.dictionary_0 = this.dictionary_0.OrderByDescending<KeyValuePair<string, DateTime>, DateTime>((Func<KeyValuePair<string, DateTime>, DateTime>) (obj0 => obj0.Value)).Take<KeyValuePair<string, DateTime>>(5).ToDictionary<KeyValuePair<string, DateTime>, string, DateTime>((Func<KeyValuePair<string, DateTime>, string>) (class29_0 => class29_0.Key), (Func<KeyValuePair<string, DateTime>, DateTime>) (obj0 => obj0.Value));
    }
  }

  internal void method_24()
  {
    Thread.Sleep(1600);
    this.method_23();
  }

  private void method_25()
  {
    try
    {
      string path = AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_9<string>(1553675172U);
      XmlWriterSettings settings = new XmlWriterSettings()
      {
        Indent = true
      };
      using (XmlWriter xmlWriter = XmlWriter.Create((Stream) File.Create(path), settings))
      {
        xmlWriter.WriteStartDocument();
        xmlWriter.WriteStartElement(\u003CModule\u003E.smethod_6<string>(2814517120U));
        for (int index = 0; index <= this.class29_0.Class112_0.form5_0.bindingList_0.Count - 1; ++index)
          xmlWriter.WriteElementString(\u003CModule\u003E.smethod_9<string>(3534260110U), this.class29_0.Class112_0.form5_0.bindingList_0[index]);
        xmlWriter.WriteEndElement();
        xmlWriter.WriteEndDocument();
      }
    }
    catch
    {
    }
  }

  internal void method_26()
  {
    try
    {
      string str = AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_7<string>(4182246070U);
      if (!File.Exists(str))
        return;
      using (XmlReader xmlReader = XmlReader.Create(str))
      {
        int content = (int) xmlReader.MoveToContent();
        while (xmlReader.Read())
        {
          if (xmlReader.Name == \u003CModule\u003E.smethod_5<string>(1417468468U) && xmlReader.Read() && Regex.IsMatch(xmlReader.Value, \u003CModule\u003E.smethod_7<string>(188955319U)) && !this.class29_0.Class112_0.form5_0.bindingList_0.Contains<string>(xmlReader.Value, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase))
            this.method_8(this.class29_0.Class112_0.form5_0.bindingList_0, this.listBox_6, xmlReader.Value);
        }
      }
    }
    catch
    {
    }
  }

  internal void method_27()
  {
    this.listBox_8.DataSource = (object) null;
    this.bindingList_2 = new BindingList<string>((IList<string>) this.class29_0.HashSet_3.ToList<string>());
    this.listBox_8.DataSource = (object) this.bindingList_2;
  }

  private void button_55_Click(object sender, EventArgs e)
  {
    foreach (string class142_0 in this.listBox_7.SelectedItems.OfType<string>().ToList<string>())
      this.class29_0.method_113(class142_0);
  }

  private void button_57_Click(object sender, EventArgs e)
  {
    foreach (string class142_0 in this.listBox_8.SelectedItems.OfType<string>().ToList<string>())
      this.class29_0.method_113(class142_0);
  }

  private void button_50_Click(object sender, EventArgs e)
  {
    BindingList<string> bindingList0 = this.class29_0.Class112_0.form5_0.bindingList_0;
    foreach (Class29 class29 in this.class29_0.Class112_0.IEnumerable_0)
    {
      if (!bindingList0.Contains<string>(class29.String_0, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase))
        bindingList0.Add(class29.String_0);
      if (this.bindingList_1.Contains<string>(class29.String_0, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase))
        this.bindingList_1.Remove(class29.String_0);
    }
    this.method_25();
    this.method_26();
  }

  private void button_51_Click(object class143_0, [In] EventArgs obj1)
  {
    foreach (string selectedItem in this.listBox_6.SelectedItems)
      this.class29_0.method_113(selectedItem);
  }

  private void button_54_Click(object string_4, [In] EventArgs obj1)
  {
    foreach (string str in this.listBox_7.SelectedItems.OfType<string>().ToList<string>())
    {
      if (this.method_13(str))
      {
        this.method_15(str, (Image) null);
        if (Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_6<string>(2121734419U), (IWin32Window) null, true) == DialogResult.OK)
        {
          this.tabControl_1.SelectTab(this.tabControl_1.TabCount - 2);
          this.tabControl_2.SelectTab(1);
        }
      }
    }
  }

  private void button_49_Click(object sender, EventArgs e)
  {
    foreach (string str in this.listBox_6.SelectedItems.OfType<string>().ToList<string>())
    {
      if (this.method_13(str))
      {
        this.method_15(str, (Image) null);
        if (Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_5<string>(1777861867U), (IWin32Window) null, true) == DialogResult.OK)
        {
          this.tabControl_1.SelectTab(this.tabControl_1.TabCount - 2);
          this.tabControl_2.SelectTab(1);
        }
      }
    }
  }

  private void button_64_Click(object sender, EventArgs e)
  {
    string str = "";
    string text = this.comboBox_11.Text;
    if (!(text == \u003CModule\u003E.smethod_5<string>(3887495415U)))
    {
      if (!(text == \u003CModule\u003E.smethod_6<string>(38054083U)))
      {
        if (!(text == \u003CModule\u003E.smethod_8<string>(3842446656U)))
        {
          if (!(text == \u003CModule\u003E.smethod_8<string>(908250279U)))
          {
            if (text == \u003CModule\u003E.smethod_7<string>(1736615580U))
              str = \u003CModule\u003E.smethod_9<string>(2003902594U);
          }
          else
            str = \u003CModule\u003E.smethod_6<string>(68595018U);
        }
        else
          str = \u003CModule\u003E.smethod_6<string>(2292913524U);
      }
      else
        str = this.class29_0.method_22(\u003CModule\u003E.smethod_6<string>(3405072777U)) ? \u003CModule\u003E.smethod_6<string>(3405072777U) : \u003CModule\u003E.smethod_8<string>(1632373254U);
    }
    else
      str = \u003CModule\u003E.smethod_6<string>(1334423987U);
    if (this.class29_0.method_29(str))
      return;
    this.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_7<string>(2434412703U) + str + \u003CModule\u003E.smethod_6<string>(198825039U));
    this.checkBox_87.Checked = false;
  }

  private void button_59_Click(object sender, EventArgs e)
  {
    if (!this.bool_1 && this.class29_0.Class26_0.control3_0 != null)
    {
      int num = (int) Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_5<string>(73416345U), (IWin32Window) null, true);
    }
    else
    {
      this.class29_0.Class26_0.control3_0 = new Control3(new Class145(\u003CModule\u003E.smethod_9<string>(2336896324U)), this.class29_0);
      this.class29_0.Class26_0.control3_0.radioButton_0.Visible = true;
      this.class29_0.Class26_0.control3_0.radioButton_1.Visible = true;
      this.class29_0.Class26_0.control3_0.radioButton_2.Visible = true;
      this.class29_0.Class26_0.control3_0.radioButton_3.Visible = true;
      TabPage tabPage = new TabPage(\u003CModule\u003E.smethod_5<string>(3379012078U));
      tabPage.Controls.Add((Control) this.class29_0.Class26_0.control3_0);
      this.tabControl_1.TabPages.Add(tabPage);
      foreach (string str in this.class29_0.HashSet_3)
      {
        if (this.class29_0.Class26_0.control3_1 == null || this.class29_0.Class112_0.method_75(str) == null)
        {
          if (this.class29_0.Class26_0.method_44(str))
          {
            this.tabControl_1.TabPages[str]?.Dispose();
            this.class29_0.Class26_0.method_43(str);
          }
          this.class29_0.Class26_0.method_42(new Class145(str)
          {
            Control3_0 = this.class29_0.Class26_0.control3_0
          });
        }
      }
      if (this.bool_1 || Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_5<string>(1777861867U), (IWin32Window) null, true) != DialogResult.OK)
        return;
      this.tabControl_1.SelectTab(tabPage);
      this.tabControl_2.SelectTab(1);
    }
  }

  private void button_58_Click(object sender, EventArgs e)
  {
    if (!this.bool_1 && this.class29_0.Class26_0.control3_1 != null)
    {
      int num = (int) Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_5<string>(3577568816U), (IWin32Window) null, true);
    }
    else
    {
      this.class29_0.Class26_0.control3_1 = new Control3(new Class145(\u003CModule\u003E.smethod_7<string>(3555944613U)), this.class29_0);
      TabPage tabPage = new TabPage(\u003CModule\u003E.smethod_7<string>(3555944613U));
      tabPage.Controls.Add((Control) this.class29_0.Class26_0.control3_1);
      this.tabControl_1.TabPages.Add(tabPage);
      foreach (Class29 class29 in this.class29_0.Class112_0.IEnumerable_0.Where<Class29>((Func<Class29, bool>) (class29_0 => class29_0.int_3 != this.class29_0.int_3)))
      {
        if (this.class29_0.Class26_0.method_44(class29.String_0))
        {
          this.tabControl_1.TabPages[class29.String_0]?.Dispose();
          this.class29_0.Class26_0.method_43(class29.String_0);
        }
        this.class29_0.Class26_0.method_42(new Class145(class29.String_0)
        {
          Control3_0 = this.class29_0.Class26_0.control3_1
        });
      }
      if (this.bool_1 || Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_9<string>(934068601U), (IWin32Window) null, true) != DialogResult.OK)
        return;
      this.tabControl_1.SelectTab(tabPage);
      this.tabControl_2.SelectTab(1);
    }
  }

  private void button_53_Click(object sender, EventArgs e)
  {
    foreach (string str in this.listBox_7.SelectedItems.OfType<string>().ToList<string>())
    {
      if (!this.class29_0.Class112_0.form5_0.bindingList_0.Contains<string>(str, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase))
        this.class29_0.Class112_0.form5_0.bindingList_0.Add(str);
      this.bindingList_1.Remove(str);
    }
    this.method_25();
    this.method_26();
  }

  private void button_48_Click(object bool_3, EventArgs ushort_0)
  {
    List<Class143> source = this.class29_0.method_125();
    foreach (string str in this.listBox_6.SelectedItems.OfType<string>().ToList<string>())
    {
      if (source.Select<Class143, string>((Func<Class143, string>) (obj0 => obj0.String_5)).Contains<string>(str, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase))
        this.method_8(this.bindingList_1, this.listBox_7, str);
      this.class29_0.Class112_0.form5_0.bindingList_0.Remove(str);
    }
    this.method_25();
    this.method_26();
  }

  private void button_67_Click(object sender, EventArgs e)
  {
    foreach (string str in this.listBox_8.SelectedItems.OfType<string>().ToList<string>())
    {
      if (!this.class29_0.Class112_0.form5_0.bindingList_0.Contains<string>(str, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase))
        this.class29_0.Class112_0.form5_0.bindingList_0.Add(str);
    }
    this.method_25();
    this.method_26();
  }

  private void button_56_Click(object sender, EventArgs e)
  {
    foreach (Class29 class29 in this.class29_0.Class112_0.IEnumerable_0)
    {
      if (!this.class29_0.HashSet_3.Contains(class29.String_0) && this.class29_0 != class29)
        this.class29_0.method_113(class29.String_0);
    }
  }

  private void button_63_Click(object sender, EventArgs e) => ThreadPool.QueueUserWorkItem((WaitCallback) delegate
  {
    this.method_28();
  });

  private void method_28()
  {
    this.method_2();
    this.class29_0.method_29(\u003CModule\u003E.smethod_8<string>(4018262351U));
    while (this.class29_0.Class75_0 == null)
      Thread.Sleep(25);
    byte byte1_1 = this.class29_0.Class75_0.Byte_1;
    int int320_1 = this.class29_0.Class75_0.Int32_0;
    ushort uint162_1 = this.class29_0.Class75_0.UInt16_2;
    ushort uint163_1 = this.class29_0.Class75_0.UInt16_3;
    byte num = this.comboBox_10.Text == \u003CModule\u003E.smethod_9<string>(608017474U) ? (byte) 1 : (byte) 2;
    this.class29_0.method_89(byte1_1, int320_1, uint162_1, (ushort) ((uint) uint163_1 + 1U));
    this.class29_0.method_90(byte1_1, int320_1, uint162_1, (ushort) ((uint) uint163_1 + 1U), num);
    this.class29_0.method_89(byte1_1, int320_1, uint162_1, (ushort) ((uint) uint163_1 + 1U));
    this.class29_0.method_89(byte1_1, int320_1, uint162_1, (ushort) ((uint) uint163_1 + 1U));
    this.class29_0.method_89(byte1_1, int320_1, uint162_1, (ushort) ((uint) uint163_1 + 1U));
    Thread.Sleep(1000);
    while (this.class29_0.Class75_0 == null)
      Thread.Sleep(25);
    byte byte1_2 = this.class29_0.Class75_0.Byte_1;
    int int320_2 = this.class29_0.Class75_0.Int32_0;
    ushort uint162_2 = this.class29_0.Class75_0.UInt16_2;
    ushort uint163_2 = this.class29_0.Class75_0.UInt16_3;
    this.class29_0.method_89(byte1_2, int320_2, uint162_2, (ushort) ((uint) uint163_2 + 1U));
    this.class29_0.method_90(byte1_2, int320_2, uint162_2, (ushort) ((uint) uint163_2 + 1U), (byte) 2);
    this.class29_0.method_89(byte1_2, int320_2, uint162_2, uint163_2);
    if (!(this.toolStripMenuItem_2.Text == \u003CModule\u003E.smethod_9<string>(591721198U)))
      return;
    this.class29_0.Class25_0.method_0();
  }

  private void class27_0_KeyPress(object sender, KeyPressEventArgs e)
  {
    if (e.KeyChar == '\u001B')
    {
      this.class27_0.Text = "";
      this.class27_0.MaxLength = 65 - this.class29_0.String_0.Length;
      e.Handled = true;
    }
    else
    {
      if (e.KeyChar != '\r')
        return;
      this.class29_0.method_60((byte) 0, this.class27_0.Text);
      this.class27_0.MaxLength = 65 - this.class29_0.String_0.Length;
      this.class27_0.Text = "";
    }
  }

  private void class27_0_KeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode == Keys.OemQuotes && e.Shift)
    {
      this.class27_0.KeyPress -= new KeyPressEventHandler(this.class27_0_KeyPress);
      this.class27_0.KeyDown -= new KeyEventHandler(this.class27_0_KeyDown);
      if (!string.IsNullOrWhiteSpace(this.class27_0.Text))
        return;
      this.class27_0.MaxLength = 67;
      this.class27_0.ForeColor = Color.Magenta;
      if (!string.IsNullOrWhiteSpace(this.list_0[0]))
      {
        this.class27_0.Text = \u003CModule\u003E.smethod_6<string>(175385344U) + this.list_0[0] + \u003CModule\u003E.smethod_7<string>(3255464850U);
        this.class27_0.KeyDown += new KeyEventHandler(this.class27_0_KeyDown_1);
        this.int_1 = 0;
        e.Handled = true;
        e.SuppressKeyPress = true;
      }
      else
        this.class27_0.Text = \u003CModule\u003E.smethod_8<string>(2005505452U);
      e.Handled = true;
      e.SuppressKeyPress = true;
      this.class27_0.KeyPress += new KeyPressEventHandler(this.class27_0_KeyPress_2);
      this.class27_0.SelectionStart = this.class27_0.Text.Length;
    }
    else
    {
      if (e.KeyCode != Keys.D1 || !e.Shift)
        return;
      this.class27_0.KeyPress -= new KeyPressEventHandler(this.class27_0_KeyPress);
      this.class27_0.ForeColor = Color.Red;
      this.class27_0.MaxLength = 67;
      this.class27_0.Text = this.class29_0.String_0 + \u003CModule\u003E.smethod_9<string>(720858371U);
      e.Handled = true;
      e.SuppressKeyPress = true;
      this.class27_0.KeyDown -= new KeyEventHandler(this.class27_0_KeyDown);
      this.class27_0.KeyPress += new KeyPressEventHandler(this.class27_0_KeyPress_1);
      this.class27_0.SelectionStart = this.class27_0.Text.Length;
    }
  }

  private void class27_0_KeyPress_1(object sender, KeyPressEventArgs e)
  {
    if (e.KeyChar == '\u001B')
    {
      this.class27_0.KeyPress -= new KeyPressEventHandler(this.class27_0_KeyPress_1);
      this.class27_0.MaxLength = 65 - this.class29_0.String_0.Length;
      this.class27_0.KeyDown += new KeyEventHandler(this.class27_0_KeyDown);
      this.class27_0.KeyPress += new KeyPressEventHandler(this.class27_0_KeyPress);
      this.class27_0.ForeColor = Color.Black;
      this.class27_0.Text = "";
      e.Handled = true;
    }
    else
    {
      if (e.KeyChar != '\r')
        return;
      this.class29_0.method_60((byte) 1, this.class27_0.Text.Replace(this.class29_0.String_0 + \u003CModule\u003E.smethod_7<string>(2154487743U), ""));
      this.class27_0.Text = "";
      this.class27_0.ForeColor = Color.Black;
      e.Handled = true;
      this.class27_0.KeyPress -= new KeyPressEventHandler(this.class27_0_KeyPress_1);
      this.class27_0.KeyDown += new KeyEventHandler(this.class27_0_KeyDown);
      this.class27_0.KeyPress += new KeyPressEventHandler(this.class27_0_KeyPress);
      this.class27_0.SelectionStart = this.class27_0.Text.Length;
    }
  }

  private void class27_0_KeyDown_1(object int_2, [In] KeyEventArgs obj1)
  {
    if (obj1.KeyCode == Keys.Up)
    {
      string[] strArray = this.class27_0.Text.Replace(\u003CModule\u003E.smethod_8<string>(2245564104U), "").Replace(\u003CModule\u003E.smethod_8<string>(4248245659U), "").Split(new char[1]
      {
        ' '
      }, 2);
      while (string.IsNullOrWhiteSpace(this.list_0[this.int_1]))
      {
        ++this.int_1;
        if (this.int_1 > 4)
          this.int_1 = 0;
      }
      this.class27_0.Text = \u003CModule\u003E.smethod_8<string>(2245564104U) + strArray[0] + \u003CModule\u003E.smethod_9<string>(1396199504U) + this.list_0[this.int_1];
      ++this.int_1;
      if (this.int_1 > 4)
        this.int_1 = 0;
      obj1.Handled = true;
      obj1.SuppressKeyPress = true;
      this.class27_0.SelectionStart = this.class27_0.Text.Length;
    }
    else
    {
      if (obj1.KeyCode != Keys.Down)
        return;
      string[] strArray = this.class27_0.Text.Replace(\u003CModule\u003E.smethod_9<string>(3200462690U), "").Replace(\u003CModule\u003E.smethod_7<string>(3768599541U), "").Split(new char[1]
      {
        ' '
      }, 2);
      while (string.IsNullOrWhiteSpace(this.list_0[this.int_1]))
      {
        --this.int_1;
        if (this.int_1 < 0)
          this.int_1 = 4;
      }
      this.class27_0.Text = \u003CModule\u003E.smethod_9<string>(3200462690U) + strArray[0] + \u003CModule\u003E.smethod_8<string>(4273018426U) + this.list_0[this.int_1];
      --this.int_1;
      if (this.int_1 < 0)
        this.int_1 = 4;
      obj1.Handled = true;
      this.class27_0.SelectionStart = this.class27_0.Text.Length;
    }
  }

  private void class27_0_KeyPress_2([In] object obj0, KeyPressEventArgs e)
  {
    if (e.KeyChar == '\u001B')
    {
      this.class27_0.KeyPress -= new KeyPressEventHandler(this.class27_0_KeyPress_2);
      this.class27_0.KeyDown -= new KeyEventHandler(this.class27_0_KeyDown_1);
      this.class27_0.MaxLength = 65 - this.class29_0.String_0.Length;
      this.class27_0.KeyDown += new KeyEventHandler(this.class27_0_KeyDown);
      this.class27_0.KeyPress += new KeyPressEventHandler(this.class27_0_KeyPress);
      this.class27_0.ForeColor = Color.Black;
      this.class27_0.Text = "";
      e.Handled = true;
    }
    else
    {
      if (e.KeyChar != '\r')
        return;
      string text = this.class27_0.Text;
      if (this.class27_0.Text.Contains(\u003CModule\u003E.smethod_5<string>(3449019772U)))
        this.string_0 = text.Replace(\u003CModule\u003E.smethod_8<string>(2005505452U), "");
      else if (this.class27_0.Text.Contains(\u003CModule\u003E.smethod_9<string>(3200462690U) + this.list_0[0] + \u003CModule\u003E.smethod_6<string>(4056222882U)) && this.class27_0.Text.Length == this.list_0[0].Length + 7)
      {
        this.string_0 = text.Replace(\u003CModule\u003E.smethod_6<string>(175385344U), "").Replace(\u003CModule\u003E.smethod_8<string>(4273018426U), "");
      }
      else
      {
        string[] strArray = text.Replace(\u003CModule\u003E.smethod_8<string>(2245564104U), "").Replace(\u003CModule\u003E.smethod_6<string>(1889191915U), "").Split(new char[1]
        {
          ' '
        }, 2);
        this.string_0 = strArray[0] == strArray[1] ? strArray[0] : strArray[1];
      }
      this.class27_0.Text = \u003CModule\u003E.smethod_5<string>(2697246069U) + this.string_0 + \u003CModule\u003E.smethod_8<string>(382084420U);
      e.Handled = true;
      this.class27_0.KeyDown -= new KeyEventHandler(this.class27_0_KeyDown_1);
      this.class27_0.KeyPress -= new KeyPressEventHandler(this.class27_0_KeyPress_2);
      this.class27_0.KeyPress += new KeyPressEventHandler(this.class27_0_KeyPress_3);
      this.class27_0.SelectionStart = this.class27_0.Text.Length;
    }
  }

  private void class27_0_KeyPress_3([In] object obj0, KeyPressEventArgs e)
  {
    if (e.KeyChar == '\u001B')
    {
      this.class27_0.KeyPress -= new KeyPressEventHandler(this.class27_0_KeyPress_3);
      this.class27_0.MaxLength = 65 - this.class29_0.String_0.Length;
      this.class27_0.KeyDown += new KeyEventHandler(this.class27_0_KeyDown);
      this.class27_0.KeyPress += new KeyPressEventHandler(this.class27_0_KeyPress);
      this.class27_0.ForeColor = Color.Black;
      this.class27_0.Text = "";
      e.Handled = true;
    }
    else
    {
      if (e.KeyChar != '\r')
        return;
      this.class29_0.method_59(this.string_0, this.class27_0.Text.Replace(\u003CModule\u003E.smethod_6<string>(1475062157U) + this.string_0 + \u003CModule\u003E.smethod_8<string>(382084420U), ""));
      e.Handled = true;
      this.class27_0.KeyDown += new KeyEventHandler(this.class27_0_KeyDown);
      this.class27_0.KeyPress -= new KeyPressEventHandler(this.class27_0_KeyPress_3);
      this.class27_0.KeyPress += new KeyPressEventHandler(this.class27_0_KeyPress);
      this.class27_0.ForeColor = Color.Black;
      this.class27_0.Text = "";
    }
  }

  private void class27_0_Enter([In] object obj0, EventArgs ushort_0) => this.class27_0.BackColor = SystemColors.GradientInactiveCaption;

  private void class27_0_Leave(object string_4, EventArgs ushort_0) => this.class27_0.BackColor = Color.White;

  private void trackBar_0_Scroll([In] object obj0, [In] EventArgs obj1)
  {
    this.label_37.Text = (obj0 as TrackBar).Value.ToString();
    this.class29_0.double_0 = (double) this.trackBar_0.Value;
  }

  private void comboBox_6_SelectedIndexChanged([In] object obj0, EventArgs ushort_0) => this.numericUpDown_22.Visible = (obj0 as ComboBox).SelectedItem.ToString() == \u003CModule\u003E.smethod_6<string>(1512216910U);

  private void textBox_20_Enter(object sender, EventArgs e) => (sender as TextBox).BackColor = SystemColors.GradientInactiveCaption;

  private void textBox_20_Leave(object sender, EventArgs e) => (sender as TextBox).BackColor = Color.White;

  internal void method_29(string sender)
  {
    Match match;
    if (!(match = Regex.Match(sender, \u003CModule\u003E.smethod_7<string>(540375945U))).Success)
      return;
    string str = match.Groups[1].Value;
    if (str == \u003CModule\u003E.smethod_7<string>(1059751547U))
      str = \u003CModule\u003E.smethod_5<string>(4021777631U);
    if (str == \u003CModule\u003E.smethod_6<string>(1321392441U))
      str = \u003CModule\u003E.smethod_8<string>(913512971U);
    if (this.list_0.Contains(str))
    {
      int index1 = this.list_0.IndexOf(str);
      switch (index1)
      {
        case 0:
          this.list_0[index1] = str;
          break;
        case 1:
          this.list_0[index1] = this.list_0[index1 - 1];
          this.list_0[0] = str;
          break;
        case 2:
          for (int index2 = 2; index2 > 0; --index2)
            this.list_0[index2] = this.list_0[index2 - 1];
          this.list_0[0] = str;
          break;
        case 3:
          for (int index3 = 3; index3 > 0; --index3)
            this.list_0[index3] = this.list_0[index3 - 1];
          this.list_0[0] = str;
          break;
        case 4:
          for (int index4 = 4; index4 > 0; --index4)
            this.list_0[index4] = this.list_0[index4 - 1];
          this.list_0[0] = str;
          break;
      }
    }
    else
    {
      for (int index = 4; index > 0; --index)
        this.list_0[index] = this.list_0[index - 1];
      this.list_0[0] = str;
    }
  }

  private void toolStripButton_3_Click([In] object obj0, EventArgs e) => this.class29_0.Boolean_10 = this.toolStripButton_3.Checked;

  internal void method_30([In] Class99 obj0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Control2.Class49 class49 = new Control2.Class49();
    // ISSUE: reference to a compiler-generated field
    class49.control2_0 = this;
    // ISSUE: reference to a compiler-generated field
    class49.class99_0 = obj0;
    if (this.InvokeRequired)
    {
      // ISSUE: reference to a compiler-generated method
      this.Invoke((Delegate) new Action(class49.method_0));
    }
    else
    {
      if (!this.toolStripButton_0.Checked)
        return;
      // ISSUE: reference to a compiler-generated field
      this.listBox_0.Items.Add((object) class49.class99_0.method_32());
    }
  }

  internal void method_31(Class100 sender)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Control2.Class50 class50 = new Control2.Class50();
    // ISSUE: reference to a compiler-generated field
    class50.control2_0 = this;
    // ISSUE: reference to a compiler-generated field
    class50.class100_0 = sender;
    if (this.InvokeRequired)
    {
      // ISSUE: reference to a compiler-generated method
      this.Invoke((Delegate) new Action(class50.method_0));
    }
    else
    {
      if (!this.toolStripButton_1.Checked)
        return;
      // ISSUE: reference to a compiler-generated field
      this.listBox_0.Items.Add((object) class50.class100_0.method_29());
    }
  }

  private void button_4_Click([In] object obj0, EventArgs e)
  {
    foreach (string line in this.richTextBox_2.Lines)
    {
      string input = Regex.Replace(line, \u003CModule\u003E.smethod_8<string>(2940967293U), (MatchEvaluator) (class29_0 =>
      {
        int dstOffset = 1;
        if (!string.IsNullOrEmpty(class29_0.Groups[2].Value))
          dstOffset = int.Parse(class29_0.Groups[2].Value);
        byte[] bytes = Encoding.GetEncoding(949).GetBytes(class29_0.Groups[1].Value.Replace(\u003CModule\u003E.smethod_7<string>(3370463686U), \u003CModule\u003E.smethod_7<string>(2767110596U)).Replace(\u003CModule\u003E.smethod_7<string>(86255098U), \u003CModule\u003E.smethod_5<string>(1797382428U)).Replace(\u003CModule\u003E.smethod_6<string>(1243288604U), \u003CModule\u003E.smethod_8<string>(3344134950U)));
        if (dstOffset != 0)
        {
          int length = bytes.Length;
          Array.Resize<byte>(ref bytes, length + dstOffset);
          Buffer.BlockCopy((Array) bytes, 0, (Array) bytes, dstOffset, length);
          if (dstOffset == 1)
          {
            bytes[0] = (byte) length;
          }
          else
          {
            bytes[0] = (byte) (length >> 8);
            bytes[1] = (byte) length;
          }
        }
        return BitConverter.ToString(bytes);
      })).Replace(\u003CModule\u003E.smethod_9<string>(593328578U), string.Empty).Replace(\u003CModule\u003E.smethod_5<string>(2854823517U), string.Empty);
      if (input.Length >= 2 && input.Length % 2 == 0 && Regex.IsMatch(input, \u003CModule\u003E.smethod_9<string>(3084032688U), RegexOptions.IgnoreCase))
      {
        Class99 class99 = new Class99(byte.Parse(input.Substring(0, 2), NumberStyles.HexNumber));
        if (input.Length > 2)
        {
          int length = (input.Length - 2) / 2;
          byte[] numArray = new byte[length];
          for (int index = 0; index < length; ++index)
          {
            int startIndex = 2 + index * 2;
            numArray[index] = byte.Parse(input.Substring(startIndex, 2), NumberStyles.HexNumber);
          }
          class99.method_13(numArray);
        }
        this.class29_0.method_4(new Class98[1]
        {
          (Class98) class99
        });
      }
    }
  }

  private void button_3_Click([In] object obj0_1, EventArgs e)
  {
    foreach (string line in this.richTextBox_2.Lines)
    {
      string input = Regex.Replace(line, \u003CModule\u003E.smethod_8<string>(2940967293U), (MatchEvaluator) (obj0_2 =>
      {
        int dstOffset = 1;
        if (!string.IsNullOrEmpty(obj0_2.Groups[2].Value))
          dstOffset = int.Parse(obj0_2.Groups[2].Value);
        byte[] bytes = Encoding.GetEncoding(949).GetBytes(obj0_2.Groups[1].Value.Replace(\u003CModule\u003E.smethod_9<string>(4236193620U), \u003CModule\u003E.smethod_6<string>(2071548120U)).Replace(\u003CModule\u003E.smethod_5<string>(3283811650U), \u003CModule\u003E.smethod_8<string>(293743756U)).Replace(\u003CModule\u003E.smethod_5<string>(1830731044U), \u003CModule\u003E.smethod_9<string>(2510668268U)));
        if (dstOffset != 0)
        {
          int length = bytes.Length;
          Array.Resize<byte>(ref bytes, length + dstOffset);
          Buffer.BlockCopy((Array) bytes, 0, (Array) bytes, dstOffset, length);
          if (dstOffset == 1)
          {
            bytes[0] = (byte) length;
          }
          else
          {
            bytes[0] = (byte) (length >> 8);
            bytes[1] = (byte) length;
          }
        }
        return BitConverter.ToString(bytes);
      })).Replace(\u003CModule\u003E.smethod_7<string>(1361428092U), string.Empty).Replace(\u003CModule\u003E.smethod_5<string>(2854823517U), string.Empty);
      if (input.Length >= 2 && input.Length % 2 == 0 && Regex.IsMatch(input, \u003CModule\u003E.smethod_8<string>(3714635802U), RegexOptions.IgnoreCase))
      {
        Class100 class100 = new Class100(byte.Parse(input.Substring(0, 2), NumberStyles.HexNumber));
        if (input.Length > 2)
        {
          int length = (input.Length - 2) / 2;
          byte[] numArray = new byte[length];
          for (int index = 0; index < length; ++index)
          {
            int startIndex = 2 + index * 2;
            numArray[index] = byte.Parse(input.Substring(startIndex, 2), NumberStyles.HexNumber);
          }
          class100.method_13(numArray);
        }
        this.class29_0.method_4(new Class98[1]
        {
          (Class98) class100
        });
      }
    }
  }

  private void toolStripButton_2_Click([In] object obj0, EventArgs e)
  {
    this.listBox_0.Items.Clear();
    this.richTextBox_1.Clear();
    this.richTextBox_0.Clear();
  }

  private void listBox_0_KeyDown([In] object obj0, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return || this.listBox_0.SelectedItem == null)
      return;
    Clipboard.SetText(((Class98) this.listBox_0.SelectedItem).method_27());
  }

  private void listBox_0_MouseDoubleClick([In] object obj0, MouseEventArgs e)
  {
    if (e.Button != MouseButtons.Left || this.listBox_0.SelectedItem == null)
      return;
    Clipboard.SetText(((Class98) this.listBox_0.SelectedItem).method_27());
  }

  private void listBox_0_SelectedIndexChanged([In] object obj0, EventArgs e)
  {
    if (this.listBox_0.SelectedItem == null)
      return;
    StringBuilder stringBuilder = new StringBuilder();
    Class98 selectedItem = (Class98) this.listBox_0.SelectedItem;
    this.richTextBox_0.Text = selectedItem.method_27();
    string str = selectedItem.method_28(true);
    for (int index = 0; index < str.Length; ++index)
    {
      if (index > 0 && index % 39 == 0)
        stringBuilder.AppendLine();
      stringBuilder.Append(str[index]);
    }
    this.richTextBox_1.Text = stringBuilder.ToString();
  }

  internal void method_32([In] Class143 obj0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Control2.Class51 class51 = new Control2.Class51();
    // ISSUE: reference to a compiler-generated field
    class51.control2_0 = this;
    // ISSUE: reference to a compiler-generated field
    class51.class143_0 = obj0;
    if (this.InvokeRequired)
    {
      // ISSUE: reference to a compiler-generated method
      this.Invoke((Delegate) new Action(class51.method_0));
    }
    else
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (this.class29_0.Class26_0.method_44(class51.class143_0.String_5) || this.tableLayoutPanel_1.Controls.ContainsKey(class51.class143_0.String_5))
        return;
      // ISSUE: reference to a compiler-generated field
      Control0 control0 = new Control0(class51.class143_0, this.class29_0);
      // ISSUE: reference to a compiler-generated field
      control0.Name = class51.class143_0.String_5;
      this.tableLayoutPanel_1.Controls.Add((Control) control0, -1, -1);
    }
  }

  internal void method_33(Class142 sender)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Control2.Class52 class52 = new Control2.Class52();
    // ISSUE: reference to a compiler-generated field
    class52.control2_0 = this;
    // ISSUE: reference to a compiler-generated field
    class52.class142_0 = sender;
    if (this.InvokeRequired)
    {
      // ISSUE: reference to a compiler-generated method
      this.Invoke((Delegate) new Action(class52.method_0));
    }
    else
    {
      // ISSUE: reference to a compiler-generated field
      if (this.class29_0.Class26_0.control4_0 != null || this.class29_0.Class26_0.method_41(class52.class142_0.UInt16_0))
        return;
      TableLayoutControlCollection controls = this.tableLayoutPanel_0.Controls;
      // ISSUE: reference to a compiler-generated field
      ushort uint160 = class52.class142_0.UInt16_0;
      string key = uint160.ToString();
      if (controls.ContainsKey(key))
        return;
      // ISSUE: reference to a compiler-generated field
      Control1 control1 = new Control1(class52.class142_0, this.class29_0);
      // ISSUE: reference to a compiler-generated field
      uint160 = class52.class142_0.UInt16_0;
      control1.Name = uint160.ToString();
      this.tableLayoutPanel_0.Controls.Add((Control) control1, -1, -1);
    }
  }

  internal void method_34([In] string obj0)
  {
    if (!this.tableLayoutPanel_1.Controls.ContainsKey(obj0))
      return;
    DateTime utcNow = DateTime.UtcNow;
    while (DateTime.UtcNow.Subtract(utcNow).TotalMilliseconds < 250.0)
    {
      if (!(this.tableLayoutPanel_1.Controls[obj0] as Control0).bool_0)
      {
        Thread.Sleep(25);
      }
      else
      {
        (this.tableLayoutPanel_1.Controls[obj0] as Control0).Dispose();
        break;
      }
    }
  }

  internal void method_35(ushort sender)
  {
    if (this.class29_0.Class26_0.control4_0 != null || !this.tableLayoutPanel_0.Controls.ContainsKey(sender.ToString()))
      return;
    DateTime utcNow = DateTime.UtcNow;
    while (DateTime.UtcNow.Subtract(utcNow).TotalMilliseconds < 250.0)
    {
      if (!(this.tableLayoutPanel_0.Controls[sender.ToString()] as Control1).bool_0)
      {
        Thread.Sleep(25);
      }
      else
      {
        (this.tableLayoutPanel_0.Controls[sender.ToString()] as Control1).Dispose();
        break;
      }
    }
  }

  private void method_36()
  {
    List<Control0> list = this.tableLayoutPanel_1.Controls.OfType<Control0>().ToList<Control0>();
    this.tableLayoutPanel_1.Controls.Clear();
    foreach (Control control in list)
      this.tableLayoutPanel_1.Controls.Add(control, -1, -1);
  }

  private void method_37()
  {
    List<Control1> list = this.tableLayoutPanel_0.Controls.OfType<Control1>().ToList<Control1>();
    this.tableLayoutPanel_0.Controls.Clear();
    foreach (Control control in list)
      this.tableLayoutPanel_0.Controls.Add(control, -1, -1);
  }

  internal void method_38()
  {
    DateTime utcNow = DateTime.UtcNow;
    while (this.tableLayoutPanel_1.Controls.Count > 0 && DateTime.UtcNow.Subtract(utcNow).TotalMilliseconds < 50.0)
    {
      if ((this.tableLayoutPanel_1.Controls[0] as Control0).bool_0)
        this.tableLayoutPanel_1.Controls[0].Dispose();
    }
    this.tableLayoutPanel_1.Controls.Clear();
  }

  internal void method_39()
  {
    if (this.class29_0.Class26_0.control4_0 != null)
      return;
    DateTime utcNow = DateTime.UtcNow;
    while (this.tableLayoutPanel_0.Controls.Count > 0 && DateTime.UtcNow.Subtract(utcNow).TotalMilliseconds < 50.0)
    {
      if ((this.tableLayoutPanel_0.Controls[0] as Control1).bool_0)
        this.tableLayoutPanel_0.Controls[0].Dispose();
    }
    this.tableLayoutPanel_0.Controls.Clear();
  }

  internal void method_40()
  {
    string str1 = this.class29_0.temClass_0.ToString();
    string str2 = this.class29_0.medClass_0.ToString();
    string str3 = this.class29_0.previousClass_0.ToString();
    if (!(str2 == \u003CModule\u003E.smethod_6<string>(4090070726U)))
    {
      if (!(str2 == \u003CModule\u003E.smethod_5<string>(2375873459U)))
      {
        if (!(str2 == \u003CModule\u003E.smethod_7<string>(3165246451U)))
        {
          if (!(str2 == \u003CModule\u003E.smethod_5<string>(196252550U)))
          {
            if (str2 == \u003CModule\u003E.smethod_8<string>(379903114U))
            {
              this.checkBox_49.Visible = true;
              if (str3 == \u003CModule\u003E.smethod_5<string>(2247324415U))
                this.checkBox_52.Visible = true;
            }
          }
          else
          {
            this.checkBox_48.Visible = true;
            if (str3 == \u003CModule\u003E.smethod_7<string>(2617878353U))
            {
              this.checkBox_64.Visible = true;
              this.checkBox_46.Visible = true;
            }
          }
        }
        else
        {
          this.checkBox_50.Visible = true;
          if (str3 == \u003CModule\u003E.smethod_5<string>(2247324415U))
          {
            this.checkBox_45.Visible = true;
            this.comboBox_3.Visible = true;
            this.textBox_15.Visible = true;
            this.checkBox_58.Visible = true;
            this.checkBox_53.Visible = true;
            this.checkBox_51.Visible = true;
          }
        }
      }
      else
      {
        this.checkBox_61.Visible = true;
        this.checkBox_47.Visible = true;
      }
    }
    else
      this.checkBox_60.Visible = true;
    if (!(str1 == \u003CModule\u003E.smethod_8<string>(806527865U)))
    {
      if (!(str1 == \u003CModule\u003E.smethod_6<string>(3238371515U)))
      {
        if (!(str1 == \u003CModule\u003E.smethod_5<string>(2909590196U)))
        {
          if (!(str1 == \u003CModule\u003E.smethod_5<string>(3571855977U)))
          {
            if (str1 == \u003CModule\u003E.smethod_9<string>(4280592784U))
              this.checkBox_55.Visible = true;
          }
          else if (str3 == \u003CModule\u003E.smethod_9<string>(799596205U))
          {
            this.checkBox_56.Visible = true;
            this.checkBox_63.Visible = true;
          }
        }
        else
        {
          this.checkBox_54.Visible = true;
          this.textBox_16.Visible = true;
        }
      }
      else
      {
        this.checkBox_57.Visible = true;
        this.checkBox_59.Visible = true;
      }
    }
    else
    {
      this.checkBox_62.Visible = true;
      this.checkBox_55.Visible = true;
    }
    if (!(str3 == \u003CModule\u003E.smethod_8<string>(806527865U)))
    {
      if (!(str3 == \u003CModule\u003E.smethod_6<string>(3238371515U)))
      {
        if (str3 == \u003CModule\u003E.smethod_8<string>(3847709348U) || str3 == \u003CModule\u003E.smethod_5<string>(3571855977U))
          return;
        if (!(str3 == \u003CModule\u003E.smethod_5<string>(2845315674U)))
        {
          int num = str3 == \u003CModule\u003E.smethod_7<string>(2617878353U) ? 1 : 0;
        }
        else
          this.checkBox_55.Visible = true;
      }
      else
      {
        this.checkBox_57.Visible = true;
        this.checkBox_59.Visible = true;
      }
    }
    else
    {
      this.checkBox_62.Visible = true;
      this.checkBox_55.Visible = true;
    }
  }

  internal void method_41() => this.class27_0.MaxLength = 65 - this.class29_0.String_0.Length;

  private void button_46_Click([In] object obj0, EventArgs e)
  {
    if (this.listBox_5.SelectedItem == null)
      return;
    this.bindingList_3.Remove(this.listBox_5.SelectedItem.ToString());
  }

  private void button_47_Click([In] object obj0, EventArgs e)
  {
    if (this.bindingList_3.Contains<string>(this.textBox_18.Text, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase))
      return;
    this.method_8(this.bindingList_3, this.listBox_5, this.textBox_18.Text);
    this.textBox_18.Text = "";
  }

  private void button_45_Click([In] object obj0, EventArgs e)
  {
    if (this.button_45.Text == \u003CModule\u003E.smethod_9<string>(1518532812U))
    {
      this.button_45.Text = \u003CModule\u003E.smethod_5<string>(3838461908U);
    }
    else
    {
      this.button_45.Text = \u003CModule\u003E.smethod_9<string>(1518532812U);
      this.class29_0.Boolean_4 = false;
    }
  }

  private void checkBox_22_CheckedChanged([In] object obj0, EventArgs e)
  {
    this.class29_0.Boolean_9 = (obj0 as CheckBox).Checked;
    this.class29_0.method_66(this.class29_0.Class143_0);
  }

  private void numericUpDown_18_ValueChanged([In] object obj0, EventArgs e)
  {
    this.class29_0.UInt16_0 = (ushort) (obj0 as NumericUpDown).Value;
    if (!this.checkBox_22.Checked)
      return;
    this.class29_0.method_66(this.class29_0.Class143_0);
  }

  internal void method_42([In] bool obj0, ushort e)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Control2.Class53 class53 = new Control2.Class53();
    // ISSUE: reference to a compiler-generated field
    class53.control2_0 = this;
    // ISSUE: reference to a compiler-generated field
    class53.bool_0 = obj0;
    // ISSUE: reference to a compiler-generated field
    class53.ushort_0 = e;
    if (this.InvokeRequired)
    {
      // ISSUE: reference to a compiler-generated method
      this.Invoke((Delegate) new Action(class53.method_0));
    }
    else
    {
      // ISSUE: reference to a compiler-generated field
      this.checkBox_22.Checked = class53.bool_0;
      // ISSUE: reference to a compiler-generated field
      this.numericUpDown_18.Value = (Decimal) class53.ushort_0;
    }
  }

  private void button_44_Click([In] object obj0, EventArgs e)
  {
    foreach (Class29 class29 in this.class29_0.Class112_0.IEnumerable_0)
    {
      if (class29 != this.class29_0)
      {
        class29.Control2_0.comboBox_4.Text = this.comboBox_4.Text;
        class29.Control2_0.trackBar_0.Value = this.trackBar_0.Value;
        class29.Control2_0.trackBar_0_Scroll((object) class29.Control2_0.trackBar_0, new EventArgs());
        class29.Control2_0.button_45.Text = \u003CModule\u003E.smethod_5<string>(3838461908U);
      }
    }
  }

  private void method_43([In] object obj0, EventArgs e)
  {
    this.form3_0.Show();
    this.form3_0.BringToFront();
  }

  private void button_41_Click([In] object obj0, EventArgs e)
  {
    if (this.class29_0.Class21_0[(byte) 1] == null)
      return;
    this.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_8<string>(2113806231U) + this.class29_0.Class21_0[(byte) 1].String_0 + \u003CModule\u003E.smethod_7<string>(3606885476U) + ((int) this.class29_0.Class21_0[(byte) 1].UInt16_0 - 32768).ToString() + \u003CModule\u003E.smethod_5<string>(1526496951U));
  }

  internal void button_43_Click([In] object obj0, EventArgs e)
  {
    if (this.listBox_4.Items.Contains((object) this.textBox_14.Text))
      return;
    this.listBox_4.Items.Add((object) this.textBox_14.Text);
    this.textBox_14.Clear();
  }

  private void button_42_Click([In] object obj0, EventArgs e)
  {
    if (this.listBox_4.SelectedItem == null)
      return;
    this.listBox_4.Items.Remove(this.listBox_4.SelectedItem);
  }

  private void comboBox_4_SelectedIndexChanged(object sender, EventArgs e)
  {
    if (this.comboBox_4.Text == \u003CModule\u003E.smethod_7<string>(2255807975U))
    {
      this.trackBar_0.Visible = false;
    }
    else
    {
      if (this.trackBar_0.Visible)
        return;
      this.trackBar_0.Visible = true;
    }
  }

  internal bool method_44(int sender)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Control2.Class54 class54 = new Control2.Class54();
    if (!(this.groupBox_6.Controls[\u003CModule\u003E.smethod_8<string>(2540430982U) + sender.ToString()] as CheckBox).Checked)
      return true;
    // ISSUE: reference to a compiler-generated field
    class54.struct16_0 = this.class29_0.Struct16_0.method_3(this.class29_0.Direction_0);
    List<Class139> source = this.class29_0.method_116();
    // ISSUE: reference to a compiler-generated method
    return (source != null ? (source.OfType<Class142>().Count<Class142>() == 0 ? 1 : 0) : 0) == 0 && this.class29_0.method_116().OfType<Class142>().Any<Class142>(new Func<Class142, bool>(class54.method_0));
  }

  private void button_13_Click([In] object obj0, EventArgs e)
  {
    Button button = obj0 as Button;
    if (button.Text.Contains(\u003CModule\u003E.smethod_5<string>(1886910683U)))
    {
      button.Text = button.Text.Replace(\u003CModule\u003E.smethod_6<string>(3912961315U), \u003CModule\u003E.smethod_5<string>(3275716767U));
      string str = button.Text.Replace(\u003CModule\u003E.smethod_9<string>(3612997944U), "");
      if (!(str == \u003CModule\u003E.smethod_9<string>(1249823627U)))
      {
        if (!(str == \u003CModule\u003E.smethod_6<string>(2931032083U)))
        {
          if (!(str == \u003CModule\u003E.smethod_7<string>(1199714027U)))
          {
            if (!(str == \u003CModule\u003E.smethod_9<string>(4471572U)))
              return;
            this.class29_0.bool_11 = true;
          }
          else
            this.class29_0.bool_10 = true;
        }
        else
          this.class29_0.bool_9 = true;
      }
      else
        this.class29_0.bool_8 = true;
    }
    else
    {
      button.Text = button.Text.Replace(\u003CModule\u003E.smethod_6<string>(3084701799U), \u003CModule\u003E.smethod_7<string>(1719089629U));
      string str = button.Text.Replace(\u003CModule\u003E.smethod_5<string>(3809433504U), "");
      if (!(str == \u003CModule\u003E.smethod_8<string>(2246879777U)))
      {
        if (!(str == \u003CModule\u003E.smethod_8<string>(4274334099U)))
        {
          if (!(str == \u003CModule\u003E.smethod_5<string>(1694087117U)))
          {
            if (!(str == \u003CModule\u003E.smethod_6<string>(162353798U)))
              return;
            this.class29_0.bool_11 = false;
          }
          else
            this.class29_0.bool_10 = false;
        }
        else
          this.class29_0.bool_9 = false;
      }
      else
        this.class29_0.bool_8 = false;
    }
  }

  private void button_9_Click([In] object obj0, EventArgs e)
  {
    this.textBox_6.AppendText(\u003CModule\u003E.smethod_9<string>(1328561461U));
    this.textBox_6.AppendText(Environment.NewLine);
    this.textBox_6.AppendText(\u003CModule\u003E.smethod_8<string>(2967055733U));
    this.textBox_6.AppendText(Environment.NewLine);
    this.textBox_6.AppendText(\u003CModule\u003E.smethod_7<string>(66152376U));
    this.textBox_6.AppendText(Environment.NewLine);
    this.textBox_6.AppendText(\u003CModule\u003E.smethod_9<string>(1073501875U));
    this.textBox_6.AppendText(Environment.NewLine);
    this.textBox_6.AppendText(\u003CModule\u003E.smethod_6<string>(1665203114U));
    this.textBox_6.AppendText(Environment.NewLine);
    this.textBox_6.AppendText(\u003CModule\u003E.smethod_7<string>(1964781182U));
    this.textBox_6.AppendText(Environment.NewLine);
    this.textBox_6.AppendText(\u003CModule\u003E.smethod_9<string>(642120537U));
    this.textBox_6.AppendText(Environment.NewLine);
    this.textBox_6.AppendText(\u003CModule\u003E.smethod_9<string>(3005294854U));
    this.textBox_6.AppendText(Environment.NewLine);
    this.textBox_6.AppendText(\u003CModule\u003E.smethod_8<string>(3791585449U));
    this.textBox_6.AppendText(Environment.NewLine);
    this.textBox_6.AppendText(\u003CModule\u003E.smethod_5<string>(3242388484U));
    this.textBox_6.AppendText(Environment.NewLine);
    this.textBox_6.AppendText(\u003CModule\u003E.smethod_7<string>(1383179677U));
    this.textBox_6.AppendText(Environment.NewLine);
    this.textBox_6.AppendText(\u003CModule\u003E.smethod_8<string>(3985595546U));
    this.textBox_6.AppendText(Environment.NewLine);
    this.textBox_6.AppendText(\u003CModule\u003E.smethod_7<string>(2449923377U));
  }

  internal void method_45([In] string obj0, ushort e, [In] Point obj2)
  {
    Bitmap bitmap = GClass9.smethod_1(this.gclass10_0[(int) e], this.gclass16_0);
    Button button = new Button();
    TextBox textBox1 = new TextBox();
    textBox1.Visible = false;
    textBox1.Text = obj0;
    textBox1.Name = obj0 + \u003CModule\u003E.smethod_8<string>(216794109U);
    TextBox textBox2 = textBox1;
    textBox2.Width = (int) ((double) TextRenderer.MeasureText(textBox2.Text, textBox2.Font).Width * 1.2);
    textBox2.Location = new Point(obj2.X + 25, obj2.Y + 25);
    button.Location = new Point(obj2.X, obj2.Y);
    button.FlatStyle = FlatStyle.Flat;
    button.Size = new Size(40, 40);
    button.Image = (Image) bitmap;
    button.BackColor = Color.White;
    button.Name = obj0;
    button.Padding = Padding.Empty;
    button.Margin = Padding.Empty;
    button.MouseEnter += new EventHandler(this.method_51);
    button.MouseLeave += new EventHandler(this.method_49);
    button.Click += new EventHandler(this.method_53);
    this.groupBox_13.Controls.Add((Control) button);
    this.groupBox_13.Controls.Add((Control) textBox2);
  }

  internal void method_46(string sender, ushort e, [In] Point obj2)
  {
    Bitmap bitmap = GClass9.smethod_1(this.gclass10_0[(int) e], this.gclass16_0);
    Button button = new Button();
    TextBox textBox1 = new TextBox();
    textBox1.Visible = false;
    textBox1.Text = sender;
    textBox1.Name = sender + \u003CModule\u003E.smethod_7<string>(3025283971U);
    TextBox textBox2 = textBox1;
    textBox2.Width = (int) ((double) TextRenderer.MeasureText(textBox2.Text, textBox2.Font).Width * 1.2);
    textBox2.Location = new Point(obj2.X + 25, obj2.Y + 25);
    button.Location = new Point(obj2.X, obj2.Y);
    button.FlatStyle = FlatStyle.Flat;
    button.Size = new Size(40, 40);
    button.Image = (Image) bitmap;
    button.BackColor = Color.White;
    button.Name = sender;
    button.Padding = Padding.Empty;
    button.Margin = Padding.Empty;
    button.MouseEnter += new EventHandler(this.method_51);
    button.MouseLeave += new EventHandler(this.method_49);
    button.Click += new EventHandler(this.method_52);
    this.groupBox_53.Controls.Add((Control) button);
    this.groupBox_53.Controls.Add((Control) textBox2);
  }

  internal void method_47([In] string obj0, ushort e, [In] Point obj2)
  {
    Bitmap bitmap = GClass9.smethod_1(this.gclass10_1[(int) e], this.gclass16_0);
    Button button = new Button();
    TextBox textBox1 = new TextBox();
    textBox1.Visible = false;
    textBox1.Text = obj0;
    TextBox textBox2 = textBox1;
    textBox2.Width = (int) ((double) TextRenderer.MeasureText(textBox2.Text, textBox2.Font).Width * 1.2);
    textBox2.Name = obj0 + \u003CModule\u003E.smethod_7<string>(3025283971U);
    textBox2.Location = new Point(obj2.X + 25, obj2.Y + 25);
    button.Location = new Point(obj2.X, obj2.Y);
    button.FlatStyle = FlatStyle.Flat;
    button.Size = new Size(40, 40);
    button.Image = (Image) bitmap;
    button.Name = obj0;
    button.Padding = Padding.Empty;
    button.Margin = Padding.Empty;
    button.MouseEnter += new EventHandler(this.method_50);
    button.MouseLeave += new EventHandler(this.method_48);
    button.Click += new EventHandler(this.method_54);
    this.groupBox_11.Controls.Add((Control) button);
    this.groupBox_11.Controls.Add((Control) textBox2);
  }

  private void method_48(object sender, EventArgs e)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Control2.Class55 class55 = new Control2.Class55();
    // ISSUE: reference to a compiler-generated field
    class55.button_0 = sender as Button;
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated method
    class55.button_0.Parent.Controls.OfType<TextBox>().First<TextBox>(new Func<TextBox, bool>(class55.method_0)).Hide();
  }

  private void method_49(object sender, EventArgs e)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Control2.Class56 class56 = new Control2.Class56();
    // ISSUE: reference to a compiler-generated field
    class56.button_0 = sender as Button;
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated method
    class56.button_0.Parent.Controls.OfType<TextBox>().First<TextBox>(new Func<TextBox, bool>(class56.method_0)).Hide();
  }

  private void method_50(object sender, EventArgs e)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Control2.Class57 class57 = new Control2.Class57();
    // ISSUE: reference to a compiler-generated field
    class57.button_0 = sender as Button;
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated method
    class57.button_0.Parent.Controls.OfType<TextBox>().First<TextBox>(new Func<TextBox, bool>(class57.method_0)).Show();
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated method
    class57.button_0.Parent.Controls.OfType<TextBox>().First<TextBox>(new Func<TextBox, bool>(class57.method_1)).BringToFront();
  }

  private void method_51(object sender, EventArgs e)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Control2.Class58 class58 = new Control2.Class58();
    // ISSUE: reference to a compiler-generated field
    class58.button_0 = sender as Button;
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated method
    class58.button_0.Parent.Controls.OfType<TextBox>().First<TextBox>(new Func<TextBox, bool>(class58.method_0)).Show();
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated method
    class58.button_0.Parent.Controls.OfType<TextBox>().First<TextBox>(new Func<TextBox, bool>(class58.method_1)).BringToFront();
  }

  internal void method_52(object sender, EventArgs e)
  {
    Button button = sender as Button;
    string name = button.Name;
    if (button.BackColor == Color.DodgerBlue)
    {
      button.BackColor = Color.White;
      this.list_4.Remove(name);
    }
    else
    {
      button.BackColor = Color.DodgerBlue;
      this.list_4.Add(name);
    }
  }

  internal void method_53(object int_2, EventArgs int_3)
  {
    Button button = int_2 as Button;
    string name = button.Name;
    if (button.BackColor == Color.DodgerBlue)
    {
      button.BackColor = Color.White;
      this.list_2.Remove(name);
    }
    else
    {
      button.BackColor = Color.DodgerBlue;
      this.list_2.Add(name);
    }
  }

  internal void method_54([In] object obj0, [In] EventArgs obj1)
  {
    Button button = obj0 as Button;
    string name = button.Name;
    if (button.BackColor == Color.DodgerBlue)
    {
      button.BackColor = Color.White;
      this.list_3.Remove(name);
    }
    else
    {
      button.BackColor = Color.DodgerBlue;
      this.list_3.Add(name);
    }
  }

  private void button_19_Click(object sender, EventArgs e) => this.button_19.Text = this.button_19.Text.Equals(\u003CModule\u003E.smethod_9<string>(2803655629U)) ? \u003CModule\u003E.smethod_6<string>(2384646980U) : \u003CModule\u003E.smethod_6<string>(2929006759U);

  private void button_18_Click(object sender, EventArgs e)
  {
    this.class29_0.Control2_0.method_2();
    this.class29_0.Control2_0.bool_1 = true;
    this.class29_0.list_4.Clear();
    this.class29_0.method_152();
    this.list_2.Clear();
    this.list_3.Clear();
    this.gclass22_0 = GClass22.smethod_0(Settings.Default.DarkAgesPath.Replace(\u003CModule\u003E.smethod_8<string>(2112040518U), \u003CModule\u003E.smethod_8<string>(3491230859U)));
    this.gclass10_1 = GClass10.smethod_2(\u003CModule\u003E.smethod_7<string>(367828921U), this.gclass22_0);
    this.gclass10_0 = GClass10.smethod_2(\u003CModule\u003E.smethod_9<string>(870823353U), this.gclass22_0);
    this.gclass16_0 = GClass16.smethod_2(\u003CModule\u003E.smethod_5<string>(3590871663U), this.gclass22_0);
    while (this.groupBox_13.Controls.Count > 0)
      this.groupBox_13.Controls[0].Dispose();
    while (this.groupBox_11.Controls.Count > 0)
      this.groupBox_11.Controls[0].Dispose();
    this.class29_0.method_138();
    this.class29_0.method_140();
    this.class29_0.Control2_0.bool_1 = false;
    if (!(this.class29_0.Control2_0.toolStripMenuItem_2.Text == \u003CModule\u003E.smethod_5<string>(3838461908U)))
      return;
    this.class29_0.Class25_0.method_0();
  }

  private void button_14_Click(object sender, EventArgs e) => this.button_14.Text = this.button_14.Text == \u003CModule\u003E.smethod_6<string>(2929006759U) ? \u003CModule\u003E.smethod_6<string>(2384646980U) : \u003CModule\u003E.smethod_6<string>(2929006759U);

  private void button_17_Click(object sender, EventArgs e) => this.button_17.Text = this.button_17.Text == \u003CModule\u003E.smethod_6<string>(2929006759U) ? \u003CModule\u003E.smethod_8<string>(3184522924U) : \u003CModule\u003E.smethod_8<string>(3209520711U);

  private void button_16_Click(object sender, EventArgs e)
  {
    if (this.button_16.Text == \u003CModule\u003E.smethod_7<string>(193816241U))
    {
      this.button_16.Text = \u003CModule\u003E.smethod_8<string>(3184522924U);
      this.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_8<string>(1230521270U));
      this.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_5<string>(14854662U));
    }
    else
      this.button_16.Text = \u003CModule\u003E.smethod_6<string>(2929006759U);
  }

  private void button_15_Click(object sender, EventArgs e) => this.button_15.Text = this.button_15.Text == \u003CModule\u003E.smethod_5<string>(1564084447U) ? \u003CModule\u003E.smethod_6<string>(2384646980U) : \u003CModule\u003E.smethod_8<string>(3209520711U);

  private void button_37_Click(object sender, EventArgs e) => this.button_37.Text = this.button_37.Text == \u003CModule\u003E.smethod_9<string>(3276082633U) ? \u003CModule\u003E.smethod_6<string>(1840287201U) : \u003CModule\u003E.smethod_7<string>(3030144893U);

  private void button_36_Click(object sender, EventArgs e) => this.button_36.Text = this.button_36.Text == \u003CModule\u003E.smethod_8<string>(2712299658U) ? \u003CModule\u003E.smethod_9<string>(908279914U) : \u003CModule\u003E.smethod_8<string>(2712299658U);

  private void button_35_Click(object sender, EventArgs e)
  {
    if (string.IsNullOrEmpty(this.class29_0.Control2_0.textBox_10.Text))
      return;
    this.button_35.Text = this.button_35.Text == \u003CModule\u003E.smethod_6<string>(16981468U) ? \u003CModule\u003E.smethod_6<string>(3087325196U) : \u003CModule\u003E.smethod_8<string>(3857784692U);
  }

  private void button_34_Click(object sender, EventArgs e) => this.button_34.Text = this.button_34.Text.Equals(\u003CModule\u003E.smethod_6<string>(2744112596U)) ? \u003CModule\u003E.smethod_8<string>(1897204673U) : \u003CModule\u003E.smethod_9<string>(2691618422U);

  private void button_30_Click(object sender, EventArgs e) => this.button_30.Text = this.button_30.Text == \u003CModule\u003E.smethod_8<string>(3640092481U) ? \u003CModule\u003E.smethod_8<string>(1657146021U) : \u003CModule\u003E.smethod_5<string>(2787682409U);

  private void button_29_Click(object sender, EventArgs e)
  {
    this.class29_0.Class26_0.struct16_4 = new Struct16(this.class29_0.Struct16_1.short_0, this.class29_0.Struct16_1.short_1);
    this.class29_0.Class26_0.short_1 = this.class29_0.class88_0.Int16_0;
    this.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(4085424948U));
  }

  private void button_28_Click(object sender, EventArgs e)
  {
    this.class29_0.Class26_0.short_2 = this.class29_0.class88_0.Int16_0;
    this.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_6<string>(3892145017U));
  }

  private void button_25_Click(object sender, EventArgs e) => this.button_25.Text = this.button_25.Text == \u003CModule\u003E.smethod_9<string>(189814521U) ? \u003CModule\u003E.smethod_8<string>(1424756387U) : \u003CModule\u003E.smethod_8<string>(2384990995U);

  private void button_27_Click(object sender, EventArgs e)
  {
    try
    {
      this.class29_0.Class26_0.method_91();
      this.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_6<string>(2910215785U) + this.class29_0.Class112_0.Dictionary_3[this.class29_0.Class26_0.short_1].String_0 + \u003CModule\u003E.smethod_7<string>(98736920U));
    }
    catch
    {
      this.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_6<string>(4152605059U));
    }
  }

  private void button_26_Click(object sender, EventArgs e)
  {
    if (this.button_26.Text.Equals(\u003CModule\u003E.smethod_9<string>(3760648725U)))
    {
      this.method_55(this.class29_0.Control2_0.comboBox_0.Text);
      this.button_26.Text = \u003CModule\u003E.smethod_6<string>(295805289U);
      this.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_7<string>(674097514U));
    }
    else
      this.button_26.Text = \u003CModule\u003E.smethod_6<string>(4210490671U);
  }

  private void method_55(string sender)
  {
    sender += \u003CModule\u003E.smethod_7<string>(3874328614U);
    string path = AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_6<string>(2757058703U) + sender;
    if (!(sender == \u003CModule\u003E.smethod_6<string>(1831904376U)))
    {
      if (!(sender == \u003CModule\u003E.smethod_6<string>(1003644860U)))
      {
        if (!(sender == \u003CModule\u003E.smethod_9<string>(1272023209U)))
          return;
        File.WriteAllText(path, Class9.String_1);
      }
      else
        File.WriteAllText(path, Class9.String_2);
    }
    else
      File.WriteAllText(path, Class9.String_0);
    if (!this.bindingList_0.Contains<string>(sender, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase))
      this.method_8(this.bindingList_0, this.form3_0.listBox_1, sender);
    this.form3_0.listBox_1.SelectedIndex = this.bindingList_0.IndexOf(sender);
    this.form3_0.button_4_Click(new object(), new EventArgs());
  }

  private void comboBox_0_SelectedIndexChanged([In] object obj0, EventArgs e)
  {
    this.button_26_Click(new object(), new EventArgs());
    this.button_26_Click(new object(), new EventArgs());
  }

  private void button_0_Click([In] object obj0, EventArgs e)
  {
    if (this.class29_0.HashSet_0.Count == 0)
    {
      this.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_5<string>(1037534175U));
    }
    else
    {
      foreach (ushort num in this.class29_0.HashSet_0)
        this.class29_0.method_75((byte) 0, num.ToString());
    }
  }

  private void button_1_Click([In] object obj0, EventArgs e)
  {
    if (this.class29_0.Class94_0 == null)
    {
      this.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_7<string>(120488505U));
    }
    else
    {
      foreach (Class95 class95 in this.class29_0.Class94_0.List_0)
        this.class29_0.method_75((byte) 0, class95.String_0 + \u003CModule\u003E.smethod_7<string>(1253952616U) + class95.Int16_0.ToString() + \u003CModule\u003E.smethod_7<string>(3264734613U) + class95.Struct16_1.ToString());
    }
  }

  private void button_2_Click([In] object obj0, EventArgs e)
  {
    if (this.class29_0.Class112_0.SortedDictionary_0.Count == 0)
    {
      this.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_6<string>(980205165U));
    }
    else
    {
      foreach (KeyValuePair<ushort, string> keyValuePair in this.class29_0.Class112_0.SortedDictionary_0)
        this.class29_0.method_75((byte) 0, keyValuePair.Value + \u003CModule\u003E.smethod_8<string>(382084420U) + keyValuePair.Key.ToString() + \u003CModule\u003E.smethod_6<string>(3181083976U));
    }
  }

  private void button_5_Click([In] object obj0, EventArgs e)
  {
    this.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(3890257112U) + this.class29_0.previousClass_0.ToString());
    this.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_6<string>(1938694702U) + this.class29_0.temClass_0.ToString());
    this.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_5<string>(1976418605U) + this.class29_0.medClass_0.ToString());
  }

  private void button_6_Click([In] object obj0, EventArgs e)
  {
    Class100 class100 = new Class100((byte) 41);
    class100.method_20(this.class29_0.UInt32_0);
    class100.method_20(this.class29_0.UInt32_0);
    class100.method_18((ushort) this.numericUpDown_0.Value);
    class100.method_18((ushort) this.numericUpDown_0.Value);
    class100.method_18((ushort) 90);
    this.class29_0.method_4(new Class98[1]
    {
      (Class98) class100
    });
  }

  private void checkBox_1_CheckedChanged([In] object obj0, EventArgs e) => this.class29_0.Class112_0.bool_5 = (obj0 as CheckBox).Checked;

  private void button_8_Click([In] object obj0, EventArgs e)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Control2.Class59 class59 = new Control2.Class59();
    // ISSUE: reference to a compiler-generated field
    class59.control2_0 = this;
    List<string> list = ((IEnumerable<string>) this.textBox_1.Text.Split(new string[1]
    {
      \u003CModule\u003E.smethod_8<string>(3145277754U)
    }, StringSplitOptions.None)).ToList<string>();
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    if (short.TryParse(list[0], out class59.short_0) && short.TryParse(list[1], out class59.short_1) && short.TryParse(list[2], out class59.short_2))
    {
      // ISSUE: reference to a compiler-generated method
      ThreadPool.QueueUserWorkItem(new WaitCallback(class59.method_0));
    }
    else
    {
      // ISSUE: reference to a compiler-generated method
      ThreadPool.QueueUserWorkItem(new WaitCallback(class59.method_1));
    }
  }

  private void button_7_Click([In] object obj0, EventArgs e)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Control2.Class60 class60 = new Control2.Class60();
    // ISSUE: reference to a compiler-generated field
    class60.control2_0 = this;
    List<string> list = ((IEnumerable<string>) this.textBox_1.Text.Split(new string[1]
    {
      \u003CModule\u003E.smethod_9<string>(4120234832U)
    }, StringSplitOptions.None)).ToList<string>();
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    if (!short.TryParse(list[0], out class60.short_0) || !short.TryParse(list[1], out class60.short_1) || !short.TryParse(list[2], out class60.short_2) || !short.TryParse(list[3], out class60.short_3) || !short.TryParse(list[4], out class60.short_4) || !short.TryParse(list[5], out class60.short_5))
      return;
    // ISSUE: reference to a compiler-generated method
    ThreadPool.QueueUserWorkItem(new WaitCallback(class60.method_0));
  }

  private void button_23_Click([In] object obj0, EventArgs e)
  {
    if (this.button_23.Text == \u003CModule\u003E.smethod_5<string>(3969857205U))
    {
      this.button_23.Text = \u003CModule\u003E.smethod_7<string>(1818577791U);
      this.checkBox_35.Checked = true;
      this.comboBox_4.Text = \u003CModule\u003E.smethod_6<string>(2377033106U);
      this.button_45.Text = \u003CModule\u003E.smethod_9<string>(591721198U);
      this.class29_0.Control2_0.form3_0.checkBox_3.Checked = false;
      this.class29_0.Control2_0.form3_0.checkBox_2.Checked = false;
      this.class29_0.Control2_0.form3_0.checkBox_1.Checked = false;
      this.class29_0.Control2_0.form3_0.checkBox_0.Checked = true;
      this.class29_0.Control2_0.form3_0.numericUpDown_11.Value = 1M;
    }
    else
    {
      this.button_23.Text = \u003CModule\u003E.smethod_7<string>(181334419U);
      this.checkBox_35.Checked = false;
      this.comboBox_4.Text = \u003CModule\u003E.smethod_6<string>(1264873853U);
      this.button_45.Text = \u003CModule\u003E.smethod_9<string>(1518532812U);
    }
  }

  private void button_22_Click([In] object obj0_1, EventArgs e)
  {
    OpenFileDialog openFileDialog = new OpenFileDialog();
    if (openFileDialog.ShowDialog() != DialogResult.OK)
      return;
    string fileName = openFileDialog.FileName;
    List<string> source = new List<string>();
    StreamReader streamReader = new StreamReader(fileName);
    while (!streamReader.EndOfStream)
      source.Add(streamReader.ReadLine());
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: object of a compiler-generated type is created
    foreach (Class6<string, int> class6 in source.GroupBy<string, string>((Func<string, string>) (obj0_2 => obj0_2)).Select<IGrouping<string, string>, Class5<IGrouping<string, string>, int>>((Func<IGrouping<string, string>, Class5<IGrouping<string, string>, int>>) (class29_0 => new Class5<IGrouping<string, string>, int>(class29_0, class29_0.Count<string>()))).OrderByDescending<Class5<IGrouping<string, string>, int>, int>((Func<Class5<IGrouping<string, string>, int>, int>) (obj0_3 => obj0_3.count)).Select<Class5<IGrouping<string, string>, int>, Class6<string, int>>((Func<Class5<IGrouping<string, string>, int>, Class6<string, int>>) (obj0_4 => new Class6<string, int>(obj0_4.g.Key, obj0_4.count))))
      this.listBox_2.Items.Add((object) (Regex.Match(class6.Value, \u003CModule\u003E.smethod_8<string>(964374178U))?.ToString() + \u003CModule\u003E.smethod_9<string>(1004256452U) + class6.Count.ToString() + \u003CModule\u003E.smethod_7<string>(1544893742U)));
    streamReader.Close();
  }

  private void button_24_Click([In] object obj0, EventArgs e)
  {
    foreach (Class29 class29 in this.class29_0.Class112_0.IEnumerable_0)
    {
      class29.Control2_0.textBox_8.Text = this.class29_0.Control2_0.textBox_8.Text;
      class29.Control2_0.button_25.Text = this.class29_0.Control2_0.button_25.Text;
    }
  }

  private void button_52_Click([In] object obj0, EventArgs e)
  {
    this.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_6<string>(3855673776U));
    foreach (KeyValuePair<string, DateTime> keyValuePair in (IEnumerable<KeyValuePair<string, DateTime>>) this.dictionary_0.OrderByDescending<KeyValuePair<string, DateTime>, DateTime>((Func<KeyValuePair<string, DateTime>, DateTime>) (class29_0 => class29_0.Value)))
      this.class29_0.method_75((byte) 0, keyValuePair.Key + \u003CModule\u003E.smethod_7<string>(1253952616U) + keyValuePair.Value.ToLocalTime().ToShortTimeString());
  }

  internal void method_56([In] int obj0, int e, [In] bool obj2, [In] bool obj3)
  {
    if (obj2)
    {
      if (!Class137.IsWindowVisible(Process.GetProcessById(this.class29_0.int_4).MainWindowHandle))
        Class137.ShowWindow(this.class29_0.intptr_0, 1U);
      else
        Class137.ShowWindow(this.class29_0.intptr_0, 0U);
    }
    else
    {
      if (!Class137.IsWindowVisible(Process.GetProcessById(this.class29_0.int_4).MainWindowHandle))
        Class137.ShowWindow(this.class29_0.intptr_0, 1U);
      if (obj3)
      {
        Class137.SetWindowLong(this.class29_0.intptr_0, -16, 268435456);
        Class137.ShowWindowAsync(this.class29_0.intptr_0, 3);
      }
      else
      {
        Class137.GetWindowLong(Process.GetProcessById(this.class29_0.int_4).MainWindowHandle, -16);
        if ((Class137.GetWindowLong(Process.GetProcessById(this.class29_0.int_4).MainWindowHandle, -16) & 12582912) != 12582912)
          Class137.SetWindowLong(this.class29_0.intptr_0, -16, 349110272);
        Class137.GetClientRect(this.class29_0.intptr_0, ref this.class29_0.struct5_0);
        Class137.GetWindowRect_1(this.class29_0.intptr_0, ref this.class29_0.struct5_1);
        this.class29_0.int_9 = this.class29_0.struct5_1.Int32_2 - this.class29_0.struct5_0.Int32_2;
        this.class29_0.int_10 = this.class29_0.struct5_1.Int32_3 - this.class29_0.struct5_0.Int32_3;
        Class137.MoveWindow(this.class29_0.intptr_0, this.class29_0.struct5_1.Int32_0, this.class29_0.struct5_1.Int32_1, obj0 + this.class29_0.int_10, e + this.class29_0.int_9, true);
      }
    }
  }

  private void toolStripMenuItem_6_Click(object string_4, [In] EventArgs obj1) => this.method_56(0, 0, true, false);

  private void toolStripMenuItem_7_Click(object class76_0, [In] EventArgs obj1) => this.method_56(640, 480, false, false);

  private void toolStripMenuItem_8_Click(object class143_0, [In] EventArgs obj1) => this.method_56(1280, 960, false, false);

  private void toolStripMenuItem_9_Click(object keyValuePair_0, [In] EventArgs obj1) => this.method_56(0, 0, false, true);

  private void button_21_Click(object class143_0, [In] EventArgs obj1)
  {
    if (this.listBox_2.Items.OfType<string>().Any<string>((Func<string, bool>) (obj0 => obj0.Contains(this.listBox_1.SelectedItem.ToString()))))
    {
      int stringExact = this.listBox_2.FindStringExact(this.listBox_2.Items.OfType<string>().First<string>((Func<string, bool>) (class29_0 => class29_0.Contains(this.listBox_1.SelectedItem.ToString()))));
      int result;
      if (int.TryParse(Regex.Match(this.listBox_2.Items[stringExact].ToString(), \u003CModule\u003E.smethod_7<string>(3186998036U)).Groups[1].Value, out result))
      {
        this.listBox_2.Items.RemoveAt(stringExact);
        this.listBox_2.Items.Insert(stringExact, (object) (this.listBox_1.SelectedItem.ToString() + \u003CModule\u003E.smethod_7<string>(4253741736U) + (result + 1).ToString() + \u003CModule\u003E.smethod_5<string>(2535368742U)));
      }
    }
    else
      this.listBox_2.Items.Add((object) (this.listBox_1.SelectedItem?.ToString() + \u003CModule\u003E.smethod_7<string>(4253741736U) + 1.ToString() + \u003CModule\u003E.smethod_6<string>(956765470U)));
    this.class29_0.method_158();
  }

  private void button_20_Click(object match_0, [In] EventArgs obj1)
  {
    this.listBox_2.Items.Remove(this.listBox_2.SelectedItem);
    this.class29_0.method_158();
  }

  private void checkBox_18_CheckedChanged(object igrouping_0, [In] EventArgs obj1)
  {
    if ((igrouping_0 as CheckBox).Checked)
      return;
    Class180 stream_1 = new Class180(Enum14.DMUResponse);
    stream_1.method_27(this.class29_0.String_0);
    stream_1.method_19(false);
    this.class29_0.Class112_0.form5_0.class178_0.method_2(stream_1);
  }

  internal void method_57() => this.class29_0 = (Class29) null;

  private void Control2_MouseEnter(object class5_0, [In] EventArgs obj1)
  {
    if (this.class29_0.Class112_0.form5_0.form2_0 == null)
      return;
    this.class29_0.Class112_0.form5_0.form2_0.method_1();
  }

  private void toolStripMenuItem_10_Click(object class24_1, [In] EventArgs obj1)
  {
    string sender = "";
    if (!string.IsNullOrEmpty(this.string_3) && Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_8<string>(1684550134U) + this.string_3 + \u003CModule\u003E.smethod_6<string>(3571774039U), (IWin32Window) null, true) == DialogResult.OK)
    {
      this.method_10(this.string_3);
    }
    else
    {
      if (Form0.smethod_0((IWin32Window) this, \u003CModule\u003E.smethod_6<string>(2175715049U), ref sender, \u003CModule\u003E.smethod_7<string>(1689167523U)) != DialogResult.OK)
        return;
      this.method_10(sender);
    }
  }

  private void toolStripMenuItem_11_MouseEnter(object class24_0, [In] EventArgs obj1)
  {
    while (this.toolStripMenuItem_11.DropDownItems.Count > 0)
      this.toolStripMenuItem_11.DropDownItems[0].Dispose();
    foreach (string str in this.list_1)
      this.toolStripMenuItem_11.DropDownItems.Add((ToolStripItem) new ToolStripMenuItem(str, (Image) null, new EventHandler(this.method_58), str));
    this.toolStripMenuItem_11.DropDownClosed += new EventHandler(this.toolStripMenuItem_11_DropDownClosed);
  }

  private void method_58(object class76_0, [In] EventArgs obj1)
  {
    string text = (class76_0 as ToolStripMenuItem).Text;
    if (Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_8<string>(2164667438U) + text + \u003CModule\u003E.smethod_7<string>(2365945889U), (IWin32Window) null, true) != DialogResult.OK)
      return;
    this.method_12(text);
  }

  private void textBox_19_KeyPress(object textBox_0, [In] KeyPressEventArgs obj1)
  {
    if (obj1.KeyChar != '\r')
      return;
    this.button_60_Click(new object(), new EventArgs());
  }

  private void textBox_20_KeyPress(object textBox_0, [In] KeyPressEventArgs obj1)
  {
    if (obj1.KeyChar != '\r')
      return;
    this.button_61_Click(new object(), new EventArgs());
  }

  private void checkBox_21_CheckedChanged(object textBox_0, [In] EventArgs obj1)
  {
    if ((textBox_0 as CheckBox).Checked)
    {
      this.class29_0.bool_47 = true;
      this.checkBox_34.Checked = false;
      this.checkBox_33.Checked = false;
      this.checkBox_32.Checked = false;
      this.checkBox_29.Checked = false;
      this.checkBox_28.Checked = false;
      this.checkBox_17.Checked = false;
      this.checkBox_20.Checked = false;
      this.class29_0.Class112_0.form5_0.dictionary_4.Clear();
      this.class29_0.method_105(false);
    }
    else
      this.class29_0.bool_47 = false;
  }

  private void button_68_Click(object object_0, [In] EventArgs obj1) => this.button_68.Text = this.button_68.Text == \u003CModule\u003E.smethod_6<string>(2306543143U) ? \u003CModule\u003E.smethod_5<string>(3922721200U) : \u003CModule\u003E.smethod_6<string>(2306543143U);

  private void button_33_Click(object object_0, [In] EventArgs obj1) => this.class29_0.Class26_0.bool_31 = true;

  private void button_32_Click([In] object obj0, EventArgs intptr_0) => this.class29_0.Class26_0.bool_32 = true;

  private void button_31_Click([In] object obj0, EventArgs fullMessage) => this.class29_0.Class26_0.bool_33 = true;

  private void button_69_Click(object client, EventArgs fullMessage) => this.button_69.Text = this.button_69.Text == \u003CModule\u003E.smethod_8<string>(3099904259U) ? \u003CModule\u003E.smethod_7<string>(3959588551U) : \u003CModule\u003E.smethod_8<string>(3099904259U);

  private void button_70_Click([In] object obj0, [In] EventArgs obj1)
  {
    foreach (Class29 class29 in this.class29_0.Class112_0.IEnumerable_0)
    {
      class29.Control2_0.button_69.Text = this.class29_0.Control2_0.button_69.Text;
      class29.Control2_0.checkBox_92.Checked = this.class29_0.Control2_0.checkBox_92.Checked;
      class29.Control2_0.comboBox_12.Text = this.class29_0.Control2_0.comboBox_12.Text;
    }
  }

  private void textBox_18_KeyPress([In] object obj0, [In] KeyPressEventArgs obj1)
  {
    if (obj1.KeyChar != '\r')
      return;
    this.button_47.PerformClick();
    obj1.Handled = true;
  }

  private void textBox_14_KeyPress(object class29_0, KeyPressEventArgs string_0)
  {
    if (string_0.KeyChar != '\r')
      return;
    this.button_43.PerformClick();
    string_0.Handled = true;
  }

  private void textBox_9_KeyPress([In] object obj0, [In] KeyPressEventArgs obj1)
  {
    if (obj1.KeyChar != '\r')
      return;
    this.button_34.PerformClick();
    obj1.Handled = true;
  }

  private void textBox_10_KeyPress([In] object obj0, KeyPressEventArgs string_0)
  {
    if (string_0.KeyChar != '\r')
      return;
    this.button_35.PerformClick();
    string_0.Handled = true;
  }

  private void textBox_8_KeyPress(object class29_0, KeyPressEventArgs string_0)
  {
    if (string_0.KeyChar != '\r')
      return;
    this.button_25.PerformClick();
    string_0.Handled = true;
  }

  private void textBox_22_KeyPress([In] object obj0, [In] KeyPressEventArgs obj1)
  {
    if (obj1.KeyChar != '\r')
      return;
    this.button_68.PerformClick();
    obj1.Handled = true;
  }

  private void textBox_11_KeyPress([In] object obj0, KeyPressEventArgs string_0)
  {
    if (string_0.KeyChar != '\r')
      return;
    this.button_36.PerformClick();
    string_0.Handled = true;
  }

  private void button_71_Click(object class29_0, EventArgs string_0) => this.button_71.Text = this.button_71.Text == \u003CModule\u003E.smethod_9<string>(2803655629U) ? \u003CModule\u003E.smethod_9<string>(2178616966U) : \u003CModule\u003E.smethod_8<string>(3209520711U);

  private void button_72_Click([In] object obj0, [In] EventArgs obj1) => this.button_72.Text = this.button_72.Text == \u003CModule\u003E.smethod_8<string>(2486713409U) ? \u003CModule\u003E.smethod_7<string>(3493535503U) : \u003CModule\u003E.smethod_5<string>(2424886633U);

  private void button_73_Click([In] object obj0, EventArgs string_0)
  {
    if (this.button_73.Text == \u003CModule\u003E.smethod_7<string>(1836103742U))
    {
      this.button_73.Text = \u003CModule\u003E.smethod_5<string>(4136518953U);
      this.button_73.Image = (Image) Class9.Bitmap_13;
      this.button_73.ImageAlign = ContentAlignment.MiddleLeft;
      this.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_8<string>(2111174885U));
      this.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_6<string>(568698804U));
    }
    else
    {
      this.button_73.Text = \u003CModule\u003E.smethod_7<string>(1836103742U);
      this.button_73.Image = (Image) Class9.Bitmap_12;
      this.button_73.ImageAlign = ContentAlignment.MiddleLeft;
    }
  }
}
