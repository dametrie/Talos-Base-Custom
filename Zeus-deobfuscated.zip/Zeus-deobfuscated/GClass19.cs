﻿// Decompiled with JetBrains decompiler
// Type: GClass19
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.IO;
using System.Runtime.InteropServices;

public class GClass19
{
  public byte[] Byte_0 { get; [param: In] private set; }

  public byte[] Byte_1 { get; private set; }

  public int Int32_0 { get; private set; }

  public int Int32_1 { get; private set; }

  public static GClass19 smethod_0([In] string obj0) => GClass19.smethod_4((Stream) new FileStream(obj0, FileMode.Open, FileAccess.Read, FileShare.Read));

  public static GClass19 smethod_1(byte[] struct16_0) => GClass19.smethod_4((Stream) new MemoryStream(struct16_0));

  public static GClass19 smethod_2([In] string obj0, GClass22 short_1) => short_1.method_0(obj0) ? GClass19.smethod_1(short_1.method_4(obj0)) : (GClass19) null;

  public static GClass19 smethod_3(string byte_2, bool byte_3, GClass22 short_1) => short_1.method_1(byte_2, byte_3) ? GClass19.smethod_1(short_1.method_5(byte_2, byte_3)) : (GClass19) null;

  private static GClass19 smethod_4([In] Stream obj0)
  {
    obj0.Seek(0L, SeekOrigin.Begin);
    BinaryReader binaryReader1 = new BinaryReader(obj0);
    uint num = binaryReader1.ReadUInt32();
    binaryReader1.BaseStream.Seek(-4L, SeekOrigin.Current);
    if (num != 4278364757U)
      throw new ArgumentException(\u003CModule\u003E.smethod_7<string>(3604955866U));
    GClass19 gclass19 = new GClass19();
    byte[] buffer = GClass24.smethod_1(binaryReader1.ReadBytes((int) binaryReader1.BaseStream.Length));
    binaryReader1.Close();
    BinaryReader binaryReader2 = new BinaryReader((Stream) new MemoryStream(buffer));
    gclass19.Byte_0 = binaryReader2.ReadBytes(8);
    gclass19.Byte_1 = binaryReader2.ReadBytes(buffer.Length - 8);
    binaryReader2.Close();
    gclass19.Int32_1 = 28;
    if (gclass19.Byte_1.Length % gclass19.Int32_1 != 0)
      throw new ArgumentException(\u003CModule\u003E.smethod_7<string>(3632948362U));
    gclass19.Int32_0 = gclass19.Byte_1.Length / gclass19.Int32_1;
    return gclass19;
  }

  public virtual string System\u002EObject\u002EToString() => \u003CModule\u003E.smethod_5<string>(3911780064U) + this.Int32_1.ToString() + \u003CModule\u003E.smethod_7<string>(2488468085U) + this.Int32_0.ToString() + \u003CModule\u003E.smethod_6<string>(2923589087U);
}
