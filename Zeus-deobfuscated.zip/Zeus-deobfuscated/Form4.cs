﻿// Decompiled with JetBrains decompiler
// Type: Form4
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.ComponentModel;
using System.Drawing;
using System.Net;
using System.Net.Mail;
using System.Runtime.InteropServices;
using System.Windows.Forms;

internal class Form4 : Form
{
  internal Form5 form5_0;
  internal string string_0;
  private IContainer icontainer_0;
  internal Label label_0;
  private PictureBox pictureBox_0;
  private RichTextBox richTextBox_0;
  internal Button button_0;
  private ComboBox comboBox_0;
  internal Label label_1;

  internal Form4(string value, [In] Form5 obj1)
  {
    this.string_0 = value;
    this.form5_0 = obj1;
    this.method_0();
  }

  private void button_0_Click(object value, [In] EventArgs obj1)
  {
    try
    {
      MailAddress from = new MailAddress(\u003CModule\u003E.smethod_8<string>(2622193281U), this.string_0);
      MailAddress to = new MailAddress(\u003CModule\u003E.smethod_6<string>(1858480102U), \u003CModule\u003E.smethod_6<string>(3986416431U));
      string str1 = this.comboBox_0.Text ?? "";
      string str2 = this.richTextBox_0.Text ?? "";
      SmtpClient smtpClient = new SmtpClient()
      {
        Host = \u003CModule\u003E.smethod_6<string>(1762097925U),
        Port = 587,
        EnableSsl = true,
        DeliveryMethod = SmtpDeliveryMethod.Network,
        Credentials = (ICredentialsByHost) new NetworkCredential(from.Address, \u003CModule\u003E.smethod_6<string>(2306457704U)),
        Timeout = 20000
      };
      using (MailMessage message = new MailMessage(from, to)
      {
        Subject = str1,
        Body = str2
      })
      {
        this.Hide();
        smtpClient.Send(message);
        int num = (int) Form1.smethod_0(this.form5_0, \u003CModule\u003E.smethod_8<string>(3317596470U), (IWin32Window) null, true);
        this.comboBox_0.Text = \u003CModule\u003E.smethod_6<string>(3264947241U);
        this.richTextBox_0.Text = string.Empty;
      }
    }
    catch (Exception ex)
    {
      int num = (int) Form1.smethod_0(this.form5_0, \u003CModule\u003E.smethod_5<string>(200047554U), (IWin32Window) null, true);
    }
    this.Dispose();
  }

  void Form.Dispose(bool value)
  {
    if (value && this.icontainer_0 != null)
      this.icontainer_0.Dispose();
    // ISSUE: explicit non-virtual call
    __nonvirtual (((Form) this).Dispose(value));
  }

  private void method_0()
  {
    ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (Form4));
    this.label_0 = new Label();
    this.pictureBox_0 = new PictureBox();
    this.richTextBox_0 = new RichTextBox();
    this.button_0 = new Button();
    this.comboBox_0 = new ComboBox();
    this.label_1 = new Label();
    ((ISupportInitialize) this.pictureBox_0).BeginInit();
    this.SuspendLayout();
    this.label_0.AutoSize = true;
    this.label_0.Font = new Font(\u003CModule\u003E.smethod_8<string>(2058547965U), 9.75f);
    this.label_0.ForeColor = Color.Black;
    this.label_0.Location = new Point(49, 160);
    this.label_0.Name = \u003CModule\u003E.smethod_7<string>(1739094811U);
    this.label_0.Size = new Size(353, 17);
    this.label_0.TabIndex = 14;
    this.label_0.Text = \u003CModule\u003E.smethod_7<string>(4202251252U);
    this.label_0.TextAlign = ContentAlignment.MiddleLeft;
    this.pictureBox_0.Image = (Image) Class9.Bitmap_11;
    this.pictureBox_0.Location = new Point(52, 32);
    this.pictureBox_0.Name = \u003CModule\u003E.smethod_7<string>(47246436U);
    this.pictureBox_0.Size = new Size(70, 93);
    this.pictureBox_0.SizeMode = PictureBoxSizeMode.Zoom;
    this.pictureBox_0.TabIndex = 13;
    this.pictureBox_0.TabStop = false;
    this.richTextBox_0.BorderStyle = BorderStyle.FixedSingle;
    this.richTextBox_0.Font = new Font(\u003CModule\u003E.smethod_5<string>(2184462853U), 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.richTextBox_0.Location = new Point(52, 189);
    this.richTextBox_0.Name = \u003CModule\u003E.smethod_7<string>(1113990136U);
    this.richTextBox_0.Size = new Size(393, 174);
    this.richTextBox_0.TabIndex = 12;
    this.richTextBox_0.Text = "";
    this.button_0.FlatStyle = FlatStyle.Flat;
    this.button_0.ForeColor = Color.Black;
    this.button_0.Location = new Point(381, 386);
    this.button_0.Name = \u003CModule\u003E.smethod_8<string>(3930787320U);
    this.button_0.Size = new Size(64, 49);
    this.button_0.TabIndex = 11;
    this.button_0.Text = \u003CModule\u003E.smethod_7<string>(1907049787U);
    this.button_0.UseVisualStyleBackColor = true;
    this.button_0.Click += new EventHandler(this.button_0_Click);
    this.comboBox_0.Font = new Font(\u003CModule\u003E.smethod_6<string>(2348004861U), 18f);
    this.comboBox_0.ForeColor = Color.Black;
    this.comboBox_0.FormattingEnabled = true;
    this.comboBox_0.Items.AddRange(new object[7]
    {
      (object) \u003CModule\u003E.smethod_9<string>(2152024589U),
      (object) \u003CModule\u003E.smethod_8<string>(4117353419U),
      (object) \u003CModule\u003E.smethod_5<string>(1035616340U),
      (object) \u003CModule\u003E.smethod_9<string>(1896965003U),
      (object) \u003CModule\u003E.smethod_9<string>(92701817U),
      (object) \u003CModule\u003E.smethod_5<string>(1633607599U),
      (object) \u003CModule\u003E.smethod_6<string>(1691778840U)
    });
    this.comboBox_0.Location = new Point(232, 95);
    this.comboBox_0.Name = \u003CModule\u003E.smethod_5<string>(1569333077U);
    this.comboBox_0.Size = new Size(158, 40);
    this.comboBox_0.TabIndex = 16;
    this.comboBox_0.Text = \u003CModule\u003E.smethod_6<string>(1715218535U);
    this.label_1.AutoSize = true;
    this.label_1.Font = new Font(\u003CModule\u003E.smethod_9<string>(868744759U), 18f);
    this.label_1.ForeColor = Color.Black;
    this.label_1.Location = new Point((int) sbyte.MaxValue, 48);
    this.label_1.Name = \u003CModule\u003E.smethod_5<string>(3257609166U);
    this.label_1.Size = new Size(363, 32);
    this.label_1.TabIndex = 17;
    this.label_1.Text = \u003CModule\u003E.smethod_9<string>(2789673554U);
    this.label_1.TextAlign = ContentAlignment.MiddleLeft;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.BackColor = Color.White;
    this.ClientSize = new Size(502, 467);
    this.Controls.Add((Control) this.label_1);
    this.Controls.Add((Control) this.comboBox_0);
    this.Controls.Add((Control) this.label_0);
    this.Controls.Add((Control) this.pictureBox_0);
    this.Controls.Add((Control) this.richTextBox_0);
    this.Controls.Add((Control) this.button_0);
    this.Font = new Font(\u003CModule\u003E.smethod_7<string>(1521212547U), 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.ForeColor = Color.Black;
    this.Icon = (Icon) componentResourceManager.GetObject(\u003CModule\u003E.smethod_8<string>(3680203284U));
    this.Name = \u003CModule\u003E.smethod_9<string>(4211347361U);
    this.Text = \u003CModule\u003E.smethod_6<string>(2236138619U);
    ((ISupportInitialize) this.pictureBox_0).EndInit();
    this.ResumeLayout(false);
    this.PerformLayout();
  }
}
