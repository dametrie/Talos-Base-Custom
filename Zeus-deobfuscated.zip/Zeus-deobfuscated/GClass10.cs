﻿// Decompiled with JetBrains decompiler
// Type: GClass10
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.IO;
using System.Runtime.InteropServices;

public class GClass10
{
  public GClass11 this[int string_1]
  {
    get => this.GClass11_0[string_1];
    set => this.GClass11_0[obj0] = value;
  }

  public GClass11[] GClass11_0 { get; [param: In] private set; }

  public long Int64_0 { get; [param: In] private set; }

  public int Int32_0 { get; private set; }

  public int Int32_1 { get; private set; }

  public byte[] Byte_0 { get; private set; }

  public int Int32_2 { get; private set; }

  public int Int32_3 { get; [param: In] private set; }

  public static GClass10 smethod_0([In] string obj0) => GClass10.smethod_4((Stream) new FileStream(obj0, FileMode.Open, FileAccess.Read, FileShare.Read));

  public static GClass10 smethod_1([In] byte[] obj0) => GClass10.smethod_4((Stream) new MemoryStream(obj0));

  public static GClass10 smethod_2([In] string obj0, [In] GClass22 obj1) => obj1.method_0(obj0) ? GClass10.smethod_1(obj1.method_4(obj0)) : (GClass10) null;

  public static GClass10 smethod_3([In] string obj0, [In] bool obj1, [In] GClass22 obj2) => obj2.method_1(obj0, obj1) ? GClass10.smethod_1(obj2.method_5(obj0, obj1)) : (GClass10) null;

  private static GClass10 smethod_4([In] Stream obj0)
  {
    obj0.Seek(0L, SeekOrigin.Begin);
    BinaryReader binaryReader = new BinaryReader(obj0);
    GClass10 gclass10 = new GClass10()
    {
      Int32_3 = (int) binaryReader.ReadUInt16(),
      Int32_2 = (int) binaryReader.ReadUInt16(),
      Int32_1 = (int) binaryReader.ReadUInt16(),
      Int32_0 = (int) binaryReader.ReadUInt16(),
      Int64_0 = (long) (binaryReader.ReadUInt32() + 12U)
    };
    if (gclass10.Int32_3 <= 0)
      return gclass10;
    gclass10.GClass11_0 = new GClass11[gclass10.Int32_3];
    for (int index = 0; index < gclass10.Int32_3; ++index)
    {
      binaryReader.BaseStream.Seek(gclass10.Int64_0 + (long) (index * 16), SeekOrigin.Begin);
      int string_0 = (int) binaryReader.ReadUInt16();
      int gclass22_0_1 = (int) binaryReader.ReadUInt16();
      int num1 = (int) binaryReader.ReadUInt16();
      int num2 = (int) binaryReader.ReadUInt16();
      int num3 = string_0;
      int gclass22_0_2 = num1 - num3;
      int num4 = num2 - gclass22_0_1;
      uint offset = binaryReader.ReadUInt32() + 12U;
      uint num5 = binaryReader.ReadUInt32() + 12U;
      binaryReader.BaseStream.Seek((long) offset, SeekOrigin.Begin);
      gclass10.Byte_0 = (long) (num5 - offset) == (long) (gclass22_0_2 * num4) ? binaryReader.ReadBytes((int) num5 - (int) offset) : binaryReader.ReadBytes((int) (gclass10.Int64_0 - (long) offset));
      gclass10.GClass11_0[index] = new GClass11(string_0, gclass22_0_1, gclass22_0_2, num4, gclass10.Byte_0);
    }
    return gclass10;
  }

  public virtual string System\u002EObject\u002EToString() => \u003CModule\u003E.smethod_9<string>(462916501U) + this.Int32_3.ToString() + \u003CModule\u003E.smethod_7<string>(1701649345U) + this.Int32_2.ToString() + \u003CModule\u003E.smethod_8<string>(2212447259U) + this.Int32_1.ToString() + \u003CModule\u003E.smethod_9<string>(2522239273U) + this.Int64_0.ToString(\u003CModule\u003E.smethod_7<string>(902348783U)).PadLeft(8, '0') + \u003CModule\u003E.smethod_5<string>(4098890791U);
}
