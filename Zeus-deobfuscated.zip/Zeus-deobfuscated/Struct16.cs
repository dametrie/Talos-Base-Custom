﻿// Decompiled with JetBrains decompiler
// Type: Struct16
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using Accolade;
using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

internal struct Struct16 : IEquatable<Struct16>
{
  internal bool bool_0;
  internal short short_0;
  internal short short_1;

  [SpecialName]
  public static bool smethod_0([In] Struct16 obj0, [In] Struct16 obj1) => obj0.Equals(obj1);

  [SpecialName]
  public static bool smethod_1(Struct16 string_1, [In] Struct16 obj1) => !string_1.Equals(obj1);

  internal Struct16([In] short obj0, short byte_5)
  {
    this.short_0 = obj0;
    this.short_1 = byte_5;
    this.bool_0 = true;
  }

  internal Struct16([In] int obj0, [In] int obj1)
  {
    this.short_0 = (short) obj0;
    this.short_1 = (short) obj1;
    this.bool_0 = true;
  }

  internal int method_0([In] Struct16 obj0) => this.method_1(obj0.short_0, obj0.short_1);

  internal int method_1(short string_1, params short class95_0) => Math.Abs((int) string_1 - (int) this.short_0) + Math.Abs((int) class95_0 - (int) this.short_1);

  internal void method_2(Direction value)
  {
    switch (value)
    {
      case Direction.North:
        --this.short_1;
        break;
      case Direction.East:
        ++this.short_0;
        break;
      case Direction.South:
        ++this.short_1;
        break;
      case Direction.West:
        --this.short_0;
        break;
    }
  }

  internal Struct16 method_3(Direction value)
  {
    Struct16 struct16 = new Struct16(this.short_0, this.short_1);
    struct16.method_2(value);
    return struct16;
  }

  internal Direction method_4(Struct16 value)
  {
    if ((int) this.short_1 < (int) value.short_1)
      return Direction.North;
    if ((int) this.short_0 > (int) value.short_0)
      return Direction.East;
    if ((int) this.short_1 > (int) value.short_1)
      return Direction.South;
    return (int) this.short_0 >= (int) value.short_0 ? Direction.Invalid : Direction.West;
  }

  public bool Equals(Struct16 value) => this.GetHashCode() == value.GetHashCode();

  public virtual bool System\u002EValueType\u002EEquals(object struct16_2) => struct16_2 is Struct16 struct16 && this.GetHashCode() == struct16.GetHashCode();

  public virtual int System\u002EValueType\u002EGetHashCode() => ((int) this.short_0 << 16) + (int) this.short_1;

  public virtual string System\u002EValueType\u002EToString() => string.Format(\u003CModule\u003E.smethod_7<string>(839206845U), (object) this.short_0, (object) this.short_1);
}
