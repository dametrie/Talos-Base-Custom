﻿// Decompiled with JetBrains decompiler
// Type: Class144
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Runtime.InteropServices;

internal class Class144
{
  internal ushort UInt16_0 { get; set; }

  internal byte Byte_0 { get; [param: In] set; }

  internal byte Byte_1 { get; set; }

  internal ushort UInt16_1 { get; set; }

  internal byte Byte_2 { get; [param: In] set; }

  internal byte Byte_3 { get; set; }

  internal ushort UInt16_2 { get; [param: In] set; }

  internal byte Byte_4 { get; set; }

  internal ushort UInt16_3 { get; [param: In] set; }

  internal byte Byte_5 { get; set; }

  internal ushort UInt16_4 { get; [param: In] set; }

  internal ushort UInt16_5 { get; set; }

  internal byte Byte_6 { get; [param: In] set; }

  internal byte Byte_7 { get; set; }

  internal Class144([In] Class143 obj0)
  {
    this.UInt16_0 = obj0.UInt16_1;
    this.Byte_0 = obj0.Byte_3;
    this.Byte_1 = obj0.Byte_4;
    this.UInt16_1 = obj0.UInt16_4;
    this.Byte_2 = obj0.Byte_5;
    this.Byte_3 = obj0.Byte_7;
    this.UInt16_2 = obj0.UInt16_5;
    this.Byte_4 = obj0.Byte_8;
    this.UInt16_3 = obj0.UInt16_6;
    this.Byte_5 = obj0.Byte_9;
    this.UInt16_4 = obj0.UInt16_7;
    this.UInt16_5 = obj0.UInt16_8;
    this.Byte_6 = obj0.Byte_13;
    this.Byte_7 = obj0.Byte_14;
  }

  internal Class144(
    ushort control4_1,
    byte class142_4,
    byte string_1 = "",
    [In] ushort obj3,
    [In] byte obj4,
    [In] byte obj5,
    [In] ushort obj6,
    [In] byte obj7,
    [In] ushort obj8,
    [In] byte obj9,
    [In] ushort obj10,
    [In] ushort obj11,
    [In] byte obj12,
    [In] byte obj13)
  {
    this.UInt16_0 = control4_1;
    this.Byte_0 = class142_4;
    this.Byte_1 = string_1;
    this.UInt16_1 = obj3;
    this.Byte_2 = obj4;
    this.Byte_3 = obj5;
    this.UInt16_2 = obj6;
    this.Byte_4 = obj7;
    this.UInt16_3 = obj8;
    this.Byte_5 = obj9;
    this.UInt16_4 = obj10;
    this.UInt16_5 = obj11;
    this.Byte_6 = obj12;
    this.Byte_7 = obj13;
  }
}
