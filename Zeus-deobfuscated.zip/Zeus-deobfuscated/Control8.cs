﻿// Decompiled with JetBrains decompiler
// Type: Control8
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using Accolade.Properties;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

internal class Control8 : UserControl, Interface0
{
  private Label label_0;
  internal TrackBar trackBar_0;
  private Label label_1;
  private IContainer icontainer_0;
  private Label label_2;
  internal TrackBar trackBar_1;
  internal TextBox textBox_0;
  private Button button_0;
  internal TextBox textBox_1;
  private Button button_1;
  private Label label_3;
  internal CheckBox checkBox_0;
  private CheckBox checkBox_1;
  private RadioButton radioButton_0;
  private Label label_4;
  private Label label_5;
  private RadioButton radioButton_1;
  private CheckBox checkBox_2;
  private readonly Form5 form5_0;
  internal CheckBox checkBox_3;
  private CheckBox checkBox_4;
  private RadioButton radioButton_2;
  private CheckBox checkBox_5;
  private CheckBox checkBox_6;
  private CheckBox checkBox_7;

  internal Control8(Form5 pByte_0)
  {
    this.method_0();
    this.form5_0 = pByte_0;
    this.textBox_0.Text = Settings.Default.DarkAgesPath;
    this.textBox_1.Text = Settings.Default.DataPath;
    this.radioButton_2.Checked = Settings.Default.SmallWindowOpt;
    this.radioButton_1.Checked = Settings.Default.LargeWindowOpt;
    this.radioButton_0.Checked = Settings.Default.FullWindowOpt;
    this.checkBox_7.Checked = Settings.Default.WhisperSound;
    this.checkBox_6.Checked = Settings.Default.WhisperFlash;
    this.checkBox_0.Checked = Settings.Default.EnableKom;
    this.checkBox_5.Checked = Settings.Default.UseDawnd;
    this.checkBox_4.Checked = Settings.Default.RemoveSpam;
    this.trackBar_0.Value = Settings.Default.BotwindowOpacity;
    this.trackBar_1.Value = (int) Settings.Default.DawindowOpacity;
    this.label_1.Text = Settings.Default.BotwindowOpacity.ToString();
    this.label_3.Text = Settings.Default.DawindowOpacity.ToString();
    this.checkBox_1.Checked = Settings.Default.EnableOverlay;
    this.checkBox_2.Checked = Settings.Default.LogOnStartup;
    this.checkBox_3.Checked = Settings.Default.ParanoiaMode;
  }

  public void imethod_0()
  {
    Settings.Default.DarkAgesPath = this.textBox_0.Text;
    Settings.Default.DataPath = this.textBox_1.Text;
    Settings.Default.SmallWindowOpt = this.radioButton_2.Checked;
    Settings.Default.LargeWindowOpt = this.radioButton_1.Checked;
    Settings.Default.FullWindowOpt = this.radioButton_0.Checked;
    Settings.Default.WhisperSound = this.checkBox_7.Checked;
    Settings.Default.WhisperFlash = this.checkBox_6.Checked;
    Settings.Default.EnableKom = this.checkBox_0.Checked;
    Settings.Default.UseDawnd = this.checkBox_5.Checked;
    Settings.Default.RemoveSpam = this.checkBox_4.Checked;
    Settings.Default.BotwindowOpacity = this.trackBar_0.Value;
    Settings.Default.DawindowOpacity = (byte) this.trackBar_1.Value;
    Settings.Default.EnableOverlay = this.checkBox_1.Checked;
    Settings.Default.LogOnStartup = this.checkBox_2.Checked;
    Settings.Default.ParanoiaMode = this.checkBox_3.Checked;
    Settings.Default.Save();
  }

  private void button_0_Click([In] object obj0, EventArgs int_0)
  {
    OpenFileDialog openFileDialog1 = new OpenFileDialog();
    openFileDialog1.Filter = \u003CModule\u003E.smethod_7<string>(1181907329U);
    openFileDialog1.InitialDirectory = Path.GetDirectoryName(Settings.Default.DarkAgesPath);
    OpenFileDialog openFileDialog2 = openFileDialog1;
    if (openFileDialog2.ShowDialog() != DialogResult.OK)
      return;
    this.textBox_0.Text = openFileDialog2.FileName;
  }

  private void button_1_Click([In] object obj0, [In] EventArgs obj1)
  {
    FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog()
    {
      SelectedPath = Settings.Default.DataPath
    };
    if (folderBrowserDialog.ShowDialog() != DialogResult.OK)
      return;
    this.textBox_1.Text = folderBrowserDialog.SelectedPath;
  }

  void ContainerControl.Dispose(bool uint_0)
  {
    if (uint_0 && this.icontainer_0 != null)
      this.icontainer_0.Dispose();
    // ISSUE: explicit non-virtual call
    __nonvirtual (((ContainerControl) this).Dispose(uint_0));
  }

  private void method_0()
  {
    this.button_0 = new Button();
    this.label_4 = new Label();
    this.textBox_0 = new TextBox();
    this.button_1 = new Button();
    this.label_5 = new Label();
    this.textBox_1 = new TextBox();
    this.radioButton_2 = new RadioButton();
    this.radioButton_1 = new RadioButton();
    this.radioButton_0 = new RadioButton();
    this.checkBox_6 = new CheckBox();
    this.checkBox_7 = new CheckBox();
    this.trackBar_0 = new TrackBar();
    this.label_0 = new Label();
    this.label_1 = new Label();
    this.label_3 = new Label();
    this.label_2 = new Label();
    this.trackBar_1 = new TrackBar();
    this.checkBox_4 = new CheckBox();
    this.checkBox_5 = new CheckBox();
    this.checkBox_1 = new CheckBox();
    this.checkBox_2 = new CheckBox();
    this.checkBox_3 = new CheckBox();
    this.checkBox_0 = new CheckBox();
    this.trackBar_0.BeginInit();
    this.trackBar_1.BeginInit();
    this.SuspendLayout();
    this.button_0.FlatStyle = FlatStyle.Flat;
    this.button_0.Location = new Point(412, 3);
    this.button_0.Name = \u003CModule\u003E.smethod_8<string>(2760113926U);
    this.button_0.Size = new Size(75, 23);
    this.button_0.TabIndex = 14;
    this.button_0.Text = \u003CModule\u003E.smethod_6<string>(1720209012U);
    this.button_0.UseVisualStyleBackColor = true;
    this.button_0.Click += new EventHandler(this.button_0_Click);
    this.label_4.AutoSize = true;
    this.label_4.Location = new Point(3, 6);
    this.label_4.Name = \u003CModule\u003E.smethod_8<string>(2190305838U);
    this.label_4.Size = new Size(87, 15);
    this.label_4.TabIndex = 9;
    this.label_4.Text = \u003CModule\u003E.smethod_5<string>(4262685953U);
    this.textBox_0.BackColor = Color.White;
    this.textBox_0.ForeColor = Color.Black;
    this.textBox_0.Location = new Point(96, 3);
    this.textBox_0.Name = \u003CModule\u003E.smethod_6<string>(3376728044U);
    this.textBox_0.Size = new Size(310, 23);
    this.textBox_0.TabIndex = 8;
    this.button_1.FlatStyle = FlatStyle.Flat;
    this.button_1.Location = new Point(412, 32);
    this.button_1.Name = \u003CModule\u003E.smethod_7<string>(9434556U);
    this.button_1.Size = new Size(75, 23);
    this.button_1.TabIndex = 17;
    this.button_1.Text = \u003CModule\u003E.smethod_7<string>(1048185760U);
    this.button_1.UseVisualStyleBackColor = true;
    this.button_1.Click += new EventHandler(this.button_1_Click);
    this.label_5.AutoSize = true;
    this.label_5.Location = new Point(3, 35);
    this.label_5.Name = \u003CModule\u003E.smethod_5<string>(4048423991U);
    this.label_5.Size = new Size(58, 15);
    this.label_5.TabIndex = 16;
    this.label_5.Text = \u003CModule\u003E.smethod_7<string>(1349862305U);
    this.textBox_1.BackColor = Color.White;
    this.textBox_1.ForeColor = Color.Black;
    this.textBox_1.Location = new Point(96, 32);
    this.textBox_1.Name = \u003CModule\u003E.smethod_9<string>(1635530897U);
    this.textBox_1.Size = new Size(310, 23);
    this.textBox_1.TabIndex = 15;
    this.radioButton_2.AutoSize = true;
    this.radioButton_2.BackColor = SystemColors.Control;
    this.radioButton_2.Checked = true;
    this.radioButton_2.Location = new Point(28, 74);
    this.radioButton_2.Name = \u003CModule\u003E.smethod_7<string>(3153680664U);
    this.radioButton_2.Size = new Size(107, 19);
    this.radioButton_2.TabIndex = 18;
    this.radioButton_2.TabStop = true;
    this.radioButton_2.Text = \u003CModule\u003E.smethod_5<string>(2552507259U);
    this.radioButton_2.UseVisualStyleBackColor = false;
    this.radioButton_1.AutoSize = true;
    this.radioButton_1.Location = new Point(177, 74);
    this.radioButton_1.Name = \u003CModule\u003E.smethod_7<string>(2606312566U);
    this.radioButton_1.Size = new Size(113, 19);
    this.radioButton_1.TabIndex = 19;
    this.radioButton_1.Text = \u003CModule\u003E.smethod_9<string>(7589463U);
    this.radioButton_1.UseVisualStyleBackColor = true;
    this.radioButton_0.AutoSize = true;
    this.radioButton_0.Location = new Point(334, 74);
    this.radioButton_0.Name = \u003CModule\u003E.smethod_5<string>(1697417912U);
    this.radioButton_0.Size = new Size(138, 19);
    this.radioButton_0.TabIndex = 20;
    this.radioButton_0.Text = \u003CModule\u003E.smethod_6<string>(300710327U);
    this.radioButton_0.UseVisualStyleBackColor = true;
    this.checkBox_6.AutoSize = true;
    this.checkBox_6.Checked = true;
    this.checkBox_6.CheckState = CheckState.Checked;
    this.checkBox_6.Location = new Point(28, 124);
    this.checkBox_6.Name = \u003CModule\u003E.smethod_6<string>(902357645U);
    this.checkBox_6.Size = new Size(146, 19);
    this.checkBox_6.TabIndex = 21;
    this.checkBox_6.Text = \u003CModule\u003E.smethod_9<string>(2205541819U);
    this.checkBox_6.UseVisualStyleBackColor = true;
    this.checkBox_7.AutoSize = true;
    this.checkBox_7.Checked = true;
    this.checkBox_7.CheckState = CheckState.Checked;
    this.checkBox_7.Location = new Point(28, 99);
    this.checkBox_7.Name = \u003CModule\u003E.smethod_9<string>(4009805005U);
    this.checkBox_7.Size = new Size(172, 19);
    this.checkBox_7.TabIndex = 22;
    this.checkBox_7.Text = \u003CModule\u003E.smethod_9<string>(577600385U);
    this.checkBox_7.UseVisualStyleBackColor = true;
    this.trackBar_0.AutoSize = false;
    this.trackBar_0.LargeChange = 20;
    this.trackBar_0.Location = new Point(316, 97);
    this.trackBar_0.Maximum = 100;
    this.trackBar_0.Minimum = 20;
    this.trackBar_0.Name = \u003CModule\u003E.smethod_8<string>(1561136339U);
    this.trackBar_0.Size = new Size(156, 44);
    this.trackBar_0.TabIndex = 23;
    this.trackBar_0.TickFrequency = 10;
    this.trackBar_0.TickStyle = TickStyle.Both;
    this.trackBar_0.Value = 100;
    this.trackBar_0.Scroll += new EventHandler(this.trackBar_0_Scroll);
    this.label_0.AutoSize = true;
    this.label_0.Location = new Point(241, 112);
    this.label_0.Name = \u003CModule\u003E.smethod_9<string>(2509393364U);
    this.label_0.Size = new Size(69, 15);
    this.label_0.TabIndex = 24;
    this.label_0.Text = \u003CModule\u003E.smethod_7<string>(1477342963U);
    this.label_1.AutoSize = true;
    this.label_1.Location = new Point(377, 144);
    this.label_1.Name = \u003CModule\u003E.smethod_9<string>(3402101915U);
    this.label_1.Size = new Size(0, 15);
    this.label_1.TabIndex = 25;
    this.label_3.AutoSize = true;
    this.label_3.Location = new Point(377, 178);
    this.label_3.MinimumSize = new Size(20, 0);
    this.label_3.Name = \u003CModule\u003E.smethod_8<string>(253857973U);
    this.label_3.Size = new Size(20, 15);
    this.label_3.TabIndex = 28;
    this.label_2.AutoSize = true;
    this.label_2.Location = new Point(243, 151);
    this.label_2.Name = \u003CModule\u003E.smethod_6<string>(3079796761U);
    this.label_2.Size = new Size(67, 15);
    this.label_2.TabIndex = 27;
    this.label_2.Text = \u003CModule\u003E.smethod_7<string>(1505335459U);
    this.trackBar_1.AutoSize = false;
    this.trackBar_1.LargeChange = 20;
    this.trackBar_1.Location = new Point(316, 136);
    this.trackBar_1.Maximum = 100;
    this.trackBar_1.Minimum = 20;
    this.trackBar_1.Name = \u003CModule\u003E.smethod_9<string>(656338219U);
    this.trackBar_1.Size = new Size(156, 44);
    this.trackBar_1.TabIndex = 26;
    this.trackBar_1.TickFrequency = 10;
    this.trackBar_1.TickStyle = TickStyle.Both;
    this.trackBar_1.Value = 100;
    this.trackBar_1.Scroll += new EventHandler(this.trackBar_1_Scroll);
    this.checkBox_4.AutoSize = true;
    this.checkBox_4.Location = new Point(28, 199);
    this.checkBox_4.Name = \u003CModule\u003E.smethod_7<string>(684283312U);
    this.checkBox_4.Size = new Size(186, 34);
    this.checkBox_4.TabIndex = 29;
    this.checkBox_4.Text = \u003CModule\u003E.smethod_6<string>(1683737771U);
    this.checkBox_4.TextAlign = ContentAlignment.MiddleCenter;
    this.checkBox_4.UseVisualStyleBackColor = true;
    this.checkBox_5.AutoSize = true;
    this.checkBox_5.Checked = true;
    this.checkBox_5.CheckState = CheckState.Checked;
    this.checkBox_5.Location = new Point(28, 149);
    this.checkBox_5.Name = \u003CModule\u003E.smethod_8<string>(3188054350U);
    this.checkBox_5.Size = new Size(95, 19);
    this.checkBox_5.TabIndex = 30;
    this.checkBox_5.Text = \u003CModule\u003E.smethod_9<string>(2479447489U);
    this.checkBox_5.UseVisualStyleBackColor = true;
    this.checkBox_1.AutoSize = true;
    this.checkBox_1.Enabled = false;
    this.checkBox_1.Location = new Point(28, 174);
    this.checkBox_1.Name = \u003CModule\u003E.smethod_8<string>(1347166127U);
    this.checkBox_1.Size = new Size(104, 19);
    this.checkBox_1.TabIndex = 31;
    this.checkBox_1.Text = \u003CModule\u003E.smethod_9<string>(802714096U);
    this.checkBox_1.TextAlign = ContentAlignment.MiddleCenter;
    this.checkBox_1.UseVisualStyleBackColor = true;
    this.checkBox_2.AutoSize = true;
    this.checkBox_2.Location = new Point(269, 218);
    this.checkBox_2.Name = \u003CModule\u003E.smethod_8<string>(520005065U);
    this.checkBox_2.Size = new Size(162, 19);
    this.checkBox_2.TabIndex = 32;
    this.checkBox_2.Text = \u003CModule\u003E.smethod_5<string>(4108903509U);
    this.checkBox_2.UseVisualStyleBackColor = true;
    this.checkBox_3.AutoSize = true;
    this.checkBox_3.Location = new Point(269, 199);
    this.checkBox_3.Name = \u003CModule\u003E.smethod_9<string>(322540799U);
    this.checkBox_3.Size = new Size(203, 19);
    this.checkBox_3.TabIndex = 33;
    this.checkBox_3.Text = \u003CModule\u003E.smethod_5<string>(3980354465U);
    this.checkBox_3.UseVisualStyleBackColor = true;
    this.checkBox_3.CheckedChanged += new EventHandler(this.checkBox_3_CheckedChanged);
    this.checkBox_0.AutoSize = true;
    this.checkBox_0.Checked = true;
    this.checkBox_0.CheckState = CheckState.Checked;
    this.checkBox_0.Location = new Point(28, 236);
    this.checkBox_0.Name = \u003CModule\u003E.smethod_8<string>(4281362504U);
    this.checkBox_0.Size = new Size(111, 19);
    this.checkBox_0.TabIndex = 34;
    this.checkBox_0.Text = \u003CModule\u003E.smethod_9<string>(3117096454U);
    this.checkBox_0.UseVisualStyleBackColor = true;
    this.AutoScaleDimensions = new SizeF(7f, 15f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.BackColor = Color.White;
    this.Controls.Add((Control) this.checkBox_0);
    this.Controls.Add((Control) this.checkBox_3);
    this.Controls.Add((Control) this.checkBox_2);
    this.Controls.Add((Control) this.checkBox_1);
    this.Controls.Add((Control) this.checkBox_5);
    this.Controls.Add((Control) this.checkBox_4);
    this.Controls.Add((Control) this.label_3);
    this.Controls.Add((Control) this.label_2);
    this.Controls.Add((Control) this.trackBar_1);
    this.Controls.Add((Control) this.label_1);
    this.Controls.Add((Control) this.label_0);
    this.Controls.Add((Control) this.trackBar_0);
    this.Controls.Add((Control) this.checkBox_7);
    this.Controls.Add((Control) this.checkBox_6);
    this.Controls.Add((Control) this.radioButton_0);
    this.Controls.Add((Control) this.radioButton_1);
    this.Controls.Add((Control) this.radioButton_2);
    this.Controls.Add((Control) this.button_1);
    this.Controls.Add((Control) this.label_5);
    this.Controls.Add((Control) this.textBox_1);
    this.Controls.Add((Control) this.button_0);
    this.Controls.Add((Control) this.label_4);
    this.Controls.Add((Control) this.textBox_0);
    this.Font = new Font(\u003CModule\u003E.smethod_5<string>(2184462853U), 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.ForeColor = Color.Black;
    this.Name = \u003CModule\u003E.smethod_6<string>(2860285803U);
    this.Size = new Size(490, 258);
    this.trackBar_0.EndInit();
    this.trackBar_1.EndInit();
    this.ResumeLayout(false);
    this.PerformLayout();
  }

  private void trackBar_0_Scroll(object uint_0, [In] EventArgs obj1)
  {
    this.form5_0.Opacity = (double) (uint_0 as TrackBar).Value / 100.0;
    this.label_1.Text = (uint_0 as TrackBar).Value.ToString();
  }

  private void trackBar_1_Scroll(object uint_0, [In] EventArgs obj1)
  {
    foreach (Class29 class29 in this.form5_0.Class112_0.IEnumerable_0)
    {
      if (class29 != null && class29.int_4 != 0)
        Class137.SetLayeredWindowAttributes(Process.GetProcessById(class29.int_4).MainWindowHandle, 0U, (byte) Math.Truncate((double) byte.MaxValue / (100.0 / (double) (uint_0 as TrackBar).Value)), 2U);
    }
    this.label_3.Text = (uint_0 as TrackBar).Value.ToString();
  }

  private void checkBox_3_CheckedChanged(object intptr_0, EventArgs uint_0)
  {
    if ((intptr_0 as CheckBox).Checked)
      this.form5_0.Text = \u003CModule\u003E.smethod_5<string>(1027480791U);
    else
      this.form5_0.Text = \u003CModule\u003E.smethod_5<string>(516656076U);
  }
}
