﻿// Decompiled with JetBrains decompiler
// Type: Class75
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

internal class Class75
{
  private readonly Class29 class29_0;
  private DateTime dateTime_0;

  internal byte Byte_0 { get; [param: In] set; }

  internal byte Byte_1 { get; [param: In] set; }

  internal int Int32_0 { get; [param: In] set; }

  internal byte Byte_2 { get; [param: In] set; }

  internal ushort UInt16_0 { get; [param: In] set; }

  internal byte Byte_3 { get; [param: In] set; }

  internal byte Byte_4 { get; [param: In] set; }

  internal ushort UInt16_1 { get; [param: In] set; }

  internal byte Byte_5 { get; [param: In] set; }

  internal ushort UInt16_2 { get; [param: In] set; }

  internal ushort UInt16_3 { get; [param: In] set; }

  internal bool Boolean_0 { get; [param: In] set; }

  internal bool Boolean_1 { get; set; }

  internal byte Byte_6 { get; [param: In] set; }

  internal string String_0 { get; [param: In] set; }

  internal string String_1 { get; [param: In] set; }

  internal List<string> List_0 { get; [param: In] set; }

  internal string String_2 { get; [param: In] set; }

  internal byte Byte_7 { get; [param: In] set; }

  internal string String_3 { get; [param: In] set; }

  internal Class75(
    [In] byte obj0,
    [In] byte obj1,
    [In] int obj2,
    [In] byte obj3,
    [In] ushort obj4,
    [In] byte obj5,
    [In] byte obj6,
    [In] ushort obj7,
    byte byte_13,
    ushort ushort_6,
    ushort ushort_7,
    bool bool_2,
    bool bool_3,
    byte byte_14,
    string string_4,
    string string_5,
    Class29 list_1)
  {
    this.Byte_0 = obj0;
    this.Byte_1 = obj1;
    this.Int32_0 = obj2;
    this.Byte_2 = obj3;
    this.UInt16_0 = obj4;
    this.Byte_3 = obj5;
    this.Byte_4 = obj6;
    this.UInt16_1 = obj7;
    this.Byte_5 = byte_13;
    this.UInt16_2 = ushort_6;
    this.UInt16_3 = ushort_7;
    this.Boolean_0 = bool_2;
    this.Boolean_1 = bool_3;
    this.Byte_6 = byte_14;
    this.String_0 = string_4;
    this.String_1 = string_5;
    this.List_0 = new List<string>();
    this.String_2 = string.Empty;
    this.String_3 = string.Empty;
    this.class29_0 = list_1;
    this.dateTime_0 = DateTime.MinValue;
  }

  internal Class75(
    byte value,
    byte ushort_1,
    int byte_3,
    byte string_1,
    ushort int_3,
    byte int_4,
    byte int_5,
    [In] ushort obj7,
    [In] byte obj8,
    [In] ushort obj9,
    [In] ushort obj10,
    [In] bool obj11,
    [In] bool obj12,
    [In] byte obj13,
    [In] string obj14,
    [In] string obj15,
    [In] List<string> obj16,
    [In] Class29 obj17)
    : this(value, ushort_1, byte_3, string_1, int_3, int_4, int_5, obj7, obj8, obj9, obj10, obj11, obj12, obj13, obj14, obj15, obj17)
  {
    this.List_0 = obj16;
  }

  internal Class75(
    [In] byte obj0,
    byte string_1,
    int intptr_0,
    byte intptr_1,
    ushort bool_0,
    byte enum8_0,
    byte intptr_2,
    ushort string_2,
    byte struct13_0,
    [Out] ushort struct14_0,
    [In] ushort obj10,
    [In] bool obj11,
    [In] bool obj12,
    [In] byte obj13,
    [In] string obj14,
    [In] string obj15,
    [In] string obj16,
    [In] byte obj17,
    [In] string obj18,
    [In] Class29 obj19)
    : this(obj0, string_1, intptr_0, intptr_1, bool_0, enum8_0, intptr_2, string_2, struct13_0, struct14_0, obj10, obj11, obj12, obj13, obj14, obj15, obj19)
  {
    this.String_2 = obj16;
    this.Byte_7 = obj17;
    this.String_3 = obj18;
  }

  internal Class75(
    [In] byte obj0,
    [In] byte obj1,
    [In] int obj2,
    byte int_1,
    ushort byte_1,
    byte uint_1,
    [In] byte obj6,
    [In] ushort obj7,
    [In] byte obj8,
    [In] ushort obj9,
    [In] ushort obj10,
    [In] bool obj11,
    [In] bool obj12,
    [In] byte obj13,
    [In] string obj14,
    [In] string obj15,
    [In] List<string> obj16,
    [In] string obj17,
    [In] byte obj18,
    [In] string obj19,
    [In] Class29 obj20)
    : this(obj0, obj1, obj2, int_1, byte_1, uint_1, obj6, obj7, obj8, obj9, obj10, obj11, obj12, obj13, obj14, obj15, obj20)
  {
    this.List_0 = obj16;
    this.String_2 = obj17;
    this.Byte_7 = obj18;
    this.String_3 = obj19;
  }

  internal void method_0()
  {
    if (DateTime.UtcNow.Subtract(this.dateTime_0).TotalSeconds < 1.0)
      return;
    this.class29_0.method_89(this.Byte_1, this.Int32_0, this.UInt16_2, (ushort) ((uint) this.UInt16_3 - 1U));
    this.dateTime_0 = DateTime.UtcNow;
  }

  internal void method_1()
  {
    if (DateTime.UtcNow.Subtract(this.dateTime_0).TotalSeconds < 1.0)
      return;
    this.class29_0.method_89(this.Byte_1, this.Int32_0, this.UInt16_2, (ushort) ((uint) this.UInt16_3 + 1U));
    this.dateTime_0 = DateTime.UtcNow;
  }

  internal void method_2([In] byte obj0)
  {
    if (DateTime.UtcNow.Subtract(this.dateTime_0).TotalSeconds < 1.0)
      return;
    this.class29_0.method_90(this.Byte_1, this.Int32_0, this.UInt16_2, (ushort) ((uint) this.UInt16_3 + 1U), obj0);
    this.dateTime_0 = DateTime.UtcNow;
  }

  internal void method_3(string uint_0)
  {
    if (DateTime.UtcNow.Subtract(this.dateTime_0).TotalSeconds < 1.0)
      return;
    this.class29_0.method_91(this.Byte_1, this.Int32_0, this.UInt16_2, (ushort) ((uint) this.UInt16_3 + 1U), uint_0);
    this.dateTime_0 = DateTime.UtcNow;
  }

  internal void method_4()
  {
    if (DateTime.UtcNow.Subtract(this.dateTime_0).TotalSeconds < 1.0)
      return;
    this.class29_0.method_89(this.Byte_1, this.Int32_0, this.UInt16_2, this.UInt16_3);
    this.dateTime_0 = DateTime.UtcNow;
  }
}
