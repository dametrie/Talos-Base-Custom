﻿// Decompiled with JetBrains decompiler
// Type: Form0
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

internal class Form0 : Form
{
  private IContainer icontainer_0;
  internal TextBox textBox_0;
  private Button button_0;
  private Button button_1;
  private Label label_0;

  internal Form0(string class143_1)
  {
    this.method_0();
    this.label_0.Text = class143_1;
  }

  internal static DialogResult smethod_0(
    IWin32Window class143_1,
    [In] string obj1,
    [In] ref string obj2,
    [In] string obj3)
  {
    using (Form0 form0 = new Form0(obj1))
    {
      form0.button_0.Text = obj3;
      int num = (int) form0.ShowDialog(class143_1);
      obj2 = form0.textBox_0.Text;
      return (DialogResult) num;
    }
  }

  void Form.Dispose(bool string_0)
  {
    if (string_0 && this.icontainer_0 != null)
      this.icontainer_0.Dispose();
    // ISSUE: explicit non-virtual call
    __nonvirtual (((Form) this).Dispose(string_0));
  }

  private void method_0()
  {
    ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (Form0));
    this.textBox_0 = new TextBox();
    this.button_0 = new Button();
    this.button_1 = new Button();
    this.label_0 = new Label();
    this.SuspendLayout();
    this.textBox_0.Location = new Point(9, 54);
    this.textBox_0.Name = \u003CModule\u003E.smethod_5<string>(1603610111U);
    this.textBox_0.Size = new Size(109, 20);
    this.textBox_0.TabIndex = 0;
    this.button_0.DialogResult = DialogResult.OK;
    this.button_0.FlatStyle = FlatStyle.Flat;
    this.button_0.Location = new Point(124, 52);
    this.button_0.Name = \u003CModule\u003E.smethod_8<string>(2960027328U);
    this.button_0.Size = new Size(75, 23);
    this.button_0.TabIndex = 1;
    this.button_0.Text = \u003CModule\u003E.smethod_7<string>(1689167523U);
    this.button_0.UseVisualStyleBackColor = true;
    this.button_1.DialogResult = DialogResult.Cancel;
    this.button_1.FlatStyle = FlatStyle.Flat;
    this.button_1.Location = new Point(205, 52);
    this.button_1.Name = \u003CModule\u003E.smethod_7<string>(3303279321U);
    this.button_1.Size = new Size(75, 23);
    this.button_1.TabIndex = 2;
    this.button_1.Text = \u003CModule\u003E.smethod_7<string>(75055725U);
    this.button_1.UseVisualStyleBackColor = true;
    this.label_0.Location = new Point(0, 0);
    this.label_0.Name = \u003CModule\u003E.smethod_8<string>(2239851372U);
    this.label_0.Size = new Size(291, 49);
    this.label_0.TabIndex = 3;
    this.label_0.Text = \u003CModule\u003E.smethod_9<string>(1051773507U);
    this.label_0.TextAlign = ContentAlignment.MiddleCenter;
    this.AcceptButton = (IButtonControl) this.button_0;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.BackColor = Color.White;
    this.ClientSize = new Size(291, 86);
    this.Controls.Add((Control) this.label_0);
    this.Controls.Add((Control) this.button_1);
    this.Controls.Add((Control) this.button_0);
    this.Controls.Add((Control) this.textBox_0);
    this.DoubleBuffered = true;
    this.ForeColor = Color.Black;
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Icon = (Icon) componentResourceManager.GetObject(\u003CModule\u003E.smethod_5<string>(2034011204U));
    this.MaximizeBox = false;
    this.MinimizeBox = false;
    this.Name = \u003CModule\u003E.smethod_8<string>(3440144632U);
    this.ShowInTaskbar = false;
    this.SizeGripStyle = SizeGripStyle.Hide;
    this.StartPosition = FormStartPosition.CenterParent;
    this.Text = \u003CModule\u003E.smethod_9<string>(2983566486U);
    this.TopMost = true;
    this.ResumeLayout(false);
    this.PerformLayout();
  }
}
