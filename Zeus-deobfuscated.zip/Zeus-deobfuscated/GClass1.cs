﻿// Decompiled with JetBrains decompiler
// Type: GClass1
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Runtime.InteropServices;

public class GClass1
{
  public long Int64_0 => this.Int64_1 - this.Int64_2;

  public long Int64_1 { get; }

  public long Int64_2 { get; }

  public string String_0 { get; set; }

  public GClass1(string gclass6_0, long int_0, [In] long obj2)
  {
    this.String_0 = gclass6_0;
    this.Int64_2 = int_0;
    this.Int64_1 = obj2;
  }

  public virtual string System\u002EObject\u002EToString() => \u003CModule\u003E.smethod_9<string>(196757124U) + this.String_0 + \u003CModule\u003E.smethod_9<string>(2991312779U) + this.Int64_0.ToString(\u003CModule\u003E.smethod_8<string>(2695195909U)) + \u003CModule\u003E.smethod_7<string>(3919114233U);
}
