﻿// Decompiled with JetBrains decompiler
// Type: Class138
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Drawing;
using System.Runtime.InteropServices;

internal static class Class138
{
  private static readonly Random random_0 = new Random();

  internal static T smethod_0<T>()
  {
    Array values = Enum.GetValues(typeof (T));
    return (T) values.GetValue(new Random().Next(values.Length));
  }

  internal static int smethod_1() => Class138.random_0.Next();

  internal static int smethod_2(int value) => Class138.random_0.Next(value);

  internal static int smethod_3(int value, [In] int obj1) => Class138.random_0.Next(value, obj1 + 1);

  internal static Struct16 smethod_4(Struct19 value, [In] Struct19 obj1) => new Struct16((short) ((int) obj1.Int16_0 + ((int) obj1.Int16_2 / 2 - (int) value.Int16_2 / 2)), (short) ((int) obj1.Int16_1 + ((int) obj1.Int16_3 / 2 - (int) value.Int16_3 / 2)));

  internal static Bitmap smethod_5(Image value, [In] int obj1, [In] int obj2)
  {
    double num = Math.Min((double) obj1 / (double) value.Width, (double) obj2 / (double) value.Height);
    int width = (int) ((double) value.Width * num);
    int height = (int) ((double) value.Height * num);
    Bitmap original = new Bitmap(width, height);
    Graphics.FromImage((Image) original).DrawImage(value, 0, 0, width, height);
    return new Bitmap((Image) original);
  }

  internal static string smethod_6(string value) => string.IsNullOrEmpty(value) ? string.Empty : char.ToUpper(value[0]).ToString() + value.Substring(1);
}
