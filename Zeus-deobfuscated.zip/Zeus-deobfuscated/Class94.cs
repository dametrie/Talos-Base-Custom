﻿// Decompiled with JetBrains decompiler
// Type: Class94
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;

internal class Class94
{
  internal string String_0 { get; }

  internal List<Class95> List_0 { get; }

  internal Class94(string value, [In] Class95[] obj1)
  {
    this.String_0 = value;
    this.List_0 = new List<Class95>((IEnumerable<Class95>) obj1);
  }

  internal uint method_0()
  {
    MemoryStream output = new MemoryStream();
    BinaryWriter binaryWriter = new BinaryWriter((Stream) output);
    binaryWriter.Write((byte) this.List_0.Count);
    foreach (Class95 class95 in this.List_0)
    {
      binaryWriter.Write(class95.Struct16_0.short_0);
      binaryWriter.Write(class95.Struct16_0.short_1);
      binaryWriter.Write(class95.String_0);
      binaryWriter.Write(class95.Int16_0);
    }
    binaryWriter.Flush();
    byte[] array = output.ToArray();
    binaryWriter.Close();
    return Class73.smethod_0(array);
  }
}
