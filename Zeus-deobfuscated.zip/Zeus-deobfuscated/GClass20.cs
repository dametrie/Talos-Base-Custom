﻿// Decompiled with JetBrains decompiler
// Type: GClass20
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;

public class GClass20
{
  private List<byte[]> list_0 = new List<byte[]>();
  public const int int_0 = 56;
  public const int int_1 = 27;
  public const int int_2 = 1512;

  public byte[] this[int intptr_0]
  {
    get => this.list_0[intptr_0];
    set => this.list_0[obj0] = value;
  }

  public string String_0 { get; private set; }

  public string String_1 { get; [param: In] set; }

  public byte[][] Byte_0 => this.list_0.ToArray();

  public int Int32_0 { get; private set; }

  public static GClass20 smethod_0(string intptr_0)
  {
    GClass20 gclass20 = GClass20.smethod_4((Stream) new FileStream(intptr_0, FileMode.Open, FileAccess.Read, FileShare.Read));
    gclass20.String_1 = Path.GetFileNameWithoutExtension(intptr_0).ToUpper();
    gclass20.String_0 = intptr_0;
    return gclass20;
  }

  public static GClass20 smethod_1([In] byte[] obj0)
  {
    GClass20 gclass20 = GClass20.smethod_4((Stream) new MemoryStream(obj0));
    gclass20.String_1 = \u003CModule\u003E.smethod_7<string>(3001602776U);
    return gclass20;
  }

  public static GClass20 smethod_2(string string_0, [In] GClass22 obj1)
  {
    if (!obj1.method_0(string_0))
      return (GClass20) null;
    GClass20 gclass20 = GClass20.smethod_4((Stream) new MemoryStream(obj1.method_4(string_0)));
    gclass20.String_1 = Path.GetFileNameWithoutExtension(string_0).ToUpper();
    gclass20.String_0 = string_0;
    return gclass20;
  }

  public static GClass20 smethod_3([In] string obj0, bool string_0, [Out] GClass22 string_1)
  {
    if (!string_1.method_1(obj0, string_0))
      return (GClass20) null;
    GClass20 gclass20 = GClass20.smethod_4((Stream) new MemoryStream(string_1.method_5(obj0, string_0)));
    gclass20.String_1 = Path.GetFileNameWithoutExtension(obj0).ToUpper();
    gclass20.String_0 = obj0;
    return gclass20;
  }

  private static GClass20 smethod_4(Stream disposing)
  {
    disposing.Seek(0L, SeekOrigin.Begin);
    BinaryReader binaryReader = new BinaryReader(disposing);
    GClass20 gclass20 = new GClass20()
    {
      Int32_0 = (int) (binaryReader.BaseStream.Length / 1512L)
    };
    for (int index = 0; index < gclass20.Int32_0; ++index)
    {
      byte[] numArray = binaryReader.ReadBytes(1512);
      gclass20.list_0.Add(numArray);
    }
    binaryReader.Close();
    return gclass20;
  }

  public virtual string System\u002EObject\u002EToString() => \u003CModule\u003E.smethod_8<string>(2748688462U) + this.String_1 + \u003CModule\u003E.smethod_8<string>(265889603U) + this.list_0.Count.ToString() + \u003CModule\u003E.smethod_7<string>(3919114233U);
}
