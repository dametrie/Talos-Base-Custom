﻿// Decompiled with JetBrains decompiler
// Type: Control6
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using Accolade.Properties;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

internal class Control6 : UserControl, Interface0
{
  private readonly Form5 form5_0;
  private IContainer icontainer_0;
  private Label label_0;
  private TextBox textBox_0;
  private Label label_1;
  private Label label_2;
  private TextBox textBox_1;
  private Label label_3;
  private TextBox textBox_2;
  private Button button_0;
  private Button button_1;
  private Label label_4;

  internal Control6() => this.method_0();

  internal Control6(Form5 assemblyName_0)
  {
    this.method_0();
    this.form5_0 = assemblyName_0;
  }

  public void imethod_0() => Settings.Default.Save();

  private void button_0_Click(object stream_0, EventArgs stream_1)
  {
    this.form5_0.int_5 = int.Parse(this.textBox_0.Text);
    this.form5_0.int_8 = int.Parse(this.textBox_1.Text);
    this.form5_0.int_9 = int.Parse(this.textBox_2.Text);
    this.form5_0.timer_0.Enabled = true;
    this.form5_0.timer_0.Start();
    this.label_4.Text = \u003CModule\u003E.smethod_8<string>(229085206U);
    this.button_0.Enabled = false;
  }

  private void button_1_Click(object string_0, [In] EventArgs obj1)
  {
    this.form5_0.timer_0.Stop();
    this.form5_0.timer_0.Enabled = false;
    this.form5_0.int_5 = 0;
    this.form5_0.int_8 = 0;
    this.form5_0.int_9 = 0;
    this.label_4.Text = \u003CModule\u003E.smethod_7<string>(1679531346U);
    this.button_0.Enabled = true;
    this.form5_0.Text = \u003CModule\u003E.smethod_6<string>(1209782516U);
  }

  void ContainerControl.Dispose([In] bool obj0)
  {
    if (obj0 && this.icontainer_0 != null)
      this.icontainer_0.Dispose();
    // ISSUE: explicit non-virtual call
    __nonvirtual (((ContainerControl) this).Dispose(obj0));
  }

  private void method_0()
  {
    this.label_0 = new Label();
    this.textBox_0 = new TextBox();
    this.label_1 = new Label();
    this.label_2 = new Label();
    this.textBox_1 = new TextBox();
    this.label_3 = new Label();
    this.textBox_2 = new TextBox();
    this.button_0 = new Button();
    this.button_1 = new Button();
    this.label_4 = new Label();
    this.SuspendLayout();
    this.label_0.AutoSize = true;
    this.label_0.Font = new Font(\u003CModule\u003E.smethod_6<string>(628866057U), 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label_0.Location = new Point(25, 28);
    this.label_0.Name = \u003CModule\u003E.smethod_7<string>(1670444790U);
    this.label_0.Size = new Size(431, 15);
    this.label_0.TabIndex = 0;
    this.label_0.Text = \u003CModule\u003E.smethod_7<string>(3433605624U);
    this.textBox_0.Location = new Point(54, 89);
    this.textBox_0.Name = \u003CModule\u003E.smethod_6<string>(3243874626U);
    this.textBox_0.Size = new Size(100, 20);
    this.textBox_0.TabIndex = 1;
    this.textBox_0.Text = \u003CModule\u003E.smethod_5<string>(3977003337U);
    this.textBox_0.TextAlign = HorizontalAlignment.Center;
    this.label_1.AutoSize = true;
    this.label_1.Font = new Font(\u003CModule\u003E.smethod_9<string>(1751960899U), 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label_1.Location = new Point(51, 71);
    this.label_1.Name = \u003CModule\u003E.smethod_6<string>(2053696975U);
    this.label_1.Size = new Size(37, 15);
    this.label_1.TabIndex = 2;
    this.label_1.Text = \u003CModule\u003E.smethod_8<string>(2683164279U);
    this.label_2.AutoSize = true;
    this.label_2.Font = new Font(\u003CModule\u003E.smethod_6<string>(628866057U), 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label_2.Location = new Point(182, 71);
    this.label_2.Name = \u003CModule\u003E.smethod_7<string>(1864096238U);
    this.label_2.Size = new Size(46, 15);
    this.label_2.TabIndex = 4;
    this.label_2.Text = \u003CModule\u003E.smethod_8<string>(1322393360U);
    this.textBox_1.Location = new Point(185, 89);
    this.textBox_1.Name = \u003CModule\u003E.smethod_5<string>(2798179669U);
    this.textBox_1.Size = new Size(100, 20);
    this.textBox_1.TabIndex = 3;
    this.textBox_1.Text = \u003CModule\u003E.smethod_5<string>(3977003337U);
    this.textBox_1.TextAlign = HorizontalAlignment.Center;
    this.label_3.AutoSize = true;
    this.label_3.Font = new Font(\u003CModule\u003E.smethod_6<string>(628866057U), 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label_3.Location = new Point(313, 71);
    this.label_3.Name = \u003CModule\u003E.smethod_6<string>(2202461653U);
    this.label_3.Size = new Size(49, 15);
    this.label_3.TabIndex = 6;
    this.label_3.Text = \u003CModule\u003E.smethod_5<string>(4186985753U);
    this.textBox_2.Location = new Point(316, 89);
    this.textBox_2.Name = \u003CModule\u003E.smethod_6<string>(2261945394U);
    this.textBox_2.Size = new Size(100, 20);
    this.textBox_2.TabIndex = 5;
    this.textBox_2.Text = \u003CModule\u003E.smethod_6<string>(2168613809U);
    this.textBox_2.TextAlign = HorizontalAlignment.Center;
    this.button_0.FlatStyle = FlatStyle.Flat;
    this.button_0.Location = new Point(316, 115);
    this.button_0.Name = \u003CModule\u003E.smethod_6<string>(1433685878U);
    this.button_0.Size = new Size(46, 23);
    this.button_0.TabIndex = 15;
    this.button_0.Text = \u003CModule\u003E.smethod_6<string>(3918464426U);
    this.button_0.UseVisualStyleBackColor = true;
    this.button_0.Click += new EventHandler(this.button_0_Click);
    this.button_1.FlatStyle = FlatStyle.Flat;
    this.button_1.Location = new Point(368, 115);
    this.button_1.Name = \u003CModule\u003E.smethod_7<string>(3405613128U);
    this.button_1.Size = new Size(48, 23);
    this.button_1.TabIndex = 18;
    this.button_1.Text = \u003CModule\u003E.smethod_9<string>(1009452937U);
    this.button_1.UseVisualStyleBackColor = true;
    this.button_1.Click += new EventHandler(this.button_1_Click);
    this.label_4.AutoSize = true;
    this.label_4.Font = new Font(\u003CModule\u003E.smethod_8<string>(415651305U), 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.label_4.Location = new Point(324, 188);
    this.label_4.Name = \u003CModule\u003E.smethod_7<string>(3131929079U);
    this.label_4.Size = new Size(0, 15);
    this.label_4.TabIndex = 19;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.BackColor = Color.White;
    this.Controls.Add((Control) this.label_4);
    this.Controls.Add((Control) this.button_1);
    this.Controls.Add((Control) this.button_0);
    this.Controls.Add((Control) this.label_3);
    this.Controls.Add((Control) this.textBox_2);
    this.Controls.Add((Control) this.label_2);
    this.Controls.Add((Control) this.textBox_1);
    this.Controls.Add((Control) this.label_1);
    this.Controls.Add((Control) this.textBox_0);
    this.Controls.Add((Control) this.label_0);
    this.ForeColor = Color.Black;
    this.Name = \u003CModule\u003E.smethod_5<string>(425735194U);
    this.Size = new Size(490, 258);
    this.ResumeLayout(false);
    this.PerformLayout();
  }
}
