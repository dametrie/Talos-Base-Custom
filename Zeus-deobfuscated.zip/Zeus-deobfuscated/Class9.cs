﻿// Decompiled with JetBrains decompiler
// Type: Class9
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Resources;
using System.Runtime.CompilerServices;

[DebuggerNonUserCode]
[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "15.0.0.0")]
[CompilerGenerated]
internal class Class9
{
  private static ResourceManager resourceManager_0;
  private static CultureInfo cultureInfo_0;

  internal Class9()
  {
  }

  [EditorBrowsable(EditorBrowsableState.Advanced)]
  internal static ResourceManager ResourceManager_0
  {
    get
    {
      if (Class9.resourceManager_0 == null)
        Class9.resourceManager_0 = new ResourceManager(\u003CModule\u003E.smethod_9<string>(2500039691U), typeof (Class9).Assembly);
      return Class9.resourceManager_0;
    }
  }

  [EditorBrowsable(EditorBrowsableState.Advanced)]
  internal static CultureInfo CultureInfo_0
  {
    get => Class9.cultureInfo_0;
    set => Class9.cultureInfo_0 = value;
  }

  internal static string String_0 => Class9.ResourceManager_0.GetString(\u003CModule\u003E.smethod_9<string>(774514339U), Class9.cultureInfo_0);

  internal static UnmanagedMemoryStream UnmanagedMemoryStream_0 => Class9.ResourceManager_0.GetStream(\u003CModule\u003E.smethod_8<string>(186308610U), Class9.cultureInfo_0);

  internal static Bitmap Bitmap_0 => (Bitmap) Class9.ResourceManager_0.GetObject(\u003CModule\u003E.smethod_8<string>(2213762932U), Class9.cultureInfo_0);

  internal static Bitmap Bitmap_1 => (Bitmap) Class9.ResourceManager_0.GetObject(\u003CModule\u003E.smethod_6<string>(865971843U), Class9.cultureInfo_0);

  internal static Bitmap Bitmap_2 => (Bitmap) Class9.ResourceManager_0.GetObject(\u003CModule\u003E.smethod_9<string>(2323717939U), Class9.cultureInfo_0);

  internal static Bitmap Bitmap_3 => (Bitmap) Class9.ResourceManager_0.GetObject(\u003CModule\u003E.smethod_9<string>(2882629070U), Class9.cultureInfo_0);

  internal static Bitmap Bitmap_4 => (Bitmap) Class9.ResourceManager_0.GetObject(\u003CModule\u003E.smethod_7<string>(858845613U), Class9.cultureInfo_0);

  internal static Icon Icon_0 => (Icon) Class9.ResourceManager_0.GetObject(\u003CModule\u003E.smethod_6<string>(485689929U), Class9.cultureInfo_0);

  internal static byte[] Byte_0 => (byte[]) Class9.ResourceManager_0.GetObject(\u003CModule\u003E.smethod_8<string>(3922893282U), Class9.cultureInfo_0);

  internal static byte[] Byte_1 => (byte[]) Class9.ResourceManager_0.GetObject(\u003CModule\u003E.smethod_8<string>(401594495U), Class9.cultureInfo_0);

  internal static UnmanagedMemoryStream UnmanagedMemoryStream_1 => Class9.ResourceManager_0.GetStream(\u003CModule\u003E.smethod_9<string>(785614130U), Class9.cultureInfo_0);

  internal static UnmanagedMemoryStream UnmanagedMemoryStream_2 => Class9.ResourceManager_0.GetStream(\u003CModule\u003E.smethod_6<string>(3668497972U), Class9.cultureInfo_0);

  internal static UnmanagedMemoryStream UnmanagedMemoryStream_3 => Class9.ResourceManager_0.GetStream(\u003CModule\u003E.smethod_8<string>(2855673568U), Class9.cultureInfo_0);

  internal static Bitmap Bitmap_5 => (Bitmap) Class9.ResourceManager_0.GetObject(\u003CModule\u003E.smethod_8<string>(3629342077U), Class9.cultureInfo_0);

  internal static UnmanagedMemoryStream UnmanagedMemoryStream_4 => Class9.ResourceManager_0.GetStream(\u003CModule\u003E.smethod_5<string>(1276524662U), Class9.cultureInfo_0);

  internal static string String_1 => Class9.ResourceManager_0.GetString(\u003CModule\u003E.smethod_5<string>(1938790443U), Class9.cultureInfo_0);

  internal static string String_2 => Class9.ResourceManager_0.GetString(\u003CModule\u003E.smethod_8<string>(2135497612U), Class9.cultureInfo_0);

  internal static byte[] Byte_2 => (byte[]) Class9.ResourceManager_0.GetObject(\u003CModule\u003E.smethod_5<string>(2601056224U), Class9.cultureInfo_0);

  internal static Bitmap Bitmap_6 => (Bitmap) Class9.ResourceManager_0.GetObject(\u003CModule\u003E.smethod_6<string>(462250234U), Class9.cultureInfo_0);

  internal static string String_3 => Class9.ResourceManager_0.GetString(\u003CModule\u003E.smethod_6<string>(1574409487U), Class9.cultureInfo_0);

  internal static Bitmap Bitmap_7 => (Bitmap) Class9.ResourceManager_0.GetObject(\u003CModule\u003E.smethod_9<string>(1982174226U), Class9.cultureInfo_0);

  internal static Bitmap Bitmap_8 => (Bitmap) Class9.ResourceManager_0.GetObject(\u003CModule\u003E.smethod_9<string>(1295733302U), Class9.cultureInfo_0);

  internal static UnmanagedMemoryStream UnmanagedMemoryStream_5 => Class9.ResourceManager_0.GetStream(\u003CModule\u003E.smethod_6<string>(4189418056U), Class9.cultureInfo_0);

  internal static Bitmap Bitmap_9 => (Bitmap) Class9.ResourceManager_0.GetObject(\u003CModule\u003E.smethod_8<string>(1254843997U), Class9.cultureInfo_0);

  internal static UnmanagedMemoryStream UnmanagedMemoryStream_6 => Class9.ResourceManager_0.GetStream(\u003CModule\u003E.smethod_8<string>(1014785345U), Class9.cultureInfo_0);

  internal static byte[] Byte_3 => (byte[]) Class9.ResourceManager_0.GetObject(\u003CModule\u003E.smethod_8<string>(2028512506U), Class9.cultureInfo_0);

  internal static Bitmap Bitmap_10 => (Bitmap) Class9.ResourceManager_0.GetObject(\u003CModule\u003E.smethod_6<string>(722710276U), Class9.cultureInfo_0);

  internal static UnmanagedMemoryStream UnmanagedMemoryStream_7 => Class9.ResourceManager_0.GetStream(\u003CModule\u003E.smethod_5<string>(2902908273U), Class9.cultureInfo_0);

  internal static Bitmap Bitmap_11 => (Bitmap) Class9.ResourceManager_0.GetObject(\u003CModule\u003E.smethod_9<string>(3677753703U), Class9.cultureInfo_0);

  internal static Bitmap Bitmap_12 => (Bitmap) Class9.ResourceManager_0.GetObject(\u003CModule\u003E.smethod_7<string>(936582190U), Class9.cultureInfo_0);

  internal static Bitmap Bitmap_13 => (Bitmap) Class9.ResourceManager_0.GetObject(\u003CModule\u003E.smethod_5<string>(659012842U), Class9.cultureInfo_0);
}
