﻿// Decompiled with JetBrains decompiler
// Type: Class19
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using Accolade;
using System.Runtime.InteropServices;

internal class Class19
{
  internal string String_0 { get; }

  internal TemClass TemClass_0 { get; }

  internal MedClass MedClass_0 { get; }

  internal byte Byte_0 { get; }

  internal byte Byte_1 { get; }

  internal byte Byte_2 { get; }

  internal byte Byte_3 { get; }

  internal byte Byte_4 { get; }

  internal byte Byte_5 { get; }

  internal byte Byte_6 { get; }

  internal string String_1 { get; }

  internal string String_2 { get; }

  internal string String_3 { get; }

  internal int Int32_0 { get; }

  internal string String_4 { get; }

  internal Class19(
    [In] string obj0,
    TemClass @object,
    [In] MedClass obj2,
    [In] byte obj3,
    [In] byte obj4,
    [In] byte obj5,
    [In] byte obj6,
    [In] byte obj7,
    [In] byte obj8,
    [In] byte obj9,
    [In] string obj10,
    [In] string obj11,
    [In] string obj12,
    [In] int obj13,
    [In] string obj14)
  {
    this.String_0 = obj0;
    this.TemClass_0 = @object;
    this.MedClass_0 = obj2;
    this.Byte_0 = obj3;
    this.Byte_1 = obj4;
    this.Byte_2 = obj5;
    this.Byte_3 = obj6;
    this.Byte_4 = obj7;
    this.Byte_5 = obj8;
    this.Byte_6 = obj9;
    this.String_1 = obj10;
    this.String_2 = obj11;
    this.String_3 = obj12;
    this.Int32_0 = obj13;
    this.String_4 = obj14;
  }
}
