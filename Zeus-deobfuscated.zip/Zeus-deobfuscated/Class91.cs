﻿// Decompiled with JetBrains decompiler
// Type: Class91
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Runtime.InteropServices;

internal class Class91 : Class90
{
  internal bool Boolean_0 { get; set; }

  internal DateTime DateTime_0 { get; [param: In] set; }

  internal Struct17 Struct17_0 => new Struct17(this.short_0, (short) this.byte_0, (short) this.byte_1);

  internal Struct16 Struct16_0 => new Struct16((short) this.byte_0, (short) this.byte_1);

  internal short Int16_0 => this.short_0;

  internal bool Boolean_1 => DateTime.UtcNow.Subtract(this.DateTime_0).TotalSeconds < 1.5;

  internal Class91(Struct17 disposing, [In] bool obj1)
  {
    this.short_0 = disposing.Int16_0;
    this.byte_0 = (byte) disposing.Struct16_0.short_0;
    this.byte_1 = (byte) disposing.Struct16_0.short_1;
    this.Boolean_0 = obj1;
    this.DateTime_0 = DateTime.MinValue;
  }

  internal Class91([In] Struct16 obj0, short class29_1, [In] bool obj2)
  {
    this.byte_0 = (byte) obj0.short_0;
    this.byte_1 = (byte) obj0.short_1;
    this.short_0 = class29_1;
    this.Boolean_0 = obj2;
    this.DateTime_0 = DateTime.MinValue;
  }

  internal Class91(byte sender, byte e, [In] short obj2, [In] bool obj3)
  {
    this.byte_0 = sender;
    this.byte_1 = e;
    this.short_0 = obj2;
  }
}
