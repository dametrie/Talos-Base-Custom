﻿// Decompiled with JetBrains decompiler
// Type: GClass21
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Runtime.InteropServices;

public class GClass21
{
  public GClass22 GClass22_0 { get; set; }

  public GClass22 GClass22_1 { get; set; }

  public GClass22 GClass22_2 { get; set; }

  public GClass22 GClass22_3 { get; set; }

  public GClass22 GClass22_4 { get; set; }

  public GClass21(string value, [In] bool obj1)
  {
    string str = obj1 ? \u003CModule\u003E.smethod_8<string>(4135547821U) : \u003CModule\u003E.smethod_7<string>(2768393045U);
    this.GClass22_0 = GClass22.smethod_0(value + \u003CModule\u003E.smethod_8<string>(1868034847U) + str + \u003CModule\u003E.smethod_6<string>(2900149392U));
    this.GClass22_1 = GClass22.smethod_0(value + \u003CModule\u003E.smethod_9<string>(3070050613U) + str + \u003CModule\u003E.smethod_5<string>(999906013U));
    this.GClass22_2 = GClass22.smethod_0(value + \u003CModule\u003E.smethod_9<string>(3070050613U) + str + \u003CModule\u003E.smethod_9<string>(1393317220U));
    this.GClass22_3 = GClass22.smethod_0(value + \u003CModule\u003E.smethod_9<string>(3070050613U) + str + \u003CModule\u003E.smethod_7<string>(2796385541U));
    this.GClass22_4 = GClass22.smethod_0(value + \u003CModule\u003E.smethod_9<string>(3070050613U) + str + \u003CModule\u003E.smethod_8<string>(4082055268U));
  }
}
