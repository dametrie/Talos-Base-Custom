﻿// Decompiled with JetBrains decompiler
// Type: Class135
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Runtime.InteropServices;

internal sealed class Class135 : Class134
{
  private static readonly DateTime dateTime_2 = DateTime.MinValue;

  internal Delegate4 Delegate4_0 { get; }

  internal Class135([In] string obj0)
  {
  }

  internal Class135(byte intptr_0, string intptr_1, string intptr_2, Delegate4 uint_1)
  {
    this.Byte_1 = intptr_0;
    this.String_0 = intptr_1;
    this.String_1 = intptr_2;
    this.Delegate4_0 = uint_1;
  }
}
