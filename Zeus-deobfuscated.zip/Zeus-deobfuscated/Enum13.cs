﻿// Decompiled with JetBrains decompiler
// Type: Enum13
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

internal enum Enum13 : byte
{
  Red = 98, // 0x62
  Yellow = 99, // 0x63
  DarkGreen = 100, // 0x64
  Silver = 101, // 0x65
  DarkBlue = 102, // 0x66
  White = 103, // 0x67
  LighterGray = 104, // 0x68
  LightGray = 105, // 0x69
  Gray = 106, // 0x6A
  DarkGray = 107, // 0x6B
  DarkerGray = 108, // 0x6C
  Black = 109, // 0x6D
  HotPink = 111, // 0x6F
  DarkPurple = 112, // 0x70
  NeonGreen = 113, // 0x71
  Orange = 115, // 0x73
  Brown = 116, // 0x74
}
