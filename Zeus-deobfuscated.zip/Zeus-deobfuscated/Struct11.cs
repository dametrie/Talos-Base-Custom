﻿// Decompiled with JetBrains decompiler
// Type: Struct11
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Runtime.InteropServices;

internal struct Struct11
{
  internal int Int32_0 { get; set; }

  internal int Int32_1 { get; set; }

  internal ushort UInt16_0 { get; set; }

  internal ushort UInt16_1 { get; set; }

  internal short Int16_0 { get; set; }

  internal Struct11(int value, [In] int obj1, [In] ushort obj2, [In] ushort obj3, [In] short obj4)
  {
    this.Int32_0 = value;
    this.Int32_1 = obj1;
    this.UInt16_0 = obj2;
    this.UInt16_1 = obj3;
    this.Int16_0 = obj4;
  }
}
