﻿// Decompiled with JetBrains decompiler
// Type: Class74
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Runtime.InteropServices;

internal static class Class74
{
  private static readonly ushort[] ushort_0 = \u003CModule\u003E.smethod_5<ushort[]>(1891058927U);

  internal static ushort smethod_0([In] byte[] obj0) => Class74.smethod_1(obj0, 0, obj0.Length);

  internal static ushort smethod_1([In] byte[] obj0, [In] int obj1, [In] int obj2)
  {
    ushort num = 0;
    for (int index = 0; index < obj2; ++index)
      num = (ushort) ((ulong) ((int) obj0[obj1 + index] ^ (int) (ushort) ((uint) num << 8)) ^ (ulong) Class74.ushort_0[(int) num >> 8]);
    return num;
  }
}
