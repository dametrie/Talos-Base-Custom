﻿// Decompiled with JetBrains decompiler
// Type: Class143
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using Accolade;
using System;
using System.Runtime.InteropServices;

internal sealed class Class143 : Class142
{
  internal bool bool_1;

  internal ushort UInt16_1 { get; set; }

  internal byte Byte_2 { get; set; }

  internal ushort UInt16_2 { get; set; }

  internal ushort UInt16_3 { get; set; }

  internal byte Byte_3 { get; set; }

  internal byte Byte_4 { get; set; }

  internal ushort UInt16_4 { get; set; }

  internal byte Byte_5 { get; set; }

  internal byte Byte_6 { get; set; }

  internal byte Byte_7 { get; set; }

  internal ushort UInt16_5 { get; set; }

  internal byte Byte_8 { get; set; }

  internal ushort UInt16_6 { get; set; }

  internal byte Byte_9 { get; set; }

  internal ushort UInt16_7 { get; set; }

  internal byte Byte_10 { get; set; }

  internal byte Byte_11 { get; set; }

  internal ushort UInt16_8 { get; set; }

  internal byte Byte_12 { get; set; }

  internal byte Byte_13 { get; set; }

  internal byte Byte_14 { get; set; }

  internal byte Byte_15 { get; set; }

  internal string String_4 { get; set; }

  internal bool Boolean_8 { get; set; }

  internal DateTime DateTime_6 { get; set; }

  internal string String_5
  {
    get => this.String_0;
    set => this.String_0 = value;
  }

  internal bool Boolean_9
  {
    get
    {
      if (!this.Dictionary_0.ContainsKey((ushort) 20))
        return false;
      return DateTime.UtcNow.Subtract(this.DateTime_6).TotalMinutes < 30.0 || DateTime.UtcNow.Subtract(this.Dictionary_0[(ushort) 20]).TotalMinutes < 2.5;
    }
  }

  internal bool Boolean_10 => this.Dictionary_0.ContainsKey((ushort) 24) && DateTime.UtcNow.Subtract(this.Dictionary_0[(ushort) 24]).TotalSeconds < 2.0;

  internal Class143(int value, string class29_1, [In] Struct16 obj2, [In] Class88 obj3, [In] Direction obj4)
    : base(value, class29_1, (ushort) 0, (byte) 4, obj2, obj3, obj4)
  {
    this.Byte_0 = (byte) 4;
    this.DateTime_6 = DateTime.MinValue;
  }

  internal void method_2()
  {
    this.UInt16_2 = (ushort) 0;
    this.Byte_3 = (byte) 0;
    this.UInt16_3 = (ushort) 0;
    this.Byte_4 = (byte) 0;
    this.UInt16_4 = (ushort) 0;
    this.Byte_5 = (byte) 0;
    this.Byte_6 = (byte) 0;
    this.Byte_7 = (byte) 0;
    this.UInt16_5 = (ushort) 0;
    this.Byte_8 = (byte) 0;
    this.UInt16_6 = (ushort) 0;
    this.Byte_8 = (byte) 0;
    this.UInt16_6 = (ushort) 0;
    this.Byte_10 = (byte) 0;
    this.Byte_11 = (byte) 0;
    this.UInt16_8 = (ushort) 0;
    this.Byte_12 = (byte) 0;
  }
}
