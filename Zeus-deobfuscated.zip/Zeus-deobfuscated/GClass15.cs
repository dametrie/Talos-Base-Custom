﻿// Decompiled with JetBrains decompiler
// Type: GClass15
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Runtime.InteropServices;

public class GClass15
{
  public bool Boolean_0 => this.Byte_0 != null && this.Byte_0.Length >= 1 && this.Int32_3 >= 1 && this.Int32_2 >= 1 && this.Int32_3 * this.Int32_2 == this.Byte_0.Length;

  public int Int32_0 { get; }

  public int Int32_1 { get; }

  public byte[] Byte_0 { get; }

  public int Int32_2 { get; }

  public int Int32_3 { get; }

  public int Int32_4 { get; set; }

  public int Int32_5 { get; set; }

  public GClass15(int value, int bool_0, [In] int obj2, [In] int obj3, [In] int obj4, [In] int obj5, [In] byte[] obj6)
  {
    this.Int32_5 = value;
    this.Int32_4 = bool_0;
    this.Int32_3 = obj2;
    this.Int32_2 = obj3;
    this.Int32_1 = obj4;
    this.Int32_0 = obj5;
    this.Byte_0 = obj6;
  }

  public virtual string System\u002EObject\u002EToString() => \u003CModule\u003E.smethod_6<string>(3858638929U) + this.Int32_5.ToString() + \u003CModule\u003E.smethod_9<string>(3628961744U) + this.Int32_4.ToString() + \u003CModule\u003E.smethod_8<string>(2348152151U) + this.Int32_3.ToString() + \u003CModule\u003E.smethod_8<string>(2212447259U) + this.Int32_2.ToString() + \u003CModule\u003E.smethod_6<string>(1222814062U) + this.Int32_1.ToString() + \u003CModule\u003E.smethod_5<string>(4258386074U) + this.Int32_0.ToString() + \u003CModule\u003E.smethod_9<string>(943089798U);
}
