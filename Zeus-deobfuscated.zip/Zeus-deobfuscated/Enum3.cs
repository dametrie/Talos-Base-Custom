﻿// Decompiled with JetBrains decompiler
// Type: Enum3
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;

[Flags]
internal enum Enum3 : byte
{
  None = 0,
  Fire = 1,
  Water = 2,
  Wind = Water | Fire, // 0x03
  Earth = 4,
  Holy = Earth | Fire, // 0x05
  Darkness = Earth | Water, // 0x06
  Wood = Darkness | Fire, // 0x07
  Metal = 8,
  Nature = Metal | Fire, // 0x09
  Any = Metal | Water, // 0x0A
}
