﻿// Decompiled with JetBrains decompiler
// Type: Class5`2
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[CompilerGenerated]
internal sealed class Class5<T, U>
{
  [DebuggerBrowsable(DebuggerBrowsableState.Never)]
  private readonly T gparam_0;
  [DebuggerBrowsable(DebuggerBrowsableState.Never)]
  private readonly U gparam_1;

  public T g => this.gparam_0;

  public U count => this.gparam_1;

  [DebuggerHidden]
  public Class5(T gclass4_0, U gclass6_0)
  {
    // ISSUE: reference to a compiler-generated field
    this.gparam_0 = gclass4_0;
    // ISSUE: reference to a compiler-generated field
    this.gparam_1 = gclass6_0;
  }

  [DebuggerHidden]
  public virtual bool System\u002EObject\u002EEquals([In] object obj0) => obj0 is Class5<T, U> class5 && EqualityComparer<T>.Default.Equals(this.gparam_0, class5.gparam_0) && EqualityComparer<U>.Default.Equals(this.gparam_1, class5.gparam_1);

  [DebuggerHidden]
  public virtual int System\u002EObject\u002EGetHashCode() => (EqualityComparer<T>.Default.GetHashCode(this.gparam_0) - 1699910972) * -1521134295 + EqualityComparer<U>.Default.GetHashCode(this.gparam_1);

  [DebuggerHidden]
  public virtual string System\u002EObject\u002EToString()
  {
    string format = \u003CModule\u003E.smethod_6<string>(1871340770U);
    object[] objArray = new object[2];
    // ISSUE: reference to a compiler-generated field
    T gparam0 = this.gparam_0;
    ref T local1 = ref gparam0;
    objArray[0] = (object) ((object) local1 != null ? local1.ToString() : (string) null);
    // ISSUE: reference to a compiler-generated field
    U gparam1 = this.gparam_1;
    ref U local2 = ref gparam1;
    objArray[1] = (object) ((object) local2 != null ? local2.ToString() : (string) null);
    return string.Format((IFormatProvider) null, format, objArray);
  }
}
