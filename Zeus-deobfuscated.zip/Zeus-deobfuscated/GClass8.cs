﻿// Decompiled with JetBrains decompiler
// Type: GClass8
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Runtime.InteropServices;

public class GClass8
{
  public int Int32_0 { get; set; }

  public int Int32_1 { get; set; }

  public int Int32_2 { get; [param: In] set; }

  public GClass8([In] int obj0, [In] int obj1, int int_4)
  {
    this.Int32_2 = obj0;
    this.Int32_1 = obj1;
    this.Int32_0 = int_4;
  }

  public virtual string System\u002EObject\u002EToString() => \u003CModule\u003E.smethod_8<string>(2879130662U) + this.Int32_2.ToString() + \u003CModule\u003E.smethod_7<string>(271003197U) + this.Int32_1.ToString() + \u003CModule\u003E.smethod_7<string>(1064062848U) + this.Int32_0.ToString() + \u003CModule\u003E.smethod_6<string>(2923589087U);
}
