﻿// Decompiled with JetBrains decompiler
// Type: Class111
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Runtime.InteropServices;

internal sealed class Class111
{
  internal Class92 Class92_0 { get; [param: In] set; }

  internal Class111 Class111_0 { get; set; }

  internal bool Boolean_0 { get; [param: In] set; }

  internal bool Boolean_1 { get; set; }

  internal float Single_0 { get; [param: In] set; }

  internal Struct17 Struct17_0 { get; }

  internal Class111(Struct17 class29_0) => this.Struct17_0 = class29_0;
}
