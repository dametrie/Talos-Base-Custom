﻿// Decompiled with JetBrains decompiler
// Type: Class96
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

internal class Class96
{
  internal string String_0 { get; }

  internal List<Class97> List_0 { get; }

  private Class96(string offset)
  {
    this.String_0 = offset;
    this.List_0 = new List<Class97>();
  }

  internal static Class96 smethod_0([In] string obj0)
  {
    try
    {
      Class96 class96 = new Class96(Path.GetFileNameWithoutExtension(obj0));
      FileStream input = File.Open(obj0, FileMode.Open, FileAccess.Read, FileShare.Read);
      BinaryReader binaryReader = new BinaryReader((Stream) input, Encoding.GetEncoding(949));
      int num1 = (int) binaryReader.ReadByte() << 8 | (int) binaryReader.ReadByte();
      for (int index1 = 0; index1 < num1; ++index1)
      {
        Class97 class97 = new Class97(binaryReader.ReadString());
        int num2 = (int) binaryReader.ReadByte() << 8 | (int) binaryReader.ReadByte();
        for (int index2 = 0; index2 < num2; ++index2)
        {
          int count = (int) binaryReader.ReadByte() << 8 | (int) binaryReader.ReadByte();
          byte[] bytes = binaryReader.ReadBytes(count);
          class97.List_0.Add(Encoding.GetEncoding(949).GetString(bytes));
        }
        class96.List_0.Add(class97);
      }
      binaryReader.Close();
      input.Close();
      return class96;
    }
    catch
    {
      return (Class96) null;
    }
  }
}
