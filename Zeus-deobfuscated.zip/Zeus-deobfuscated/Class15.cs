﻿// Decompiled with JetBrains decompiler
// Type: Class15
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Runtime.InteropServices;

internal class Class15
{
  internal Class134 Class134_0 { get; set; }

  internal Class142 Class142_0 { get; set; }

  internal Class15([In] Class134 obj0, Class142 temClass_1)
  {
    this.Class134_0 = obj0;
    this.Class142_0 = temClass_1;
  }
}
