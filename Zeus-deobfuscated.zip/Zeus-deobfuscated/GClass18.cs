﻿// Decompiled with JetBrains decompiler
// Type: GClass18
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;

public class GClass18
{
  private List<GClass17> list_0 = new List<GClass17>();
  private Dictionary<int, GClass16> dictionary_0 = new Dictionary<int, GClass16>();
  private List<GClass17> list_1 = new List<GClass17>();

  public GClass16 this[int value]
  {
    get
    {
      int key = 0;
      foreach (GClass17 gclass17 in this.list_1)
      {
        if (value >= gclass17.Int32_2 && value <= gclass17.Int32_1)
          key = gclass17.Int32_0;
      }
      foreach (GClass17 gclass17 in this.list_0)
      {
        if (value >= gclass17.Int32_2 && value <= gclass17.Int32_1)
          key = gclass17.Int32_0;
      }
      return this.dictionary_0[key];
    }
  }

  public GClass16 method_0(string value)
  {
    int key = 0;
    int int32 = Convert.ToInt32(value.Substring(2, 3));
    if (value.StartsWith(\u003CModule\u003E.smethod_9<string>(3756491537U)))
    {
      foreach (GClass17 gclass17 in this.list_1)
      {
        if (int32 >= gclass17.Int32_2 && int32 <= gclass17.Int32_1)
          key = gclass17.Int32_0;
      }
    }
    else if (value.StartsWith(\u003CModule\u003E.smethod_5<string>(2517261141U)))
    {
      foreach (GClass17 gclass17 in this.list_0)
      {
        if (int32 >= gclass17.Int32_2 && int32 <= gclass17.Int32_1)
          key = gclass17.Int32_0;
      }
    }
    if (key < 0 || key > this.dictionary_0.Count)
      key = 0;
    return this.dictionary_0[key];
  }

  private int method_1(Stream value)
  {
    value.Seek(0L, SeekOrigin.Begin);
    StreamReader streamReader = new StreamReader(value);
    this.list_0.Clear();
    while (!streamReader.EndOfStream)
    {
      string[] strArray = streamReader.ReadLine().Split(' ');
      if (strArray.Length == 3)
        this.list_0.Add(new GClass17(Convert.ToInt32(strArray[0]), Convert.ToInt32(strArray[1]), Convert.ToInt32(strArray[2])));
      else if (strArray.Length == 2)
      {
        int int32_1 = Convert.ToInt32(strArray[0]);
        int num = int32_1;
        int int32_2 = Convert.ToInt32(strArray[1]);
        this.list_0.Add(new GClass17(int32_1, num, int32_2));
      }
    }
    streamReader.Close();
    return this.list_0.Count;
  }

  public int method_2(string string_1, GClass22 int_2)
  {
    this.dictionary_0.Clear();
    foreach (GClass23 gclass23 in int_2.GClass23_0)
    {
      if (gclass23.String_0.Length == 11 && gclass23.String_0.ToUpper().EndsWith(\u003CModule\u003E.smethod_8<string>(3172681867U)) && gclass23.String_0.ToUpper().StartsWith(string_1.ToUpper()))
        this.dictionary_0.Add(Convert.ToInt32(Path.GetFileNameWithoutExtension(gclass23.String_0).Remove(0, string_1.Length)), GClass16.smethod_2(gclass23.String_0, int_2));
    }
    return this.dictionary_0.Count;
  }

  public int method_3([In] string obj0, [In] GClass22 obj1)
  {
    this.list_0.Clear();
    foreach (GClass23 gclass23 in obj1.GClass23_0)
    {
      if (gclass23.String_0.ToUpper().EndsWith(\u003CModule\u003E.smethod_7<string>(628664734U)) && gclass23.String_0.ToUpper().StartsWith(obj0.ToUpper()) && Path.GetFileNameWithoutExtension(gclass23.String_0).Remove(0, obj0.Length) != \u003CModule\u003E.smethod_5<string>(3937013464U))
      {
        StreamReader streamReader = new StreamReader((Stream) new MemoryStream(obj1.method_6(gclass23)));
        while (!streamReader.EndOfStream)
        {
          string[] strArray = streamReader.ReadLine().TrimEnd().Split(' ');
          if (strArray.Length == 3)
          {
            int int32_1 = Convert.ToInt32(strArray[0]);
            int int32_2 = Convert.ToInt32(strArray[1]);
            int int32_3 = Convert.ToInt32(strArray[2]);
            switch (int32_3)
            {
              case -2:
                this.list_1.Add(new GClass17(int32_1, int32_1, int32_2));
                continue;
              case -1:
                this.list_0.Add(new GClass17(int32_1, int32_1, int32_2));
                continue;
              default:
                this.list_0.Add(new GClass17(int32_1, int32_2, int32_3));
                this.list_1.Add(new GClass17(int32_1, int32_2, int32_3));
                continue;
            }
          }
          else if (strArray.Length == 2)
          {
            int int32_4 = Convert.ToInt32(strArray[0]);
            int num = int32_4;
            int int32_5 = Convert.ToInt32(strArray[1]);
            this.list_1.Add(new GClass17(int32_4, num, int32_5));
            this.list_0.Add(new GClass17(int32_4, num, int32_5));
          }
        }
        streamReader.Close();
      }
    }
    return this.list_0.Count;
  }

  public virtual string System\u002EObject\u002EToString() => \u003CModule\u003E.smethod_8<string>(2452505911U) + this.list_0.Count.ToString() + \u003CModule\u003E.smethod_9<string>(2345917521U) + (string) (ValueType) this.dictionary_0.Count + \u003CModule\u003E.smethod_6<string>(2923589087U);
}
