﻿// Decompiled with JetBrains decompiler
// Type: GClass0
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

public class GClass0
{
  public GClass1 this[[In] int obj0]
  {
    get => this.List_0[obj0];
    set => this.List_0[string_1] = value;
  }

  public string String_0 { get; [param: In] set; }

  public List<GClass1> List_0 { get; private set; }

  public int Int32_0 { get; [param: In] private set; }

  public static GClass0 smethod_0([In] string obj0)
  {
    BinaryReader binaryReader = new BinaryReader((Stream) new FileStream(obj0, FileMode.Open, FileAccess.Read, FileShare.Read));
    GClass0 gclass0 = new GClass0()
    {
      String_0 = obj0,
      Int32_0 = binaryReader.ReadInt32(),
      List_0 = new List<GClass1>()
    };
    for (int index = 0; index < gclass0.Int32_0 - 1; ++index)
    {
      long int_0 = (long) binaryReader.ReadUInt32();
      string gclass6_0 = Encoding.ASCII.GetString(binaryReader.ReadBytes(13));
      long num = (long) binaryReader.ReadUInt32();
      binaryReader.BaseStream.Seek(-4L, SeekOrigin.Current);
      int startIndex = gclass6_0.IndexOf(char.MinValue);
      if (startIndex != -1)
        gclass6_0 = gclass6_0.Remove(startIndex, 13 - startIndex);
      gclass0.List_0.Add(new GClass1(gclass6_0, int_0, num));
    }
    binaryReader.Close();
    return gclass0;
  }

  public static GClass0 smethod_1(string stream_0, byte[] string_1)
  {
    BinaryReader binaryReader = new BinaryReader((Stream) new MemoryStream(string_1));
    GClass0 gclass0 = new GClass0()
    {
      String_0 = stream_0,
      Int32_0 = binaryReader.ReadInt32(),
      List_0 = new List<GClass1>()
    };
    for (int index = 0; index < gclass0.Int32_0 - 1; ++index)
    {
      long int_0 = (long) binaryReader.ReadUInt32();
      string gclass6_0 = Encoding.ASCII.GetString(binaryReader.ReadBytes(13));
      long num = (long) binaryReader.ReadUInt32();
      binaryReader.BaseStream.Seek(-4L, SeekOrigin.Current);
      int startIndex = gclass6_0.IndexOf(char.MinValue);
      if (startIndex != -1)
        gclass6_0 = gclass6_0.Remove(startIndex, 13 - startIndex);
      gclass0.List_0.Add(new GClass1(gclass6_0, int_0, num));
    }
    binaryReader.Close();
    return gclass0;
  }

  public bool method_0(string int_0)
  {
    foreach (GClass1 gclass1 in this.List_0)
    {
      if (gclass1.String_0 == int_0)
        return true;
    }
    return false;
  }

  public bool method_1(string int_0, bool value)
  {
    foreach (GClass1 gclass1 in this.List_0)
    {
      if (value)
      {
        if (gclass1.String_0.ToUpper() == int_0.ToUpper())
          return true;
      }
      else if (gclass1.String_0 == int_0)
        return true;
    }
    return false;
  }

  public int method_2(string string_0)
  {
    for (int index = 0; index < this.List_0.Count; ++index)
    {
      if (this.List_0[index].String_0 == string_0)
        return index;
    }
    return -1;
  }

  public int method_3(string byte_0, [In] bool obj1)
  {
    for (int index = 0; index < this.List_0.Count; ++index)
    {
      if (obj1)
      {
        if (this.List_0[index].String_0.ToUpper() == byte_0.ToUpper())
          return index;
      }
      else if (this.List_0[index].String_0 == byte_0)
        return index;
    }
    return -1;
  }

  public byte[] method_4([In] string obj0)
  {
    if (!this.method_0(obj0))
      return (byte[]) null;
    BinaryReader binaryReader = new BinaryReader((Stream) new FileStream(this.String_0, FileMode.Open, FileAccess.Read, FileShare.Read));
    int index = this.method_2(obj0);
    binaryReader.BaseStream.Seek(this.List_0[index].Int64_2, SeekOrigin.Begin);
    byte[] numArray = binaryReader.ReadBytes((int) this.List_0[index].Int64_0);
    binaryReader.Close();
    return numArray;
  }

  public byte[] method_5(string string_0, bool bool_0)
  {
    if (!this.method_1(string_0, bool_0))
      return (byte[]) null;
    BinaryReader binaryReader = new BinaryReader((Stream) new FileStream(this.String_0, FileMode.Open, FileAccess.Read, FileShare.Read));
    int index = this.method_3(string_0, bool_0);
    binaryReader.BaseStream.Seek(this.List_0[index].Int64_2, SeekOrigin.Begin);
    byte[] numArray = binaryReader.ReadBytes((int) this.List_0[index].Int64_0);
    binaryReader.Close();
    return numArray;
  }

  public byte[] method_6([In] GClass1 obj0)
  {
    if (!this.method_0(obj0.String_0))
      return (byte[]) null;
    BinaryReader binaryReader = new BinaryReader((Stream) new FileStream(this.String_0, FileMode.Open, FileAccess.Read, FileShare.Read));
    binaryReader.BaseStream.Seek(obj0.Int64_2, SeekOrigin.Begin);
    byte[] numArray = binaryReader.ReadBytes((int) obj0.Int64_0);
    binaryReader.Close();
    return numArray;
  }

  public virtual string System\u002EObject\u002EToString() => \u003CModule\u003E.smethod_5<string>(2047818926U) + this.String_0 + \u003CModule\u003E.smethod_6<string>(3751848603U) + this.Int32_0.ToString() + \u003CModule\u003E.smethod_7<string>(3919114233U);
}
