﻿// Decompiled with JetBrains decompiler
// Type: Control7
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using Accolade.Properties;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Windows.Forms;

internal class Control7 : UserControl, Interface0
{
  private Label label_0;
  private TextBox textBox_0;
  private TextBox textBox_1;
  private TextBox textBox_2;
  private TextBox textBox_3;
  private Label label_1;
  private Label label_2;
  private Label label_3;
  private Label label_4;
  private Label label_5;
  private Label label_6;
  private Label label_7;
  private readonly Form5 form5_0;
  private readonly List<Keys> list_0 = new List<Keys>()
  {
    Keys.Alt,
    Keys.Menu,
    Keys.Control,
    Keys.ControlKey,
    Keys.Shift,
    Keys.ShiftKey,
    Keys.LWin,
    Keys.RWin
  };
  private CheckBox checkBox_0;
  private TextBox textBox_4;
  private TextBox textBox_5;
  private TextBox textBox_6;
  private TextBox textBox_7;

  internal Control7(Form5 stream_0)
  {
    this.Name = \u003CModule\u003E.smethod_8<string>(3589906334U);
    this.method_0();
    this.form5_0 = stream_0;
    this.checkBox_0.Checked = Settings.Default.RefreshAll;
    this.textBox_4.Text = Settings.Default.BotHotKey;
    this.textBox_5.Text = Settings.Default.CastHotKey;
    this.textBox_7.Text = Settings.Default.WalkHotKey;
    this.textBox_6.Text = Settings.Default.SoundHotKey;
    this.textBox_0.Text = Settings.Default.Combo1HotKey;
    this.textBox_1.Text = Settings.Default.Combo2HotKey;
    this.textBox_2.Text = Settings.Default.Combo3HotKey;
    this.textBox_3.Text = Settings.Default.Combo4HotKey;
  }

  public void imethod_0()
  {
    Settings.Default.RefreshAll = this.checkBox_0.Checked;
    Settings.Default.BotHotKey = this.textBox_4.Text;
    Settings.Default.CastHotKey = this.textBox_5.Text;
    Settings.Default.WalkHotKey = this.textBox_7.Text;
    Settings.Default.SoundHotKey = this.textBox_6.Text;
    Settings.Default.Combo1HotKey = this.textBox_0.Text;
    Settings.Default.Combo2HotKey = this.textBox_1.Text;
    Settings.Default.Combo3HotKey = this.textBox_2.Text;
    Settings.Default.Combo4HotKey = this.textBox_3.Text;
    Settings.Default.Save();
  }

  private void method_0()
  {
    this.checkBox_0 = new CheckBox();
    this.label_0 = new Label();
    this.label_2 = new Label();
    this.label_1 = new Label();
    this.label_3 = new Label();
    this.textBox_4 = new TextBox();
    this.textBox_6 = new TextBox();
    this.textBox_7 = new TextBox();
    this.textBox_5 = new TextBox();
    this.textBox_0 = new TextBox();
    this.textBox_1 = new TextBox();
    this.textBox_2 = new TextBox();
    this.textBox_3 = new TextBox();
    this.label_4 = new Label();
    this.label_5 = new Label();
    this.label_6 = new Label();
    this.label_7 = new Label();
    this.SuspendLayout();
    this.checkBox_0.AutoSize = true;
    this.checkBox_0.Location = new Point(180, 13);
    this.checkBox_0.Name = \u003CModule\u003E.smethod_8<string>(172961307U);
    this.checkBox_0.Size = new Size(137, 17);
    this.checkBox_0.TabIndex = 0;
    this.checkBox_0.Text = \u003CModule\u003E.smethod_6<string>(3577277150U);
    this.checkBox_0.UseVisualStyleBackColor = true;
    this.checkBox_0.CheckedChanged += new EventHandler(this.checkBox_0_CheckedChanged);
    this.label_0.AutoSize = true;
    this.label_0.Location = new Point(34, 48);
    this.label_0.Name = \u003CModule\u003E.smethod_6<string>(2879247655U);
    this.label_0.Size = new Size(65, 13);
    this.label_0.TabIndex = 1;
    this.label_0.Text = \u003CModule\u003E.smethod_8<string>(3400708889U);
    this.label_2.AutoSize = true;
    this.label_2.Location = new Point(15, 93);
    this.label_2.Name = \u003CModule\u003E.smethod_5<string>(4048423991U);
    this.label_2.Size = new Size(84, 13);
    this.label_2.TabIndex = 2;
    this.label_2.Text = \u003CModule\u003E.smethod_9<string>(1204149559U);
    this.label_1.AutoSize = true;
    this.label_1.Location = new Point(11, 141);
    this.label_1.Name = \u003CModule\u003E.smethod_7<string>(1670444790U);
    this.label_1.Size = new Size(88, 13);
    this.label_1.TabIndex = 3;
    this.label_1.Text = \u003CModule\u003E.smethod_5<string>(4217931992U);
    this.label_3.AutoSize = true;
    this.label_3.Location = new Point(19, 190);
    this.label_3.Name = \u003CModule\u003E.smethod_5<string>(3404245478U);
    this.label_3.Size = new Size(80, 13);
    this.label_3.TabIndex = 4;
    this.label_3.Text = \u003CModule\u003E.smethod_6<string>(1897318423U);
    this.textBox_4.BackColor = Color.White;
    this.textBox_4.Cursor = Cursors.Hand;
    this.textBox_4.ForeColor = Color.Black;
    this.textBox_4.Location = new Point(105, 45);
    this.textBox_4.Name = \u003CModule\u003E.smethod_7<string>(1569857386U);
    this.textBox_4.ReadOnly = true;
    this.textBox_4.Size = new Size(120, 20);
    this.textBox_4.TabIndex = 5;
    this.textBox_4.TextAlign = HorizontalAlignment.Center;
    this.textBox_4.KeyDown += new KeyEventHandler(this.textBox_3_KeyDown);
    this.textBox_4.KeyUp += new KeyEventHandler(this.textBox_3_KeyUp);
    this.textBox_6.BackColor = Color.White;
    this.textBox_6.Cursor = Cursors.Hand;
    this.textBox_6.ForeColor = Color.Black;
    this.textBox_6.Location = new Point(105, 187);
    this.textBox_6.Name = \u003CModule\u003E.smethod_6<string>(3188868728U);
    this.textBox_6.ReadOnly = true;
    this.textBox_6.Size = new Size(120, 20);
    this.textBox_6.TabIndex = 6;
    this.textBox_6.TextAlign = HorizontalAlignment.Center;
    this.textBox_6.KeyDown += new KeyEventHandler(this.textBox_3_KeyDown);
    this.textBox_6.KeyUp += new KeyEventHandler(this.textBox_3_KeyUp);
    this.textBox_7.BackColor = Color.White;
    this.textBox_7.Cursor = Cursors.Hand;
    this.textBox_7.ForeColor = Color.Black;
    this.textBox_7.Location = new Point(105, 138);
    this.textBox_7.Name = \u003CModule\u003E.smethod_6<string>(102442862U);
    this.textBox_7.ReadOnly = true;
    this.textBox_7.Size = new Size(120, 20);
    this.textBox_7.TabIndex = 7;
    this.textBox_7.TextAlign = HorizontalAlignment.Center;
    this.textBox_7.KeyDown += new KeyEventHandler(this.textBox_3_KeyDown);
    this.textBox_7.KeyUp += new KeyEventHandler(this.textBox_3_KeyUp);
    this.textBox_5.BackColor = Color.White;
    this.textBox_5.Cursor = Cursors.Hand;
    this.textBox_5.ForeColor = Color.Black;
    this.textBox_5.Location = new Point(105, 90);
    this.textBox_5.Name = \u003CModule\u003E.smethod_8<string>(3509875301U);
    this.textBox_5.ReadOnly = true;
    this.textBox_5.Size = new Size(120, 20);
    this.textBox_5.TabIndex = 8;
    this.textBox_5.TextAlign = HorizontalAlignment.Center;
    this.textBox_5.KeyDown += new KeyEventHandler(this.textBox_3_KeyDown);
    this.textBox_5.KeyUp += new KeyEventHandler(this.textBox_3_KeyUp);
    this.textBox_0.BackColor = Color.White;
    this.textBox_0.Cursor = Cursors.Hand;
    this.textBox_0.ForeColor = Color.Black;
    this.textBox_0.Location = new Point(323, 45);
    this.textBox_0.Name = \u003CModule\u003E.smethod_9<string>(662005918U);
    this.textBox_0.ReadOnly = true;
    this.textBox_0.Size = new Size(120, 20);
    this.textBox_0.TabIndex = 9;
    this.textBox_0.TextAlign = HorizontalAlignment.Center;
    this.textBox_0.KeyDown += new KeyEventHandler(this.textBox_3_KeyDown);
    this.textBox_0.KeyUp += new KeyEventHandler(this.textBox_3_KeyUp);
    this.textBox_1.BackColor = Color.White;
    this.textBox_1.Cursor = Cursors.Hand;
    this.textBox_1.ForeColor = Color.Black;
    this.textBox_1.Location = new Point(323, 90);
    this.textBox_1.Name = \u003CModule\u003E.smethod_5<string>(1827400249U);
    this.textBox_1.ReadOnly = true;
    this.textBox_1.Size = new Size(120, 20);
    this.textBox_1.TabIndex = 10;
    this.textBox_1.TextAlign = HorizontalAlignment.Center;
    this.textBox_1.KeyDown += new KeyEventHandler(this.textBox_3_KeyDown);
    this.textBox_1.KeyUp += new KeyEventHandler(this.textBox_3_KeyUp);
    this.textBox_2.BackColor = Color.White;
    this.textBox_2.Cursor = Cursors.Hand;
    this.textBox_2.ForeColor = Color.Black;
    this.textBox_2.Location = new Point(323, 138);
    this.textBox_2.Name = \u003CModule\u003E.smethod_8<string>(3245043882U);
    this.textBox_2.ReadOnly = true;
    this.textBox_2.Size = new Size(120, 20);
    this.textBox_2.TabIndex = 11;
    this.textBox_2.TextAlign = HorizontalAlignment.Center;
    this.textBox_2.KeyDown += new KeyEventHandler(this.textBox_3_KeyDown);
    this.textBox_2.KeyUp += new KeyEventHandler(this.textBox_3_KeyUp);
    this.textBox_3.BackColor = Color.White;
    this.textBox_3.Cursor = Cursors.Hand;
    this.textBox_3.ForeColor = Color.Black;
    this.textBox_3.Location = new Point(323, 187);
    this.textBox_3.Name = \u003CModule\u003E.smethod_7<string>(3121743281U);
    this.textBox_3.ReadOnly = true;
    this.textBox_3.Size = new Size(120, 20);
    this.textBox_3.TabIndex = 12;
    this.textBox_3.TextAlign = HorizontalAlignment.Center;
    this.textBox_3.KeyDown += new KeyEventHandler(this.textBox_3_KeyDown);
    this.textBox_3.KeyUp += new KeyEventHandler(this.textBox_3_KeyUp);
    this.label_4.AutoSize = true;
    this.label_4.Location = new Point(258, 48);
    this.label_4.Name = \u003CModule\u003E.smethod_6<string>(2202461653U);
    this.label_4.Size = new Size(55, 13);
    this.label_4.TabIndex = 13;
    this.label_4.Text = \u003CModule\u003E.smethod_5<string>(1247496258U);
    this.label_5.AutoSize = true;
    this.label_5.Location = new Point(258, 93);
    this.label_5.Name = \u003CModule\u003E.smethod_5<string>(1547430472U);
    this.label_5.Size = new Size(55, 13);
    this.label_5.TabIndex = 14;
    this.label_5.Text = \u003CModule\u003E.smethod_5<string>(2636302342U);
    this.label_6.AutoSize = true;
    this.label_6.Location = new Point(258, 141);
    this.label_6.Name = \u003CModule\u003E.smethod_9<string>(2351917696U);
    this.label_6.Size = new Size(55, 13);
    this.label_6.TabIndex = 15;
    this.label_6.Text = \u003CModule\u003E.smethod_9<string>(420124717U);
    this.label_7.AutoSize = true;
    this.label_7.Location = new Point(258, 190);
    this.label_7.Name = \u003CModule\u003E.smethod_5<string>(1781212995U);
    this.label_7.Size = new Size(55, 13);
    this.label_7.TabIndex = 16;
    this.label_7.Text = \u003CModule\u003E.smethod_6<string>(1045619212U);
    this.BackColor = Color.White;
    this.Controls.Add((Control) this.label_7);
    this.Controls.Add((Control) this.label_6);
    this.Controls.Add((Control) this.label_5);
    this.Controls.Add((Control) this.label_4);
    this.Controls.Add((Control) this.textBox_3);
    this.Controls.Add((Control) this.textBox_2);
    this.Controls.Add((Control) this.textBox_1);
    this.Controls.Add((Control) this.textBox_0);
    this.Controls.Add((Control) this.textBox_5);
    this.Controls.Add((Control) this.textBox_7);
    this.Controls.Add((Control) this.textBox_6);
    this.Controls.Add((Control) this.textBox_4);
    this.Controls.Add((Control) this.label_3);
    this.Controls.Add((Control) this.label_1);
    this.Controls.Add((Control) this.label_2);
    this.Controls.Add((Control) this.label_0);
    this.Controls.Add((Control) this.checkBox_0);
    this.ForeColor = Color.Black;
    this.Name = \u003CModule\u003E.smethod_8<string>(3827333640U);
    this.Size = new Size(490, 258);
    this.ResumeLayout(false);
    this.PerformLayout();
  }

  private void checkBox_0_CheckedChanged(object dictionary_3, EventArgs dictionary_4)
  {
    if (dictionary_3 is CheckBox checkBox && checkBox.Checked)
      Class137.RegisterHotKey(this.form5_0.Handle, 1, 0U, (uint) Keys.F5.GetHashCode());
    else
      Class137.UnregisterHotKey(this.form5_0.Handle, 1);
  }

  internal void textBox_3_KeyDown([In] object obj0, [In] KeyEventArgs obj1)
  {
    try
    {
      TextBox textBox = obj0 as TextBox;
      KeysConverter keysConverter = new KeysConverter();
      string str1 = "";
      string name = textBox.Name;
      int int_1;
      // ISSUE: reference to a compiler-generated method
      switch (Class181.smethod_0(name))
      {
        case 524642968:
          if (!(name == \u003CModule\u003E.smethod_6<string>(102442862U)))
            return;
          int_1 = 4;
          break;
        case 2204040798:
          if (!(name == \u003CModule\u003E.smethod_6<string>(930702378U)))
            return;
          int_1 = 2;
          break;
        case 2518218100:
          if (!(name == \u003CModule\u003E.smethod_5<string>(4071295680U)))
            return;
          int_1 = 5;
          break;
        case 3287411856:
          if (!(name == \u003CModule\u003E.smethod_7<string>(714571832U)))
            return;
          int_1 = 9;
          break;
        case 3320967094:
          if (!(name == \u003CModule\u003E.smethod_7<string>(3395427330U)))
            return;
          int_1 = 11;
          break;
        case 3337744713:
          if (!(name == \u003CModule\u003E.smethod_6<string>(2490839233U)))
            return;
          int_1 = 10;
          break;
        case 3371299951:
          if (!(name == \u003CModule\u003E.smethod_9<string>(3280239821U)))
            return;
          int_1 = 12;
          break;
        case 3810417378:
          if (!(name == \u003CModule\u003E.smethod_7<string>(1815548939U)))
            return;
          int_1 = 3;
          break;
        default:
          return;
      }
      Class137.UnregisterHotKey(this.form5_0.Handle, int_1);
      string str2 = str1 + keysConverter.ConvertToString((object) obj1.Modifiers).Replace(\u003CModule\u003E.smethod_8<string>(1011738406U), "");
      string str3 = (this.list_0.Contains(obj1.KeyCode) ? str2.Remove(str2.Length - 1) : str2 + keysConverter.ConvertToString((object) obj1.KeyValue)).Replace(\u003CModule\u003E.smethod_7<string>(3862762827U), \u003CModule\u003E.smethod_5<string>(2854823517U));
      textBox.Text = str3;
      obj1.Handled = true;
    }
    catch
    {
      int num = (int) Form1.smethod_0(this.form5_0, \u003CModule\u003E.smethod_9<string>(3461189975U), (IWin32Window) this, true);
    }
  }

  internal void textBox_3_KeyUp([In] object obj0, KeyEventArgs resolveEventArgs_0)
  {
    try
    {
      KeysConverter keysConverter = new KeysConverter();
      TextBox textBox = obj0 as TextBox;
      List<Keys> keysList = new List<Keys>();
      if (string.IsNullOrEmpty(textBox.Text))
        return;
      Match match = Regex.Match(textBox.Text, \u003CModule\u003E.smethod_6<string>(308324201U));
      foreach (Group group in match.Groups)
      {
        if (group != match.Groups[0] && group.Success)
          keysList.Add((Keys) keysConverter.ConvertFromString(group.Value));
      }
      if (this.list_0.Contains(keysList[keysList.Count - 1]))
      {
        textBox.Text = "";
      }
      else
      {
        string name = textBox.Name;
        int uint_1;
        // ISSUE: reference to a compiler-generated method
        switch (Class181.smethod_0(name))
        {
          case 524642968:
            if (!(name == \u003CModule\u003E.smethod_6<string>(102442862U)))
              return;
            uint_1 = 4;
            break;
          case 2204040798:
            if (!(name == \u003CModule\u003E.smethod_7<string>(1569857386U)))
              return;
            uint_1 = 2;
            break;
          case 2518218100:
            if (!(name == \u003CModule\u003E.smethod_7<string>(3942795428U)))
              return;
            uint_1 = 5;
            break;
          case 3287411856:
            if (!(name == \u003CModule\u003E.smethod_5<string>(1165134468U)))
              return;
            uint_1 = 9;
            break;
          case 3320967094:
            if (!(name == \u003CModule\u003E.smethod_7<string>(3395427330U)))
              return;
            uint_1 = 11;
            break;
          case 3337744713:
            if (!(name == \u003CModule\u003E.smethod_8<string>(2231316721U)))
              return;
            uint_1 = 10;
            break;
          case 3371299951:
            if (!(name == \u003CModule\u003E.smethod_7<string>(3121743281U)))
              return;
            uint_1 = 12;
            break;
          case 3810417378:
            if (!(name == \u003CModule\u003E.smethod_6<string>(4113510421U)))
              return;
            uint_1 = 3;
            break;
          default:
            return;
        }
        switch (keysList.Count)
        {
          case 1:
            Class137.RegisterHotKey(this.form5_0.Handle, uint_1, 0U, (uint) keysList[0].GetHashCode());
            break;
          case 2:
            Class137.RegisterHotKey(this.form5_0.Handle, uint_1, Class18.smethod_0(keysList[0]), (uint) keysList[1].GetHashCode());
            break;
          case 3:
            Class137.RegisterHotKey(this.form5_0.Handle, uint_1, Class18.smethod_0(keysList[0]) | Class18.smethod_0(keysList[1]), (uint) keysList[2].GetHashCode());
            break;
          case 4:
            Class137.RegisterHotKey(this.form5_0.Handle, uint_1, Class18.smethod_0(keysList[0]) | Class18.smethod_0(keysList[1]) | Class18.smethod_0(keysList[2]), (uint) keysList[3].GetHashCode());
            break;
        }
      }
    }
    catch
    {
      int num = (int) Form1.smethod_0(this.form5_0, \u003CModule\u003E.smethod_5<string>(2343978469U), (IWin32Window) this, true);
    }
  }
}
