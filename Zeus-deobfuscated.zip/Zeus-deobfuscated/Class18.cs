﻿// Decompiled with JetBrains decompiler
// Type: Class18
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Windows.Forms;

internal static class Class18
{
  internal const uint uint_0 = 0;
  internal const uint uint_1 = 1;
  internal const uint uint_2 = 2;
  internal const uint uint_3 = 4;
  internal const uint uint_4 = 8;

  internal static uint smethod_0(Keys callback)
  {
    switch (callback)
    {
      case Keys.ShiftKey:
        return 4;
      case Keys.ControlKey:
        return 2;
      case Keys.Menu:
        return 1;
      case Keys.LWin:
        return 8;
      case Keys.RWin:
        return 8;
      case Keys.Shift:
        return 4;
      case Keys.Control:
        return 2;
      case Keys.Alt:
        return 1;
      default:
        return 0;
    }
  }
}
