﻿// Decompiled with JetBrains decompiler
// Type: Class27
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Windows.Forms;

internal class Class27 : TextBox
{
  bool TextBox.IsInputKey(Keys value)
  {
    bool flag = true;
    switch (value)
    {
      case Keys.Left:
      case Keys.Up:
      case Keys.Right:
      case Keys.Down:
        return flag;
      default:
        // ISSUE: explicit non-virtual call
        flag = __nonvirtual (((TextBox) this).IsInputKey(value));
        goto case Keys.Left;
    }
  }
}
