﻿// Decompiled with JetBrains decompiler
// Type: Form6
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

internal class Form6 : Form
{
  private Button button_0;
  private Button button_1;
  private IContainer icontainer_0;
  private UserControl userControl_0;
  private readonly Form5 form5_0;
  private ListBox listBox_0;
  private Panel panel_0;
  private readonly List<UserControl> list_0;
  private Label label_0;

  internal Form6([In] Form5 obj0)
  {
    this.form5_0 = obj0;
    this.list_0 = new List<UserControl>();
    this.method_1();
    this.method_0(\u003CModule\u003E.smethod_6<string>(3264947241U), (UserControl) new Control8(obj0));
    this.method_0(\u003CModule\u003E.smethod_5<string>(1814541278U), (UserControl) new Control7(obj0));
    this.method_0(\u003CModule\u003E.smethod_9<string>(751178591U), (UserControl) new Control6(obj0));
    this.method_0(\u003CModule\u003E.smethod_5<string>(2352012353U), (UserControl) new Control5(obj0));
    this.listBox_0.SelectedIndex = 0;
  }

  private void method_0([In] string obj0, [In] UserControl obj1)
  {
    this.list_0.Add(obj1);
    this.listBox_0.Items.Add((object) obj0);
  }

  private void listBox_0_SelectedIndexChanged([In] object obj0, EventArgs bool_0)
  {
    if (this.userControl_0 != null)
      this.panel_0.Controls.Remove((Control) this.userControl_0);
    this.userControl_0 = this.list_0[this.listBox_0.SelectedIndex];
    this.panel_0.Controls.Add((Control) this.userControl_0);
  }

  private void button_0_Click(object int_1, [In] EventArgs obj1)
  {
    foreach (Interface0 nterface0 in this.list_0)
      nterface0.imethod_0();
  }

  void Form.Dispose(bool class0_0)
  {
    if (class0_0 && this.icontainer_0 != null)
      this.icontainer_0.Dispose();
    // ISSUE: explicit non-virtual call
    __nonvirtual (((Form) this).Dispose(class0_0));
  }

  private void method_1()
  {
    ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (Form6));
    this.listBox_0 = new ListBox();
    this.panel_0 = new Panel();
    this.label_0 = new Label();
    this.button_1 = new Button();
    this.button_0 = new Button();
    this.panel_0.SuspendLayout();
    this.SuspendLayout();
    this.listBox_0.FormattingEnabled = true;
    this.listBox_0.ItemHeight = 15;
    this.listBox_0.Location = new Point(12, 12);
    this.listBox_0.Name = \u003CModule\u003E.smethod_7<string>(3366335592U);
    this.listBox_0.Size = new Size(120, 259);
    this.listBox_0.TabIndex = 0;
    this.listBox_0.SelectedIndexChanged += new EventHandler(this.listBox_0_SelectedIndexChanged);
    this.panel_0.Controls.Add((Control) this.label_0);
    this.panel_0.Location = new Point(138, 12);
    this.panel_0.Name = \u003CModule\u003E.smethod_5<string>(834657225U);
    this.panel_0.Size = new Size(490, 259);
    this.panel_0.TabIndex = 1;
    this.label_0.BorderStyle = BorderStyle.Fixed3D;
    this.label_0.Dock = DockStyle.Bottom;
    this.label_0.Location = new Point(0, 257);
    this.label_0.Name = \u003CModule\u003E.smethod_8<string>(3299367621U);
    this.label_0.Size = new Size(490, 2);
    this.label_0.TabIndex = 0;
    this.button_1.DialogResult = DialogResult.Cancel;
    this.button_1.Location = new Point(553, 285);
    this.button_1.Name = \u003CModule\u003E.smethod_5<string>(3612269393U);
    this.button_1.Size = new Size(75, 23);
    this.button_1.TabIndex = 3;
    this.button_1.Text = \u003CModule\u003E.smethod_5<string>(1475061067U);
    this.button_1.UseVisualStyleBackColor = true;
    this.button_1.Click += new EventHandler(this.button_1_Click);
    this.button_0.DialogResult = DialogResult.OK;
    this.button_0.Location = new Point(472, 285);
    this.button_0.Name = \u003CModule\u003E.smethod_8<string>(444752237U);
    this.button_0.Size = new Size(75, 23);
    this.button_0.TabIndex = 2;
    this.button_0.Text = \u003CModule\u003E.smethod_7<string>(3008674055U);
    this.button_0.UseVisualStyleBackColor = true;
    this.button_0.Click += new EventHandler(this.button_0_Click);
    this.AcceptButton = (IButtonControl) this.button_0;
    this.AutoScaleDimensions = new SizeF(7f, 15f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.BackColor = Color.White;
    this.CancelButton = (IButtonControl) this.button_1;
    this.ClientSize = new Size(640, 320);
    this.Controls.Add((Control) this.button_0);
    this.Controls.Add((Control) this.button_1);
    this.Controls.Add((Control) this.panel_0);
    this.Controls.Add((Control) this.listBox_0);
    this.Font = new Font(\u003CModule\u003E.smethod_7<string>(1521212547U), 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.ForeColor = Color.Black;
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Icon = (Icon) componentResourceManager.GetObject(\u003CModule\u003E.smethod_6<string>(3848230780U));
    this.MaximizeBox = false;
    this.MinimizeBox = false;
    this.Name = \u003CModule\u003E.smethod_5<string>(641833659U);
    this.ShowIcon = false;
    this.ShowInTaskbar = false;
    this.StartPosition = FormStartPosition.CenterParent;
    this.Text = \u003CModule\u003E.smethod_5<string>(141001329U);
    this.panel_0.ResumeLayout(false);
    this.ResumeLayout(false);
  }

  private void button_1_Click(object struct0_1, EventArgs uint_0)
  {
    this.form5_0.method_5();
    this.form5_0.method_6();
  }
}
