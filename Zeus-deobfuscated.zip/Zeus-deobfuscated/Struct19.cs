﻿// Decompiled with JetBrains decompiler
// Type: Struct19
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

internal struct Struct19
{
  internal short Int16_0 { get; set; }

  internal short Int16_1 { get; set; }

  internal short Int16_2 { get; set; }

  internal short Int16_3 { get; set; }

  internal short Int16_4 => this.Int16_1;

  internal short Int16_5 => this.Int16_0;

  internal short Int16_6 => (short) ((int) this.Int16_0 + (int) this.Int16_2);

  internal short Int16_7 => (short) ((int) this.Int16_1 + (int) this.Int16_3);

  internal List<Struct16> List_0
  {
    get
    {
      List<Struct16> list0 = new List<Struct16>();
      for (int int160 = (int) this.Int16_0; int160 <= (int) this.Int16_0 + (int) this.Int16_2; ++int160)
      {
        for (int int161 = (int) this.Int16_1; int161 <= (int) this.Int16_1 + (int) this.Int16_3; ++int161)
          list0.Add(new Struct16((short) int160, (short) int161));
      }
      return list0;
    }
  }

  [SpecialName]
  public static bool smethod_0(Struct19 bool_0 = true, [In] Struct19 obj1) => bool_0.Equals((object) obj1);

  [SpecialName]
  public static bool smethod_1([In] Struct19 obj0, Struct19 class29_0) => !obj0.Equals((object) class29_0);

  internal Struct19(short match_0, [In] short obj1, [In] short obj2, [In] short obj3)
  {
    this.Int16_0 = match_0;
    this.Int16_1 = obj1;
    this.Int16_2 = obj2;
    this.Int16_3 = obj3;
  }

  internal Struct19(Struct16 class72_0, [In] Struct18 obj1)
  {
    this.Int16_0 = class72_0.short_0;
    this.Int16_1 = class72_0.short_1;
    this.Int16_2 = obj1.Int16_0;
    this.Int16_3 = obj1.Int16_1;
  }

  internal bool method_0(Struct16 byte_5) => this.method_1(byte_5.short_0, byte_5.short_1);

  internal bool method_1(short byte_5, [In] short obj1) => (int) byte_5 >= (int) this.Int16_0 && (int) byte_5 < (int) this.Int16_0 + (int) this.Int16_2 && (int) obj1 >= (int) this.Int16_1 && (int) obj1 < (int) this.Int16_1 + (int) this.Int16_3;

  internal bool method_2(Struct19 class72_0) => (int) class72_0.Int16_0 >= (int) this.Int16_0 && (int) class72_0.Int16_1 >= (int) this.Int16_1 && (int) class72_0.Int16_0 + (int) class72_0.Int16_2 <= (int) this.Int16_0 + (int) this.Int16_2 && (int) class72_0.Int16_1 + (int) class72_0.Int16_3 <= (int) this.Int16_1 + (int) this.Int16_3;

  public virtual bool System\u002EValueType\u002EEquals(object class29_1) => class29_1 is Struct19 struct19 && (int) struct19.Int16_0 == (int) this.Int16_0 && (int) struct19.Int16_1 == (int) this.Int16_1 && (int) struct19.Int16_2 == (int) this.Int16_2 && (int) struct19.Int16_3 == (int) this.Int16_3;

  public virtual int System\u002EValueType\u002EGetHashCode() => ((int) this.Int16_0 << 24) + ((int) this.Int16_1 << 16) + ((int) this.Int16_2 << 8) + (int) this.Int16_3;

  public virtual string System\u002EValueType\u002EToString() => string.Format(\u003CModule\u003E.smethod_9<string>(2050615959U), (object) this.Int16_0, (object) this.Int16_1, (object) this.Int16_2, (object) this.Int16_3);
}
