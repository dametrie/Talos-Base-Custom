﻿// Decompiled with JetBrains decompiler
// Type: GClass2
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Runtime.InteropServices;

public class GClass2
{
  public GClass0 GClass0_0 { get; set; }

  public GClass0 GClass0_1 { get; set; }

  public GClass0 GClass0_2 { get; set; }

  public GClass0 GClass0_3 { get; [param: In] set; }

  public GClass0 GClass0_4 { get; set; }

  internal GClass2([In] string obj0, bool string_1, [In] Form5 obj2)
  {
    string str = string_1 ? \u003CModule\u003E.smethod_9<string>(579346503U) : \u003CModule\u003E.smethod_6<string>(2769919371U);
    this.GClass0_0 = GClass0.smethod_0(obj0 + \u003CModule\u003E.smethod_9<string>(3070050613U) + str + \u003CModule\u003E.smethod_8<string>(2881762008U));
    this.GClass0_1 = GClass0.smethod_0(obj0 + \u003CModule\u003E.smethod_9<string>(3070050613U) + str + \u003CModule\u003E.smethod_5<string>(999906013U));
    this.GClass0_2 = GClass0.smethod_0(obj0 + \u003CModule\u003E.smethod_8<string>(1868034847U) + str + \u003CModule\u003E.smethod_5<string>(273365710U));
    this.GClass0_3 = GClass0.smethod_0(obj0 + \u003CModule\u003E.smethod_8<string>(1868034847U) + str + \u003CModule\u003E.smethod_5<string>(935631491U));
    this.GClass0_4 = GClass0.smethod_0(obj0 + \u003CModule\u003E.smethod_6<string>(1941659855U) + str + \u003CModule\u003E.smethod_9<string>(3373902158U));
  }
}
