﻿// Decompiled with JetBrains decompiler
// Type: Class145
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

internal class Class145
{
  internal Control3 Control3_0 { get; set; }

  internal string String_0 { get; set; }

  internal Class145(string class142_4) => this.String_0 = class142_4;

  public virtual string System\u002EObject\u002EToString() => this.String_0;
}
