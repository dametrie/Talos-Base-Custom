﻿// Decompiled with JetBrains decompiler
// Type: Enum7
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;

[Flags]
internal enum Enum7
{
  None = 0,
  Terminate = 1,
  CreateThread = 2,
  VmOperation = 8,
  VmRead = 16, // 0x00000010
  VmWrite = 32, // 0x00000020
  DuplicateHandle = 64, // 0x00000040
  CreateProcess = 128, // 0x00000080
  SetQuota = 256, // 0x00000100
  SetInformation = 512, // 0x00000200
  QueryInformation = 1024, // 0x00000400
  SuspendResume = 2048, // 0x00000800
  QueryLimitedInformation = 4096, // 0x00001000
}
