﻿// Decompiled with JetBrains decompiler
// Type: Class77
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

internal static class Class77
{
  [DllImport("kernel32.dll")]
  internal static extern bool CloseHandle(IntPtr string_0);

  [DllImport("kernel32.dll")]
  internal static extern bool CreateProcess(
    string process_0,
    string int_0,
    IntPtr byte_0,
    [In] IntPtr obj3,
    [In] bool obj4,
    [In] Enum8 obj5,
    [In] IntPtr obj6,
    [In] string obj7,
    [In] ref Struct13 obj8,
    [In] ref Struct14 obj9);

  [DllImport("kernel32.dll")]
  internal static extern IntPtr OpenProcess(Enum7 value, [In] bool obj1, [In] int obj2);

  [DllImport("kernel32.dll")]
  internal static extern bool ReadProcessMemory(
    IntPtr value,
    [In] IntPtr obj1,
    [In] IntPtr obj2,
    [In] int obj3,
    [In] ref int obj4);

  [DllImport("kernel32.dll", EntryPoint = "ReadProcessMemory")]
  internal static extern bool ReadProcessMemory_1(
    IntPtr value,
    [In] int obj1,
    [In] byte[] obj2,
    [In] int obj3,
    [In] byte obj4);

  [DllImport("kernel32.dll")]
  internal static extern int ResumeThread(IntPtr value);

  [DllImport("kernel32.dll")]
  internal static extern Enum2 WaitForSingleObject(IntPtr value, [In] int obj1);

  [DllImport("kernel32.dll")]
  internal static extern bool WriteProcessMemory(
    IntPtr value,
    IntPtr e,
    [In] IntPtr obj2,
    [In] int obj3,
    [In] ref int obj4);

  [DllImport("kernel32.dll", EntryPoint = "WriteProcessMemory")]
  internal static extern bool WriteProcessMemory_1(
    IntPtr sender,
    int e,
    [In] byte[] obj2,
    [In] int obj3,
    [In] byte obj4);

  [DllImport("kernel32")]
  internal static extern IntPtr CreateRemoteThread(
    IntPtr class29_0,
    IntPtr e,
    [In] uint obj2,
    [In] UIntPtr obj3,
    [In] IntPtr obj4,
    [In] uint obj5,
    [In] ref IntPtr obj6);

  [DllImport("kernel32.dll", EntryPoint = "OpenProcess")]
  internal static extern IntPtr OpenProcess_1([In] uint obj0, int string_3, int process_0);

  [DllImport("kernel32.dll", SetLastError = true)]
  internal static extern bool VirtualFreeEx(
    IntPtr intptr_1,
    IntPtr string_2,
    [In] UIntPtr obj2,
    [In] uint obj3);

  [DllImport("kernel32.dll", CharSet = CharSet.Ansi)]
  internal static extern UIntPtr GetProcAddress(IntPtr sender, string e);

  [DllImport("kernel32.dll", SetLastError = true)]
  internal static extern IntPtr VirtualAllocEx(
    IntPtr sender,
    IntPtr e,
    [In] uint obj2,
    [In] uint obj3,
    [In] uint obj4);

  [DllImport("kernel32.dll", EntryPoint = "WriteProcessMemory")]
  internal static extern bool WriteProcessMemory_2(
    [In] IntPtr obj0,
    IntPtr e,
    [In] string obj2,
    [In] UIntPtr obj3,
    [In] ref IntPtr obj4);

  [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
  internal static extern IntPtr GetModuleHandle(string sender);

  internal static bool smethod_0([In] Process obj0, int e, [In] byte[] obj2) => Class77.ReadProcessMemory_1(obj0.Handle, e, obj2, obj2.Length, (byte) 0);

  internal static bool smethod_1(Process sender, int e, [In] byte[] obj2) => Class77.WriteProcessMemory_1(sender.Handle, e, obj2, obj2.Length, (byte) 0);
}
