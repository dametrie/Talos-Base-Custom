﻿// Decompiled with JetBrains decompiler
// Type: Class92
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Runtime.InteropServices;

internal sealed class Class92 : Class90
{
  internal byte Byte_0 => this.byte_0;

  internal byte Byte_1 => this.byte_1;

  internal byte Byte_2 { get; }

  internal byte Byte_3 { get; }

  internal short Int16_0 { get; }

  internal Struct17 Struct17_0 => new Struct17(this.short_0, (short) this.byte_0, (short) this.byte_1);

  internal Struct17 Struct17_1 => new Struct17(this.Int16_0, (short) this.Byte_2, (short) this.Byte_3);

  internal Class92(byte class142_0, [In] byte obj1, [In] byte obj2, [In] byte obj3, [In] short obj4, [In] short obj5)
  {
    this.byte_0 = class142_0;
    this.byte_1 = obj1;
    this.Byte_2 = obj2;
    this.Byte_3 = obj3;
    this.short_0 = obj4;
    this.Int16_0 = obj5;
  }
}
