﻿using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;
using System.Security.Permissions;

[assembly: AssemblyCopyright("Copyright © Nerds 2021")]
[assembly: Guid("494A6AF4-3165-4173-B557-170805A9FCB6")]
[assembly: ComVisible(false)]
[assembly: AssemblyFileVersion("0.2.1.0")]
[assembly: AssemblyDescription("Dark Ages Enhancement Tool")]
[assembly: AssemblyConfiguration("")]
[assembly: NeutralResourcesLanguage("en")]
[assembly: AssemblyTitle("Accolade")]
[assembly: AssemblyProduct("Accolade")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCompany("Apotheosis")]
[assembly: AssemblyVersion("0.2.1.0")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
