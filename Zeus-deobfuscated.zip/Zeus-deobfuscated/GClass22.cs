﻿// Decompiled with JetBrains decompiler
// Type: GClass22
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.IO;
using System.Runtime.InteropServices;
using System.Text;

public class GClass22
{
  public GClass23 this[int value]
  {
    get => this.GClass23_0[value];
    [param: In] set => this.GClass23_0[value] = value;
  }

  public string String_0 { get; set; }

  public GClass23[] GClass23_0 { get; [param: In] private set; }

  public int Int32_0 { get; [param: In] private set; }

  public static GClass22 smethod_0([In] string obj0)
  {
    BinaryReader binaryReader = new BinaryReader((Stream) new FileStream(obj0, FileMode.Open, FileAccess.Read, FileShare.Read));
    GClass22 gclass22 = new GClass22()
    {
      String_0 = obj0,
      Int32_0 = binaryReader.ReadInt32()
    };
    gclass22.GClass23_0 = new GClass23[gclass22.Int32_0 - 1];
    for (int index = 0; index < gclass22.Int32_0 - 1; ++index)
    {
      long process_0 = (long) binaryReader.ReadUInt32();
      string str = Encoding.ASCII.GetString(binaryReader.ReadBytes(13));
      long bool_0 = (long) binaryReader.ReadUInt32();
      binaryReader.BaseStream.Seek(-4L, SeekOrigin.Current);
      int startIndex = str.IndexOf(char.MinValue);
      if (startIndex != -1)
        str = str.Remove(startIndex, 13 - startIndex);
      gclass22.GClass23_0[index] = new GClass23(str, process_0, bool_0);
    }
    binaryReader.Close();
    return gclass22;
  }

  public bool method_0([In] string obj0)
  {
    foreach (GClass23 gclass23 in this.GClass23_0)
    {
      if (gclass23.String_0 == obj0)
        return true;
    }
    return false;
  }

  public bool method_1([In] string obj0, [In] bool obj1)
  {
    foreach (GClass23 gclass23 in this.GClass23_0)
    {
      if (obj1)
      {
        if (gclass23.String_0.ToUpper() == obj0.ToUpper())
          return true;
      }
      else if (gclass23.String_0 == obj0)
        return true;
    }
    return false;
  }

  public int method_2([In] string obj0)
  {
    for (int index = 0; index < this.GClass23_0.Length; ++index)
    {
      if (this.GClass23_0[index].String_0 == obj0)
        return index;
    }
    return -1;
  }

  public int method_3([In] string obj0, [In] bool obj1)
  {
    for (int index = 0; index < this.GClass23_0.Length; ++index)
    {
      if (obj1)
      {
        if (this.GClass23_0[index].String_0.ToUpper() == obj0.ToUpper())
          return index;
      }
      else if (this.GClass23_0[index].String_0 == obj0)
        return index;
    }
    return -1;
  }

  public byte[] method_4(string string_0)
  {
    if (!this.method_0(string_0))
      return (byte[]) null;
    BinaryReader binaryReader = new BinaryReader((Stream) new FileStream(this.String_0, FileMode.Open, FileAccess.Read, FileShare.Read));
    int index = this.method_2(string_0);
    binaryReader.BaseStream.Seek(this.GClass23_0[index].Int64_2, SeekOrigin.Begin);
    byte[] numArray = binaryReader.ReadBytes((int) this.GClass23_0[index].Int64_0);
    binaryReader.Close();
    return numArray;
  }

  public byte[] method_5([In] string obj0, bool process_0)
  {
    if (!this.method_1(obj0, process_0))
      return (byte[]) null;
    BinaryReader binaryReader = new BinaryReader((Stream) new FileStream(this.String_0, FileMode.Open, FileAccess.Read, FileShare.Read));
    int index = this.method_3(obj0, process_0);
    binaryReader.BaseStream.Seek(this.GClass23_0[index].Int64_2, SeekOrigin.Begin);
    byte[] numArray = binaryReader.ReadBytes((int) this.GClass23_0[index].Int64_0);
    binaryReader.Close();
    return numArray;
  }

  public byte[] method_6([In] GClass23 obj0)
  {
    if (!this.method_0(obj0.String_0))
      return (byte[]) null;
    BinaryReader binaryReader = new BinaryReader((Stream) new FileStream(this.String_0, FileMode.Open, FileAccess.Read, FileShare.Read));
    binaryReader.BaseStream.Seek(obj0.Int64_2, SeekOrigin.Begin);
    byte[] numArray = binaryReader.ReadBytes((int) obj0.Int64_0);
    binaryReader.Close();
    return numArray;
  }

  public virtual string System\u002EObject\u002EToString() => \u003CModule\u003E.smethod_5<string>(2047818926U) + this.String_0 + \u003CModule\u003E.smethod_9<string>(4109135041U) + this.Int32_0.ToString() + \u003CModule\u003E.smethod_9<string>(3422694117U);
}
