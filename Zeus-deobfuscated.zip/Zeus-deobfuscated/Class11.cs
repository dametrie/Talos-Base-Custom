﻿// Decompiled with JetBrains decompiler
// Type: Class11
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Runtime.InteropServices;

internal static class Class11
{
  internal static readonly int int_0 = 8;
  internal static readonly int int_1 = 4;
  internal static readonly int int_2 = 1;

  [DllImport("dwmapi.dll")]
  internal static extern int DwmRegisterThumbnail(IntPtr class143_1, [In] IntPtr obj1, [In] ref IntPtr obj2);

  [DllImport("dwmapi.dll")]
  internal static extern int DwmUpdateThumbnailProperties(
    IntPtr class143_1,
    [In] ref Class16.Struct8 obj1);

  [DllImport("dwmapi.dll")]
  internal static extern int DwmUnregisterThumbnail(IntPtr class143_1);

  [DllImport("dwmapi.dll")]
  internal static extern int DwmQueryThumbnailSourceSize(
    IntPtr class143_1,
    [In] ref Class16.Struct10 obj1);
}
