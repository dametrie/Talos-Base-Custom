﻿// Decompiled with JetBrains decompiler
// Type: Class10
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Runtime.InteropServices;

internal class Class10
{
  internal string String_0 { get; [param: In] set; }

  internal int Int32_0 { get; set; }

  internal int Int32_1 { get; set; }

  internal Class10([In] string obj0, int string_0, int iwin32Window_0 = default (int))
  {
    this.String_0 = obj0;
    this.Int32_0 = string_0;
    this.Int32_1 = iwin32Window_0;
  }

  internal Class10()
  {
    this.String_0 = "";
    this.Int32_0 = 0;
    this.Int32_1 = 0;
  }

  internal bool method_0(int sender, int e) => sender >= this.Int32_0 && e == this.Int32_1;
}
