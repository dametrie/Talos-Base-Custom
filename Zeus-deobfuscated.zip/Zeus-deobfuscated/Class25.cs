﻿// Decompiled with JetBrains decompiler
// Type: Class25
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Collections.Generic;
using System.Threading;

internal abstract class Class25
{
  private readonly List<Delegate0> list_0;

  internal List<Thread> List_0 { get; set; }

  internal Class29 Class29_0 { get; set; }

  internal Class112 Class112_0 { get; set; }

  internal List<Struct16> List_1 { get; set; }

  internal Class25()
  {
    this.List_0 = new List<Thread>();
    this.list_0 = new List<Delegate0>();
    this.List_1 = new List<Struct16>();
  }

  protected Class25(Class29 value)
    : this()
  {
    this.Class29_0 = value;
    this.Class112_0 = value.Class112_0;
  }

  internal void method_0()
  {
    this.List_0.Clear();
    foreach (Delegate0 parameter in this.list_0)
    {
      Thread thread = new Thread(new ParameterizedThreadStart(Class25.smethod_0));
      this.List_0.Add(thread);
      thread.Start((object) parameter);
    }
  }

  internal void method_1()
  {
    foreach (Thread thread in this.List_0)
    {
      if (thread != null && thread.IsAlive && !thread.Join(100))
        thread.Abort();
    }
    this.List_0.Clear();
    this.List_0 = new List<Thread>();
  }

  protected void method_2(Delegate0 value) => this.list_0.Add(value);

  private static void smethod_0(object value)
  {
    Thread.GetDomain().UnhandledException += new UnhandledExceptionEventHandler(Class106.smethod_0);
    Delegate0 delegate0 = (Delegate0) value;
    while (true)
    {
      try
      {
        delegate0();
        Thread.Sleep(10);
      }
      catch
      {
      }
    }
  }
}
