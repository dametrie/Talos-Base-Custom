﻿// Decompiled with JetBrains decompiler
// Type: Struct15
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.IO;
using System.Runtime.InteropServices;

internal struct Struct15
{
  private static readonly byte[] byte_0;
  private readonly short short_0;
  private readonly short short_1;
  private readonly short short_2;

  internal bool Boolean_0 => ((this.short_1 <= (short) 0 ? 0 : (((int) Struct15.byte_0[(int) this.short_1 - 1] & 15) == 15 ? 1 : 0)) | (this.short_2 <= (short) 0 ? 0 : (((int) Struct15.byte_0[(int) this.short_2 - 1] & 15) == 15 ? 1 : 0))) != 0;

  static Struct15()
  {
    using (Stream stream = (Stream) new MemoryStream(Class9.Byte_3))
    {
      int length = (int) stream.Length;
      Struct15.byte_0 = new byte[length];
      stream.Read(Struct15.byte_0, 0, length);
    }
  }

  internal Struct15([In] short obj0, short byte_3, short byte_4)
  {
    this.short_0 = obj0;
    this.short_1 = byte_3;
    this.short_2 = byte_4;
  }
}
