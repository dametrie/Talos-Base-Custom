﻿// Decompiled with JetBrains decompiler
// Type: GClass7
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;

public class GClass7
{
  private List<GClass8> list_0 = new List<GClass8>();
  public Dictionary<int, GClass6> dictionary_0 = new Dictionary<int, GClass6>();
  private List<GClass8> list_1 = new List<GClass8>();

  public GClass6 this[[In] int obj0] => obj0 >= this.dictionary_0.Count ? this.dictionary_0[0] : this.dictionary_0[obj0];

  public GClass6 method_0(string int_3)
  {
    int key = 0;
    int int32 = Convert.ToInt32(int_3.Substring(2, 3));
    if (int_3.StartsWith(\u003CModule\u003E.smethod_6<string>(2769919371U)))
    {
      foreach (GClass8 gclass8 in this.list_1)
      {
        if (int32 >= gclass8.Int32_2 && int32 <= gclass8.Int32_1)
          key = gclass8.Int32_0;
      }
    }
    else if (int_3.StartsWith(\u003CModule\u003E.smethod_6<string>(2355789613U)))
    {
      foreach (GClass8 gclass8 in this.list_0)
      {
        if (int32 >= gclass8.Int32_2 && int32 <= gclass8.Int32_1)
          key = gclass8.Int32_0;
      }
    }
    if (key < 0 || key > this.dictionary_0.Count)
      key = 0;
    return this.dictionary_0[key];
  }

  private int method_1([In] Stream obj0)
  {
    obj0.Seek(0L, SeekOrigin.Begin);
    StreamReader streamReader = new StreamReader(obj0);
    this.list_0.Clear();
    while (!streamReader.EndOfStream)
    {
      string[] strArray = streamReader.ReadLine().Split(' ');
      if (strArray.Length == 3)
        this.list_0.Add(new GClass8(Convert.ToInt32(strArray[0]), Convert.ToInt32(strArray[1]), Convert.ToInt32(strArray[2])));
      else if (strArray.Length == 2)
      {
        int int32_1 = Convert.ToInt32(strArray[0]);
        int num = int32_1;
        int int32_2 = Convert.ToInt32(strArray[1]);
        this.list_0.Add(new GClass8(int32_1, num, int32_2));
      }
    }
    streamReader.Close();
    return this.list_0.Count;
  }

  public int method_2([In] string obj0, [In] GClass0 obj1)
  {
    this.dictionary_0.Clear();
    foreach (GClass1 gclass1 in obj1.List_0)
    {
      if (gclass1.String_0.Length == 11 && gclass1.String_0.ToUpper().EndsWith(\u003CModule\u003E.smethod_8<string>(3172681867U)) && gclass1.String_0.ToUpper().StartsWith(obj0.ToUpper()))
        this.dictionary_0.Add(Convert.ToInt32(Path.GetFileNameWithoutExtension(gclass1.String_0).Remove(0, obj0.Length)), GClass6.smethod_2(gclass1.String_0, obj1));
    }
    return this.dictionary_0.Count;
  }

  public int method_3(string value, [In] string obj1)
  {
    string[] files = Directory.GetFiles(obj1, value + \u003CModule\u003E.smethod_9<string>(3816383287U), SearchOption.TopDirectoryOnly);
    this.dictionary_0.Clear();
    foreach (string path in files)
    {
      if (Path.GetFileName(path).ToUpper().EndsWith(\u003CModule\u003E.smethod_8<string>(3172681867U)) && Path.GetFileName(path).ToUpper().StartsWith(value.ToUpper()))
        this.dictionary_0.Add(Convert.ToInt32(Path.GetFileNameWithoutExtension(path).Remove(0, value.Length)), GClass6.smethod_0(path));
    }
    return this.dictionary_0.Count;
  }

  public int method_4(string value, [In] GClass0 obj1)
  {
    this.list_0.Clear();
    foreach (GClass1 gclass1 in obj1.List_0)
    {
      if (gclass1.String_0.ToUpper().EndsWith(\u003CModule\u003E.smethod_9<string>(3257472156U)) && gclass1.String_0.ToUpper().StartsWith(value.ToUpper()) && Path.GetFileNameWithoutExtension(gclass1.String_0).Remove(0, value.Length) != \u003CModule\u003E.smethod_9<string>(2826090818U))
      {
        StreamReader streamReader = new StreamReader((Stream) new MemoryStream(obj1.method_6(gclass1)));
        while (!streamReader.EndOfStream)
        {
          string[] strArray = streamReader.ReadLine().TrimEnd().Split(' ');
          if (strArray.Length == 3)
          {
            int int32_1 = Convert.ToInt32(strArray[0]);
            int int32_2 = Convert.ToInt32(strArray[1]);
            int int32_3 = Convert.ToInt32(strArray[2]);
            switch (int32_3)
            {
              case -2:
                this.list_1.Add(new GClass8(int32_1, int32_1, int32_2));
                continue;
              case -1:
                this.list_0.Add(new GClass8(int32_1, int32_1, int32_2));
                continue;
              default:
                this.list_0.Add(new GClass8(int32_1, int32_2, int32_3));
                this.list_1.Add(new GClass8(int32_1, int32_2, int32_3));
                continue;
            }
          }
          else if (strArray.Length == 2)
          {
            int int32_4 = Convert.ToInt32(strArray[0]);
            int num = int32_4;
            int int32_5 = Convert.ToInt32(strArray[1]);
            this.list_1.Add(new GClass8(int32_4, num, int32_5));
            this.list_0.Add(new GClass8(int32_4, num, int32_5));
          }
        }
        streamReader.Close();
      }
    }
    return this.list_0.Count;
  }

  public int method_5(string string_1, [In] string obj1)
  {
    string[] files = Directory.GetFiles(obj1, string_1 + \u003CModule\u003E.smethod_9<string>(1021827632U), SearchOption.TopDirectoryOnly);
    this.list_0.Clear();
    foreach (string path in files)
    {
      if (Path.GetFileName(path).ToUpper().EndsWith(\u003CModule\u003E.smethod_9<string>(3257472156U)) && Path.GetFileName(path).ToUpper().StartsWith(string_1.ToUpper()))
      {
        string s = Path.GetFileNameWithoutExtension(path).Remove(0, string_1.Length);
        if (s != \u003CModule\u003E.smethod_9<string>(2826090818U))
        {
          foreach (string readAllLine in File.ReadAllLines(path))
          {
            char[] chArray = new char[1]{ ' ' };
            string[] strArray = readAllLine.Split(chArray);
            if (strArray.Length == 3)
            {
              int int32_1 = Convert.ToInt32(strArray[0]);
              int int32_2 = Convert.ToInt32(strArray[1]);
              int int32_3 = Convert.ToInt32(strArray[2]);
              if (int.TryParse(s, out int _))
                this.list_1.Add(new GClass8(int32_1, int32_2, int32_3));
              else
                this.list_0.Add(new GClass8(int32_1, int32_2, int32_3));
            }
            else if (strArray.Length == 2)
            {
              int int32_4 = Convert.ToInt32(strArray[0]);
              int num = int32_4;
              int int32_5 = Convert.ToInt32(strArray[1]);
              if (int.TryParse(s, out int _))
                this.list_1.Add(new GClass8(int32_4, num, int32_5));
              else
                this.list_0.Add(new GClass8(int32_4, num, int32_5));
            }
          }
        }
      }
    }
    return this.list_0.Count;
  }

  public static void smethod_0([In] GClass7 obj0, string int_3)
  {
    if (!File.Exists(int_3))
      return;
    StreamReader streamReader = new StreamReader((Stream) new FileStream(int_3, FileMode.Open, FileAccess.Read));
    while (!streamReader.EndOfStream)
    {
      string[] strArray = streamReader.ReadLine().TrimEnd().Split(' ');
      if (strArray.Length == 3)
      {
        int int32_1 = Convert.ToInt32(strArray[0]);
        int int32_2 = Convert.ToInt32(strArray[1]);
        int int32_3 = Convert.ToInt32(strArray[2]);
        foreach (GClass8 gclass8 in obj0.list_1)
        {
          if (gclass8.Int32_2 == int32_1)
          {
            gclass8.Int32_0 = int32_3;
            break;
          }
        }
        foreach (GClass8 gclass8 in obj0.list_0)
        {
          if (gclass8.Int32_2 == int32_1)
          {
            gclass8.Int32_0 = int32_2;
            break;
          }
        }
      }
    }
    streamReader.Close();
  }

  public virtual string System\u002EObject\u002EToString() => \u003CModule\u003E.smethod_8<string>(2452505911U) + this.list_0.Count.ToString() + \u003CModule\u003E.smethod_9<string>(2345917521U) + this.dictionary_0.Count.ToString() + \u003CModule\u003E.smethod_8<string>(907800239U);
}
