﻿// Decompiled with JetBrains decompiler
// Type: Enum4
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;

[Flags]
internal enum Enum4 : byte
{
  HasParcel = 1,
  HasLetter = 16, // 0x10
}
