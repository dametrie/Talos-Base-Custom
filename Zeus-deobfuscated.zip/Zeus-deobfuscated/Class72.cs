﻿// Decompiled with JetBrains decompiler
// Type: Class72
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

internal sealed class Class72
{
  private static readonly MD5 md5_0 = MD5.Create();
  private static readonly byte[][] byte_0 = new byte[10][]
  {
    \u003CModule\u003E.smethod_8<byte[]>(698980209U),
    \u003CModule\u003E.smethod_8<byte[]>(2272405667U),
    \u003CModule\u003E.smethod_6<byte[]>(1821246213U),
    \u003CModule\u003E.smethod_8<byte[]>(2940404743U),
    \u003CModule\u003E.smethod_9<byte[]>(3064299795U),
    \u003CModule\u003E.smethod_7<byte[]>(1910652645U),
    \u003CModule\u003E.smethod_5<byte[]>(3187975045U),
    \u003CModule\u003E.smethod_6<byte[]>(604920031U),
    \u003CModule\u003E.smethod_8<byte[]>(996478433U),
    \u003CModule\u003E.smethod_8<byte[]>(2569903891U)
  };
  private readonly string string_0;

  internal byte Byte_0 { get; }

  internal byte[] Byte_1 { get; }

  internal byte[] Byte_2 => Class72.byte_0[(int) this.Byte_0];

  internal Class72()
    : this((byte) 0, \u003CModule\u003E.smethod_8<string>(4007736967U))
  {
  }

  internal Class72([In] byte obj0, [In] string obj1)
  {
    this.Byte_0 = obj0;
    this.Byte_1 = Encoding.ASCII.GetBytes(obj1);
    this.string_0 = string.Empty;
  }

  internal Class72([In] byte obj0, [In] string obj1, [In] string obj2)
    : this(obj0, obj1)
  {
    this.string_0 = Class72.smethod_0(obj2);
  }

  internal byte[] method_0([In] ushort obj0, [In] byte obj1)
  {
    byte[] numArray = new byte[9];
    for (int index1 = 0; index1 < 9; ++index1)
    {
      int index2 = (index1 * (9 * index1 + (int) obj1 * (int) obj1) + (int) obj0) % this.string_0.Length;
      numArray[index1] = (byte) this.string_0[index2];
    }
    return numArray;
  }

  internal static string smethod_0([In] string obj0)
  {
    string str = Class72.smethod_1(Class72.smethod_1(obj0));
    for (int index = 0; index < 31; ++index)
      str += Class72.smethod_1(str);
    return str;
  }

  internal static string smethod_1([In] string obj0)
  {
    byte[] bytes = Encoding.ASCII.GetBytes(obj0);
    return BitConverter.ToString(Class72.md5_0.ComputeHash(bytes)).Replace(\u003CModule\u003E.smethod_5<string>(1777882200U), string.Empty).ToLower();
  }
}
