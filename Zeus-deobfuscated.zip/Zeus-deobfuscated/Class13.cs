﻿// Decompiled with JetBrains decompiler
// Type: Class13
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;
using WindowsInput.Native;

internal static class Class13
{
  internal static void smethod_0([In] string obj0, Process int_27)
  {
    foreach (byte num in Encoding.ASCII.GetBytes(obj0))
      Class137.SendMessage(int_27.MainWindowHandle, 258U, (IntPtr) (int) num, IntPtr.Zero);
  }

  internal static void smethod_1([In] VirtualKeyCode obj0, [In] Process obj1) => Class137.SendMessage(obj1.MainWindowHandle, 258U, (IntPtr) (int) obj0, IntPtr.Zero);

  internal static void smethod_2(string value, Process class142_1, [In] bool obj2)
  {
    byte[] bytes1 = Encoding.ASCII.GetBytes(value);
    byte[] bytes2 = Encoding.ASCII.GetBytes(value.ToUpper());
    for (int index = 0; index < bytes1.Length; ++index)
    {
      uint num1 = (uint) (1 | Class137.MapVirtualKey((int) bytes2[index], 0) << 16);
      if (!obj2)
      {
        Class137.PostMessage_1(class142_1.MainWindowHandle, 256U, (IntPtr) (int) bytes2[index], (IntPtr) (long) num1);
        Class137.PostMessage_1(class142_1.MainWindowHandle, 258U, (IntPtr) (int) bytes1[index], (IntPtr) (long) num1);
        uint num2 = num1 | 3221225472U;
        Class137.PostMessage_1(class142_1.MainWindowHandle, 257U, (IntPtr) (int) bytes2[index], (IntPtr) (int) num2);
      }
      else
      {
        Class137.SendMessage(class142_1.MainWindowHandle, 256U, (IntPtr) (int) bytes2[index], (IntPtr) (long) num1);
        Class137.SendMessage(class142_1.MainWindowHandle, 258U, (IntPtr) (int) bytes1[index], (IntPtr) (long) num1);
        uint num3 = num1 | 3221225472U;
        Class137.SendMessage(class142_1.MainWindowHandle, 257U, (IntPtr) (int) bytes2[index], (IntPtr) (int) num3);
      }
    }
  }

  internal static void smethod_3(Point int_4, Process int_5)
  {
    uint x = (uint) int_4.X;
    uint num = (uint) (int_4.Y << 16) | x;
    Class137.PostMessage_1(int_5.MainWindowHandle, 513U, (IntPtr) 1, (IntPtr) (int) num);
    Class137.PostMessage_1(int_5.MainWindowHandle, 514U, (IntPtr) 1, (IntPtr) (int) num);
  }

  internal static void smethod_4([In] Point obj0, [In] Process obj1)
  {
    uint x = (uint) obj0.X;
    uint num = (uint) (obj0.Y << 16) | x;
    Class137.PostMessage_1(obj1.MainWindowHandle, 512U, (IntPtr) 1, (IntPtr) (int) num);
  }
}
