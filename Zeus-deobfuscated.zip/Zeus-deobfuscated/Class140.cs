﻿// Decompiled with JetBrains decompiler
// Type: Class140
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Runtime.InteropServices;

internal abstract class Class140 : Class139
{
  internal ushort UInt16_0 { get; set; }

  internal Struct16 Struct16_0 { get; set; }

  internal Class88 Class88_0 { get; set; }

  internal Class140(
    [In] int obj0,
    string string_4,
    ushort struct16_1,
    Struct16 class88_1,
    Class88 direction_1)
    : base(obj0, string_4)
  {
    this.UInt16_0 = struct16_1;
    this.Struct16_0 = class88_1;
    this.Class88_0 = direction_1;
  }

  internal bool method_1(Class140 value, [In] int obj1) => this.Class88_0 == value.Class88_0 && this.Struct16_0.method_0(value.Struct16_0) <= obj1;
}
