﻿// Decompiled with JetBrains decompiler
// Type: Accolade.Properties.Settings
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Accolade.Properties
{
  [CompilerGenerated]
  [GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "12.0.0.0")]
  internal sealed class Settings : ApplicationSettingsBase
  {
    [DefaultSettingValue("False")]
    [DebuggerNonUserCode]
    [UserScopedSetting]
    public bool ParanoiaMode
    {
      get => (bool) this[\u003CModule\u003E.smethod_6<string>(3144783613U)];
      [param: In] set => this[\u003CModule\u003E.smethod_5<string>(2324922117U)] = (object) value;
    }

    [UserScopedSetting]
    [DefaultSettingValue("False")]
    [DebuggerNonUserCode]
    public bool OverrideSprites
    {
      get => (bool) this[\u003CModule\u003E.smethod_5<string>(3713728201U)];
      set => this[\u003CModule\u003E.smethod_8<string>(1939306209U)] = (object) value;
    }

    [DefaultSettingValue("False")]
    [DebuggerNonUserCode]
    [UserScopedSetting]
    public bool DisableSprites
    {
      get => (bool) this[\u003CModule\u003E.smethod_8<string>(685520396U)];
      set => this[\u003CModule\u003E.smethod_9<string>(2222073702U)] = (object) value;
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("True")]
    public bool NormalSprites
    {
      get => (bool) this[\u003CModule\u003E.smethod_5<string>(743292467U)];
      set => this[\u003CModule\u003E.smethod_9<string>(2428341329U)] = (object) value;
    }

    [DefaultSettingValue("false")]
    [DebuggerNonUserCode]
    [UserScopedSetting]
    public bool RefreshAll
    {
      get => (bool) this[\u003CModule\u003E.smethod_7<string>(1968542862U)];
      set => this[\u003CModule\u003E.smethod_9<string>(2987252460U)] = (object) value;
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("C:\\Program Files (x86)\\KRU\\Dark Ages\\Darkages.exe")]
    public string DarkAgesPath
    {
      get => (string) this[\u003CModule\u003E.smethod_6<string>(2293084402U)];
      set => this[\u003CModule\u003E.smethod_9<string>(751607936U)] = (object) value;
    }

    [DefaultSettingValue("%localappdata%\\VirtualStore\\Program Files (x86)\\KRU\\Dark Ages")]
    [DebuggerNonUserCode]
    [UserScopedSetting]
    public string DataPath
    {
      get => (string) this[\u003CModule\u003E.smethod_9<string>(65167012U)];
      set => this[\u003CModule\u003E.smethod_7<string>(4102030262U)] = (object) value;
    }

    [DebuggerNonUserCode]
    [DefaultSettingValue("PgDn")]
    [UserScopedSetting]
    public string BotHotKey
    {
      get => (string) this[\u003CModule\u003E.smethod_9<string>(3977544929U)];
      set => this[\u003CModule\u003E.smethod_5<string>(2003549507U)] = (object) value;
    }

    [DefaultSettingValue("Del")]
    [UserScopedSetting]
    [DebuggerNonUserCode]
    public string CastHotKey
    {
      get => (string) this[\u003CModule\u003E.smethod_7<string>(656107609U)];
      set => this[\u003CModule\u003E.smethod_9<string>(3291104005U)] = (object) value;
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("Subtract")]
    public string SoundHotKey
    {
      get => (string) this[\u003CModule\u003E.smethod_6<string>(3251573939U)];
      set => this[\u003CModule\u003E.smethod_9<string>(1055459481U)] = (object) value;
    }

    [DebuggerNonUserCode]
    [DefaultSettingValue("Ins")]
    [UserScopedSetting]
    public string WalkHotKey
    {
      get => (string) this[\u003CModule\u003E.smethod_9<string>(369018557U)];
      [param: In] set => this[\u003CModule\u003E.smethod_5<string>(1875000463U)] = (object) value;
    }

    [DefaultSettingValue("")]
    [UserScopedSetting]
    [DebuggerNonUserCode]
    public string Combo1HotKey
    {
      get => (string) this[\u003CModule\u003E.smethod_5<string>(1771684819U)];
      [param: In] set => this[\u003CModule\u003E.smethod_6<string>(613125675U)] = (object) value;
    }

    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    [UserScopedSetting]
    public string Combo2HotKey
    {
      get => (string) this[\u003CModule\u003E.smethod_7<string>(796070089U)];
      set => this[\u003CModule\u003E.smethod_6<string>(4079833455U)] = (object) value;
    }

    [DefaultSettingValue("")]
    [DebuggerNonUserCode]
    [UserScopedSetting]
    public string Combo3HotKey
    {
      get => (string) this[\u003CModule\u003E.smethod_7<string>(1862813789U)];
      [param: In] set => this[\u003CModule\u003E.smethod_6<string>(2269644707U)] = (object) value;
    }

    [UserScopedSetting]
    [DefaultSettingValue("")]
    [DebuggerNonUserCode]
    public string Combo4HotKey
    {
      get => (string) this[\u003CModule\u003E.smethod_7<string>(2929557489U)];
      [param: In] set => this[\u003CModule\u003E.smethod_8<string>(2312438407U)] = (object) value;
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("True")]
    public bool SmallWindowOpt
    {
      get => Convert.ToBoolean(this[\u003CModule\u003E.smethod_6<string>(3926163739U)]);
      [param: In] set => this[\u003CModule\u003E.smethod_7<string>(4052286181U)] = (object) value;
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("False")]
    public bool LargeWindowOpt
    {
      get => Convert.ToBoolean(this[\u003CModule\u003E.smethod_5<string>(852320950U)]);
      set => this[\u003CModule\u003E.smethod_5<string>(852320950U)] = (object) value;
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("False")]
    public bool FullWindowOpt
    {
      get => Convert.ToBoolean(this[\u003CModule\u003E.smethod_5<string>(61506125U)]);
      set => this[\u003CModule\u003E.smethod_5<string>(61506125U)] = (object) value;
    }

    [DefaultSettingValue("True")]
    [DebuggerNonUserCode]
    [UserScopedSetting]
    public bool WhisperSound
    {
      get => Convert.ToBoolean(this[\u003CModule\u003E.smethod_6<string>(1417945496U)]);
      set => this[\u003CModule\u003E.smethod_7<string>(3694624644U)] = (object) value;
    }

    [DebuggerNonUserCode]
    [DefaultSettingValue("True")]
    [UserScopedSetting]
    public bool EnableKom
    {
      get => Convert.ToBoolean(this[\u003CModule\u003E.smethod_6<string>(589685980U)]);
      set => this[\u003CModule\u003E.smethod_8<string>(1671843444U)] = (object) value;
    }

    [DefaultSettingValue("True")]
    [DebuggerNonUserCode]
    [UserScopedSetting]
    public bool WhisperFlash
    {
      get => Convert.ToBoolean(this[\u003CModule\u003E.smethod_8<string>(1431784792U)]);
      set => this[\u003CModule\u003E.smethod_8<string>(1431784792U)] = (object) value;
    }

    [DefaultSettingValue("True")]
    [DebuggerNonUserCode]
    [UserScopedSetting]
    public bool UseDawnd
    {
      get => Convert.ToBoolean(this[\u003CModule\u003E.smethod_6<string>(2246205012U)]);
      set => this[\u003CModule\u003E.smethod_5<string>(2048303468U)] = (object) value;
    }

    [DefaultSettingValue("False")]
    [UserScopedSetting]
    [DebuggerNonUserCode]
    public bool RemoveSpam
    {
      get => Convert.ToBoolean(this[\u003CModule\u003E.smethod_6<string>(2376435033U)]);
      set => this[\u003CModule\u003E.smethod_9<string>(3388687923U)] = (object) value;
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("100")]
    public int BotwindowOpacity
    {
      get => Convert.ToInt32(this[\u003CModule\u003E.smethod_6<string>(1548175517U)]);
      set => this[\u003CModule\u003E.smethod_8<string>(3645805213U)] = (object) value;
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("100")]
    public byte DawindowOpacity
    {
      get => (byte) this[\u003CModule\u003E.smethod_6<string>(2092535296U)];
      set => this[\u003CModule\u003E.smethod_8<string>(2392019400U)] = (object) value;
    }

    [DefaultSettingValue("False")]
    [DebuggerNonUserCode]
    [UserScopedSetting]
    public bool EnableOverlay
    {
      get => Convert.ToBoolean(this[\u003CModule\u003E.smethod_8<string>(898174935U)]);
      set => this[\u003CModule\u003E.smethod_6<string>(2790564791U)] = (object) value;
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("False")]
    public bool LogOnStartup
    {
      get => Convert.ToBoolean(this[\u003CModule\u003E.smethod_6<string>(1865923098U)]);
      set => this[\u003CModule\u003E.smethod_9<string>(2968406376U)] = (object) value;
    }

    [DefaultSettingValue("True")]
    [UserScopedSetting]
    [DebuggerNonUserCode]
    public bool RangerSend
    {
      get => (bool) this[\u003CModule\u003E.smethod_5<string>(1830246502U)];
      set => this[\u003CModule\u003E.smethod_8<string>(3140915142U)] = (object) value;
    }

    internal static Settings Default { get; } = (Settings) SettingsBase.Synchronized((SettingsBase) new Settings());
  }
}
