﻿// Decompiled with JetBrains decompiler
// Type: Accolade.Direction
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;

namespace Accolade
{
  [Flags]
  internal enum Direction : byte
  {
    North = 0,
    East = 1,
    South = 2,
    West = South | East, // 0x03
    Invalid = 255, // 0xFF
  }
}
