﻿// Decompiled with JetBrains decompiler
// Type: Accolade.MedClass
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;

namespace Accolade
{
  [Flags]
  internal enum MedClass : byte
  {
    NonMed = 0,
    Gladiator = 1,
    Druid = 2,
    Archer = Druid | Gladiator, // 0x03
    Bard = 4,
    Summoner = Bard | Gladiator, // 0x05
    Unknown = Bard | Druid, // 0x06
  }
}
