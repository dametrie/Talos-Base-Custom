﻿// Decompiled with JetBrains decompiler
// Type: Class26
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using Accolade;
using Accolade.Properties;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Media;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Media;

internal class Class26 : Class25
{
  internal static readonly object object_0 = new object();
  internal HashSet<ushort> hashSet_0;
  internal List<Class177> list_3;
  internal HashSet<string> hashSet_1;
  internal List<Class145> list_4;
  internal List<Class142> list_5;
  internal List<Class143> list_6;
  internal List<Class143> list_7;
  internal List<Class142> list_8;
  internal List<Class143> list_9;
  internal List<Class143> list_10;
  internal List<Class142> list_11;
  internal List<Class143> list_12;
  internal DateTime dateTime_0 = DateTime.MinValue;
  internal DateTime dateTime_1 = DateTime.MinValue;
  internal DateTime dateTime_2 = DateTime.MinValue;
  internal DateTime dateTime_3 = DateTime.MinValue;
  internal DateTime dateTime_4 = DateTime.MinValue;
  internal DateTime dateTime_5 = DateTime.MinValue;
  internal DateTime dateTime_6 = DateTime.MinValue;
  internal DateTime dateTime_7 = DateTime.MinValue;
  internal DateTime dateTime_8 = DateTime.MinValue;
  private readonly List<Class142> list_13 = new List<Class142>();
  internal bool bool_0;
  internal bool bool_1;
  private bool bool_2;
  internal bool bool_3;
  internal bool bool_4;
  internal bool[] bool_5 = new bool[5];
  internal Control3 control3_0;
  internal Control3 control3_1;
  internal Control4 control4_0;
  internal List<string> list_14;
  internal Class142 class142_0;
  internal int int_0;
  internal bool bool_6;
  internal DateTime dateTime_9 = DateTime.MinValue;
  private Thread thread_0;
  internal List<Struct17> list_15 = new List<Struct17>();
  internal int int_1;
  internal bool bool_7;
  internal bool bool_8;
  internal bool bool_9;
  internal bool bool_10;
  internal bool bool_11;
  internal bool bool_12;
  internal DateTime dateTime_10 = DateTime.MinValue;
  internal DateTime dateTime_11 = DateTime.MinValue;
  internal DateTime dateTime_12 = DateTime.MinValue;
  internal DateTime dateTime_13 = DateTime.MinValue;
  internal Struct16 struct16_0;
  internal string string_0 = "";
  internal int int_2;
  internal DateTime dateTime_14 = DateTime.MinValue;
  internal bool bool_13 = true;
  internal DateTime dateTime_15 = DateTime.MinValue;
  internal DateTime dateTime_16 = DateTime.MinValue;
  internal bool bool_14;
  internal bool bool_15;
  internal DateTime dateTime_17 = DateTime.MinValue;
  internal Class143 class143_0;
  internal bool bool_16;
  private Class142 class142_1;
  internal DateTime dateTime_18;
  private DateTime dateTime_19;
  private Label label_0;
  internal bool bool_17;
  private SoundPlayer soundPlayer_0;
  private MediaPlayer mediaPlayer_0;
  internal bool bool_18;
  internal bool bool_19;
  internal Struct16 struct16_1;
  private List<string> list_16 = new List<string>()
  {
    \u003CModule\u003E.smethod_9<string>(1029906401U),
    \u003CModule\u003E.smethod_5<string>(2330614623U),
    \u003CModule\u003E.smethod_7<string>(208227673U),
    \u003CModule\u003E.smethod_9<string>(2402788249U),
    \u003CModule\u003E.smethod_9<string>(780750121U),
    \u003CModule\u003E.smethod_9<string>(1716347325U),
    \u003CModule\u003E.smethod_6<string>(2082127147U)
  };
  private List<string> list_17 = new List<string>()
  {
    \u003CModule\u003E.smethod_5<string>(1372714507U),
    \u003CModule\u003E.smethod_8<string>(2458443663U),
    \u003CModule\u003E.smethod_7<string>(1915403515U)
  };
  private List<string> list_18 = new List<string>()
  {
    \u003CModule\u003E.smethod_5<string>(681399989U),
    \u003CModule\u003E.smethod_9<string>(3363134843U),
    \u003CModule\u003E.smethod_8<string>(424635996U)
  };
  private List<string> list_19 = new List<string>()
  {
    \u003CModule\u003E.smethod_7<string>(3330722196U),
    \u003CModule\u003E.smethod_6<string>(271938399U),
    \u003CModule\u003E.smethod_8<string>(1624929256U),
    \u003CModule\u003E.smethod_7<string>(895558251U),
    \u003CModule\u003E.smethod_5<string>(3992728894U),
    \u003CModule\u003E.smethod_6<string>(2886946968U),
    \u003CModule\u003E.smethod_6<string>(3999106221U)
  };
  private List<string> list_20 = new List<string>()
  {
    \u003CModule\u003E.smethod_7<string>(1085264812U),
    \u003CModule\u003E.smethod_9<string>(550675532U)
  };
  private Dictionary<short, ushort> dictionary_0 = new Dictionary<short, ushort>()
  {
    {
      (short) 5260,
      (ushort) 153
    },
    {
      (short) 5261,
      (ushort) 539
    },
    {
      (short) 5262,
      (ushort) 68
    },
    {
      (short) 5263,
      (ushort) 54
    },
    {
      (short) 5264,
      (ushort) 339
    },
    {
      (short) 5265,
      (ushort) 345
    },
    {
      (short) 5266,
      (ushort) 399
    },
    {
      (short) 5267,
      (ushort) 17
    },
    {
      (short) 5268,
      (ushort) 97
    }
  };
  private int int_3 = 1;
  private int int_4 = 1;
  private List<Class142> list_21 = new List<Class142>();
  private List<Class142> list_22 = new List<Class142>();
  private DateTime dateTime_20 = DateTime.MinValue;
  private readonly ushort ushort_0 = 649;
  private Class142 class142_2;
  private readonly List<string> list_23 = new List<string>()
  {
    \u003CModule\u003E.smethod_5<string>(2759602756U),
    \u003CModule\u003E.smethod_8<string>(3290642397U),
    \u003CModule\u003E.smethod_9<string>(1142179215U),
    \u003CModule\u003E.smethod_8<string>(449183743U),
    \u003CModule\u003E.smethod_7<string>(251181222U),
    \u003CModule\u003E.smethod_6<string>(1490802539U),
    \u003CModule\u003E.smethod_7<string>(1119131805U),
    \u003CModule\u003E.smethod_9<string>(3356899061U),
    \u003CModule\u003E.smethod_9<string>(1084033583U),
    \u003CModule\u003E.smethod_7<string>(3034920148U),
    \u003CModule\u003E.smethod_8<string>(1222852252U),
    \u003CModule\u003E.smethod_8<string>(317650890U),
    \u003CModule\u003E.smethod_5<string>(3073365025U),
    \u003CModule\u003E.smethod_5<string>(2761984800U)
  };
  private readonly List<string> list_24 = new List<string>()
  {
    \u003CModule\u003E.smethod_9<string>(4049575767U),
    \u003CModule\u003E.smethod_5<string>(1556009897U),
    \u003CModule\u003E.smethod_5<string>(2944815981U),
    \u003CModule\u003E.smethod_5<string>(2218275678U)
  };
  private readonly List<string> list_25 = new List<string>()
  {
    \u003CModule\u003E.smethod_7<string>(2693135699U)
  };
  private readonly List<string> list_26 = new List<string>()
  {
    \u003CModule\u003E.smethod_8<string>(3040508401U),
    \u003CModule\u003E.smethod_7<string>(531655803U)
  };
  private readonly List<string> list_27 = new List<string>()
  {
    \u003CModule\u003E.smethod_7<string>(3268496293U),
    \u003CModule\u003E.smethod_6<string>(1938865580U)
  };
  private readonly List<string> list_28 = new List<string>()
  {
    \u003CModule\u003E.smethod_6<string>(128676832U),
    \u003CModule\u003E.smethod_5<string>(2662484493U),
    \u003CModule\u003E.smethod_9<string>(3021591130U)
  };
  private readonly List<string> list_29 = new List<string>()
  {
    \u003CModule\u003E.smethod_6<string>(956936348U),
    \u003CModule\u003E.smethod_8<string>(3947250456U),
    \u003CModule\u003E.smethod_9<string>(3021591130U)
  };
  private readonly List<string> list_30 = new List<string>()
  {
    \u003CModule\u003E.smethod_5<string>(2469660927U),
    \u003CModule\u003E.smethod_5<string>(290040018U),
    \u003CModule\u003E.smethod_7<string>(1324715454U)
  };
  private readonly List<int> list_31 = new List<int>()
  {
    272,
    266,
    87
  };
  private readonly List<int> list_32 = new List<int>()
  {
    273,
    240
  };
  internal bool bool_20;
  private readonly List<Class26.Class146> list_33 = new List<Class26.Class146>()
  {
    new Class26.Class146(\u003CModule\u003E.smethod_9<string>(4139413392U), (short) 133, (short) 8999, new List<string>()
    {
      \u003CModule\u003E.smethod_8<string>(2052869680U),
      \u003CModule\u003E.smethod_6<string>(3288045180U),
      \u003CModule\u003E.smethod_9<string>(2050144745U),
      \u003CModule\u003E.smethod_5<string>(1382706892U),
      \u003CModule\u003E.smethod_9<string>(4030729683U)
    }),
    new Class26.Class146(\u003CModule\u003E.smethod_8<string>(745591314U), (short) 6513, (short) 8998, new List<string>()
    {
      \u003CModule\u003E.smethod_6<string>(2436345969U),
      \u003CModule\u003E.smethod_9<string>(1667555366U),
      \u003CModule\u003E.smethod_7<string>(3296488789U),
      \u003CModule\u003E.smethod_7<string>(68265193U),
      \u003CModule\u003E.smethod_6<string>(1040286979U)
    }),
    new Class26.Class146(\u003CModule\u003E.smethod_5<string>(1723600063U), (short) 10001, (short) 8996, new List<string>()
    {
      \u003CModule\u003E.smethod_9<string>(245881559U),
      \u003CModule\u003E.smethod_5<string>(932785238U),
      \u003CModule\u003E.smethod_9<string>(1746293200U),
      \u003CModule\u003E.smethod_6<string>(3525065527U),
      \u003CModule\u003E.smethod_9<string>(3561656177U)
    }),
    new Class26.Class146(\u003CModule\u003E.smethod_6<string>(2355618735U), (short) 10265, (short) 8997, new List<string>()
    {
      \u003CModule\u003E.smethod_9<string>(639570729U),
      \u003CModule\u003E.smethod_7<string>(1648143584U),
      \u003CModule\u003E.smethod_6<string>(2201949019U),
      \u003CModule\u003E.smethod_8<string>(502901316U),
      \u003CModule\u003E.smethod_9<string>(2188774329U)
    })
  };
  private bool bool_21;
  private bool bool_22;
  private bool bool_23;
  private bool bool_24;
  private Class142 class142_3;
  private readonly ushort ushort_1 = 529;
  internal byte byte_0;
  private DateTime dateTime_21;
  private bool bool_25;
  private bool bool_26;
  private DateTime dateTime_22 = DateTime.MinValue;
  private DateTime dateTime_23 = DateTime.MinValue;
  private DateTime dateTime_24 = DateTime.MinValue;
  private Struct16 struct16_2 = new Struct16(8, 8);
  private bool bool_27;
  private Dictionary<int, DateTime> dictionary_1 = new Dictionary<int, DateTime>();
  private int int_5;
  private int int_6;
  internal bool bool_28;
  private int int_7 = 1;
  internal bool bool_29;
  internal bool bool_30;
  internal bool bool_31;
  internal bool bool_32;
  internal bool bool_33;
  internal bool bool_34;
  internal bool bool_35;
  internal short short_0;
  internal Struct16 struct16_3;
  internal Dictionary<string, string> dictionary_2 = new Dictionary<string, string>()
  {
    {
      \u003CModule\u003E.smethod_6<string>(3030208535U),
      \u003CModule\u003E.smethod_5<string>(3143352386U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(237191174U),
      \u003CModule\u003E.smethod_7<string>(1865842641U)
    },
    {
      \u003CModule\u003E.smethod_8<string>(395916210U),
      \u003CModule\u003E.smethod_7<string>(827091437U)
    },
    {
      \u003CModule\u003E.smethod_7<string>(3234262886U),
      \u003CModule\u003E.smethod_6<string>(3574568314U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(2718664132U),
      \u003CModule\u003E.smethod_8<string>(929526067U)
    },
    {
      \u003CModule\u003E.smethod_7<string>(967053917U),
      \u003CModule\u003E.smethod_5<string>(2590115088U)
    },
    {
      \u003CModule\u003E.smethod_6<string>(1740939871U),
      \u003CModule\u003E.smethod_7<string>(827091437U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(2461566044U),
      \u003CModule\u003E.smethod_8<string>(3730648898U)
    },
    {
      \u003CModule\u003E.smethod_8<string>(3276620034U),
      \u003CModule\u003E.smethod_9<string>(1149689901U)
    },
    {
      \u003CModule\u003E.smethod_9<string>(2492625874U),
      \u003CModule\u003E.smethod_9<string>(1149689901U)
    },
    {
      \u003CModule\u003E.smethod_9<string>(2668947626U),
      \u003CModule\u003E.smethod_7<string>(146001770U)
    },
    {
      \u003CModule\u003E.smethod_6<string>(2675989713U),
      \u003CModule\u003E.smethod_8<string>(929526067U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(687112828U),
      \u003CModule\u003E.smethod_8<string>(288931104U)
    },
    {
      \u003CModule\u003E.smethod_9<string>(3366488341U),
      \u003CModule\u003E.smethod_5<string>(3657548562U)
    },
    {
      \u003CModule\u003E.smethod_6<string>(4105896547U),
      \u003CModule\u003E.smethod_7<string>(827091437U)
    },
    {
      \u003CModule\u003E.smethod_8<string>(3011788615U),
      \u003CModule\u003E.smethod_6<string>(2048279303U)
    },
    {
      \u003CModule\u003E.smethod_7<string>(2273248259U),
      \u003CModule\u003E.smethod_5<string>(3657548562U)
    },
    {
      \u003CModule\u003E.smethod_9<string>(1434695362U),
      \u003CModule\u003E.smethod_7<string>(2882842260U)
    },
    {
      \u003CModule\u003E.smethod_9<string>(2199874120U),
      \u003CModule\u003E.smethod_5<string>(3143352386U)
    },
    {
      \u003CModule\u003E.smethod_8<string>(3144862161U),
      \u003CModule\u003E.smethod_9<string>(1149689901U)
    },
    {
      \u003CModule\u003E.smethod_8<string>(3918530670U),
      \u003CModule\u003E.smethod_6<string>(1894609587U)
    },
    {
      \u003CModule\u003E.smethod_9<string>(2503725665U),
      \u003CModule\u003E.smethod_7<string>(146001770U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(1536489336U),
      \u003CModule\u003E.smethod_5<string>(2288263039U)
    },
    {
      \u003CModule\u003E.smethod_6<string>(331849335U),
      \u003CModule\u003E.smethod_6<string>(1042910376U)
    },
    {
      \u003CModule\u003E.smethod_6<string>(876209114U),
      \u003CModule\u003E.smethod_8<string>(4236854642U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(3419971035U),
      \u003CModule\u003E.smethod_8<string>(288931104U)
    },
    {
      \u003CModule\u003E.smethod_9<string>(3209012673U),
      \u003CModule\u003E.smethod_9<string>(1149689901U)
    },
    {
      \u003CModule\u003E.smethod_7<string>(3725645992U),
      \u003CModule\u003E.smethod_8<string>(4236854642U)
    },
    {
      \u003CModule\u003E.smethod_6<string>(3077087925U),
      \u003CModule\u003E.smethod_7<string>(6039290U)
    },
    {
      \u003CModule\u003E.smethod_7<string>(3367984455U),
      \u003CModule\u003E.smethod_5<string>(2288263039U)
    },
    {
      \u003CModule\u003E.smethod_7<string>(3094300406U),
      \u003CModule\u003E.smethod_6<string>(3574568314U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(3696589684U),
      \u003CModule\u003E.smethod_6<string>(3574568314U)
    },
    {
      \u003CModule\u003E.smethod_8<string>(369827770U),
      \u003CModule\u003E.smethod_8<string>(288931104U)
    },
    {
      \u003CModule\u003E.smethod_6<string>(3105859853U),
      \u003CModule\u003E.smethod_8<string>(288931104U)
    },
    {
      \u003CModule\u003E.smethod_9<string>(1645591391U),
      \u003CModule\u003E.smethod_8<string>(4236854642U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(1519350819U),
      \u003CModule\u003E.smethod_6<string>(3574568314U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(1455076297U),
      \u003CModule\u003E.smethod_9<string>(864684440U)
    },
    {
      \u003CModule\u003E.smethod_8<string>(4217344567U),
      \u003CModule\u003E.smethod_5<string>(2159713995U)
    },
    {
      \u003CModule\u003E.smethod_9<string>(2714621694U),
      \u003CModule\u003E.smethod_9<string>(3385334425U)
    },
    {
      \u003CModule\u003E.smethod_7<string>(706034897U),
      \u003CModule\u003E.smethod_7<string>(2882842260U)
    }
  };
  internal Dictionary<string, string> dictionary_3 = new Dictionary<string, string>()
  {
    {
      \u003CModule\u003E.smethod_7<string>(1072782990U),
      \u003CModule\u003E.smethod_9<string>(3385334425U)
    },
    {
      \u003CModule\u003E.smethod_9<string>(4263825294U),
      \u003CModule\u003E.smethod_6<string>(2959889450U)
    },
    {
      \u003CModule\u003E.smethod_6<string>(290302178U),
      \u003CModule\u003E.smethod_7<string>(146001770U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(1927849307U),
      \u003CModule\u003E.smethod_6<string>(2048279303U)
    },
    {
      \u003CModule\u003E.smethod_8<string>(3276620034U),
      \u003CModule\u003E.smethod_9<string>(3385334425U)
    },
    {
      \u003CModule\u003E.smethod_6<string>(1717500176U),
      \u003CModule\u003E.smethod_5<string>(2159713995U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(3911315855U),
      \u003CModule\u003E.smethod_7<string>(146001770U)
    },
    {
      \u003CModule\u003E.smethod_9<string>(2174556647U),
      \u003CModule\u003E.smethod_5<string>(3143352386U)
    },
    {
      \u003CModule\u003E.smethod_7<string>(3554845371U),
      \u003CModule\u003E.smethod_9<string>(864684440U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(111024174U),
      \u003CModule\u003E.smethod_5<string>(3143352386U)
    },
    {
      \u003CModule\u003E.smethod_6<string>(550762220U),
      \u003CModule\u003E.smethod_6<string>(1042910376U)
    },
    {
      \u003CModule\u003E.smethod_9<string>(3355388550U),
      \u003CModule\u003E.smethod_9<string>(1149689901U)
    },
    {
      \u003CModule\u003E.smethod_6<string>(2337511273U),
      \u003CModule\u003E.smethod_9<string>(1708601032U)
    },
    {
      \u003CModule\u003E.smethod_8<string>(135031810U),
      \u003CModule\u003E.smethod_7<string>(2882842260U)
    },
    {
      \u003CModule\u003E.smethod_8<string>(3011788615U),
      \u003CModule\u003E.smethod_5<string>(2159713995U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(3310942552U),
      \u003CModule\u003E.smethod_9<string>(1149689901U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(3844659289U),
      \u003CModule\u003E.smethod_6<string>(1894609587U)
    },
    {
      \u003CModule\u003E.smethod_7<string>(329467420U),
      \u003CModule\u003E.smethod_7<string>(827091437U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(2695812776U),
      \u003CModule\u003E.smethod_7<string>(2882842260U)
    },
    {
      \u003CModule\u003E.smethod_6<string>(811222262U),
      \u003CModule\u003E.smethod_5<string>(2590115088U)
    },
    {
      \u003CModule\u003E.smethod_7<string>(1669895169U),
      \u003CModule\u003E.smethod_5<string>(2288263039U)
    },
    {
      \u003CModule\u003E.smethod_7<string>(743113949U),
      \u003CModule\u003E.smethod_5<string>(2288263039U)
    },
    {
      \u003CModule\u003E.smethod_7<string>(2932586341U),
      \u003CModule\u003E.smethod_6<string>(1894609587U)
    },
    {
      \u003CModule\u003E.smethod_7<string>(2733793224U),
      \u003CModule\u003E.smethod_5<string>(2590115088U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(2502989210U),
      \u003CModule\u003E.smethod_6<string>(2959889450U)
    },
    {
      \u003CModule\u003E.smethod_7<string>(3367984455U),
      \u003CModule\u003E.smethod_8<string>(929526067U)
    },
    {
      \u003CModule\u003E.smethod_8<string>(375090462U),
      \u003CModule\u003E.smethod_5<string>(2590115088U)
    },
    {
      \u003CModule\u003E.smethod_8<string>(2617830669U),
      \u003CModule\u003E.smethod_5<string>(2590115088U)
    },
    {
      \u003CModule\u003E.smethod_9<string>(2823305403U),
      \u003CModule\u003E.smethod_7<string>(146001770U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(3075747069U),
      \u003CModule\u003E.smethod_9<string>(1708601032U)
    },
    {
      \u003CModule\u003E.smethod_8<string>(2564338116U),
      \u003CModule\u003E.smethod_7<string>(6039290U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(2220657722U),
      \u003CModule\u003E.smethod_8<string>(4236854642U)
    },
    {
      \u003CModule\u003E.smethod_9<string>(2728839376U),
      \u003CModule\u003E.smethod_9<string>(1149689901U)
    },
    {
      \u003CModule\u003E.smethod_9<string>(272709543U),
      \u003CModule\u003E.smethod_7<string>(1865842641U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(703302594U),
      \u003CModule\u003E.smethod_5<string>(3143352386U)
    },
    {
      \u003CModule\u003E.smethod_9<string>(4019865499U),
      \u003CModule\u003E.smethod_7<string>(6039290U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(2027834156U),
      \u003CModule\u003E.smethod_5<string>(2590115088U)
    },
    {
      \u003CModule\u003E.smethod_8<string>(882611879U),
      \u003CModule\u003E.smethod_7<string>(1865842641U)
    },
    {
      \u003CModule\u003E.smethod_6<string>(3306408959U),
      \u003CModule\u003E.smethod_9<string>(864684440U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(2458235249U),
      \u003CModule\u003E.smethod_6<string>(3574568314U)
    }
  };
  internal Dictionary<Struct16, Struct16> dictionary_4 = new Dictionary<Struct16, Struct16>()
  {
    {
      new Struct16(30, 50),
      new Struct16(31, 52)
    },
    {
      new Struct16(31, 50),
      new Struct16(31, 52)
    },
    {
      new Struct16(32, 50),
      new Struct16(31, 52)
    },
    {
      new Struct16(33, 50),
      new Struct16(31, 52)
    },
    {
      new Struct16(33, 51),
      new Struct16(31, 52)
    },
    {
      new Struct16(33, 52),
      new Struct16(31, 52)
    },
    {
      new Struct16(33, 53),
      new Struct16(31, 53)
    },
    {
      new Struct16(33, 54),
      new Struct16(31, 53)
    },
    {
      new Struct16(33, 55),
      new Struct16(31, 53)
    },
    {
      new Struct16(32, 55),
      new Struct16(31, 53)
    },
    {
      new Struct16(31, 55),
      new Struct16(31, 53)
    },
    {
      new Struct16(30, 55),
      new Struct16(31, 53)
    },
    {
      new Struct16(29, 55),
      new Struct16(31, 53)
    },
    {
      new Struct16(29, 54),
      new Struct16(31, 53)
    }
  };
  internal List<Struct16> list_34 = new List<Struct16>()
  {
    new Struct16(33, 18),
    new Struct16(32, 18),
    new Struct16(31, 18),
    new Struct16(30, 18),
    new Struct16(29, 18),
    new Struct16(28, 18),
    new Struct16(27, 18),
    new Struct16(33, 17),
    new Struct16(32, 17),
    new Struct16(31, 17),
    new Struct16(30, 17),
    new Struct16(29, 17),
    new Struct16(28, 17),
    new Struct16(27, 17)
  };
  internal bool bool_36;
  internal bool bool_37;
  internal bool bool_38;
  internal short short_1;
  internal Struct16 struct16_4;
  internal short short_2;
  internal Dictionary<short, Struct16> dictionary_5 = new Dictionary<short, Struct16>()
  {
    {
      (short) 167,
      new Struct16(6, 6)
    },
    {
      (short) 135,
      new Struct16(6, 6)
    },
    {
      (short) 6718,
      new Struct16(8, 6)
    },
    {
      (short) 6520,
      new Struct16(6, 6)
    },
    {
      (short) 148,
      new Struct16(6, 6)
    },
    {
      (short) 3052,
      new Struct16(45, 22)
    },
    {
      (short) 422,
      new Struct16(6, 6)
    },
    {
      (short) 1966,
      new Struct16(6, 6)
    },
    {
      (short) 432,
      new Struct16(6, 6)
    },
    {
      (short) 950,
      new Struct16(6, 6)
    },
    {
      (short) 10006,
      new Struct16(6, 6)
    },
    {
      (short) 10061,
      new Struct16(6, 6)
    },
    {
      (short) 3950,
      new Struct16(12, 13)
    },
    {
      (short) 3212,
      new Struct16(3, 9)
    }
  };

  internal List<Class177> method_3()
  {
    lock (Class26.object_0)
      return new List<Class177>((IEnumerable<Class177>) this.list_3);
  }

  internal List<Class145> method_4()
  {
    lock (Class26.object_0)
      return new List<Class145>((IEnumerable<Class145>) this.list_4);
  }

  internal Class26(Class29 class142_4)
    : base(class142_4)
  {
    this.hashSet_0 = new HashSet<ushort>();
    this.list_3 = new List<Class177>();
    this.hashSet_1 = new HashSet<string>((IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase);
    this.list_4 = new List<Class145>();
    this.list_5 = new List<Class142>();
    this.list_6 = new List<Class143>();
    this.list_7 = new List<Class143>();
    this.list_8 = new List<Class142>();
    this.list_9 = new List<Class143>();
    this.list_10 = new List<Class143>();
    this.list_11 = new List<Class142>();
    this.list_12 = new List<Class143>();
    this.soundPlayer_0 = new SoundPlayer();
    this.mediaPlayer_0 = new MediaPlayer();
    this.list_14 = new List<string>()
    {
      \u003CModule\u003E.smethod_6<string>(928420737U),
      \u003CModule\u003E.smethod_8<string>(2937470314U),
      \u003CModule\u003E.smethod_5<string>(876605599U),
      \u003CModule\u003E.smethod_8<string>(1096582091U),
      \u003CModule\u003E.smethod_8<string>(2110309252U),
      \u003CModule\u003E.smethod_7<string>(2292154199U),
      \u003CModule\u003E.smethod_6<string>(1886910274U),
      \u003CModule\u003E.smethod_8<string>(376406135U),
      \u003CModule\u003E.smethod_8<string>(2056816699U),
      \u003CModule\u003E.smethod_7<string>(2481860760U),
      \u003CModule\u003E.smethod_8<string>(3844212369U),
      \u003CModule\u003E.smethod_6<string>(2431270053U),
      \u003CModule\u003E.smethod_7<string>(102681807U),
      \u003CModule\u003E.smethod_8<string>(2003324146U),
      \u003CModule\u003E.smethod_6<string>(3673659327U),
      \u003CModule\u003E.smethod_5<string>(1153224248U),
      \u003CModule\u003E.smethod_9<string>(2489507983U),
      \u003CModule\u003E.smethod_6<string>(3389759590U),
      \u003CModule\u003E.smethod_9<string>(940304383U),
      \u003CModule\u003E.smethod_6<string>(694023787U),
      \u003CModule\u003E.smethod_8<string>(3174897620U),
      \u003CModule\u003E.smethod_9<string>(3314578491U),
      \u003CModule\u003E.smethod_7<string>(587824002U),
      \u003CModule\u003E.smethod_8<string>(1440994503U),
      \u003CModule\u003E.smethod_6<string>(2480772840U),
      \u003CModule\u003E.smethod_9<string>(2931989112U),
      \u003CModule\u003E.smethod_6<string>(3178802335U),
      \u003CModule\u003E.smethod_5<string>(3492340440U),
      \u003CModule\u003E.smethod_9<string>(4177341167U),
      \u003CModule\u003E.smethod_9<string>(2373077981U),
      \u003CModule\u003E.smethod_7<string>(1079207108U),
      \u003CModule\u003E.smethod_8<string>(800399540U),
      \u003CModule\u003E.smethod_5<string>(457630184U),
      \u003CModule\u003E.smethod_5<string>(1119895965U),
      \u003CModule\u003E.smethod_8<string>(3361463719U),
      \u003CModule\u003E.smethod_9<string>(1637845098U)
    };
    this.method_2(new Delegate0(this.method_6));
    this.method_2(new Delegate0(this.method_23));
    this.method_2(new Delegate0(this.method_5));
    this.method_2(new Delegate0(this.method_49));
  }

  private void method_5()
  {
    if (this.Class112_0.bool_3)
    {
      Thread.Sleep(250);
    }
    else
    {
      if (this.Class29_0.Control2_0.checkBox_39.Checked && this.Class29_0.Boolean_1)
      {
        this.soundPlayer_0.Stream = (Stream) Class9.UnmanagedMemoryStream_6;
        this.soundPlayer_0.PlaySync();
      }
      else if (this.Class29_0.Control2_0.checkBox_37.Checked && this.method_37())
      {
        this.soundPlayer_0.Stream = (Stream) Class9.UnmanagedMemoryStream_5;
        this.soundPlayer_0.PlaySync();
      }
      else if (this.Class29_0.Control2_0.checkBox_41.Checked && this.method_38())
      {
        this.soundPlayer_0.Stream = (Stream) Class9.UnmanagedMemoryStream_1;
        this.soundPlayer_0.PlaySync();
      }
      else if (this.Class29_0.Control2_0.checkBox_36.Checked && this.bool_14)
      {
        this.soundPlayer_0.Stream = (Stream) Class9.UnmanagedMemoryStream_4;
        this.soundPlayer_0.PlaySync();
        this.bool_14 = false;
      }
      else if (this.Class29_0.Control2_0.checkBox_40.Checked && ((IEnumerable<bool>) this.bool_5).Contains<bool>(true))
      {
        List<bool> boolList = new List<bool>((IEnumerable<bool>) this.bool_5);
        foreach (bool flag in boolList)
        {
          if (flag)
          {
            this.soundPlayer_0.Stream = (Stream) Class9.UnmanagedMemoryStream_2;
            this.soundPlayer_0.PlaySync();
            this.bool_5[boolList.IndexOf(true)] = false;
            break;
          }
        }
      }
      else if (this.Class29_0.Control2_0.checkBox_38.Checked && this.Class29_0.UInt32_7 >= 4290000000U)
      {
        this.soundPlayer_0.Stream = (Stream) Class9.UnmanagedMemoryStream_3;
        this.soundPlayer_0.PlaySync();
      }
      Thread.Sleep(2000);
    }
  }

  private void method_6()
  {
    if (this.Class29_0.Boolean_0)
    {
      Thread.Sleep(1000);
    }
    else
    {
      if (this.label_0 == null)
        this.label_0 = this.Class29_0.Control2_0.label_5;
      this.bool_17 = this.method_37();
      if ((!this.Class29_0.bool_1 || !(this.Class29_0.Control2_0.button_30.Text == \u003CModule\u003E.smethod_9<string>(349368783U))) && (!this.Class29_0.Class26_0.bool_38 || !(this.Class29_0.Control2_0.button_30.Text == \u003CModule\u003E.smethod_6<string>(2389295701U))) && !this.Class29_0.bool_37 && this.Class29_0.Control2_0 != null && this.Class29_0.Class75_0 == null && !this.bool_7)
      {
        this.list_6 = this.Class29_0.method_127();
        this.list_5 = this.Class29_0.method_119(11);
        List<Class143> source = this.Class29_0.method_125();
        this.list_7 = source != null ? source.Where<Class143>((Func<Class143, bool>) (string_0 => DateTime.UtcNow.Subtract(string_0.DateTime_0).TotalMilliseconds > 250.0)).ToList<Class143>() : (List<Class143>) null;
        this.list_12.Clear();
        if (this.Class29_0.UInt32_5 <= 1U && this.Class29_0.Boolean_1)
        {
          this.label_0.Text = this.Class29_0.string_7 + \u003CModule\u003E.smethod_8<string>(2774361309U);
          this.dateTime_16 = this.dateTime_16 == DateTime.MinValue ? DateTime.UtcNow : this.dateTime_16;
          if (this.Class29_0.Control2_0.checkBox_71.Checked && DateTime.UtcNow.Subtract(this.dateTime_16).TotalSeconds > 6.0)
          {
            string fileName = AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_9<string>(4256079001U);
            string path = fileName;
            string[] strArray = new string[6];
            DateTime dateTime = DateTime.UtcNow;
            dateTime = dateTime.ToLocalTime();
            strArray[0] = dateTime.ToString();
            strArray[1] = \u003CModule\u003E.smethod_7<string>(2187524368U);
            strArray[2] = this.Class29_0.class88_0.String_0;
            strArray[3] = \u003CModule\u003E.smethod_8<string>(26731031U);
            strArray[4] = this.Class29_0.Struct16_1.ToString();
            strArray[5] = \u003CModule\u003E.smethod_9<string>(2359899596U);
            string contents = string.Concat(strArray);
            File.WriteAllText(path, contents);
            Process.Start(fileName);
            this.Class29_0.method_6(false);
          }
        }
        if (DateTime.UtcNow.Subtract(this.Class29_0.DateTime_0).TotalSeconds > 20.0 && DateTime.UtcNow.Subtract(this.dateTime_10).TotalSeconds > 20.0 && DateTime.UtcNow.Subtract(this.dateTime_17).TotalSeconds > 30.0)
        {
          this.Class29_0.method_105(false);
          this.dateTime_17 = DateTime.UtcNow;
        }
        else
        {
          if (this.Class29_0.method_24(\u003CModule\u003E.smethod_9<string>(3030279851U)) && !this.Class29_0.Class136_0[\u003CModule\u003E.smethod_6<string>(3317073425U)].Boolean_0)
            this.dateTime_7 = DateTime.UtcNow;
          if (this.list_7 != null && this.Class29_0.Control2_0.checkBox_42.Checked && this.list_7.Any<Class143>((Func<Class143, bool>) (string_1 => string_1.Boolean_10)))
          {
            this.list_7.RemoveAll((Predicate<Class143>) (class17_0 => class17_0.Boolean_10));
            foreach (Class143 class143 in this.Class29_0.method_125().Where<Class143>((Func<Class143, bool>) (class143_0 => this.Class29_0.Control2_0.bindingList_2.Concat<string>((IEnumerable<string>) this.Class112_0.form5_0.bindingList_0).Contains<string>(class143_0.String_5, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase) && class143_0.Boolean_10)))
              this.list_12.Add(class143);
            List<Class143> list12 = this.list_12;
            this.list_12 = list12 != null ? list12.OrderBy<Class143, int>((Func<Class143, int>) (class143_0 => this.Class29_0.Struct16_1.method_0(class143_0.Struct16_0))).ToList<Class143>() : (List<Class143>) null;
          }
          this.dateTime_16 = DateTime.MinValue;
          if (this.method_38())
          {
            List<Class143> class143List = new List<Class143>();
            foreach (Class143 class143_1 in this.list_7)
            {
              foreach (Class143 class143_2 in this.list_7)
              {
                if (class143_1 != class143_2 && (Struct16.smethod_0(class143_1.Struct16_0, class143_2.Struct16_0) || class143_2.bool_1) && !class143List.Contains(class143_1))
                  class143List.Add(class143_1);
              }
              foreach (Class142 class142 in this.list_5)
              {
                if (class142 != null && Struct16.smethod_0(class143_1.Struct16_0, class142.Struct16_0) && !class143List.Contains(class143_1))
                  class143List.Add(class143_1);
              }
            }
            foreach (Class143 class143 in class143List)
              this.list_7.Remove(class143);
          }
          this.method_35();
          this.method_36();
          this.bool_2 = this.Class29_0.Control2_0.checkBox_73.Checked;
          this.bool_0 = this.Class29_0.method_25((ushort) 26) || this.Class29_0.method_24(\u003CModule\u003E.smethod_8<string>(2568700728U)) && DateTime.UtcNow.Subtract(this.Class29_0.Class136_0[\u003CModule\u003E.smethod_6<string>(2118940144U)].DateTime_0).TotalSeconds < 1.5;
          this.bool_1 = this.Class29_0.method_25((ushort) 143);
          DateTime utcNow = DateTime.UtcNow;
          if (utcNow.Subtract(this.dateTime_9).TotalSeconds < 2.5)
            return;
          if (this.Class29_0.Control2_0.checkBox_76.Checked && this.Class29_0.method_7(Enum10.Suain))
          {
            if (!this.Class29_0.method_31(\u003CModule\u003E.smethod_5<string>(2136378097U), (Class142) null, false, false) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(3589190982U), (Class142) this.Class29_0.Class143_0, false, true))
              return;
            this.Class29_0.method_9(Enum10.Suain);
          }
          else
          {
            if (this.Class29_0.Control2_0.checkBox_86.Checked && this.Class29_0.UInt32_7 > 4250000000U)
            {
              utcNow = DateTime.UtcNow;
              if (utcNow.Subtract(this.dateTime_5).TotalMinutes > 5.0)
                this.Class29_0.method_133(this.Class29_0.Control2_0.comboBox_10.Text == \u003CModule\u003E.smethod_9<string>(608017474U) ? (byte) 1 : (byte) 2);
            }
            this.list_7 = this.method_38() ? this.list_7.Where<Class143>((Func<Class143, bool>) (class10_0 => DateTime.UtcNow.Subtract(class10_0.DateTime_0).TotalSeconds > 2.0)).ToList<Class143>() : this.list_7;
            int result;
            if (this.Class29_0.Control2_0.checkBox_54.Checked && int.TryParse(this.Class29_0.Control2_0.textBox_16.Text.Trim(), out result) && (long) this.Class29_0.UInt32_6 < (long) result)
              this.bool_4 = true;
            try
            {
              if (this.method_8())
                this.method_9();
            }
            catch
            {
            }
            byte? byte2 = this.Class29_0?.class134_1?.Byte_2;
            int? nullable = byte2.HasValue ? new int?((int) byte2.GetValueOrDefault()) : new int?();
            if (!(nullable.GetValueOrDefault() <= 0 & nullable.HasValue))
              return;
            Thread.Sleep(330);
          }
        }
      }
      else
        Thread.Sleep(100);
    }
  }

  private bool method_7()
  {
    if (!this.Class29_0.Control2_0.checkBox_55.Checked)
      return false;
    string class143_1 = "";
    if (this.Class29_0.method_24(\u003CModule\u003E.smethod_6<string>(3327481574U)))
      class143_1 = \u003CModule\u003E.smethod_8<string>(1579746334U);
    else if (this.Class29_0.method_24(\u003CModule\u003E.smethod_7<string>(4201701631U)))
      class143_1 = \u003CModule\u003E.smethod_9<string>(3843543747U);
    if (!this.Class29_0.method_7(Enum10.Hide) || DateTime.UtcNow.Subtract(this.dateTime_1).TotalSeconds > 50.0)
    {
      this.Class29_0.method_30(\u003CModule\u003E.smethod_7<string>(4065317624U));
      this.Class29_0.method_31(class143_1, (Class142) null, true, true);
      this.dateTime_1 = DateTime.UtcNow;
    }
    return true;
  }

  private bool method_8()
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class26.Class148 class148 = new Class26.Class148();
    // ISSUE: reference to a compiler-generated field
    class148.class26_0 = this;
    if (this.bool_4)
    {
      uint uint326 = this.Class29_0.UInt32_6;
      DateTime utcNow = DateTime.UtcNow;
      while (this.bool_4)
      {
        int result;
        if (this.Class29_0.Control2_0.checkBox_54.Checked && int.TryParse(this.Class29_0.Control2_0.textBox_16.Text.Trim(), out result) && (long) this.Class29_0.UInt32_6 <= (long) result)
          this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(673812530U), (Class142) null, this.bool_2, false);
        if (this.Class29_0.UInt32_6 >= this.Class29_0.UInt32_2 / 2U || this.Class29_0.UInt32_6 - uint326 >= this.Class29_0.UInt32_2 / 20U || DateTime.UtcNow.Subtract(utcNow).TotalSeconds > 20.0)
          this.bool_4 = false;
        Thread.Sleep(10);
      }
    }
    if (this.method_7())
    {
      this.bool_8 = true;
      return false;
    }
    if (this.Class29_0.Control2_0.checkBox_66.Checked && this.Class29_0.Control2_0.checkBox_65.Checked)
    {
      if (this.Class29_0.method_31(\u003CModule\u003E.smethod_6<string>(2103541518U), (Class142) null, true, true))
        return false;
    }
    else if (this.Class29_0.Control2_0.checkBox_66.Checked && this.Class29_0.bool_34)
    {
      if (this.Class29_0.Control2_0.comboBox_4.Text == \u003CModule\u003E.smethod_8<string>(2926494890U))
      {
        if (this.method_34())
          return false;
      }
      else if (this.Class29_0.Control2_0.checkBox_68.Checked && this.Class29_0.bool_35 && this.method_34())
        return false;
    }
    for (int index = 20; index <= 100 && !this.bool_0; index += 20)
    {
      foreach (Class143 class143_1 in this.Class29_0.method_125())
      {
        // ISSUE: object of a compiler-generated type is created
        // ISSUE: variable of a compiler-generated type
        Class26.Class149 class149 = new Class26.Class149();
        // ISSUE: reference to a compiler-generated field
        class149.class148_0 = class148;
        // ISSUE: reference to a compiler-generated field
        class149.class143_0 = class143_1;
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (this.method_44(class149.class143_0.String_5) || class149.class143_0 == this.Class29_0.Class143_0)
        {
          // ISSUE: object of a compiler-generated type is created
          // ISSUE: variable of a compiler-generated type
          Class26.Class150 class150_1 = new Class26.Class150();
          // ISSUE: reference to a compiler-generated field
          class150_1.class149_0 = class149;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated method
          Control3 control30 = this.method_4().FirstOrDefault<Class145>(new Func<Class145, bool>(class150_1.class149_0.method_0))?.Control3_0;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          Class29 class29 = this.Class112_0.method_75(class150_1.class149_0.class143_0.String_5);
          // ISSUE: variable of a compiler-generated type
          Class26.Class150 class150_2 = class150_1;
          Class143 class143_2;
          if (class29 == null)
          {
            class143_2 = (Class143) null;
          }
          else
          {
            class143_2 = class29.Class143_0;
            if (class143_2 != null)
              goto label_27;
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          class143_2 = class150_1.class149_0.class143_0;
label_27:
          // ISSUE: reference to a compiler-generated field
          class150_2.class143_0 = class143_2;
          if ((control30 != null || class29 == this.Class29_0) && (class29 != this.Class29_0 || this.Class29_0.Control2_0.checkBox_82.Checked) && (class29 == this.Class29_0 || control30.checkBox_4.Checked))
          {
            // ISSUE: reference to a compiler-generated field
            string str = class150_1.class143_0 == this.Class29_0.Class143_0 ? this.Class29_0.Control2_0.comboBox_5.Text : control30.comboBox_2.Text;
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated method
            if (index == 20 && class150_1.class143_0 != this.Class29_0.Class143_0 && (this.Class29_0.method_24(\u003CModule\u003E.smethod_8<string>(70338813U)) || this.Class29_0.method_24(\u003CModule\u003E.smethod_9<string>(3477153775U))) && this.Class29_0.method_127().Count<Class143>(class150_1.class149_0.class148_0.func_0 ?? (class150_1.class149_0.class148_0.func_0 = new Func<Class143, bool>(class150_1.class149_0.class148_0.method_0))) > 2)
              str = this.Class29_0.method_24(\u003CModule\u003E.smethod_5<string>(2910054405U)) ? \u003CModule\u003E.smethod_9<string>(2104271927U) : \u003CModule\u003E.smethod_8<string>(3885188805U);
            // ISSUE: reference to a compiler-generated method
            // ISSUE: reference to a compiler-generated field
            if (!this.Class29_0.method_125().Any<Class143>(new Func<Class143, bool>(class150_1.method_0)) || class150_1.class143_0 == this.Class29_0.Class143_0 || str.Contains(\u003CModule\u003E.smethod_7<string>(2696164551U)))
            {
              // ISSUE: reference to a compiler-generated field
              int num1 = (int) (class150_1.class143_0 == this.Class29_0.Class143_0 ? this.Class29_0.Control2_0.numericUpDown_21.Value : control30.numericUpDown_0.Value);
              int num2 = num1 > index ? index : num1;
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              if ((class29 != null && class29.Int32_2 < num2 || class150_1.class143_0 != class29?.Class143_0 && (int) class150_1.class143_0.Byte_1 < num2 || class150_1.class143_0.Boolean_8) && (!this.bool_17 || (class29 == null ? (class150_1.class143_0.Byte_1 > (byte) 50 ? 1 : 0) : (class29.Int32_2 > 50 ? 1 : 0)) == 0 || class150_1.class143_0.Boolean_8))
              {
                uint num3 = (uint) this.Class29_0.method_132(str);
                List<Class143> class143List = new List<Class143>();
                if (!(str == \u003CModule\u003E.smethod_8<string>(70338813U)) && !(str == \u003CModule\u003E.smethod_5<string>(1392699277U)))
                {
                  // ISSUE: reference to a compiler-generated field
                  if (this.Class29_0.method_31(str, (Class142) class150_1.class143_0, this.bool_2, false))
                  {
                    // ISSUE: reference to a compiler-generated field
                    class143List.Add(class150_1.class143_0);
                  }
                }
                else if (this.Class29_0.method_31(str, (Class142) null, this.bool_2, false))
                  class143List.AddRange((IEnumerable<Class143>) this.Class29_0.method_127());
                foreach (Class143 class143_3 in class143List)
                {
                  // ISSUE: reference to a compiler-generated field
                  if (class29?.Class143_0 == class150_1.class143_0)
                  {
                    class29.UInt32_5 += class29.UInt32_5 + num3 < class29.UInt32_1 ? num3 : class29.UInt32_1 - class29.UInt32_5;
                    class143_3.Byte_1 = (byte) class29.Int32_2;
                    class29.Class143_0.Boolean_8 = false;
                  }
                  else
                    class143_3.Byte_1 += (byte) ((int) class143_3.Byte_1 + 20 < 100 ? 20 : (int) (byte) (100 - (int) class143_3.Byte_1));
                  class143_3.Boolean_8 = false;
                }
                return false;
              }
            }
          }
        }
      }
    }
    if (!this.Class29_0.Control2_0.checkBox_74.Checked || !this.Class29_0.method_7(Enum10.Poison) || !this.Class29_0.Class143_0.Boolean_7)
    {
      TimeSpan timeSpan1;
      if (this.Class29_0.Control2_0.checkBox_44.Checked && this.Class29_0.bool_42)
      {
        timeSpan1 = DateTime.UtcNow.Subtract(this.dateTime_8);
        if (timeSpan1.TotalSeconds > 1.0 && (this.Class29_0.method_7(Enum10.Poison) && this.Class29_0.Class143_0.Boolean_7 || this.Class29_0.method_127().Any<Class143>((Func<Class143, bool>) (string_1 => string_1.Boolean_7))))
          goto label_53;
      }
      if (this.Class29_0.Control2_0.checkBox_75.Checked && this.Class29_0.Class143_0.Boolean_1)
      {
        string string1 = this.Class29_0.Class143_0.String_1;
        if (!(string1 == \u003CModule\u003E.smethod_5<string>(186239832U)) && !(string1 == \u003CModule\u003E.smethod_9<string>(291223151U)) && !(string1 == \u003CModule\u003E.smethod_9<string>(3547106019U)))
        {
          if (string1 == \u003CModule\u003E.smethod_7<string>(3452694771U) && this.Class29_0.method_22(\u003CModule\u003E.smethod_7<string>(3928017582U)) && this.Class29_0.bool_42)
          {
            timeSpan1 = DateTime.UtcNow.Subtract(this.dateTime_0);
            if (timeSpan1.TotalSeconds > 12.0 && this.method_47(\u003CModule\u003E.smethod_9<string>(2598191692U)))
            {
              this.Class29_0.Class143_0.Double_0 = 0.0;
              this.Class29_0.Class143_0.String_1 = "";
              return false;
            }
          }
        }
        else if (this.Class29_0.method_31(\u003CModule\u003E.smethod_8<string>(2720868756U) + this.Class29_0.Class143_0.String_1, (Class142) this.Class29_0.Class143_0, this.bool_2, true))
        {
          this.Class29_0.Class143_0.Double_0 = 0.0;
          this.Class29_0.Class143_0.String_1 = "";
          return false;
        }
      }
      foreach (Class145 object_1 in this.method_4())
      {
        Class143 class143;
        Class29 class29;
        if (this.method_45(object_1, ref class143, ref class29) && object_1.Control3_0.checkBox_8.Checked && (class29 != null && class29.method_7(Enum10.Suain) || class143 != class29?.Class143_0 && class143.Boolean_4))
        {
          this.Class29_0.method_31(\u003CModule\u003E.smethod_6<string>(548395140U), (Class142) class143, this.bool_2, true);
          return false;
        }
      }
      foreach (Class145 object_1 in this.method_4())
      {
        TimeSpan timeSpan2;
        if (!object_1.Control3_0.checkBox_7.Checked)
        {
          if (this.Class29_0.Control2_0.checkBox_44.Checked && this.Class29_0.bool_42 && this.Class29_0.HashSet_3.Contains<string>(object_1.String_0, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase))
          {
            timeSpan2 = DateTime.UtcNow.Subtract(this.dateTime_8);
            if (timeSpan2.TotalSeconds <= 1.0)
              continue;
          }
          else
            continue;
        }
        Class143 class143;
        Class29 class29;
        if (this.method_45(object_1, ref class143, ref class29) && (class29 != null && class29.method_7(Enum10.Poison) || class143 != class29?.Class143_0 && class143.Boolean_7))
        {
          if (this.Class29_0.Control2_0.checkBox_44.Checked && this.Class29_0.bool_42 && this.Class29_0.HashSet_3.Contains<string>(object_1.String_0, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase))
          {
            timeSpan2 = DateTime.UtcNow.Subtract(this.dateTime_8);
            if (timeSpan2.TotalSeconds > 1.0)
            {
              for (int index = 0; index < 6; ++index)
                this.Class29_0.method_29(\u003CModule\u003E.smethod_7<string>(2448176974U));
              this.dateTime_8 = DateTime.UtcNow;
              goto label_89;
            }
          }
          if (object_1.Control3_0.checkBox_7.Checked)
            this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(1372392542U), (Class142) class143, this.bool_2, true);
          else
            continue;
label_89:
          return false;
        }
      }
      foreach (Class145 object_1 in this.method_4())
      {
        Class143 class143;
        Class29 class29;
        if (object_1.Control3_0.checkBox_6.Checked && this.method_45(object_1, ref class143, ref class29) && class143.Boolean_1)
        {
          string string1 = class143.String_1;
          if ((string1 == \u003CModule\u003E.smethod_9<string>(2223016130U) || string1 == \u003CModule\u003E.smethod_7<string>(1375192363U) || string1 == \u003CModule\u003E.smethod_5<string>(2237311697U)) && this.Class29_0.method_31(\u003CModule\u003E.smethod_7<string>(2313905784U) + class143.String_1, (Class142) class143, this.bool_2, true))
          {
            class143.Double_0 = 0.0;
            class143.String_1 = "";
            return false;
          }
        }
      }
      if (this.Class29_0.Control2_0.checkBox_83.Checked && !this.Class29_0.method_7(Enum10.Dion))
      {
        string text = this.Class29_0.Control2_0.comboBox_6.Text;
        if (!(text == \u003CModule\u003E.smethod_9<string>(4005883424U)))
        {
          if (!(text == \u003CModule\u003E.smethod_9<string>(2074090445U)))
          {
            if (!(text == \u003CModule\u003E.smethod_6<string>(4280895195U)))
            {
              if (!(text == \u003CModule\u003E.smethod_7<string>(3011788574U)))
              {
                if (text == \u003CModule\u003E.smethod_8<string>(745141274U) && this.list_5.Any<Class142>((Func<Class142, bool>) (class142_0 => class142_0.UInt16_0 == (ushort) 87)))
                  goto label_112;
              }
              else if ((Decimal) (this.Class29_0.UInt32_5 * 100U / this.Class29_0.UInt32_1) >= this.Class29_0.Control2_0.numericUpDown_22.Value)
                goto label_112;
            }
            else if (this.Class29_0.UInt32_5 >= this.Class29_0.UInt32_1)
              goto label_112;
          }
          else if (this.list_5.Count <= 0)
            goto label_112;
        }
        if (this.Class29_0.Control2_0.comboBox_7.Text != \u003CModule\u003E.smethod_8<string>(2132000633U))
          this.Class29_0.method_31(this.Class29_0.Control2_0.comboBox_7.Text, (Class142) null, this.bool_2, false);
        else if (this.Class29_0.bool_42)
          this.method_47(\u003CModule\u003E.smethod_9<string>(1642709107U));
        return false;
      }
label_112:
      if (this.Class29_0.Control2_0.checkBox_80.Checked && this.bool_3 && !this.Class29_0.method_7(Enum10.Dion))
      {
        if (this.Class29_0.Control2_0.comboBox_7.Text != \u003CModule\u003E.smethod_9<string>(1642709107U))
          this.Class29_0.method_31(this.Class29_0.Control2_0.comboBox_7.Text, (Class142) null, this.bool_2, false);
        else if (this.Class29_0.bool_42)
          this.method_47(\u003CModule\u003E.smethod_8<string>(2132000633U));
        return false;
      }
      if (this.Class29_0.method_7(Enum10.Dion))
        this.bool_3 = false;
      if (this.Class29_0.Control2_0.checkBox_85.Checked && !this.Class29_0.method_7(Enum10.NaomhAite) && (!this.Class29_0.Class143_0.Boolean_3 || this.Class29_0.Class143_0.Double_2 != 2.0))
      {
        this.Class29_0.method_31(this.Class29_0.Control2_0.comboBox_9.Text, (Class142) this.Class29_0.Class143_0, this.bool_2, false);
        return false;
      }
      if (this.Class29_0.Control2_0.checkBox_84.Checked && !this.Class29_0.method_7(Enum10.FasNadur) && (!this.Class29_0.Class143_0.Boolean_2 || this.Class29_0.Class143_0.Double_1 != 2.0))
      {
        this.Class29_0.method_31(this.Class29_0.Control2_0.comboBox_8.Text, (Class142) this.Class29_0.Class143_0, this.bool_2, false);
        return false;
      }
      if (this.Class29_0.Control2_0.checkBox_50.Checked && this.Class29_0.bool_42 && !this.Class29_0.method_7(Enum10.Armachd))
      {
        this.method_47(\u003CModule\u003E.smethod_8<string>(1593128084U));
        return false;
      }
      if (this.Class29_0.Control2_0.checkBox_57.Checked && !this.Class29_0.method_7(Enum10.Armachd))
      {
        this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(3674635812U), (Class142) this.Class29_0.Class143_0, this.bool_2, false);
        return false;
      }
      foreach (Class145 object_1 in this.method_4())
      {
        Class143 class143;
        Class29 class29;
        if (object_1.Control3_0.checkBox_0.Checked && this.method_45(object_1, ref class143, ref class29) && (class29 != null && !class29.method_7(Enum10.NaomhAite) || class143 != class29?.Class143_0 && !class143.Boolean_3) && (!class143.Boolean_3 || class143.Double_2 != 2.0))
        {
          this.Class29_0.method_31(object_1.Control3_0.comboBox_0.Text, (Class142) class143, this.bool_2, false);
          return false;
        }
      }
      foreach (Class145 object_1 in this.method_4())
      {
        Class143 class143;
        Class29 class29;
        if (object_1.Control3_0.checkBox_3.Checked && this.method_45(object_1, ref class143, ref class29) && (class29 != null && !class29.method_7(Enum10.FasNadur) || class143 != class29?.Class143_0 && !class143.Boolean_2) && (!class143.Boolean_2 || class143.Double_1 != 2.0))
        {
          this.Class29_0.method_31(object_1.Control3_0.comboBox_1.Text, (Class142) class143, this.bool_2, false);
          return false;
        }
      }
      foreach (Class145 object_1 in this.method_4())
      {
        Class143 class143;
        Class29 class29;
        if ((object_1.Control3_0.checkBox_1.Checked || this.Class29_0.Control2_0.checkBox_50.Checked && this.Class29_0.bool_42 && this.Class29_0.HashSet_3.Contains<string>(object_1.String_0, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase) && this.Class112_0.method_75(object_1.String_0) != null) && this.method_45(object_1, ref class143, ref class29) && (class29 != null && !class29.method_7(Enum10.Armachd) || class143 != class29?.Class143_0 && !class143.Boolean_9))
        {
          if (this.Class29_0.Control2_0.checkBox_50.Checked && this.Class29_0.bool_42 && this.Class29_0.HashSet_3.Contains<string>(class143.String_5, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase) && class29 != null)
            this.method_47(\u003CModule\u003E.smethod_8<string>(1593128084U));
          else if (object_1.Control3_0.checkBox_1.Checked)
            this.Class29_0.method_31(\u003CModule\u003E.smethod_8<string>(1981598318U), (Class142) class143, this.bool_2, false);
          return false;
        }
      }
      // ISSUE: reference to a compiler-generated method
      if (this.Class29_0.Control2_0.checkBox_47.Checked && this.Class29_0.bool_42 && this.list_6.Any<Class143>(new Func<Class143, bool>(class148.method_1)))
      {
        if (this.Class29_0.method_29(\u003CModule\u003E.smethod_5<string>(2712466751U)))
        {
          foreach (Class143 class143 in this.list_6)
            this.Class112_0.method_75(class143.String_5)?.method_9(Enum10.Pramh);
        }
        return false;
      }
      if (this.Class29_0.Control2_0.checkBox_59.Checked && !this.Class29_0.Class143_0.Boolean_1)
      {
        this.Class29_0.method_31(\u003CModule\u003E.smethod_8<string>(3768993988U), (Class142) this.Class29_0.Class143_0, this.bool_2, false);
        return false;
      }
      foreach (Class145 object_1 in this.method_4())
      {
        Class143 class143;
        Class29 class29;
        if (object_1.Control3_0.checkBox_2.Checked && this.method_45(object_1, ref class143, ref class29) && !class143.Boolean_1)
        {
          this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(163693358U), (Class142) class143, this.bool_2, false);
          return false;
        }
      }
      TimeSpan timeSpan3;
      if (this.list_12.Count > 0)
      {
        if (this.Class29_0.Control2_0.checkBox_42.Checked)
        {
          if (!this.Class29_0.Class21_0.method_0(\u003CModule\u003E.smethod_7<string>(3728858051U)) && !this.Class29_0.Class21_0.method_0(\u003CModule\u003E.smethod_8<string>(213297130U)))
          {
            if (this.Class29_0.Class21_0.method_0(\u003CModule\u003E.smethod_9<string>(1097780051U)) && this.Class29_0.bool_42)
            {
              timeSpan3 = DateTime.UtcNow.Subtract(this.dateTime_6);
              if (timeSpan3.TotalMinutes <= 2.0)
                goto label_187;
            }
            else
              goto label_187;
          }
          this.class143_0 = this.list_12[0];
          this.bool_6 = true;
          Struct16 struct16 = this.class143_0.Struct16_0;
          Direction int_11 = struct16.method_4(this.Class29_0.Struct16_1);
          struct16 = this.Class29_0.Struct16_1;
          if (struct16.method_0(this.class143_0.Struct16_0) > 1)
          {
            struct16 = this.Class29_0.Struct16_0;
            if (struct16.method_0(this.class143_0.Struct16_0) == 1)
              this.Class29_0.method_105(true);
            this.Class29_0.method_50(this.class143_0.Struct16_0, (short) 1, true, true);
          }
          else if (int_11 != this.Class29_0.Direction_1)
          {
            this.Class29_0.method_48(int_11);
          }
          else
          {
            if (this.Class29_0.method_22(\u003CModule\u003E.smethod_6<string>(493474681U)) && this.Class29_0.bool_42)
            {
              timeSpan3 = DateTime.UtcNow.Subtract(this.dateTime_6);
              if (timeSpan3.TotalMinutes > 2.0)
              {
                if (this.Class29_0.method_29(\u003CModule\u003E.smethod_6<string>(493474681U)))
                {
                  this.dateTime_6 = DateTime.UtcNow;
                  this.class143_0.Dictionary_0[(ushort) 24] = DateTime.UtcNow.Subtract(new TimeSpan(0, 0, 2));
                  goto label_184;
                }
                else
                  goto label_184;
              }
            }
            if (this.Class29_0.method_29(\u003CModule\u003E.smethod_6<string>(1308531773U)) || this.Class29_0.method_29(\u003CModule\u003E.smethod_7<string>(699793986U)))
              this.class143_0.Dictionary_0[(ushort) 24] = DateTime.UtcNow.Subtract(new TimeSpan(0, 0, 2));
          }
label_184:
          this.Class29_0.method_30(\u003CModule\u003E.smethod_7<string>(1001470531U));
          Thread.Sleep(1000);
          return false;
        }
      }
      else if (this.class143_0 == null || !this.Class29_0.method_125().Contains(this.class143_0) || this.class143_0.Byte_1 > (byte) 30 || DateTime.UtcNow.Subtract(this.class143_0.Dictionary_0[(ushort) 24]).TotalSeconds > 5.0)
      {
        this.class143_0 = (Class143) null;
        this.bool_6 = false;
      }
label_187:
      if (!this.method_22())
        return false;
      if (this.control3_0 != null)
      {
        if (this.control3_0.radioButton_0.Checked)
        {
          using (IEnumerator<Class143> enumerator = this.list_6.Where<Class143>((Func<Class143, bool>) (class142_0 => !class142_0.Boolean_0)).GetEnumerator())
          {
            if (enumerator.MoveNext())
            {
              Class143 current = enumerator.Current;
              this.Class29_0.method_31(\u003CModule\u003E.smethod_6<string>(326687980U), (Class142) null, this.bool_2, false);
              return false;
            }
          }
        }
        else if (this.control3_0.radioButton_1.Checked)
        {
          if (this.Class29_0.method_31(\u003CModule\u003E.smethod_7<string>(2605946152U), (Class142) null, this.bool_2, false))
            return false;
        }
        else if (this.control3_0.radioButton_2.Checked)
        {
          if (!this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(2104271927U), (Class142) null, this.bool_2, false) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(3477153775U), (Class142) null, this.bool_2, false))
            this.Class29_0.method_31(\u003CModule\u003E.smethod_8<string>(1030573421U), (Class142) null, this.bool_2, false);
          return false;
        }
      }
      // ISSUE: reference to a compiler-generated field
      if (int.TryParse(this.Class29_0.Control2_0.textBox_15.Text, out class148.int_0) && this.Class29_0.Control2_0.checkBox_45.Checked && this.Class29_0.method_24(\u003CModule\u003E.smethod_9<string>(3030279851U)) && this.Class29_0.Class136_0[\u003CModule\u003E.smethod_7<string>(28523703U)].Boolean_0)
      {
        int num;
        if (!(this.Class29_0.Control2_0.comboBox_3.Text == \u003CModule\u003E.smethod_6<string>(1358632633U)))
        {
          // ISSUE: reference to a compiler-generated method
          num = this.Class112_0.IEnumerable_0.Any<Class29>(new Func<Class29, bool>(class148.method_2)) ? 1 : 0;
        }
        else
        {
          timeSpan3 = DateTime.UtcNow.Subtract(this.dateTime_7);
          // ISSUE: reference to a compiler-generated field
          num = timeSpan3.TotalMilliseconds > (double) class148.int_0 ? 1 : 0;
        }
        if (num != 0)
          this.Class29_0.method_31(\u003CModule\u003E.smethod_6<string>(3317073425U), (Class142) null, this.bool_2, true);
      }
      foreach (Class145 object_1 in this.method_4())
      {
        Class143 class143;
        Class29 class29;
        int result;
        if (object_1.Control3_0.checkBox_9.Checked && this.method_45(object_1, ref class143, ref class29) && int.TryParse(object_1.Control3_0.textBox_0.Text, out result))
        {
          if (class29 != null)
          {
            if ((long) class29.UInt32_6 < (long) result)
            {
              this.Class29_0.method_31(\u003CModule\u003E.smethod_8<string>(2653544413U), (Class142) class143, this.bool_2, true);
              class29.Class26_0.bool_4 = false;
              return false;
            }
          }
          else
          {
            if (class143.Dictionary_0.ContainsKey((ushort) 84))
            {
              timeSpan3 = DateTime.UtcNow.Subtract(class143.Dictionary_0[(ushort) 84]);
              if (timeSpan3.TotalMilliseconds <= (double) result)
                continue;
            }
            this.Class29_0.method_31(\u003CModule\u003E.smethod_7<string>(3256747299U), (Class142) class143, this.bool_2, true);
            return false;
          }
        }
      }
      return true;
    }
label_53:
    if (this.Class29_0.Control2_0.checkBox_44.Checked && this.Class29_0.bool_42)
    {
      for (int index = 0; index < 6; ++index)
        this.Class29_0.method_29(\u003CModule\u003E.smethod_5<string>(661394886U));
      this.dateTime_8 = DateTime.UtcNow;
    }
    else if (this.Class29_0.Control2_0.checkBox_74.Checked)
      this.Class29_0.method_31(\u003CModule\u003E.smethod_6<string>(2204914172U), (Class142) this.Class29_0.Class143_0, this.bool_2, true);
    return false;
  }

  private bool method_9()
  {
    this.list_5 = this.Class29_0.method_119(11);
    if (this.list_5.Count > 0)
      this.list_5 = this.list_5.OrderBy<Class142, int>((Func<Class142, int>) (string_1 => Class138.smethod_1())).ToList<Class142>();
    if (this.method_38() && this.list_5.Count > 0)
      this.list_5.RemoveAll((Predicate<Class142>) (string_1 => DateTime.UtcNow.Subtract(string_1.DateTime_0).TotalSeconds < 2.0));
    if (this.method_38())
    {
      List<Class142> class142List = new List<Class142>();
      foreach (Class142 class142_1 in this.list_5)
      {
        foreach (Class142 class142_2 in this.list_5)
        {
          if (class142_1 != class142_2 && Struct16.smethod_0(class142_1.Struct16_0, class142_2.Struct16_0) && !class142List.Contains(class142_1))
            class142List.Add(class142_1);
        }
      }
      foreach (Class142 class142 in class142List)
        this.list_5.Remove(class142);
    }
    if (this.control4_0 != null)
    {
      if (this.control4_0.checkBox_2.Checked)
        this.list_5.RemoveAll((Predicate<Class142>) (class143_0 => this.control4_0.listBox_0.Items.Contains((object) class143_0.UInt16_0.ToString())));
      if (this.control4_0.checkBox_8.Checked)
      {
        List<Class142> class142List1 = new List<Class142>();
        List<Class142> class142List2 = new List<Class142>();
        foreach (Class142 class142 in this.list_5)
        {
          if (this.control4_0.listBox_1.Items.Contains((object) class142.UInt16_0.ToString()))
            class142List1.Add(class142);
          else if (!this.control4_0.checkBox_9.Checked)
            class142List2.Add(class142);
        }
        if (this.control4_0.radioButton_3.Checked)
        {
          this.class142_0 = (Class142) null;
          if (class142List1.Count > 0 && this.method_10(this.control4_0, class142List1))
          {
            this.bool_8 = true;
            return true;
          }
          if (class142List2.Count > 0 && this.method_10(this.control4_0, class142List2))
          {
            this.bool_8 = true;
            return true;
          }
        }
        else
        {
          if (class142List1.Count > 0 && this.method_15(this.control4_0, class142List1))
          {
            this.bool_8 = true;
            return true;
          }
          if (!class142List1.Contains(this.class142_0) && class142List2.Count > 0 && this.method_15(this.control4_0, class142List2))
          {
            this.bool_8 = true;
            return true;
          }
        }
      }
      else if (this.control4_0.radioButton_3.Checked)
      {
        this.class142_0 = (Class142) null;
        if (this.list_5.Count > 0 && this.method_10(this.control4_0, this.list_5))
        {
          this.bool_8 = true;
          return true;
        }
      }
      else if (this.list_5.Count > 0 && this.method_15(this.control4_0, this.list_5))
      {
        this.bool_8 = true;
        return true;
      }
    }
    else
    {
      List<Class142> class142List = new List<Class142>();
      foreach (Class177 class177 in this.method_3())
      {
        class142List.Clear();
        Class29 class290 = this.Class29_0;
        ushort[] numArray = new ushort[1]
        {
          class177.UInt16_0
        };
        foreach (Class142 class142 in class290.method_118(11, numArray))
        {
          ushort uint160 = class142.UInt16_0;
          string str1 = uint160.ToString();
          uint160 = class177.UInt16_0;
          string str2 = uint160.ToString();
          if (str1 == str2)
            class142List.Add(class142);
        }
        if (class142List.Count > 0)
        {
          if (class177.Control4_0.radioButton_3.Checked)
          {
            this.class142_0 = (Class142) null;
            if (this.method_10(class177.Control4_0, class142List))
            {
              this.bool_8 = true;
              return true;
            }
          }
          else if (this.method_15(class177.Control4_0, class142List))
          {
            this.bool_8 = true;
            return true;
          }
        }
      }
    }
    if (this.Class29_0.list_7.Count > 0 && !this.Class29_0.list_7[0].Class134_0.String_0.Contains(\u003CModule\u003E.smethod_5<string>(147198710U)))
      return false;
    if (this.control4_0 != null)
    {
      if (this.control4_0.checkBox_8.Checked)
      {
        List<Class142> class142List3 = new List<Class142>();
        List<Class142> class142List4 = new List<Class142>();
        foreach (Class142 class142 in this.list_5)
        {
          if (this.control4_0.listBox_1.Items.Contains((object) class142.UInt16_0.ToString()))
            class142List3.Add(class142);
          else if (!this.control4_0.checkBox_9.Checked)
            class142List4.Add(class142);
        }
        if (this.method_17(this.control4_0, class142List3) || this.method_17(this.control4_0, class142List4))
          return true;
      }
      else if (this.method_17(this.control4_0, this.list_5))
        return true;
    }
    else
    {
      List<Class142> class142List = new List<Class142>();
      foreach (Class177 class177 in this.method_3())
      {
        class142List.Clear();
        Class29 class290 = this.Class29_0;
        ushort[] numArray = new ushort[1]
        {
          class177.UInt16_0
        };
        foreach (Class142 class142 in class290.method_118(11, numArray))
        {
          ushort uint160 = class142.UInt16_0;
          string str3 = uint160.ToString();
          uint160 = class177.UInt16_0;
          string str4 = uint160.ToString();
          if (str3 == str4)
            class142List.Add(class142);
        }
        if (this.method_17(class177.Control4_0, class142List))
          return true;
      }
    }
    this.bool_8 = false;
    return false;
  }

  private bool method_10(Control4 class142_4, [In] List<Class142> obj1)
  {
    if (class142_4.radioButton_2.Checked)
    {
      if (this.method_11(class142_4, obj1) || this.method_12(class142_4, obj1))
        return true;
    }
    else if (class142_4.radioButton_4.Checked && (this.method_12(class142_4, obj1) || this.method_11(class142_4, obj1)))
      return true;
    return false;
  }

  private bool method_11(Control4 class29_1, [In] List<Class142> obj1)
  {
    List<Class142> source = this.method_21(class29_1, obj1);
    if (this.Class29_0.Class112_0.list_5.Contains(class29_1.class177_0.UInt16_0))
    {
      List<Class142> class142List = this.Class29_0.method_118(8, this.Class29_0.Class112_0.list_5.ToArray());
      foreach (Class142 class142 in class142List.ToList<Class142>())
      {
        foreach (Struct16 struct16 in this.Class29_0.method_121(new Struct16(0, 0)))
        {
          if (class142.Struct16_0.method_0(struct16) <= 3)
            class142List.Remove(class142);
        }
      }
      source.AddRange((IEnumerable<Class142>) class142List);
    }
    Class142 class142_1 = source.FirstOrDefault<Class142>();
    if (class142_1 == null || !source.Any<Class142>() || !class29_1.checkBox_10.Checked || class142_1.Boolean_6)
      return false;
    this.Class29_0.method_31(class29_1.comboBox_2.Text, source.FirstOrDefault<Class142>(), this.bool_2, false);
    return true;
  }

  private bool method_12(Control4 class143_1, [In] List<Class142> obj1)
  {
    List<Class142> list = obj1.Where<Class142>((Func<Class142, bool>) (string_1 => !string_1.Boolean_2 || !string_1.Boolean_1)).ToList<Class142>();
    if (list != null && list.Any<Class142>() && (class143_1.checkBox_12.Checked || class143_1.checkBox_11.Checked))
    {
      if (class143_1.radioButton_1.Checked)
      {
        if (this.method_13(class143_1, list))
        {
          this.bool_8 = true;
          return true;
        }
        if (this.method_14(class143_1, list))
        {
          this.bool_8 = true;
          return true;
        }
      }
      else if (class143_1.radioButton_0.Checked)
      {
        if (this.method_14(class143_1, list))
        {
          this.bool_8 = true;
          return true;
        }
        if (this.method_13(class143_1, list))
        {
          this.bool_8 = true;
          return true;
        }
      }
    }
    return false;
  }

  private bool method_13(Control4 class142_4, [In] List<Class142> obj1)
  {
    IEnumerable<Class142> source = obj1.Where<Class142>((Func<Class142, bool>) (class142_0 => !class142_0.Boolean_2));
    Class142 class142 = !class142_4.checkBox_7.Checked ? source.FirstOrDefault<Class142>() : source.OrderBy<Class142, int>((Func<Class142, int>) (class143_0 => class143_0.Struct16_0.method_0(this.Class29_0.Struct16_1))).FirstOrDefault<Class142>();
    if (class142 == null || !class142_4.checkBox_12.Checked)
      return false;
    this.bool_8 = true;
    this.Class29_0.method_31(class142_4.comboBox_4.Text, class142, this.bool_2, false);
    return true;
  }

  private bool method_14(Control4 struct16_5, [In] List<Class142> obj1)
  {
    IEnumerable<Class142> source = obj1.Where<Class142>((Func<Class142, bool>) (class142_0 => !class142_0.Boolean_1));
    Class142 class142 = !struct16_5.checkBox_7.Checked ? source.FirstOrDefault<Class142>() : source.OrderBy<Class142, int>((Func<Class142, int>) (class142_0 => class142_0.Struct16_0.method_0(this.Class29_0.Struct16_1))).FirstOrDefault<Class142>();
    if (class142 == null || !struct16_5.checkBox_11.Checked)
      return false;
    this.bool_8 = true;
    this.Class29_0.method_31(struct16_5.comboBox_3.Text, class142, this.bool_2, false);
    return true;
  }

  private bool method_15(Control4 class142_4, [In] List<Class142> obj1)
  {
    if (obj1.Count == 0)
      return false;
    if (!obj1.Contains(this.class142_0))
      this.class142_0 = obj1.OrderBy<Class142, int>((Func<Class142, int>) (class143_0 => class143_0.Struct16_0.method_0(this.Class29_0.Struct16_0))).FirstOrDefault<Class142>();
    if (this.class142_0 == null)
      return false;
    if (class142_4.radioButton_2.Checked && (class142_4.checkBox_10.Checked ? (!this.class142_0.Boolean_6 ? 1 : 0) : 0) != 0)
    {
      this.Class29_0.method_31(class142_4.comboBox_2.Text, this.class142_0, this.bool_2, false);
      return true;
    }
    if (class142_4.radioButton_4.Checked && ((class142_4.checkBox_12.Checked ? (!this.class142_0.Boolean_2 ? 1 : 0) : 0) != 0 || (class142_4.checkBox_11.Checked ? (!this.class142_0.Boolean_1 ? 1 : 0) : 0) != 0))
    {
      if (this.method_16(class142_4, this.class142_0))
        return true;
    }
    else if (class142_4.radioButton_2.Checked && (class142_4.checkBox_10.Checked ? (this.class142_0.Boolean_6 ? 1 : 0) : 1) != 0 && ((class142_4.checkBox_12.Checked ? (!this.class142_0.Boolean_2 ? 1 : 0) : 0) != 0 || (class142_4.checkBox_11.Checked ? (!this.class142_0.Boolean_1 ? 1 : 0) : 0) != 0))
    {
      if (this.method_16(class142_4, this.class142_0))
        return true;
    }
    else if (class142_4.radioButton_4.Checked && (class142_4.checkBox_12.Checked ? (this.class142_0.Boolean_2 ? 1 : 0) : 1) != 0 && (class142_4.checkBox_11.Checked ? (this.class142_0.Boolean_1 ? 1 : 0) : 1) != 0 && (class142_4.checkBox_10.Checked ? (!this.class142_0.Boolean_6 ? 1 : 0) : 0) != 0)
    {
      this.Class29_0.method_31(class142_4.comboBox_2.Text, this.class142_0, this.bool_2, false);
      return true;
    }
    return false;
  }

  private bool method_16(Control4 string_1, [In] Class142 obj1)
  {
    if (string_1.radioButton_1.Checked && (string_1.checkBox_12.Checked ? (!obj1.Boolean_2 ? 1 : 0) : 0) != 0)
    {
      this.bool_8 = true;
      this.Class29_0.method_31(string_1.comboBox_4.Text, obj1, this.bool_2, false);
      return true;
    }
    if (string_1.radioButton_0.Checked && (string_1.checkBox_11.Checked ? (!obj1.Boolean_1 ? 1 : 0) : 0) != 0)
    {
      this.bool_8 = true;
      this.Class29_0.method_31(string_1.comboBox_3.Text, obj1, this.bool_2, false);
      return true;
    }
    if ((!string_1.radioButton_1.Checked || !string_1.checkBox_12.Checked ? 1 : (obj1.Boolean_2 ? 1 : 0)) != 0 && (string_1.checkBox_11.Checked ? (!obj1.Boolean_1 ? 1 : 0) : 0) != 0)
    {
      this.bool_8 = true;
      this.Class29_0.method_31(string_1.comboBox_3.Text, obj1, this.bool_2, false);
      return true;
    }
    if ((!string_1.radioButton_0.Checked || !string_1.checkBox_11.Checked ? 1 : (obj1.Boolean_1 ? 1 : 0)) == 0 || (string_1.checkBox_12.Checked ? (!obj1.Boolean_2 ? 1 : 0) : 0) == 0)
      return false;
    this.bool_8 = true;
    this.Class29_0.method_31(string_1.comboBox_4.Text, obj1, this.bool_2, false);
    return true;
  }

  private bool method_17(Control4 string_1, [In] List<Class142> obj1)
  {
    bool flag = false;
    if (!string_1.checkBox_13.Checked || obj1.Count == 0)
      return false;
    if (string_1.radioButton_5.Checked)
    {
      if (obj1.Count == 0)
        return false;
      if (!obj1.Contains(this.class142_0))
        this.class142_0 = obj1.OrderBy<Class142, int>((Func<Class142, int>) (class142_0 => class142_0.Struct16_0.method_0(this.Class29_0.Struct16_0))).FirstOrDefault<Class142>();
      if (this.class142_0 == null)
        return false;
      obj1 = new List<Class142>() { this.class142_0 };
    }
    if (this.control4_0 != null && this.control4_0.checkBox_3.Checked && (string_1.checkBox_0.Checked || string_1.checkBox_1.Checked ? (this.list_5.All<Class142>((Func<Class142, bool>) (class142_0 => class142_0.bool_0)) ? 1 : 0) : (this.list_5.Any<Class142>((Func<Class142, bool>) (class142_0 => class142_0.Boolean_0)) ? 1 : 0)) != 0)
    {
      Class142 class142 = this.list_5.OrderBy<Class142, int>((Func<Class142, int>) (class142_0 => class142_0.Struct16_0.method_0(this.Class29_0.Struct16_0))).FirstOrDefault<Class142>((Func<Class142, bool>) (class142_0 => class142_0.bool_0));
      if (class142 != null && (this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(3716013954U), class142, this.bool_2, false) || this.Class29_0.method_31(\u003CModule\u003E.smethod_8<string>(1947200247U), class142, this.bool_2, false) || this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(186225416U), class142, this.bool_2, false)))
        return true;
    }
    if (!this.bool_1)
    {
      if (string_1.checkBox_1.Checked)
      {
        Class142 class142 = this.method_18(string_1, obj1, string_1.comboBox_1.Text);
        if (class142 != null)
        {
          string text = string_1.comboBox_1.Text;
          // ISSUE: reference to a compiler-generated method
          switch (Class181.smethod_0(text))
          {
            case 1007116742:
              if (text == \u003CModule\u003E.smethod_6<string>(2694353492U) && this.Class29_0.method_31(\u003CModule\u003E.smethod_5<string>(1100375404U), class142, this.bool_2, false))
              {
                flag = true;
                break;
              }
              break;
            case 1285349432:
              if (text == \u003CModule\u003E.smethod_8<string>(353364634U) && this.Class29_0.method_31(\u003CModule\u003E.smethod_5<string>(1536004794U), class142, this.bool_2, false) && this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(4222447152U), class142, this.bool_2, false))
              {
                flag = true;
                break;
              }
              break;
            case 1792178996:
              if (text == \u003CModule\u003E.smethod_8<string>(113305982U) && this.Class29_0.method_31(\u003CModule\u003E.smethod_5<string>(2924810878U), class142, this.bool_2, true))
              {
                flag = true;
                break;
              }
              break;
            case 2591503996:
              if (text == \u003CModule\u003E.smethod_5<string>(1164649926U))
              {
                if (string_1.checkBox_5.Checked && this.Class29_0.Int32_3 < 80)
                {
                  this.bool_12 = true;
                  this.Class29_0.method_31(\u003CModule\u003E.smethod_7<string>(1620883916U), (Class142) null, this.bool_2, false);
                  return true;
                }
                this.Class29_0.method_31(\u003CModule\u003E.smethod_5<string>(3589479036U), (Class142) this.Class29_0.Class143_0, this.bool_2, true);
                return true;
              }
              break;
            case 3122026787:
              if (text == \u003CModule\u003E.smethod_8<string>(292878123U) && this.Class29_0.method_31(\u003CModule\u003E.smethod_8<string>(292878123U), class142, this.bool_2, false))
              {
                flag = true;
                break;
              }
              break;
            case 3210331623:
              if (text == \u003CModule\u003E.smethod_8<string>(106312024U) && this.method_46(\u003CModule\u003E.smethod_5<string>(4006536616U), class142, this.bool_2, false))
              {
                flag = true;
                break;
              }
              break;
            case 3848328981:
              if (text == \u003CModule\u003E.smethod_7<string>(3900025086U))
              {
                if (!this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(1862958809U), (Class142) this.Class29_0.Class143_0, this.bool_2, false))
                {
                  if (this.Class29_0.method_31(\u003CModule\u003E.smethod_8<string>(1041773865U), (Class142) this.Class29_0.Class143_0, this.bool_2, false))
                  {
                    flag = true;
                    break;
                  }
                  break;
                }
                flag = true;
                break;
              }
              break;
          }
        }
      }
      if (string_1.checkBox_0.Checked)
      {
        Class142 class142 = this.method_18(string_1, obj1, string_1.comboBox_0.Text);
        if (class142 != null)
        {
          string text = string_1.comboBox_0.Text;
          if (!(text == \u003CModule\u003E.smethod_6<string>(1899941820U)))
          {
            if (!(text == \u003CModule\u003E.smethod_5<string>(2997664825U)))
            {
              if (!(text == \u003CModule\u003E.smethod_7<string>(1082052753U)))
              {
                if (this.Class29_0.method_31(string_1.comboBox_0.Text, class142, this.bool_2, false) || this.method_46(string_1.comboBox_0.Text, class142, this.bool_2, false))
                  flag = true;
              }
              else
              {
                if (!this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(3423262200U), (Class142) null, this.bool_2, false) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_7<string>(1732304279U), (Class142) null, this.bool_2, false) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(1618999014U), (Class142) null, this.bool_2, false) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_8<string>(1948515920U), (Class142) null, this.bool_2, false))
                  this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(4188440958U), (Class142) null, this.bool_2, false);
                flag = true;
              }
            }
            else if (this.Class29_0.method_31(\u003CModule\u003E.smethod_8<string>(2589110883U), class142, this.bool_2, false) || this.Class29_0.method_31(\u003CModule\u003E.smethod_7<string>(1430627734U), class142, this.bool_2, false))
              flag = true;
          }
          else if (this.Class29_0.method_31(\u003CModule\u003E.smethod_6<string>(209574944U), class142, this.bool_2, false) || this.Class29_0.method_31(\u003CModule\u003E.smethod_5<string>(1955464751U), class142, this.bool_2, false) || this.Class29_0.method_31(\u003CModule\u003E.smethod_5<string>(4070811138U), class142, this.bool_2, false))
            flag = true;
        }
      }
    }
    if (this.bool_1 && string_1.checkBox_4.Checked)
    {
      Class142 class142 = this.method_18(string_1, obj1, \u003CModule\u003E.smethod_6<string>(1899941820U));
      return this.Class29_0.method_31(\u003CModule\u003E.smethod_8<string>(3441044712U), class142, this.bool_2, false) || this.Class29_0.method_31(\u003CModule\u003E.smethod_5<string>(1955464751U), class142, this.bool_2, false) || this.Class29_0.method_31(\u003CModule\u003E.smethod_5<string>(4070811138U), class142, this.bool_2, false);
    }
    if (!this.bool_1 || !string_1.checkBox_6.Checked || this.method_18(string_1, obj1, \u003CModule\u003E.smethod_8<string>(2373824998U)) == null)
      return flag;
    if (string_1.checkBox_5.Checked && this.Class29_0.Int32_3 < 80)
    {
      this.bool_12 = true;
      this.Class29_0.method_31(\u003CModule\u003E.smethod_5<string>(3220950088U), (Class142) null, this.bool_2, false);
      return true;
    }
    this.Class29_0.method_31(\u003CModule\u003E.smethod_7<string>(2444048880U), (Class142) this.Class29_0.Class143_0, this.bool_2, true);
    return true;
  }

  private Class142 method_18(Control4 class142_4, [In] List<Class142> obj1, [In] string obj2)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class26.Class152 class152 = new Class26.Class152();
    // ISSUE: reference to a compiler-generated field
    class152.control4_0 = class142_4;
    // ISSUE: reference to a compiler-generated field
    class152.class26_0 = this;
    List<Class142> source1 = new List<Class142>();
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    bool flag1 = class152.control4_0.checkBox_1.Checked && class152.control4_0.checkBox_13.Checked && (class152.control4_0.comboBox_1.Text == \u003CModule\u003E.smethod_9<string>(3794751788U) || class152.control4_0.comboBox_1.Text == \u003CModule\u003E.smethod_9<string>(1048988092U));
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    if (class152.control4_0.checkBox_14.Checked && class152.control4_0.checkBox_15.Checked)
    {
      foreach (Class142 class142 in obj1)
      {
        if (class142.Boolean_1 && class142.Boolean_2)
          source1.Add(class142);
        else if (flag1 && class142.Struct16_0.method_0(this.Class29_0.Struct16_1) <= this.method_19())
        {
          source1.Clear();
          break;
        }
      }
    }
    else
    {
      // ISSUE: reference to a compiler-generated field
      if (class152.control4_0.checkBox_14.Checked)
      {
        foreach (Class142 class142 in obj1)
        {
          if (class142.Boolean_1)
            source1.Add(class142);
          else if (flag1 && class142.Struct16_0.method_0(this.Class29_0.Struct16_1) <= this.method_19())
          {
            source1.Clear();
            break;
          }
        }
      }
      else
      {
        // ISSUE: reference to a compiler-generated field
        if (class152.control4_0.checkBox_15.Checked)
        {
          foreach (Class142 class142 in obj1)
          {
            if (class142.Boolean_2)
              source1.Add(class142);
            else if (flag1 && class142.Struct16_0.method_0(this.Class29_0.Struct16_1) <= this.method_19())
            {
              source1.Clear();
              break;
            }
          }
        }
        else
        {
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          if (!class152.control4_0.checkBox_14.Checked && !class152.control4_0.checkBox_15.Checked)
            source1 = obj1;
        }
      }
    }
    if (source1.Count == 0)
      return (Class142) null;
    if (!(obj2 == \u003CModule\u003E.smethod_7<string>(2420184478U)))
    {
      if (!(obj2 == \u003CModule\u003E.smethod_7<string>(3324664492U)))
      {
        if (!(obj2 == \u003CModule\u003E.smethod_9<string>(356879469U)) && !(obj2 == \u003CModule\u003E.smethod_7<string>(3486928178U)) && !(obj2 == \u003CModule\u003E.smethod_5<string>(2924810878U)))
        {
          if (obj2 != \u003CModule\u003E.smethod_9<string>(2991880862U))
            source1 = source1.Where<Class142>((Func<Class142, bool>) (class143_0 => !class143_0.Boolean_0)).ToList<Class142>();
          // ISSUE: reference to a compiler-generated field
          if (class152.control4_0.numericUpDown_0.Value > 0M)
          {
            // ISSUE: reference to a compiler-generated method
            source1 = source1.Where<Class142>(new Func<Class142, bool>(class152.method_0)).ToList<Class142>();
          }
        }
      }
      else
        source1 = source1.Where<Class142>((Func<Class142, bool>) (class142_0 => !class142_0.Boolean_7)).ToList<Class142>();
    }
    else
      source1 = source1.Where<Class142>((Func<Class142, bool>) (class142_0 => !class142_0.Boolean_5)).ToList<Class142>();
    if (source1.Count == 0)
      return (Class142) null;
    if (this.class142_0 != null && source1.Contains(this.class142_0))
      return this.class142_0;
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    if (!(class152.control4_0.comboBox_5.Text == \u003CModule\u003E.smethod_7<string>(1394464717U)) && (!this.bool_1 || !class152.control4_0.checkBox_4.Checked))
    {
      // ISSUE: reference to a compiler-generated field
      if (!class152.control4_0.comboBox_5.Text.Contains(\u003CModule\u003E.smethod_5<string>(3402832518U)) || flag1)
        return (Class142) null;
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      int num1 = class152.control4_0.comboBox_5.Text == \u003CModule\u003E.smethod_7<string>(3262438589U) ? 3 : (class152.control4_0.comboBox_5.Text == \u003CModule\u003E.smethod_9<string>(2511707565U) ? 2 : 1);
      Dictionary<Class142, int> source2 = new Dictionary<Class142, int>();
      List<Class142> list1 = this.Class29_0.method_117(12).Concat<Class142>((IEnumerable<Class142>) this.list_7).ToList<Class142>();
      List<Class142> source3 = this.Class29_0.method_119(12);
      // ISSUE: reference to a compiler-generated method
      List<Class142> list2 = source3.Where<Class142>(new Func<Class142, bool>(class152.method_2)).ToList<Class142>();
      if (!list1.Contains((Class142) this.Class29_0.Class143_0))
        list1.Add((Class142) this.Class29_0.Class143_0);
      foreach (Class142 key in list1)
      {
        int num2 = 0;
        foreach (Class142 class142 in source1)
        {
          if (key.Struct16_0.method_0(class142.Struct16_0) <= num1 || (num1 > 1 ? (this.method_20(key.Struct16_0, class142.Struct16_0, num1) ? 1 : 0) : 0) != 0)
            ++num2;
        }
        bool flag2 = false;
        foreach (Class142 class142 in list2)
        {
          if (key != class142)
          {
            foreach (Struct16 struct16 in this.Class29_0.method_57(class142))
            {
              if (key.Struct16_0.method_0(struct16) <= num1 || this.method_20(key.Struct16_0, struct16, num1))
              {
                flag2 = true;
                break;
              }
            }
          }
          else
          {
            flag2 = true;
            break;
          }
        }
        if (!flag2)
          source2.Add(key, num2);
      }
      foreach (Class142 key in source2.Keys.ToList<Class142>())
      {
        if ((key.Byte_0 == (byte) 4 || key.Byte_0 == (byte) 1 && !source3.Contains(key) || key.Boolean_0) && source2[key] <= 1)
          source2.Remove(key);
      }
      return source2.Count <= 0 ? (Class142) null : source2.OrderByDescending<KeyValuePair<Class142, int>, int>((Func<KeyValuePair<Class142, int>, int>) (class143_0 => class143_0.Value)).ThenBy<KeyValuePair<Class142, int>, DateTime>((Func<KeyValuePair<Class142, int>, DateTime>) (class142_0 => class142_0.Key.DateTime_0)).First<KeyValuePair<Class142, int>>().Key;
    }
    // ISSUE: reference to a compiler-generated method
    return source1.Count <= 0 ? (Class142) null : source1.OrderBy<Class142, int>(new Func<Class142, int>(class152.method_1)).FirstOrDefault<Class142>();
  }

  private int method_19()
  {
    try
    {
      List<Class143> class143List = this.Class29_0.method_125();
      List<Class29> source = new List<Class29>();
      foreach (Class143 class143 in class143List)
      {
        if (class143 != null)
        {
          Class29 class29 = this.Class112_0.method_75(class143.String_5);
          if (class29 != null)
            source.Add(class29);
        }
      }
      return 11 - source.OrderByDescending<Class29, int>((Func<Class29, int>) (class142_0 => class142_0.Struct16_1.method_0(this.Class29_0.Struct16_1))).First<Class29>().Struct16_1.method_0(this.Class29_0.Struct16_1);
    }
    catch
    {
      return 11;
    }
  }

  private bool method_20(Struct16 class143_1, [In] Struct16 obj1, [In] int obj2)
  {
    --obj2;
    return Struct16.smethod_0(obj1, new Struct16((short) ((int) class143_1.short_0 - obj2), (short) ((int) class143_1.short_1 + obj2))) || Struct16.smethod_0(obj1, new Struct16((short) ((int) class143_1.short_0 + obj2), (short) ((int) class143_1.short_1 + obj2))) || Struct16.smethod_0(obj1, new Struct16((short) ((int) class143_1.short_0 - obj2), (short) ((int) class143_1.short_1 - obj2))) || Struct16.smethod_0(obj1, new Struct16((short) ((int) class143_1.short_0 + obj2), (short) ((int) class143_1.short_1 - obj2)));
  }

  private List<Class142> method_21(Control4 class142_4, [In] List<Class142> obj1)
  {
    List<Class142> class142List = new List<Class142>();
    foreach (Class142 class142 in obj1)
    {
      if (class142_4.comboBox_2.Text != \u003CModule\u003E.smethod_9<string>(2520160679U))
      {
        if (!class142.Boolean_6)
          class142List.Add(class142);
      }
      else if (class142_4.comboBox_2.Text == \u003CModule\u003E.smethod_7<string>(3284739795U) && !class142.Boolean_4)
        class142List.Add(class142);
    }
    return class142List;
  }

  private bool method_22()
  {
    if (this.Class29_0.Control2_0.checkBox_81.Checked && !this.Class29_0.method_7(Enum10.DeireasFaileas))
    {
      this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(2879511179U), (Class142) null, this.bool_2, true);
      return false;
    }
    if (this.Class29_0.Control2_0.checkBox_51.Checked && this.Class29_0.bool_42 && !this.Class29_0.method_7(Enum10.DragonsFire))
      this.method_47(\u003CModule\u003E.smethod_8<string>(3140465102U));
    if (this.Class29_0.Control2_0.checkBox_60.Checked && !this.Class29_0.method_25((ushort) 183) && !this.Class29_0.method_25((ushort) 184) && !this.Class29_0.method_25((ushort) 185) && !this.bool_26)
    {
      if (!this.Class29_0.method_31(\u003CModule\u003E.smethod_8<string>(1654964715U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_5<string>(3936549255U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_8<string>(161120250U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_5<string>(200532096U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(3089464780U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(853820256U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_6<string>(4053941241U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_8<string>(3335375279U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_5<string>(605699789U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_5<string>(1994505873U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_8<string>(642591U), (Class142) null, this.bool_2, true))
        this.Class29_0.method_31(\u003CModule\u003E.smethod_7<string>(2827040475U), (Class142) null, this.bool_2, true);
      Thread.Sleep(1000);
    }
    if (this.Class29_0.Control2_0.checkBox_56.Checked && !this.Class29_0.method_7(Enum10.AsgallFaileas))
      this.Class29_0.method_31(\u003CModule\u003E.smethod_8<string>(2834847820U), (Class142) null, true, true);
    if (this.Class29_0.Control2_0.checkBox_63.Checked && !this.Class29_0.method_7(Enum10.PerfectDefense))
      this.Class29_0.method_30(\u003CModule\u003E.smethod_6<string>(186562444U));
    if (this.Class29_0.Control2_0.checkBox_64.Checked && !this.Class29_0.method_7(Enum10.Armachd))
      this.Class29_0.method_31(\u003CModule\u003E.smethod_5<string>(2502020126U), (Class142) null, false, true);
    if (this.Class29_0.Control2_0.checkBox_76.Checked && this.Class29_0.method_7(Enum10.BeagSuain))
      this.Class29_0.method_30(\u003CModule\u003E.smethod_6<string>(1719952695U));
    if (this.Class29_0.Control2_0.checkBox_48.Checked && this.Class29_0.bool_42 && !this.Class29_0.method_7(Enum10.FasDeireas))
      this.method_47(\u003CModule\u003E.smethod_7<string>(1268913669U));
    if (this.Class29_0.Control2_0.checkBox_49.Checked && this.Class29_0.bool_42 && !this.Class29_0.method_7(Enum10.Beannaich))
      this.method_47(\u003CModule\u003E.smethod_5<string>(3917028694U));
    if (this.Class29_0.Control2_0.checkBox_58.Checked && DateTime.UtcNow.Subtract(this.dateTime_2).TotalMinutes > 6.0)
    {
      this.Class29_0.method_31(\u003CModule\u003E.smethod_5<string>(3016216302U), (Class142) null, this.bool_2, true);
      Thread.Sleep(1000);
      return false;
    }
    if (this.Class29_0.Control2_0.checkBox_46.Checked && this.Class29_0.bool_42 && DateTime.UtcNow.Subtract(this.dateTime_3).TotalSeconds > 2.0 && this.method_47(\u003CModule\u003E.smethod_9<string>(1008413640U)))
      this.dateTime_3 = DateTime.UtcNow;
    if (this.Class29_0.Control2_0.checkBox_62.Checked && !this.Class29_0.method_7(Enum10.Mist))
      this.Class29_0.method_31(\u003CModule\u003E.smethod_6<string>(2825010708U), (Class142) null, this.bool_2, true);
    if (this.Class29_0.Control2_0.checkBox_53.Checked)
      this.Class29_0.method_31(\u003CModule\u003E.smethod_6<string>(1986343043U), (Class142) null, false, false);
    if (this.Class29_0.Control2_0.checkBox_52.Checked && this.Class29_0.bool_42)
    {
      foreach (Class143 class143 in this.list_6)
      {
        if (!class143.bool_1)
          this.method_47(\u003CModule\u003E.smethod_7<string>(386734861U));
      }
    }
    if (this.Class29_0.Control2_0.checkBox_87.Checked && !this.Class29_0.method_25((ushort) 8) && this.Class29_0.bool_42)
    {
      string class142_4 = "";
      string text = this.Class29_0.Control2_0.comboBox_11.Text;
      if (!(text == \u003CModule\u003E.smethod_7<string>(915563433U)))
      {
        if (!(text == \u003CModule\u003E.smethod_9<string>(1500726025U)))
        {
          if (!(text == \u003CModule\u003E.smethod_8<string>(3842446656U)))
          {
            if (!(text == \u003CModule\u003E.smethod_8<string>(908250279U)))
            {
              if (!(text == \u003CModule\u003E.smethod_5<string>(3032406068U)))
              {
                if (text == \u003CModule\u003E.smethod_9<string>(1804577570U))
                  class142_4 = \u003CModule\u003E.smethod_9<string>(2003902594U);
              }
              else
                class142_4 = \u003CModule\u003E.smethod_8<string>(2748272869U);
            }
            else
              class142_4 = \u003CModule\u003E.smethod_6<string>(68595018U);
          }
          else
            class142_4 = \u003CModule\u003E.smethod_7<string>(2736089248U);
        }
        else
          class142_4 = this.Class29_0.method_22(\u003CModule\u003E.smethod_5<string>(3365224689U)) ? \u003CModule\u003E.smethod_9<string>(2131432387U) : \u003CModule\u003E.smethod_5<string>(4027490470U);
      }
      else
        class142_4 = \u003CModule\u003E.smethod_5<string>(626653643U);
      if (!this.method_47(class142_4))
      {
        this.Class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(3327992483U) + class142_4 + \u003CModule\u003E.smethod_8<string>(271602335U));
        this.Class29_0.Control2_0.checkBox_87.Checked = false;
      }
    }
    if (string.IsNullOrEmpty(this.Class112_0.form5_0.class178_0.string_1))
      Process.GetCurrentProcess().Kill();
    if (this.Class29_0.Control2_0.checkBox_61.Checked && (!this.Class29_0.method_25((ushort) 146) || !this.Class29_0.method_25((ushort) 181)))
    {
      if (this.Class29_0.method_24(\u003CModule\u003E.smethod_6<string>(2163025259U)) && !this.Class29_0.method_25((ushort) 181))
      {
        this.Class29_0.method_31(\u003CModule\u003E.smethod_5<string>(1932613395U), (Class142) this.Class29_0.Class143_0, this.bool_2, true);
        return false;
      }
      if (this.Class29_0.Class136_0.Any<Class134>((Func<Class134, bool>) (class141_0 => class141_0.String_0 != \u003CModule\u003E.smethod_9<string>(1484762225U) && class141_0.String_0.Contains(\u003CModule\u003E.smethod_6<string>(3973470324U)))) && !this.Class29_0.method_25((ushort) 146))
      {
        this.method_46(\u003CModule\u003E.smethod_7<string>(4103129504U), (Class142) this.Class29_0.Class143_0, this.bool_2, true);
        return false;
      }
    }
    foreach (Class145 class145 in this.method_4())
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      Class26.Class153 class153 = new Class26.Class153();
      // ISSUE: reference to a compiler-generated field
      class153.class145_0 = class145;
      // ISSUE: reference to a compiler-generated method
      if (this.list_7.Count != 0 && this.list_7.Any<Class143>(new Func<Class143, bool>(class153.method_0)))
      {
        // ISSUE: reference to a compiler-generated method
        Class143 class143 = this.list_7.First<Class143>(new Func<Class143, bool>(class153.method_1));
        // ISSUE: reference to a compiler-generated field
        if (class143 != null && class143 != this.Class29_0.Class143_0 && class153.class145_0.Control3_0.checkBox_5.Checked)
        {
          // ISSUE: reference to a compiler-generated field
          Class29 class29 = this.Class29_0.Class112_0.method_75(class153.class145_0.String_0);
          if (class29 != null)
          {
            if (!class29.method_25((ushort) 181) && this.Class29_0.method_31(\u003CModule\u003E.smethod_8<string>(3314549531U), (Class142) class29.Class143_0, this.bool_2, true) || this.Class29_0.Class136_0.Any<Class134>((Func<Class134, bool>) (keyValuePair_0 => keyValuePair_0.String_0 != \u003CModule\u003E.smethod_5<string>(1932613395U) && keyValuePair_0.String_0.Contains(\u003CModule\u003E.smethod_7<string>(4103129504U)))) && !class29.method_25((ushort) 146) && this.method_46(\u003CModule\u003E.smethod_7<string>(4103129504U), (Class142) class29.Class143_0, this.bool_2, true))
              return false;
          }
          else if ((!class143.Dictionary_0.ContainsKey((ushort) 170) || DateTime.UtcNow.Subtract(class143.Dictionary_0[(ushort) 170]).TotalSeconds > 1.5) && this.Class29_0.method_31(\u003CModule\u003E.smethod_5<string>(1932613395U), (Class142) class143, this.bool_2, true) || this.Class29_0.Class136_0.Any<Class134>((Func<Class134, bool>) (keyValuePair_0 => keyValuePair_0.String_0 != \u003CModule\u003E.smethod_8<string>(3314549531U) && keyValuePair_0.String_0.Contains(\u003CModule\u003E.smethod_5<string>(2816246604U)))) && (!class143.Dictionary_0.ContainsKey((ushort) 187) || DateTime.UtcNow.Subtract(class143.Dictionary_0[(ushort) 187]).TotalSeconds > 1.5) && this.method_46(\u003CModule\u003E.smethod_6<string>(3973470324U), (Class142) class143, this.bool_2, true))
            return false;
        }
      }
    }
    if (!this.Class29_0.Control2_0.checkBox_43.Checked || !this.Class29_0.bool_42 || this.Class29_0.method_25((ushort) 113))
      return true;
    if (!this.Class29_0.method_29(\u003CModule\u003E.smethod_9<string>(1612292018U)) && !this.Class29_0.method_29(\u003CModule\u003E.smethod_8<string>(3848159388U)))
    {
      this.Class29_0.Control2_0.checkBox_43.Checked = false;
      this.Class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_6<string>(3535644554U));
      return false;
    }
    while (this.Class29_0.Class75_0 == null)
      Thread.Sleep(10);
    this.Class29_0.Class75_0.method_1();
    Thread.Sleep(500);
    return false;
  }

  private void method_23()
  {
    this.bool_17 = this.method_37();
    if (!this.Class29_0.bool_37)
    {
      if (this.Class29_0.Control2_0 != null)
      {
        try
        {
          this.list_10 = this.Class29_0.method_125();
          this.list_8 = this.Class29_0.method_119(12);
          if (this.bool_6 || this.Class29_0.Control2_0.checkBox_67.Checked && this.bool_17)
            return;
          if (this.Class29_0.Control2_0.button_45.Text == \u003CModule\u003E.smethod_9<string>(591721198U))
          {
            Struct17 int_11_1 = new Struct17();
            string text = this.Class29_0.Control2_0.comboBox_4.Text;
            // ISSUE: reference to a compiler-generated method
            switch (Class181.smethod_0(text))
            {
              case 42952968:
                if (text == \u003CModule\u003E.smethod_9<string>(2294811361U))
                {
                  int_11_1 = new Struct17((short) 8995, (short) 41, (short) 36);
                  break;
                }
                goto default;
              case 104857644:
                if (text == \u003CModule\u003E.smethod_8<string>(630262130U))
                {
                  int_11_1 = new Struct17((short) 11500, (short) 76, (short) 90);
                  break;
                }
                goto default;
              case 122196308:
                if (text == \u003CModule\u003E.smethod_7<string>(4121852237U))
                {
                  int_11_1 = new Struct17((short) 10240, (short) 15, (short) 15);
                  break;
                }
                goto default;
              case 140575268:
                if (text == \u003CModule\u003E.smethod_5<string>(764225988U))
                {
                  int_11_1 = new Struct17((short) 10055, (short) 0, (short) 0);
                  break;
                }
                goto default;
              case 197647056:
                if (text == \u003CModule\u003E.smethod_9<string>(3285103830U))
                {
                  int_11_1 = new Struct17((short) 8295, (short) 12, (short) 7);
                  break;
                }
                goto default;
              case 270108063:
                if (text == \u003CModule\u003E.smethod_9<string>(186696630U))
                {
                  int_11_1 = new Struct17((short) 8314, (short) 9, (short) 95);
                  break;
                }
                goto default;
              case 390284915:
                if (text == \u003CModule\u003E.smethod_8<string>(1564408298U))
                {
                  Struct17 int_11_2 = new Struct17((short) 6537, (short) 65, (short) 1);
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6525 && this.Class29_0.Struct16_1.method_1((short) 32, (short) 23) > 2)
                  {
                    this.Class29_0.method_51(new Struct17((short) 6525, (short) 32, (short) 23), (short) 0, false, true, true);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6525)
                  {
                    this.Class29_0.method_60((byte) 3, \u003CModule\u003E.smethod_5<string>(2402055610U));
                    Thread.Sleep(500);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6530 && !this.Class29_0.method_51(int_11_2, (short) 0, false, true, true))
                  {
                    this.Class29_0.method_50(new Struct16(10, 0), (short) 0, true, false);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6537 && this.Class29_0.Struct16_0.short_0 < (short) 31 && this.Class29_0.Struct16_0.short_1 < (short) 43)
                  {
                    this.Class29_0.method_50(new Struct16(0, 31), (short) 0, true, false);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6535 && this.Class29_0.Struct16_0.short_0 > (short) 68 && this.Class29_0.Struct16_0.short_1 < (short) 56)
                  {
                    this.Class29_0.method_50(new Struct16(74, 49), (short) 0, true, false);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6537 && this.Class29_0.Struct16_0.short_0 < (short) 43 && this.Class29_0.Struct16_0.short_1 > (short) 43)
                  {
                    this.Class29_0.method_50(new Struct16(14, 74), (short) 0, true, false);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6536 && this.Class29_0.Struct16_0.short_0 < (short) 25 && this.Class29_0.Struct16_0.short_1 < (short) 24)
                  {
                    this.Class29_0.method_50(new Struct16(0, 15), (short) 0, true, false);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6534 && this.Class29_0.Struct16_0.short_0 > (short) 45)
                  {
                    this.Class29_0.method_50(new Struct16(74, 28), (short) 0, true, false);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6536 && (this.Class29_0.Struct16_0.short_0 > (short) 25 || this.Class29_0.Struct16_0.short_1 > (short) 26) && this.Class29_0.Struct16_0.short_0 < (short) 69)
                  {
                    this.Class29_0.method_50(new Struct16(72, 4), (short) 0, true, false);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6536 && this.Class29_0.Struct16_0.short_0 > (short) 68)
                  {
                    this.Class29_0.method_50(new Struct16(69, 0), (short) 0, true, false);
                    return;
                  }
                  if (!this.Class29_0.method_51(int_11_2, (short) 3, false, true, true) && !this.Class29_0.method_51(int_11_2, (short) 3, false, true, true))
                  {
                    if ((int) this.Class29_0.class88_0.Int16_0 == (int) int_11_2.Int16_0 && this.Class29_0.Struct16_1.method_0(int_11_2.Struct16_0) <= 3)
                      this.Class29_0.Control2_0.button_45.Text = \u003CModule\u003E.smethod_5<string>(3787510566U);
                    this.Class29_0.method_54((short) 6525);
                    break;
                  }
                  break;
                }
                goto default;
              case 656194412:
                if (text == \u003CModule\u003E.smethod_5<string>(3368535151U))
                {
                  int_11_1 = new Struct17((short) 3210, (short) 69, (short) 34);
                  break;
                }
                goto default;
              case 705191458:
                if (text == \u003CModule\u003E.smethod_7<string>(2262048886U))
                {
                  int_11_1 = new Struct17((short) 72, (short) 23, (short) 19);
                  break;
                }
                goto default;
              case 1434418274:
                if (text == \u003CModule\u003E.smethod_6<string>(840335946U))
                {
                  Struct17 int_11_3 = new Struct17((short) 6541, (short) 73, (short) 4);
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6525 && this.Class29_0.Struct16_1.method_1((short) 32, (short) 23) > 2)
                  {
                    this.Class29_0.method_51(new Struct17((short) 6525, (short) 32, (short) 23), (short) 0, false, true, true);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6525)
                  {
                    this.Class29_0.method_60((byte) 3, \u003CModule\u003E.smethod_8<string>(2780939674U));
                    Thread.Sleep(500);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6530 && !this.Class29_0.method_51(int_11_3, (short) 0, false, true, true))
                  {
                    this.Class29_0.method_50(new Struct16(10, 0), (short) 0, true, false);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6537)
                  {
                    this.Class29_0.method_50(new Struct16(0, 4), (short) 0, true, false);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6539)
                  {
                    this.Class29_0.method_50(new Struct16(53, 74), (short) 0, true, true);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6538)
                  {
                    this.Class29_0.method_50(new Struct16(74, 16), (short) 0, true, false);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6540 && this.Class29_0.Struct16_0.short_0 < (short) 4)
                  {
                    this.Class29_0.method_50(new Struct16(3, 0), (short) 0, true, false);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6541 && this.Class29_0.Struct16_0.short_0 < (short) 28 && this.Class29_0.Struct16_0.short_1 > (short) 63)
                  {
                    this.Class29_0.method_50(new Struct16(23, 74), (short) 0, true, false);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6540)
                  {
                    this.Class29_0.method_50(new Struct16(35, 0), (short) 0, true, false);
                    return;
                  }
                  if (!this.Class29_0.method_51(int_11_3, (short) 3, false, true, true) && !this.Class29_0.method_51(int_11_3, (short) 3, false, true, true))
                  {
                    if ((int) this.Class29_0.class88_0.Int16_0 == (int) int_11_3.Int16_0 && this.Class29_0.Struct16_1.method_0(int_11_3.Struct16_0) <= 3)
                      this.Class29_0.Control2_0.button_45.Text = \u003CModule\u003E.smethod_6<string>(3085470750U);
                    this.Class29_0.method_54((short) 6525);
                    break;
                  }
                  break;
                }
                goto default;
              case 1570042694:
                if (text == \u003CModule\u003E.smethod_7<string>(122320575U))
                {
                  int_11_1 = new Struct17((short) 8368, (short) 48, (short) 24);
                  break;
                }
                goto default;
              case 1669916139:
                if (text == \u003CModule\u003E.smethod_8<string>(2926494890U))
                {
                  this.method_32(false);
                  return;
                }
                goto default;
              case 1936185911:
                if (text == \u003CModule\u003E.smethod_7<string>(3328792586U))
                {
                  int_11_1 = new Struct17((short) 10101, (short) 15, (short) 10);
                  break;
                }
                goto default;
              case 2122966770:
                if (text == \u003CModule\u003E.smethod_5<string>(2365376199U))
                {
                  int_11_1 = new Struct17((short) 6998, (short) 11, (short) 9);
                  break;
                }
                goto default;
              case 2487385400:
                if (text == \u003CModule\u003E.smethod_9<string>(1285672808U))
                {
                  int_11_1 = new Struct17((short) 8358, (short) 58, (short) 1);
                  break;
                }
                goto default;
              case 2510239379:
                if (text == \u003CModule\u003E.smethod_8<string>(2284584254U))
                {
                  int_11_1 = new Struct17((short) 559, (short) 43, (short) 26);
                  break;
                }
                goto default;
              case 2543647522:
                if (text == \u003CModule\u003E.smethod_5<string>(442853378U))
                {
                  int_11_1 = new Struct17((short) 566, (short) 28, (short) 24);
                  break;
                }
                goto default;
              case 2577202760:
                if (text == \u003CModule\u003E.smethod_5<string>(1831659462U))
                {
                  int_11_1 = new Struct17((short) 568, (short) 28, (short) 38);
                  break;
                }
                goto default;
              case 2628668450:
                if (text == \u003CModule\u003E.smethod_9<string>(970721472U))
                {
                  int_11_1 = new Struct17((short) 573, (short) 22, (short) 26);
                  break;
                }
                goto default;
              case 2728795543:
                if (text == \u003CModule\u003E.smethod_8<string>(2524642906U))
                {
                  int_11_1 = new Struct17((short) 9376, (short) 42, (short) 47);
                  break;
                }
                goto default;
              case 2911405393:
                if (text == \u003CModule\u003E.smethod_6<string>(3525663600U))
                {
                  int_11_1 = new Struct17((short) 8300, (short) 121, (short) 33);
                  break;
                }
                goto default;
              case 3002224923:
                if (text == \u003CModule\u003E.smethod_7<string>(2318033878U))
                {
                  Struct17 int_11_4 = new Struct17((short) 6538, (short) 58, (short) 73);
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6525 && this.Class29_0.Struct16_1.method_1((short) 32, (short) 23) > 2)
                  {
                    this.Class29_0.method_51(new Struct17((short) 6525, (short) 32, (short) 23), (short) 0, false, true, true);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6525)
                  {
                    this.Class29_0.method_60((byte) 3, \u003CModule\u003E.smethod_9<string>(1357232432U));
                    Thread.Sleep(500);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6530 && !this.Class29_0.method_51(int_11_4, (short) 0, false, true, true))
                  {
                    this.Class29_0.method_50(new Struct16(10, 0), (short) 0, true, false);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6537)
                  {
                    this.Class29_0.method_50(new Struct16(0, 4), (short) 0, true, false);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6539 && this.Class29_0.Struct16_0.short_1 < (short) 8)
                  {
                    this.Class29_0.method_50(new Struct16(1, 8), (short) 1, true, false);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6539)
                  {
                    this.Class29_0.method_50(new Struct16(4, 74), (short) 0, true, true);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6538 && this.Class29_0.Struct16_0.short_1 < (short) 50)
                  {
                    this.Class29_0.method_50(new Struct16(74, 47), (short) 0, true, false);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6540)
                  {
                    this.Class29_0.method_50(new Struct16(0, 67), (short) 0, true, false);
                    return;
                  }
                  if (!this.Class29_0.method_51(int_11_4, (short) 3, false, true, true) && !this.Class29_0.method_51(int_11_4, (short) 3, false, true, true))
                  {
                    if ((int) this.Class29_0.class88_0.Int16_0 == (int) int_11_4.Int16_0 && this.Class29_0.Struct16_1.method_0(int_11_4.Struct16_0) <= 3)
                      this.Class29_0.Control2_0.button_45.Text = \u003CModule\u003E.smethod_8<string>(233672838U);
                    this.Class29_0.method_54((short) 6525);
                    break;
                  }
                  break;
                }
                goto default;
              case 3033542801:
                if (text == \u003CModule\u003E.smethod_5<string>(1317463286U))
                {
                  int_11_1 = new Struct17((short) 10180, (short) 20, (short) 20);
                  break;
                }
                goto default;
              case 3045472732:
                if (text == \u003CModule\u003E.smethod_6<string>(994005662U))
                {
                  Struct17 int_11_5 = new Struct17((short) 6534, (short) 1, (short) 36);
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6525 && this.Class29_0.Struct16_1.method_1((short) 32, (short) 23) > 2)
                  {
                    this.Class29_0.method_51(new Struct17((short) 6525, (short) 32, (short) 23), (short) 0, false, true, true);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6525)
                  {
                    this.Class29_0.method_60((byte) 3, \u003CModule\u003E.smethod_6<string>(897196290U));
                    Thread.Sleep(500);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6530 && !this.Class29_0.method_51(int_11_5, (short) 0, false, true, true))
                  {
                    this.Class29_0.method_50(new Struct16(10, 0), (short) 0, true, false);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6537)
                  {
                    this.Class29_0.method_50(new Struct16(0, 4), (short) 0, true, false);
                    return;
                  }
                  if (this.Class29_0.class88_0.Int16_0 == (short) 6535)
                  {
                    this.Class29_0.method_50(new Struct16(20, 74), (short) 0, true, false);
                    return;
                  }
                  if (!this.Class29_0.method_51(int_11_5, (short) 3, false, true, true) && !this.Class29_0.method_51(int_11_5, (short) 3, false, true, true))
                  {
                    if ((int) this.Class29_0.class88_0.Int16_0 == (int) int_11_5.Int16_0 && this.Class29_0.Struct16_1.method_0(int_11_5.Struct16_0) <= 3)
                      this.Class29_0.Control2_0.button_45.Text = \u003CModule\u003E.smethod_6<string>(3085470750U);
                    this.Class29_0.method_54((short) 6525);
                    break;
                  }
                  break;
                }
                goto default;
              case 3381421134:
                if (text == \u003CModule\u003E.smethod_5<string>(571402422U))
                {
                  int_11_1 = new Struct17((short) 9378, (short) 40, (short) 20);
                  break;
                }
                goto default;
              case 3390820287:
                if (text == \u003CModule\u003E.smethod_5<string>(3111437063U))
                {
                  int_11_1 = new Struct17((short) 2901, (short) 15, (short) 15);
                  break;
                }
                goto default;
              case 3560321112:
                if (text == \u003CModule\u003E.smethod_5<string>(2320622238U))
                {
                  int_11_1 = new Struct17((short) 2092, (short) 79, (short) 6);
                  break;
                }
                goto default;
              case 3610506874:
                if (text == \u003CModule\u003E.smethod_6<string>(3762683947U))
                {
                  int_11_1 = new Struct17((short) 2092, (short) 57, (short) 93);
                  break;
                }
                goto default;
              case 3644209207:
                if (text == \u003CModule\u003E.smethod_6<string>(1692035157U))
                {
                  int_11_1 = new Struct17((short) 2095, (short) 55, (short) 94);
                  break;
                }
                goto default;
              case 3660986826:
                if (text == \u003CModule\u003E.smethod_7<string>(3792183196U))
                {
                  int_11_1 = new Struct17((short) 2096, (short) 4, (short) 7);
                  break;
                }
                goto default;
              case 3770643204:
                if (text == \u003CModule\u003E.smethod_8<string>(1137783547U))
                {
                  int_11_1 = new Struct17((short) 8432, (short) 5, (short) 8);
                  break;
                }
                goto default;
              case 3826339036:
                if (text == \u003CModule\u003E.smethod_5<string>(185755290U))
                {
                  int_11_1 = new Struct17((short) 8318, (short) 50, (short) 93);
                  break;
                }
                goto default;
              case 3848419112:
                if (text == \u003CModule\u003E.smethod_9<string>(2118489609U))
                {
                  int_11_1 = new Struct17((short) 5031, (short) 6, (short) 34);
                  break;
                }
                goto default;
              case 3907532079:
                if (text == \u003CModule\u003E.smethod_7<string>(2255807975U))
                {
                  this.method_26();
                  return;
                }
                goto default;
              case 4189239892:
                if (text == \u003CModule\u003E.smethod_9<string>(1304518892U))
                {
                  int_11_1 = new Struct17((short) 3634, (short) 18, (short) 10);
                  break;
                }
                goto default;
              default:
                short result = 0;
                if (!short.TryParse(this.Class29_0.Control2_0.comboBox_4.Text, out result))
                  return;
                this.Class29_0.method_54(result);
                return;
            }
            if (this.Class29_0.Control2_0.comboBox_4.Text.Contains(\u003CModule\u003E.smethod_8<string>(3207564425U)) || this.Class29_0.method_51(int_11_1, (short) 3, false, true, true) || (int) this.Class29_0.class88_0.Int16_0 != (int) int_11_1.Int16_0 || this.Class29_0.Struct16_1.method_0(int_11_1.Struct16_0) > 4)
              return;
            this.Class29_0.Control2_0.button_45.Text = \u003CModule\u003E.smethod_8<string>(233672838U);
            return;
          }
          if (!this.Class29_0.Control2_0.checkBox_68.Checked || string.IsNullOrEmpty(this.Class29_0.Control2_0.textBox_17.Text))
            return;
          // ISSUE: object of a compiler-generated type is created
          // ISSUE: variable of a compiler-generated type
          Class26.Class154 class154 = new Class26.Class154();
          // ISSUE: reference to a compiler-generated field
          class154.string_0 = this.Class29_0.Control2_0.textBox_17.Text;
          // ISSUE: reference to a compiler-generated field
          Class29 class29 = this.Class112_0.method_75(class154.string_0);
          Class143 class143_1;
          if (class29 == null)
          {
            class143_1 = (Class143) null;
          }
          else
          {
            class143_1 = class29.Class143_0;
            if (class143_1 != null)
              goto label_160;
          }
          // ISSUE: reference to a compiler-generated method
          class143_1 = this.Class29_0.Dictionary_0.Values.OfType<Class143>().FirstOrDefault<Class143>(new Func<Class143, bool>(class154.method_0));
label_160:
          Class143 class143_2 = class143_1;
          if (class143_2 == null)
            return;
          int num1 = class143_2.Struct16_0.method_0(this.Class29_0.struct16_1);
          // ISSUE: reference to a compiler-generated method
          if (this.list_10.Any<Class143>(new Func<Class143, bool>(class154.method_1)))
          {
            // ISSUE: reference to a compiler-generated method
            Class143 class142_4 = this.Class29_0.Dictionary_0.Values.OfType<Class143>().FirstOrDefault<Class143>(new Func<Class143, bool>(class154.method_2));
            if (class142_4 == null)
              return;
            if (class29?.Control2_0?.comboBox_4.Text == \u003CModule\u003E.smethod_5<string>(2938134058U) && class29.Control2_0.button_45.Text == \u003CModule\u003E.smethod_6<string>(2579949292U) && Struct17.smethod_0(class29.Class26_0.list_15[class29.Class26_0.int_1 >= class29.Class26_0.list_15.Count ? 0 : class29.Class26_0.int_1], this.Class29_0.Struct17_1) && class29.bool_39)
            {
              Struct16 struct161 = this.Class29_0.Struct16_1;
              List<Struct16> struct16List = new List<Struct16>();
              struct16List.Add(new Struct16(struct161.short_0, (short) ((int) struct161.short_1 - 1)));
              struct16List.Add(new Struct16((short) ((int) struct161.short_0 + 1), struct161.short_1));
              struct16List.Add(new Struct16(struct161.short_0, (short) ((int) struct161.short_1 + 1)));
              struct16List.Add(new Struct16((short) ((int) struct161.short_0 - 1), struct161.short_1));
              List<Class142> list = this.Class29_0.method_116().OfType<Class142>().ToList<Class142>();
              foreach (Struct16 struct16 in struct16List)
              {
                // ISSUE: object of a compiler-generated type is created
                // ISSUE: variable of a compiler-generated type
                Class26.Class155 class155 = new Class26.Class155();
                // ISSUE: reference to a compiler-generated field
                class155.struct16_0 = struct16;
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated method
                if (!this.Class29_0.class88_0.method_3(class155.struct16_0) && !list.Any<Class142>(new Func<Class142, bool>(class155.method_0)))
                {
                  // ISSUE: reference to a compiler-generated field
                  if (this.Class29_0.method_50(class155.struct16_0, (short) 0, true, true))
                    break;
                }
              }
              Thread.Sleep(2500);
            }
            if (this.method_25(class142_4))
              return;
            if ((Decimal) num1 > this.Class29_0.Control2_0.numericUpDown_20.Value)
            {
              this.Class29_0.bool_35 = false;
              if (class142_4 == null)
                return;
              this.Class29_0.Boolean_4 = this.Class29_0.method_50(class142_4.Struct16_0, (short) this.Class29_0.Control2_0.numericUpDown_20.Value, true, true) && !this.Class29_0.Control2_0.checkBox_70.Checked && !this.Class112_0.bool_2;
              return;
            }
            this.Class29_0.Boolean_4 = false;
            if (class29 == null || !this.Class29_0.bool_34)
              return;
            TimeSpan timeSpan = DateTime.UtcNow.Subtract(class29.dateTime_3);
            if (timeSpan.TotalMilliseconds <= 1000.0)
              return;
            timeSpan = DateTime.UtcNow.Subtract(this.Class29_0.DateTime_0);
            if (timeSpan.TotalMilliseconds <= 500.0)
              return;
            timeSpan = DateTime.UtcNow.Subtract(this.Class29_0.dateTime_3);
            if (timeSpan.TotalMilliseconds <= 500.0)
              return;
            if (Struct16.smethod_1(this.Class29_0.Struct16_1, this.Class29_0.Struct16_0))
            {
              this.Class29_0.bool_35 = false;
              this.Class29_0.method_105(true);
              return;
            }
            if (!this.Class29_0.class88_0.String_0.Contains(\u003CModule\u003E.smethod_8<string>(2098018155U)) && !this.Class29_0.class88_0.String_0.Contains(\u003CModule\u003E.smethod_9<string>(3926674376U)) && !this.list_8.Any<Class142>((Func<Class142, bool>) (class142_0 => this.Class29_0.Struct16_1.method_0(class142_0.Struct16_0) <= 6)))
              return;
            this.Class29_0.bool_35 = true;
            return;
          }
          if (class29?.Class143_0 == class143_2)
          {
            Struct16 struct161 = class29.Struct16_1;
            if (!this.Class29_0.method_51(class29.Struct17_1, (short) 0, false, true, true) && this.Class29_0.Dictionary_4.ContainsKey((int) class29.UInt32_0))
            {
              Struct17 struct17 = this.Class29_0.Dictionary_4[(int) class29.UInt32_0];
              if ((int) struct17.Int16_0 == (int) this.Class29_0.class88_0.Int16_0)
              {
                Class29 class290 = this.Class29_0;
                struct17 = this.Class29_0.Dictionary_4[(int) class29.UInt32_0];
                Struct16 struct160 = struct17.Struct16_0;
                class290.method_50(struct160, (short) 0, true, true);
              }
            }
            this.Class29_0.Boolean_4 = !this.Class29_0.Control2_0.checkBox_70.Checked && !this.Class112_0.bool_2;
            return;
          }
          if (!this.Class29_0.Dictionary_4.ContainsKey(class143_2.Int32_0))
            return;
          Struct17 struct17_1 = this.Class29_0.Dictionary_4[class143_2.Int32_0];
          if ((int) struct17_1.Int16_0 != (int) this.Class29_0.class88_0.Int16_0)
            return;
          Class29 class290_1 = this.Class29_0;
          Class29 class290_2 = this.Class29_0;
          struct17_1 = this.Class29_0.Dictionary_4[class143_2.Int32_0];
          Struct16 struct160_1 = struct17_1.Struct16_0;
          int num2 = class290_2.method_50(struct160_1, (short) 0, true, true) ? (!this.Class29_0.Control2_0.checkBox_70.Checked ? (!this.Class112_0.bool_2 ? 1 : 0) : 0) : 0;
          class290_1.Boolean_4 = num2 != 0;
          return;
        }
        catch
        {
          this.Class29_0.Boolean_4 = false;
          return;
        }
      }
    }
    Thread.Sleep(100);
  }

  private bool method_24()
  {
    TimeSpan timeSpan;
    if (this.Class29_0.method_119(10).Count < 3)
    {
      timeSpan = DateTime.UtcNow.Subtract(this.Class29_0.DateTime_0);
      if (timeSpan.TotalSeconds >= 3.0)
      {
        timeSpan = DateTime.UtcNow.Subtract(this.dateTime_10);
        if (timeSpan.TotalSeconds > 20.0)
          goto label_4;
      }
    }
    timeSpan = DateTime.UtcNow.Subtract(this.dateTime_11);
    if (timeSpan.TotalSeconds > 15.0)
      return false;
label_4:
    this.Class112_0.bool_4 = this.Class29_0.method_44(this.Class29_0.Struct16_1);
    return this.Class112_0.bool_4;
  }

  private bool method_25(Class143 class142_4)
  {
    Struct16 int_11 = new Struct16((short) ((int) this.Class29_0.class88_0.Byte_0 / 2), (short) ((int) this.Class29_0.class88_0.Byte_1 / 2));
    if (this.Class29_0.method_119(10).Count < 3)
    {
      DateTime utcNow = DateTime.UtcNow;
      TimeSpan timeSpan = utcNow.Subtract(class142_4.DateTime_4);
      if (timeSpan.TotalSeconds > 5.0)
      {
        utcNow = DateTime.UtcNow;
        timeSpan = utcNow.Subtract(this.Class29_0.DateTime_0);
        if (timeSpan.TotalSeconds > 5.0 && (int) class142_4.Class88_0.Int16_0 == (int) this.Class29_0.class88_0.Int16_0)
        {
          utcNow = DateTime.UtcNow;
          timeSpan = utcNow.Subtract(this.dateTime_10);
          if (timeSpan.TotalSeconds <= 20.0)
          {
            utcNow = DateTime.UtcNow;
            timeSpan = utcNow.Subtract(this.dateTime_11);
            if (timeSpan.TotalSeconds >= 15.0)
              goto label_13;
          }
          if (this.Class29_0.Struct16_0.method_0(class142_4.Struct16_0) == 1 || this.Class112_0.bool_4)
          {
            bool flag;
            if (!(flag = this.Class29_0.method_43()))
            {
              if (!this.Class29_0.method_50(int_11, (short) 1, true, true))
                this.Class29_0.method_49(int_11.method_4(this.Class29_0.Struct16_0));
              if (!this.Class29_0.method_50(int_11, (short) 1, true, true))
                this.Class29_0.method_49(int_11.method_4(this.Class29_0.Struct16_0));
              Thread.Sleep(2000);
            }
            this.Class112_0.bool_4 = flag;
            return flag;
          }
        }
      }
    }
label_13:
    this.Class112_0.bool_4 = false;
    return false;
  }

  private void method_26()
  {
    this.list_21 = this.Class29_0.method_120(12, new ushort[1]
    {
      (ushort) 87
    });
    this.list_22 = this.Class29_0.method_119(11);
    this.List_1 = new List<Struct16>()
    {
      new Struct16(this.method_30().short_0, (short) 44),
      new Struct16(44, 44),
      new Struct16(44, 6),
      new Struct16((int) this.method_30().short_0 + 3, 6),
      new Struct16((int) this.Struct16_3.short_0 - 2, (int) this.Struct16_3.short_1 + 2),
      new Struct16(this.method_30().short_0, (short) 6),
      new Struct16(6, 6),
      new Struct16(6, 44),
      new Struct16((int) this.method_30().short_0 - 3, 44),
      new Struct16((int) this.Struct16_1.short_0 + 2, (int) this.Struct16_1.short_1 - 2)
    };
    switch (this.int_3)
    {
      case 1:
        this.method_27(0, 4);
        break;
      case 2:
      case 4:
        this.method_28();
        break;
      case 3:
        this.method_27(5, 9);
        break;
      default:
        this.int_3 = 1;
        break;
    }
  }

  private void method_27(int class142_4, [In] int obj1)
  {
    if (this.Class29_0.Int32_1 >= class142_4 && this.Class29_0.Int32_1 <= obj1)
    {
      Struct16 struct16;
      if (this.Class29_0.Int32_1 == obj1)
      {
        struct16 = this.Class29_0.Struct16_1;
        if (struct16.method_0(this.method_30()) <= 9)
        {
          this.int_4 = this.method_29() + 1;
          ++this.int_3;
          if (this.Class29_0.Int32_1 >= this.List_1.Count - 1)
          {
            this.Class29_0.Int32_1 = 0;
            return;
          }
          ++this.Class29_0.Int32_1;
          return;
        }
      }
      int count = this.list_22.Count;
      Class29 class290 = this.Class29_0;
      int num1;
      if (count != 0)
      {
        struct16 = this.method_30();
        if (struct16.method_0(this.Class29_0.Struct16_1) > 8)
        {
          num1 = count <= 4 ? 700 : (count <= 6 ? 800 : (count <= 8 ? 900 : (count <= 10 ? 1000 : 1200)));
          goto label_10;
        }
      }
      num1 = 420;
label_10:
      double num2 = (double) num1;
      class290.double_0 = num2;
      this.Class29_0.method_55((short) 0, true);
    }
    else
    {
      this.int_4 = this.method_29() + 1;
      ++this.int_3;
      Thread.Sleep(500);
    }
  }

  private void method_28()
  {
    if (this.method_30().method_0(this.Class29_0.Struct16_1) <= 10)
      this.Class29_0.double_0 = 300.0;
    ushort[] class142_4 = new ushort[2]
    {
      (ushort) 273,
      (ushort) 266
    };
    if ((this.list_22.Count <= 2 || this.list_22.Where<Class142>((Func<Class142, bool>) (class142_0 => class142_0.Struct16_0.method_0(this.Class29_0.Struct16_1) <= 8)).Count<Class142>() < 2) && this.list_21.Count < 1)
      ++this.int_3;
    else if (this.method_31(class142_4))
    {
      Thread.Sleep(25);
    }
    else
    {
      Struct16 int_11 = new Struct16();
      switch (this.int_4)
      {
        case 1:
          int_11 = this.Struct16_0;
          break;
        case 2:
          int_11 = this.Struct16_3;
          break;
        case 3:
          int_11 = this.Struct16_2;
          break;
        case 4:
          int_11 = this.Struct16_1;
          break;
        default:
          this.int_4 = 1;
          break;
      }
      this.Class29_0.method_50(int_11, (short) 0, true, true);
      if (!Struct16.smethod_0(this.Class29_0.Struct16_0, int_11))
        return;
      ++this.int_4;
    }
  }

  private int method_29()
  {
    int index1 = 0;
    int[] numArray = new int[4]
    {
      this.Class29_0.Struct16_0.method_0(this.Struct16_0),
      this.Class29_0.Struct16_0.method_0(this.Struct16_3),
      this.Class29_0.Struct16_0.method_0(this.Struct16_2),
      this.Class29_0.Struct16_0.method_0(this.Struct16_1)
    };
    for (int index2 = 0; index2 < numArray.Length; ++index2)
    {
      if (numArray[index2] < numArray[index1])
        index1 = index2;
    }
    return index1;
  }

  private Struct16 method_30()
  {
    string string0 = this.Class29_0.class88_0.String_0;
    if (string0 == \u003CModule\u003E.smethod_8<string>(2727447121U))
      return new Struct16(24, 29);
    return !(string0 == \u003CModule\u003E.smethod_8<string>(219875495U)) && !(string0 == \u003CModule\u003E.smethod_5<string>(4260303909U)) ? new Struct16(50, 50) : new Struct16(29, 27);
  }

  private bool method_31(ushort[] class142_4)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class26.Class156 class156 = new Class26.Class156();
    // ISSUE: reference to a compiler-generated field
    class156.ushort_0 = class142_4;
    // ISSUE: reference to a compiler-generated field
    class156.class26_0 = this;
    try
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated method
      foreach (Class142 class142 in this.list_22.Where<Class142>(class156.func_0 ?? (class156.func_0 = new Func<Class142, bool>(class156.method_0))))
      {
        if (class142.Byte_1 <= (byte) 40)
          return false;
      }
    }
    catch
    {
      return true;
    }
    return true;
  }

  private Struct16 Struct16_0 => new Struct16((short) ((int) this.method_30().short_0 - 5), (short) ((int) this.method_30().short_1 - 5));

  private Struct16 Struct16_1 => new Struct16((short) ((int) this.method_30().short_0 - 5), (short) ((int) this.method_30().short_1 + 5));

  private Struct16 Struct16_2 => new Struct16((short) ((int) this.method_30().short_0 + 5), (short) ((int) this.method_30().short_1 + 5));

  private Struct16 Struct16_3 => new Struct16((short) ((int) this.method_30().short_0 + 5), (short) ((int) this.method_30().short_1 - 5));

  private void method_32(bool class142_4)
  {
    if (this.list_15.Count == 0)
      return;
    if (class142_4 && this.Class29_0.method_116().OfType<Class142>().Any<Class142>((Func<Class142, bool>) (class142_0 => Struct16.smethod_0(class142_0.Struct16_0, this.list_15[this.int_1].Struct16_0))))
      ++this.int_1;
    if (this.int_1 < this.list_15.Count)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      Class26.Class157 class157 = new Class26.Class157();
      // ISSUE: reference to a compiler-generated field
      class157.class26_0 = this;
      this.Class29_0.double_0 = (double) this.Class29_0.Control2_0.trackBar_0.Value;
      // ISSUE: reference to a compiler-generated field
      class157.form3_0 = this.Class29_0.Control2_0.form3_0;
      if (DateTime.UtcNow.Subtract(this.dateTime_11).TotalSeconds < 2.5)
      {
        this.Class29_0.double_0 = this.Class29_0.double_0 > 350.0 ? 350.0 : this.Class29_0.double_0;
      }
      else
      {
        List<Class142> source = this.Class29_0.method_119(12);
        if (this.Class29_0.Control2_0.button_73.Text == \u003CModule\u003E.smethod_7<string>(3924072695U))
          source = source.Where<Class142>((Func<Class142, bool>) (class142_0 => !this.Class29_0.method_44(class142_0.Struct16_0))).ToList<Class142>();
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated method
        // ISSUE: reference to a compiler-generated field
        if (class157.form3_0.checkBox_3.Checked && (Decimal) source.Where<Class142>(new Func<Class142, bool>(class157.method_0)).Count<Class142>() >= class157.form3_0.numericUpDown_5.Value && !(this.Class29_0.Control2_0.button_73.Text == \u003CModule\u003E.smethod_8<string>(2351233537U)))
        {
          // ISSUE: reference to a compiler-generated field
          this.Class29_0.double_0 = (double) class157.form3_0.numericUpDown_3.Value;
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated method
        // ISSUE: reference to a compiler-generated field
        if (class157.form3_0.checkBox_2.Checked && (Decimal) source.Where<Class142>(new Func<Class142, bool>(class157.method_1)).Count<Class142>() >= class157.form3_0.numericUpDown_2.Value && !(this.Class29_0.Control2_0.button_73.Text == \u003CModule\u003E.smethod_8<string>(2351233537U)))
        {
          // ISSUE: reference to a compiler-generated field
          this.Class29_0.double_0 = (double) class157.form3_0.numericUpDown_0.Value;
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated method
        // ISSUE: reference to a compiler-generated field
        if (class157.form3_0.checkBox_1.Checked && (Decimal) source.Where<Class142>(new Func<Class142, bool>(class157.method_2)).Count<Class142>() >= class157.form3_0.numericUpDown_9.Value && !(this.Class29_0.Control2_0.button_73.Text == \u003CModule\u003E.smethod_8<string>(2351233537U)))
        {
          // ISSUE: reference to a compiler-generated field
          this.Class29_0.double_0 = (double) class157.form3_0.numericUpDown_7.Value;
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated method
        // ISSUE: reference to a compiler-generated field
        if (class157.form3_0.checkBox_0.Checked && (Decimal) source.Where<Class142>(new Func<Class142, bool>(class157.method_3)).Count<Class142>() >= class157.form3_0.numericUpDown_11.Value)
        {
          this.Class29_0.bool_39 = true;
          if (this.method_33())
            return;
          if (this.Class29_0.class88_0.String_0.Contains(\u003CModule\u003E.smethod_6<string>(449645883U)) || this.Class29_0.class88_0.String_0.Contains(\u003CModule\u003E.smethod_9<string>(3926674376U)) || this.list_8.Count > 0 && this.list_8.Where<Class142>((Func<Class142, bool>) (class142_0 => class142_0.Struct16_0.method_0(this.Class29_0.Struct16_1) <= 6)).ToList<Class142>().Count > 0)
            this.Class29_0.bool_34 = true;
          foreach (Class29 class29 in this.Class112_0.method_76(this.Class29_0))
          {
            if (!class29.bool_34)
              class29.bool_34 = true;
          }
          this.Class29_0.Boolean_4 = false;
          return;
        }
      }
      this.Class29_0.bool_39 = false;
      foreach (Class29 class29 in this.Class112_0.method_76(this.Class29_0))
        class29.bool_34 = false;
      this.Class29_0.bool_34 = false;
      if (this.method_24() || this.method_33())
        return;
      foreach (Class29 class29 in this.Class112_0.method_76(this.Class29_0))
      {
        if (class29.method_7(Enum10.Pramh) || class29.method_7(Enum10.Suain) || class29.method_7(Enum10.BeagSuain) || class29.method_25((ushort) 89) || class29.Class143_0.Boolean_10)
          return;
      }
      if (this.Class29_0.Control2_0.checkBox_35.Checked && this.Class29_0.Control2_0.listBox_4.Items.Count > 0)
      {
        if (!this.Class29_0.bool_1)
        {
          try
          {
            List<ushort> ushortList = new List<ushort>();
            ushort result = 0;
            foreach (string s in this.Class29_0.Control2_0.listBox_4.Items.OfType<string>())
            {
              if (ushort.TryParse(s, out result))
                ushortList.Add(result);
            }
            List<Class141> source = this.Class29_0.method_123(12, ushortList.ToArray());
            foreach (Class141 class141 in source.ToList<Class141>())
            {
              int count = this.Class29_0.Class103_0.method_2(this.Class29_0.Struct16_0, class141.Struct16_0, true, (short) 1).Count;
              if (count == 0)
                count = this.Class29_0.Class103_0.method_2(this.Class29_0.Struct16_0, class141.Struct16_0, true, (short) 1).Count;
              if (count == 0 || (Decimal) count > this.Class29_0.Control2_0.numericUpDown_19.Value)
                source.Remove(class141);
            }
            if (source.Count > 0)
            {
              List<Class141> list = source.OrderBy<Class141, int>((Func<Class141, int>) (class142_0 => class142_0.Struct16_0.method_0(this.Class29_0.Struct16_0))).ToList<Class141>();
              if (this.Class29_0.Struct16_0.method_0(list[0].Struct16_0) > 2)
              {
                this.Class29_0.Boolean_4 = this.Class29_0.method_50(list[0].Struct16_0, (short) 2, true, true) && !this.Class29_0.Control2_0.checkBox_70.Checked && !this.Class112_0.bool_2;
                return;
              }
              Struct16 struct16 = this.Class29_0.Struct16_0;
              if (struct16.method_0(list[0].Struct16_0) <= 2)
              {
                struct16 = this.Class29_0.Struct16_1;
                if (struct16.method_0(list[0].Struct16_0) > 2)
                {
                  this.Class29_0.method_105(true);
                  goto label_68;
                }
              }
              if (Monitor.TryEnter(this.Class29_0.object_1, 200))
              {
                try
                {
                  this.Class29_0.method_93((byte) 0, list[0].Struct16_0);
                }
                finally
                {
                  Monitor.Exit(this.Class29_0.object_1);
                }
              }
label_68:
              this.Class29_0.Boolean_4 = false;
              return;
            }
          }
          catch
          {
            this.Class29_0.Boolean_4 = false;
          }
        }
      }
      Class29 class290 = this.Class29_0;
      Struct16 struct16_1 = this.Class29_0.Struct16_0;
      Struct17 struct17;
      int num;
      // ISSUE: reference to a compiler-generated field
      if (!((Decimal) struct16_1.method_0(this.list_15[this.int_1].Struct16_0) > class157.form3_0.numericUpDown_6.Value))
      {
        int int160_1 = (int) this.Class29_0.class88_0.Int16_0;
        struct17 = this.list_15[this.int_1];
        int int160_2 = (int) struct17.Int16_0;
        if (int160_1 == int160_2)
        {
          num = 0;
          goto label_75;
        }
      }
      // ISSUE: reference to a compiler-generated field
      num = this.Class29_0.method_51(this.list_15[this.int_1], (short) class157.form3_0.numericUpDown_6.Value, false, true, true) ? (!this.Class29_0.Control2_0.checkBox_70.Checked ? (!this.Class112_0.bool_2 ? 1 : 0) : 0) : 0;
label_75:
      class290.Boolean_4 = num != 0;
      struct16_1 = this.Class29_0.Struct16_0;
      ref Struct16 local1 = ref struct16_1;
      struct17 = this.list_15[this.int_1];
      Struct16 struct160_1 = struct17.Struct16_0;
      // ISSUE: reference to a compiler-generated field
      if (!((Decimal) local1.method_0(struct160_1) <= class157.form3_0.numericUpDown_6.Value))
        return;
      int int160_3 = (int) this.Class29_0.class88_0.Int16_0;
      struct17 = this.list_15[this.int_1];
      int int160_4 = (int) struct17.Int16_0;
      if (int160_3 != int160_4)
        return;
      struct16_1 = this.Class29_0.Struct16_1;
      ref Struct16 local2 = ref struct16_1;
      struct17 = this.list_15[this.int_1];
      Struct16 struct160_2 = struct17.Struct16_0;
      // ISSUE: reference to a compiler-generated field
      if ((Decimal) local2.method_0(struct160_2) > class157.form3_0.numericUpDown_6.Value)
        this.Class29_0.method_105(true);
      else
        ++this.int_1;
    }
    else
      this.int_1 = 0;
  }

  private bool method_33()
  {
    List<Class29> class29List = new List<Class29>();
    Class29 class29_1 = (Class29) null;
    try
    {
      List<Class29> list = this.Class112_0.IEnumerable_0.Where<Class29>((Func<Class29, bool>) (class142_0 => class142_0?.Control2_0?.toolStripMenuItem_2.Text == \u003CModule\u003E.smethod_9<string>(591721198U) && class142_0.Control2_0.checkBox_68.Checked && class142_0.Control2_0.textBox_17.Text.ToUpper() == this.Class29_0.String_0.ToUpper())).ToList<Class29>();
      bool bool13 = this.bool_13;
      this.bool_13 = true;
      foreach (Class29 class29_2 in list)
      {
        if ((int) class29_2.class88_0.Int16_0 != (int) this.Class29_0.class88_0.Int16_0 || class29_2.Struct16_1.method_0(this.Class29_0.Struct16_1) > 9 && (int) class29_2.class88_0.Int16_0 == (int) this.Class29_0.class88_0.Int16_0)
        {
          class29_1 = class29_2;
          this.bool_13 = false;
          break;
        }
      }
      if (bool13 && !this.bool_13)
        this.dateTime_15 = DateTime.UtcNow;
      else if (!this.bool_13 && DateTime.UtcNow.Subtract(this.dateTime_15).TotalSeconds > 5.0)
      {
        this.Class29_0.double_0 = (double) this.Class29_0.Control2_0.trackBar_0.Value;
        this.Class29_0.Boolean_4 = class29_1 != null && this.Class29_0.method_51(class29_1.Struct17_1, (short) 3, false, false, true);
        return true;
      }
      return false;
    }
    catch
    {
      this.bool_13 = true;
      return false;
    }
  }

  private bool method_34()
  {
    if (Struct16.smethod_1(this.struct16_0, this.Class29_0.Struct16_1))
    {
      if (this.Class29_0.method_24(\u003CModule\u003E.smethod_8<string>(1193907446U)) && this.Class29_0.method_41(this.Class29_0.Class136_0[\u003CModule\u003E.smethod_6<string>(2103541518U)], (Class142) null))
      {
        this.Class29_0.method_31(\u003CModule\u003E.smethod_8<string>(1193907446U), (Class142) null, this.bool_2, true);
        this.struct16_0 = this.Class29_0.Struct16_1;
        this.string_0 = \u003CModule\u003E.smethod_7<string>(3066491117U);
        return true;
      }
      if (this.Class29_0.method_24(\u003CModule\u003E.smethod_9<string>(3671614790U)) && this.Class29_0.method_41(this.Class29_0.Class136_0[\u003CModule\u003E.smethod_9<string>(3671614790U)], (Class142) null))
      {
        this.Class29_0.method_31(\u003CModule\u003E.smethod_8<string>(2433895916U), (Class142) null, this.bool_2, true);
        this.struct16_0 = this.Class29_0.Struct16_1;
        this.string_0 = \u003CModule\u003E.smethod_6<string>(2530275627U);
        return true;
      }
    }
    else if (Struct16.smethod_0(this.struct16_0, this.Class29_0.Struct16_1))
    {
      string string0 = this.string_0;
      if (!(string0 == \u003CModule\u003E.smethod_7<string>(3066491117U)))
      {
        if (!(string0 == \u003CModule\u003E.smethod_7<string>(1072966197U)))
        {
          if (!this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(3067736412U), (Class142) null, this.bool_2, false))
            this.Class29_0.method_31(\u003CModule\u003E.smethod_7<string>(3859550768U), (Class142) null, true, true);
        }
        else if (this.Class29_0.method_31(\u003CModule\u003E.smethod_5<string>(3469489084U), (Class142) null, this.bool_2, false))
        {
          Thread.Sleep(100);
          return true;
        }
      }
      else if (this.Class29_0.method_31(\u003CModule\u003E.smethod_6<string>(2103541518U), (Class142) null, this.bool_2, false))
      {
        Thread.Sleep(100);
        return true;
      }
    }
    return false;
  }

  private void method_35()
  {
    if (!this.Class29_0.Control2_0.checkBox_79.Checked && !this.Class29_0.Control2_0.checkBox_78.Checked && !this.Class29_0.Control2_0.checkBox_77.Checked)
      return;
    try
    {
      if (this.method_38())
        return;
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      Class26.Class158 class158 = new Class26.Class158();
      List<Class141> source = this.Class29_0.method_122(4);
      // ISSUE: reference to a compiler-generated field
      class158.struct19_0 = new Struct19(new Struct16((short) ((int) this.Class29_0.Struct16_1.short_0 - 2), (short) ((int) this.Class29_0.Struct16_1.short_1 - 2)), new Struct18((short) 5, (short) 5));
      if (source.Count != 0)
      {
        if (this.Class29_0.Control2_0.checkBox_79.Checked)
        {
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated method
          foreach (Class140 class140 in source.Where<Class141>(class158.func_0 ?? (class158.func_0 = new Func<Class141, bool>(class158.method_0))))
            this.Class29_0.method_93((byte) 0, class140.Struct16_0);
        }
        if (this.Class29_0.Control2_0.checkBox_78.Checked)
        {
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated method
          foreach (Class140 class140 in source.Where<Class141>(class158.func_1 ?? (class158.func_1 = new Func<Class141, bool>(class158.method_1))))
            this.Class29_0.method_93((byte) 0, class140.Struct16_0);
        }
      }
      if (!this.Class29_0.Control2_0.checkBox_77.Checked)
        return;
      if (this.int_0 >= 15)
      {
        foreach (Class76 class76 in this.Class29_0.Class21_0.ToList<Class76>())
        {
          if (this.Class29_0.Control2_0.bindingList_3.Contains<string>(class76.String_0, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase))
            this.Class29_0.method_95(class76.Byte_0, this.Class29_0.Struct16_1, class76.Int32_0);
        }
        this.int_0 = 0;
      }
      else
        ++this.int_0;
    }
    catch
    {
    }
  }

  private void method_36()
  {
    DateTime utcNow1 = DateTime.UtcNow;
    DateTime utcNow2;
    while (this.Class29_0.list_7.Count >= 3 || this.Class29_0.int_1 >= 3)
    {
      utcNow2 = DateTime.UtcNow;
      if (utcNow2.Subtract(utcNow1).TotalSeconds > 1.0)
        this.Class29_0.list_7.Clear();
      Thread.Sleep(10);
    }
    utcNow2 = DateTime.UtcNow;
    if (utcNow2.Subtract(this.dateTime_4).TotalSeconds <= 1.0)
      return;
    this.Class29_0.list_7.Clear();
  }

  internal bool method_37() => !Settings.Default.ParanoiaMode ? this.Class29_0.method_125().Any<Class143>((Func<Class143, bool>) (class142_0 => this.list_14.Contains<string>(class142_0.String_5, (IEqualityComparer<string>) StringComparer.OrdinalIgnoreCase))) : this.method_38();

  internal bool method_38() => this.Class29_0.method_125().Any<Class143>((Func<Class143, bool>) (keyValuePair_0 => !this.Class29_0.Control2_0.listBox_6.Items.OfType<string>().Contains<string>(keyValuePair_0.String_5, (IEqualityComparer<string>) StringComparer.OrdinalIgnoreCase)));

  internal void method_39(Class177 class142_4)
  {
    if (!Monitor.TryEnter(Class26.object_0, 500))
      return;
    try
    {
      this.list_3.Add(class142_4);
      this.hashSet_0.Add(class142_4.UInt16_0);
    }
    finally
    {
      Monitor.Exit(Class26.object_0);
    }
  }

  internal void method_40(string class143_1)
  {
    if (!Monitor.TryEnter(Class26.object_0, 1000))
      return;
    try
    {
      foreach (Class177 class177 in new List<Class177>((IEnumerable<Class177>) this.list_3))
      {
        if (class177.UInt16_0.ToString() == class143_1)
        {
          this.list_3.Remove(class177);
          this.hashSet_0.Remove(class177.UInt16_0);
        }
      }
    }
    finally
    {
      Monitor.Exit(Class26.object_0);
    }
  }

  internal bool method_41(ushort class142_4)
  {
    lock (Class26.object_0)
      return this.hashSet_0.Contains(class142_4);
  }

  internal void method_42(Class145 class142_4)
  {
    if (!Monitor.TryEnter(Class26.object_0, 1000))
      return;
    try
    {
      this.list_4.Add(class142_4);
      this.hashSet_1.Add(class142_4.String_0);
    }
    finally
    {
      Monitor.Exit(Class26.object_0);
    }
  }

  internal void method_43(string string_1)
  {
    if (!Monitor.TryEnter(Class26.object_0, 1000))
      return;
    try
    {
      foreach (Class145 class145 in this.list_4)
      {
        if (class145.String_0 == string_1)
        {
          this.list_4.Remove(class145);
          this.hashSet_1.Remove(class145.String_0);
          break;
        }
      }
    }
    finally
    {
      Monitor.Exit(Class26.object_0);
    }
  }

  internal bool method_44(string string_1)
  {
    lock (Class26.object_0)
      return this.hashSet_1.Contains<string>(string_1, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase);
  }

  internal bool method_45(Class145 object_1, [In] ref Class143 obj1, [In] ref Class29 obj2)
  {
    obj1 = this.Class29_0.method_124(object_1.String_0);
    obj2 = this.Class112_0.method_75(object_1.String_0);
    if (obj1 == null || obj2 == this.Class29_0)
      return false;
    ref Class143 local = ref obj1;
    Class29 class29 = obj2;
    Class143 class143;
    if (class29 == null)
    {
      class143 = (Class143) null;
    }
    else
    {
      class143 = class29.Class143_0;
      if (class143 != null)
        goto label_5;
    }
    class143 = obj1;
label_5:
    local = class143;
    return true;
  }

  private bool method_46(string struct16_5, [In] Class142 obj1, [In] bool obj2, [In] bool obj3)
  {
    for (int index = 20; index > 0; --index)
    {
      if (this.Class29_0.method_31(struct16_5 + \u003CModule\u003E.smethod_8<string>(1421900021U) + index.ToString(), obj1, obj2, obj3))
        return true;
    }
    return false;
  }

  private bool method_47(string class142_4)
  {
    if (!this.Class29_0.method_29(class142_4))
      return false;
    if (class142_4 == \u003CModule\u003E.smethod_5<string>(661394886U))
    {
      foreach (Class143 class143 in this.list_6)
      {
        class143.Dictionary_0[(ushort) 25] = DateTime.MinValue;
        class143.Dictionary_0[(ushort) 247] = DateTime.MinValue;
        class143.Dictionary_0[(ushort) 295] = DateTime.MinValue;
      }
    }
    this.Class29_0.Class134_0 = new Class134();
    return this.Class29_0.method_34();
  }

  private bool method_48(string class142_4)
  {
    for (int index = 20; index > 0; --index)
    {
      if (this.Class29_0.method_30(class142_4 + \u003CModule\u003E.smethod_9<string>(366607487U) + index.ToString()))
        return true;
    }
    return false;
  }

  private void method_49()
  {
    try
    {
      if (this.Class29_0?.Control2_0 == null)
        return;
      this.Class29_0.bool_1 = this.Class29_0.Class21_0.Boolean_0;
      if (this.bool_18)
        this.method_50();
      this.method_52();
      this.method_53();
      this.method_65();
      if (this.bool_17 && this.Class29_0.Control2_0.checkBox_67.Checked || this.Class29_0.bool_37)
      {
        Thread.Sleep(100);
        return;
      }
      this.method_66();
      this.method_84();
    }
    catch
    {
    }
    Thread.Sleep(25);
  }

  private void method_50()
  {
    Struct16 struct16_1 = new Struct16();
    int count = 0;
    while (Struct16.smethod_0(struct16_1, new Struct16()))
    {
      List<Struct16> struct16List1 = new List<Struct16>();
      List<Class142> source = this.Class29_0.method_118(4, new ushort[1]
      {
        (ushort) 3
      });
      List<Class143> all = this.Class29_0.method_125().FindAll((Predicate<Class143>) (keyValuePair_0 => keyValuePair_0 != this.Class29_0.Class143_0));
      Class142 class142_1 = this.Class29_0.method_118(12, new ushort[1]
      {
        (ushort) 918
      }).FirstOrDefault<Class142>();
      foreach (Class142 class142_2 in source.Where<Class142>((Func<Class142, bool>) (keyValuePair_0 => DateTime.UtcNow.Subtract(keyValuePair_0.DateTime_0).TotalMilliseconds > 250.0)).OrderByDescending<Class142, DateTime>((Func<Class142, DateTime>) (keyValuePair_0 => keyValuePair_0.DateTime_0)).Skip<Class142>(count))
        struct16List1.AddRange((IEnumerable<Struct16>) this.method_51(class142_2.Struct16_0));
      foreach (Class142 class142_3 in source.Where<Class142>((Func<Class142, bool>) (class134_0 => Struct16.smethod_1(class134_0.Struct16_0, this.Class29_0.Struct16_0))))
        struct16List1.Add(class142_3.Struct16_0);
      foreach (Class143 class143 in all)
        struct16List1.Add(class143.Struct16_0);
      if (class142_1 != null)
        struct16List1.Add(class142_1.Struct16_0);
      List<Struct16> struct16List2 = new List<Struct16>();
      struct16List2.Add(this.Class29_0.Struct16_0);
      Struct16 struct160 = this.Class29_0.Struct16_0;
      struct16List2.Add(struct160.method_3(Direction.South));
      struct160 = this.Class29_0.Struct16_0;
      struct16List2.Add(struct160.method_3(Direction.West));
      struct160 = this.Class29_0.Struct16_0;
      struct16List2.Add(struct160.method_3(Direction.North));
      struct160 = this.Class29_0.Struct16_0;
      struct16List2.Add(struct160.method_3(Direction.East));
      foreach (Struct16 struct16_2 in struct16List2)
      {
        if (!struct16List1.Contains(struct16_2))
        {
          struct16_1 = struct16_2;
          break;
        }
      }
      ++count;
    }
    if (Struct16.smethod_1(struct16_1, this.Class29_0.Struct16_0))
      this.Class29_0.method_50(struct16_1, (short) 0, true, true);
    Thread.Sleep(5);
  }

  private List<Struct16> method_51(Struct16 class142_4) => new List<Struct16>()
  {
    new Struct16((int) class142_4.short_0 + 1, (int) class142_4.short_1),
    new Struct16((int) class142_4.short_0 + 2, (int) class142_4.short_1),
    new Struct16((int) class142_4.short_0 - 1, (int) class142_4.short_1),
    new Struct16((int) class142_4.short_0 - 2, (int) class142_4.short_1),
    new Struct16((int) class142_4.short_0, (int) class142_4.short_1 + 1),
    new Struct16((int) class142_4.short_0, (int) class142_4.short_1 + 2),
    new Struct16((int) class142_4.short_0, (int) class142_4.short_1 - 1),
    new Struct16((int) class142_4.short_0, (int) class142_4.short_1 - 2)
  };

  private void method_52()
  {
    foreach (Class143 class143 in this.Class29_0.method_125())
    {
      if (class143 != null && class143.String_2 != null && class143.Double_3 > 0.0)
      {
        double double3_1 = class143.Double_3;
        DateTime utcNow = DateTime.UtcNow;
        TimeSpan timeSpan = utcNow.Subtract(class143.DateTime_5);
        double totalSeconds1 = timeSpan.TotalSeconds;
        double num;
        if (double3_1 - totalSeconds1 < 0.0)
        {
          class143.Double_3 = 0.0;
          this.Class29_0.method_61((byte) 2, class143.Int32_0, \u003CModule\u003E.smethod_6<string>(899990565U));
        }
        else if (class143.String_2 != \u003CModule\u003E.smethod_7<string>(4112032853U))
        {
          Class29 class290 = this.Class29_0;
          int int320 = class143.Int32_0;
          double double3_2 = class143.Double_3;
          utcNow = DateTime.UtcNow;
          timeSpan = utcNow.Subtract(class143.DateTime_5);
          double totalSeconds2 = timeSpan.TotalSeconds;
          num = Math.Ceiling(double3_2 - totalSeconds2);
          string str = num.ToString();
          class290.method_61((byte) 2, int320, str);
        }
        else
        {
          utcNow = DateTime.UtcNow;
          timeSpan = utcNow.Subtract(class143.DateTime_5);
          if (8.0 - timeSpan.TotalSeconds > -1.0)
          {
            Class29 class290 = this.Class29_0;
            int int320 = class143.Int32_0;
            utcNow = DateTime.UtcNow;
            timeSpan = utcNow.Subtract(class143.DateTime_5);
            num = Math.Ceiling(8.0 - timeSpan.TotalSeconds);
            string str1 = num.ToString();
            string str2 = \u003CModule\u003E.smethod_8<string>(622143072U);
            double double3_3 = class143.Double_3;
            utcNow = DateTime.UtcNow;
            timeSpan = utcNow.Subtract(class143.DateTime_5);
            double totalSeconds3 = timeSpan.TotalSeconds;
            num = Math.Ceiling(double3_3 - totalSeconds3);
            string str3 = num.ToString();
            string str4 = str1 + str2 + str3;
            class290.method_61((byte) 2, int320, str4);
          }
          else
          {
            Class29 class290 = this.Class29_0;
            int int320 = class143.Int32_0;
            string str5 = \u003CModule\u003E.smethod_9<string>(1454816350U);
            double double3_4 = class143.Double_3;
            utcNow = DateTime.UtcNow;
            timeSpan = utcNow.Subtract(class143.DateTime_5);
            double totalSeconds4 = timeSpan.TotalSeconds;
            num = Math.Ceiling(double3_4 - totalSeconds4);
            string str6 = num.ToString();
            string str7 = str5 + str6;
            class290.method_61((byte) 2, int320, str7);
          }
        }
      }
    }
    if (DateTime.UtcNow.Subtract(this.dateTime_20).TotalMilliseconds >= 1000.0 && this.bool_19)
    {
      foreach (Class143 class143 in this.Class29_0.method_125())
      {
        if (class143 != null && class143.Int32_0 != this.Class29_0.Class143_0.Int32_0 && class143.Boolean_1 && (class143.String_1 == \u003CModule\u003E.smethod_7<string>(2385951071U) || class143.String_1 == \u003CModule\u003E.smethod_5<string>(3626117781U) || class143.String_1 == \u003CModule\u003E.smethod_9<string>(625020571U) || class143.String_1 == \u003CModule\u003E.smethod_7<string>(1291214875U)))
          this.Class29_0.method_63(class143.Int32_0);
      }
      this.dateTime_20 = DateTime.UtcNow;
    }
    if (this.Class29_0.byte_8 > (byte) 0)
    {
      TimeSpan timeSpan = new TimeSpan(0, (int) this.Class29_0.byte_8 == (this.Class29_0.previousClass_0 == PreviousClass.Pure ? 3 : 2) ? 2 : 1, 2) - DateTime.UtcNow.Subtract(this.Class29_0.dateTime_4);
      if (timeSpan < new TimeSpan(0, 0, 1))
        this.Class29_0.byte_8 = (byte) 0;
      if (!this.bool_19)
        return;
      this.Class29_0.method_75((byte) 18, \u003CModule\u003E.smethod_6<string>(4056564638U) + timeSpan.ToString(\u003CModule\u003E.smethod_5<string>(395737706U)));
    }
    else
    {
      if (this.Class29_0.medClass_0 != MedClass.Druid || !this.bool_19)
        return;
      this.Class29_0.method_75((byte) 18, \u003CModule\u003E.smethod_6<string>(3358535143U));
    }
  }

  internal void method_53()
  {
    if (!(this.Class29_0.Control2_0.button_19.Text == \u003CModule\u003E.smethod_5<string>(3530897020U)))
      return;
    if (this.method_37())
      Thread.Sleep(150000);
    if (this.Class29_0.Control2_0.checkBox_9.Checked)
    {
      this.Class29_0.method_30(\u003CModule\u003E.smethod_5<string>(3047667416U));
      Thread.Sleep(100);
    }
    else if (!this.dictionary_0.ContainsKey(this.Class29_0.class88_0.Int16_0))
    {
      Class142 class142 = (Class142) null;
      if (this.Class29_0.class88_0.Int16_0 == (short) 5271)
      {
        while (class142 == null)
        {
          class142 = this.Class29_0.method_128(\u003CModule\u003E.smethod_6<string>(3902894922U));
          this.Class29_0.method_50(new Struct16(2, 2), (short) 1, false, false);
        }
        this.Class29_0.method_78(class142.Int32_0);
        Thread.Sleep(2500);
      }
      if (this.Class29_0.class88_0.Int16_0 != (short) 3071 && !this.bool_17)
      {
        this.Class29_0.method_54((short) 3071);
      }
      else
      {
        Struct16 int_11 = new Struct16(4, 5);
        if (this.Class29_0.Struct16_1.method_0(int_11) > 5)
        {
          this.Class29_0.method_50(int_11, (short) 1, true, true);
        }
        else
        {
          if (this.bool_17)
            Thread.Sleep(2500);
          Class142 sender = this.Class29_0.method_128(\u003CModule\u003E.smethod_9<string>(4249372005U));
          if (sender == null)
            return;
          if (this.Class29_0.method_141(sender, \u003CModule\u003E.smethod_7<string>(2960762044U), false))
            this.Class29_0.method_90((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2, (byte) 1);
          if (this.Class29_0.Control2_0.checkBox_13.Checked)
          {
            this.Class29_0.method_107();
            this.Class29_0.method_110();
          }
          Thread.Sleep(2500);
        }
      }
    }
    else
      this.method_54();
  }

  private void method_54()
  {
    if (this.Class29_0.Control2_0.checkBox_10.Checked && !string.IsNullOrEmpty(this.Class29_0.Control2_0.textBox_7.Text))
    {
      this.method_58();
    }
    else
    {
      if (!this.method_55())
        return;
      if (this.Class29_0.Control2_0.checkBox_8.Checked)
      {
        Struct16 int_11 = new List<Struct16>()
        {
          new Struct16((short) ((int) this.class142_1.Struct16_0.short_0 + 2), this.class142_1.Struct16_0.short_1),
          new Struct16((short) ((int) this.class142_1.Struct16_0.short_0 - 2), this.class142_1.Struct16_0.short_1),
          new Struct16(this.class142_1.Struct16_0.short_0, (short) ((int) this.class142_1.Struct16_0.short_1 + 2)),
          new Struct16(this.class142_1.Struct16_0.short_0, (short) ((int) this.class142_1.Struct16_0.short_1 - 2))
        }.Where<Struct16>((Func<Struct16, bool>) (class134_0 =>
        {
          // ISSUE: object of a compiler-generated type is created
          // ISSUE: variable of a compiler-generated type
          Class26.Class159 class159 = new Class26.Class159();
          // ISSUE: reference to a compiler-generated field
          class159.struct16_0 = class134_0;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated method
          return !this.Class29_0.method_44(class159.struct16_0) && !this.Class29_0.method_117(12).Any<Class142>(new Func<Class142, bool>(class159.method_0));
        })).OrderBy<Struct16, int>((Func<Struct16, int>) (class134_0 => class134_0.method_0(this.Class29_0.Struct16_1))).FirstOrDefault<Struct16>();
        if (int_11.method_0(this.Class29_0.Struct16_1) != 0 && !this.bool_17)
        {
          this.Class29_0.method_50(int_11, (short) 0, true, true);
          return;
        }
      }
      else if (this.class142_1.Struct16_0.method_0(this.Class29_0.Struct16_1) != 1 && !this.bool_17)
      {
        this.Class29_0.method_50(this.class142_1.Struct16_0, (short) 1, true, true);
        return;
      }
      Direction int_11_1 = this.class142_1.Struct16_0.method_4(this.Class29_0.Struct16_1);
      if (int_11_1 != this.Class29_0.Direction_1)
      {
        this.Class29_0.method_48(int_11_1);
      }
      else
      {
        if (this.thread_0 == null || !this.thread_0.IsAlive)
        {
          if (this.List_0.Contains(this.thread_0))
            this.List_0.Remove(this.thread_0);
          this.thread_0 = new Thread(new ThreadStart(this.method_56));
          this.List_0.Add(this.thread_0);
          this.thread_0.Start();
          if (this.Class29_0.Control2_0.toolStripMenuItem_2.Text == \u003CModule\u003E.smethod_8<string>(50828738U))
            this.thread_0.Abort();
        }
        if (!this.List_0.Contains(this.thread_0))
          this.thread_0.Abort();
        this.method_57();
        this.method_59();
        Thread.Sleep(50);
      }
    }
  }

  private bool method_55()
  {
    short? int160_1 = this.class142_1?.Class88_0.Int16_0;
    int? nullable = int160_1.HasValue ? new int?((int) int160_1.GetValueOrDefault()) : new int?();
    int int160_2 = (int) this.Class29_0.class88_0.Int16_0;
    if (nullable.GetValueOrDefault() == int160_2 & nullable.HasValue && this.Class29_0.method_131((Class140) this.class142_1, 12) && !this.Class29_0.method_44(this.class142_1.Struct16_0))
      return true;
    this.class142_1 = this.Class29_0.method_118(12, new ushort[1]
    {
      this.dictionary_0[this.Class29_0.class88_0.Int16_0]
    }).Where<Class142>((Func<Class142, bool>) (class142_0 => !this.Class29_0.method_44(class142_0.Struct16_0))).OrderBy<Class142, int>((Func<Class142, int>) (class142_0 => class142_0.Struct16_0.method_0(this.Class29_0.Struct16_1))).FirstOrDefault<Class142>();
    return this.class142_1 != null;
  }

  private void method_56()
  {
    while (this.Class29_0.Control2_0.button_19.Text == \u003CModule\u003E.smethod_9<string>(2178616966U))
    {
      try
      {
        bool flag1 = false;
        // ISSUE: object of a compiler-generated type is created
        // ISSUE: reference to a compiler-generated method
        List<string> list1 = this.Class29_0.Control2_0.list_2.Where<string>((Func<string, bool>) (string_0 => this.list_16.Any<string>(new Func<string, bool>(new Class26.Class160()
        {
          string_0 = string_0
        }.method_0)))).ToList<string>();
        List<string> list2 = this.Class29_0.Control2_0.list_2.Where<string>((Func<string, bool>) (class142_0 => this.list_18.Contains(class142_0))).ToList<string>();
        bool flag2 = this.Class29_0.Control2_0.list_2.Any<string>((Func<string, bool>) (class12_0 => class12_0.Contains(\u003CModule\u003E.smethod_6<string>(845240984U))));
        if (this.Class29_0.Control2_0.list_3.Count == 0)
          this.Class29_0.Control2_0.list_3.Add(\u003CModule\u003E.smethod_8<string>(2086852158U));
        foreach (string class143_1 in this.Class29_0.Control2_0.list_3)
        {
          // ISSUE: object of a compiler-generated type is created
          // ISSUE: variable of a compiler-generated type
          Class26.Class161 class161 = new Class26.Class161();
          foreach (string str in list1.Where<string>((Func<string, bool>) (class142_0 => this.Class29_0.method_28(this.Class29_0.Class133_0[class142_0]))))
          {
            if (str.Contains(\u003CModule\u003E.smethod_8<string>(2745641523U)))
            {
              if (!this.Class29_0.method_29(\u003CModule\u003E.smethod_7<string>(134252776U)) && !this.Class29_0.method_29(\u003CModule\u003E.smethod_5<string>(741859174U)) && !this.Class29_0.method_29(\u003CModule\u003E.smethod_7<string>(899319931U)) && !this.Class29_0.method_29(\u003CModule\u003E.smethod_7<string>(2547665136U)) && !this.Class29_0.method_29(\u003CModule\u003E.smethod_9<string>(1893611505U)))
                this.Class29_0.method_29(\u003CModule\u003E.smethod_8<string>(4040403772U));
            }
            else
            {
              this.Class29_0.method_107();
              this.Class29_0.method_110();
            }
            if (this.Class29_0.method_30(str))
            {
              this.Class29_0.method_107();
              this.Class29_0.method_110();
              while (this.Class29_0.Class76_0[1] != null || this.Class29_0.Class76_0[3] != null)
                Thread.Sleep(5);
              Thread.Sleep(5);
            }
          }
          foreach (string str in list2.Where<string>((Func<string, bool>) (class142_0 => this.Class29_0.method_28(this.Class29_0.Class133_0[class142_0]))))
          {
            // ISSUE: object of a compiler-generated type is created
            // ISSUE: variable of a compiler-generated type
            Class26.Class162 class162 = new Class26.Class162();
            // ISSUE: reference to a compiler-generated field
            class162.string_0 = this.Class29_0.Class76_0[1]?.String_0;
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated method
            if ((class162.string_0 == null || !this.list_20.Concat<string>((IEnumerable<string>) this.list_19).Any<string>(new Func<string, bool>(class162.method_0))) && string.IsNullOrEmpty(this.Class29_0.method_39()))
            {
              foreach (Class76 class76 in this.Class29_0.Class21_0)
              {
                // ISSUE: object of a compiler-generated type is created
                // ISSUE: variable of a compiler-generated type
                Class26.Class163 class163 = new Class26.Class163();
                // ISSUE: reference to a compiler-generated field
                class163.class76_0 = class76;
                // ISSUE: reference to a compiler-generated method
                if (this.list_19.Any<string>(new Func<string, bool>(class163.method_0)))
                {
                  // ISSUE: reference to a compiler-generated field
                  this.Class29_0.method_29(class163.class76_0.String_0);
                  break;
                }
              }
            }
            this.Class29_0.method_30(str);
          }
          // ISSUE: reference to a compiler-generated field
          class161.string_0 = this.Class29_0.Class76_0[1]?.String_0;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated method
          if (flag2 && (class161.string_0 == null || !this.list_20.Any<string>(new Func<string, bool>(class161.method_0))) && !string.IsNullOrEmpty(this.Class29_0.method_39()))
            flag1 = true;
          DateTime utcNow = DateTime.UtcNow;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated method
          while (flag1 && (class161.string_0 == null || !this.list_20.Concat<string>((IEnumerable<string>) this.list_19).Any<string>(new Func<string, bool>(class161.method_1))) && DateTime.UtcNow.Subtract(utcNow).TotalMilliseconds <= 500.0)
            Thread.Sleep(5);
          flag1 = false;
          Thread.Sleep(5);
          if (!(class143_1 == \u003CModule\u003E.smethod_9<string>(2572638612U)))
          {
            if (this.bool_4)
            {
              this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(673812530U), (Class142) null, this.Class29_0.Control2_0.checkBox_13.Checked, false);
            }
            else
            {
              this.method_36();
              if (class143_1 != \u003CModule\u003E.smethod_7<string>(1016981205U) && class143_1 != \u003CModule\u003E.smethod_6<string>(4033124943U))
                this.Class29_0.method_31(class143_1, this.class142_1, this.Class29_0.Control2_0.checkBox_13.Checked, false);
              else
                this.Class29_0.method_31(class143_1, (Class142) this.Class29_0.Class143_0, this.Class29_0.Control2_0.checkBox_13.Checked, false);
            }
          }
        }
      }
      catch
      {
      }
      Thread.Sleep(5);
    }
  }

  private void method_57()
  {
    try
    {
      if (!this.Class29_0.method_25((ushort) 147) && DateTime.UtcNow.Subtract(this.dateTime_19).TotalSeconds > 5.0 && this.Class29_0.Control2_0.checkBox_14.Checked)
      {
        if (!this.Class29_0.method_29(\u003CModule\u003E.smethod_8<string>(5905283U)) && !this.Class29_0.method_29(\u003CModule\u003E.smethod_8<string>(1446257195U)))
          this.Class29_0.method_29(\u003CModule\u003E.smethod_5<string>(1334622136U));
        this.dateTime_19 = DateTime.UtcNow;
      }
      List<string> list = this.Class29_0.Control2_0.list_2.Where<string>((Func<string, bool>) (class143_0 => this.list_17.Contains(class143_0))).ToList<string>();
      if (list.Count > 0 && !this.Class29_0.method_7(Enum10.Poison))
        this.Class29_0.method_58(\u003CModule\u003E.smethod_6<string>(4197202808U));
      if (this.Class29_0.Int32_2 <= 1)
      {
        foreach (string str in list)
          this.Class29_0.method_30(str);
      }
      else
      {
        foreach (string str in list)
        {
          if (this.Class29_0.method_28(this.Class29_0.Class133_0[str]) && this.Class29_0.method_30(\u003CModule\u003E.smethod_9<string>(277337945U)))
          {
            using (List<string>.Enumerator enumerator = list.GetEnumerator())
            {
              while (enumerator.MoveNext())
                this.Class29_0.method_30(enumerator.Current);
              break;
            }
          }
        }
      }
      foreach (string str in this.Class29_0.Control2_0.list_2.ToList<string>())
      {
        // ISSUE: object of a compiler-generated type is created
        // ISSUE: variable of a compiler-generated type
        Class26.Class164 class164 = new Class26.Class164();
        // ISSUE: reference to a compiler-generated field
        class164.string_0 = str;
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated method
        // ISSUE: reference to a compiler-generated field
        if (!this.list_17.Contains(class164.string_0) && !this.list_16.Any<string>(new Func<string, bool>(class164.method_0)) && !this.list_18.Contains(class164.string_0))
        {
          // ISSUE: reference to a compiler-generated field
          this.Class29_0.method_30(class164.string_0);
        }
      }
    }
    catch
    {
    }
  }

  private void method_58()
  {
    Class29 class29 = this.Class112_0.method_75(this.Class29_0.Control2_0.textBox_7.Text);
    if (class29 == null)
      return;
    while (!this.Class29_0.class88_0.method_5(this.Class29_0, this.struct16_1) || this.struct16_1.short_0 < (short) 6 || this.struct16_1.short_1 < (short) 6 || class29.class88_0.String_0.Contains(\u003CModule\u003E.smethod_6<string>(394725424U)) && class29.Class143_0.Struct16_0.method_0(this.struct16_1) > 9)
      this.struct16_1 = new Struct16(Class138.smethod_3(1, (int) this.Class29_0.class88_0.Byte_0 - 1), Class138.smethod_3(1, (int) this.Class29_0.class88_0.Byte_1 - 1));
    if ((int) class29.class88_0.Int16_0 != (int) this.Class29_0.class88_0.Int16_0)
    {
      Class142 class142 = this.Class29_0.method_128(\u003CModule\u003E.smethod_7<string>(1803799945U));
      if (class142 == null)
        return;
      this.Class29_0.method_78(class142.Int32_0);
      while (this.Class29_0.Class75_0 == null)
        Thread.Sleep(25);
      byte byte1 = this.Class29_0.Class75_0.Byte_1;
      int int320 = this.Class29_0.Class75_0.Int32_0;
      ushort uint162 = this.Class29_0.Class75_0.UInt16_2;
      ushort uint163 = this.Class29_0.Class75_0.UInt16_3;
      byte result;
      if (byte.TryParse(class29.class88_0.String_0.Replace(\u003CModule\u003E.smethod_5<string>(4087000904U), ""), out result))
      {
        this.Class29_0.method_90(byte1, int320, uint162, (ushort) ((uint) uint163 + 1U), (byte) 2);
        this.Class29_0.method_90(byte1, int320, uint162, (ushort) ((uint) uint163 + 1U), result);
      }
      Thread.Sleep(2000);
    }
    else
    {
      if (this.Class29_0.Struct16_1.method_0(this.struct16_1) > 2 && this.Class29_0.method_50(this.struct16_1, (short) 1, true, true))
        return;
      if (this.bool_4)
      {
        this.Class29_0.method_31(\u003CModule\u003E.smethod_8<string>(2568700728U), (Class142) null, this.Class29_0.Control2_0.checkBox_13.Checked, false);
      }
      else
      {
        this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(970957079U), (Class142) class29.Class143_0, this.Class29_0.Control2_0.checkBox_13.Checked, false);
        this.bool_4 = true;
      }
    }
  }

  private void method_59()
  {
    List<Class142> list = this.Class29_0.method_116().OfType<Class142>().Where<Class142>((Func<Class142, bool>) (struct17_1 => (struct17_1 is Class143 class143 ? (!class143.bool_1 ? 1 : 0) : 1) != 0 && !struct17_1.Boolean_7)).ToList<Class142>();
    if (this.Class29_0.Control2_0.checkBox_12.Checked)
    {
      foreach (Class142 class142 in list.Where<Class142>((Func<Class142, bool>) (class143_0 => !class143_0.Dictionary_0.ContainsKey((ushort) 187) || DateTime.UtcNow.Subtract(class143_0.Dictionary_0[(ushort) 187]).TotalSeconds > 4.0)))
      {
        this.method_36();
        this.method_46(\u003CModule\u003E.smethod_5<string>(2816246604U), class142, true, false);
      }
    }
    if (!this.Class29_0.Control2_0.checkBox_11.Checked)
      return;
    foreach (Class142 class142 in list.Where<Class142>((Func<Class142, bool>) (class143_0 =>
    {
      if (!(class143_0 is Class143))
        return false;
      return !class143_0.Dictionary_0.ContainsKey((ushort) 184) || DateTime.UtcNow.Subtract(class143_0.Dictionary_0[(ushort) 184]).TotalSeconds > 20.0;
    })))
    {
      this.method_36();
      this.method_46(\u003CModule\u003E.smethod_8<string>(751494619U), class142, true, false);
    }
  }

  private void method_60()
  {
    try
    {
      List<Class142> list = this.Class29_0.method_118(12, new ushort[1]
      {
        this.ushort_1
      }).Where<Class142>((Func<Class142, bool>) (class142_0 =>
      {
        if (this.Class29_0.class88_0.method_3(class142_0.Struct16_0))
          return false;
        return !this.dictionary_1.ContainsKey(class142_0.Int32_0) || DateTime.UtcNow.Subtract(this.dictionary_1[class142_0.Int32_0]).TotalSeconds > 5.0;
      })).ToList<Class142>();
      if (list.Count > 0)
      {
        if (this.class142_2 != null && list.Contains(this.class142_2))
          return;
        this.class142_2 = list.OrderBy<Class142, int>((Func<Class142, int>) (class142_0 => class142_0.Struct16_0.method_0(this.Class29_0.Struct16_1))).First<Class142>();
      }
      else
        this.class142_2 = (Class142) null;
    }
    catch
    {
      this.class142_2 = (Class142) null;
    }
  }

  private void method_61()
  {
    if (this.Class29_0.temClass_0.Equals((object) TemClass.Monk) && this.Class29_0.medClass_0.Equals((object) MedClass.Druid) && !this.Class29_0.method_25((ushort) 183) && !this.Class29_0.method_25((ushort) 184) && !this.Class29_0.method_25((ushort) 185) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_7<string>(1156943685U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(2688029317U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_6<string>(1024802914U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(1285201594U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_6<string>(1853062430U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_7<string>(475854018U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_5<string>(3296186079U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_7<string>(2391642361U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_6<string>(587233461U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_8<string>(2508214217U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_6<string>(1829622735U), (Class142) null, this.bool_2, true))
      this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(1922850559U), (Class142) null, this.bool_2, true);
    Thread.Sleep(80);
  }

  private void method_62()
  {
    if (this.Class29_0.temClass_0.Equals((object) TemClass.Monk) && (this.Class29_0.method_25((ushort) 183) || this.Class29_0.method_25((ushort) 184) || this.Class29_0.method_25((ushort) 185)) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_5<string>(2547743171U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_6<string>(480443135U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_7<string>(335891538U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_5<string>(200532096U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(3089464780U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(853820256U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(2662476237U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(3393316325U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_8<string>(827803653U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_7<string>(3921776671U), (Class142) null, this.bool_2, true) && !this.Class29_0.method_31(\u003CModule\u003E.smethod_8<string>(642591U), (Class142) null, this.bool_2, true))
      this.Class29_0.method_31(\u003CModule\u003E.smethod_9<string>(1922850559U), (Class142) null, this.bool_2, true);
    Thread.Sleep(80);
  }

  private void method_63()
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class26.Class165 class165 = new Class26.Class165();
    // ISSUE: reference to a compiler-generated field
    class165.class26_0 = this;
    if (this.bool_8)
    {
      Thread.Sleep(100);
    }
    else
    {
      // ISSUE: reference to a compiler-generated field
      class165.bool_0 = this.Class29_0.Control2_0.checkBox_99.Checked;
      // ISSUE: reference to a compiler-generated field
      class165.bool_1 = this.Class29_0.Control2_0.checkBox_100.Checked;
      int num = this.class142_2.Struct16_0.method_0(this.Class29_0.Struct16_0);
      Direction direction = this.class142_2.Struct16_0.method_4(this.Class29_0.Struct16_0);
      // ISSUE: reference to a compiler-generated field
      class165.string_0 = this.Class29_0.Class76_0[1]?.String_0;
      // ISSUE: reference to a compiler-generated method
      bool flag1 = this.Class29_0.list_5.Any<Class17>(new Func<Class17, bool>(class165.method_0));
      // ISSUE: reference to a compiler-generated method
      bool flag2 = this.Class29_0.list_6.Any<Class10>(new Func<Class10, bool>(class165.method_1));
      try
      {
        if (this.Class29_0.class88_0.String_0.Contains(\u003CModule\u003E.smethod_5<string>(3231911557U)))
        {
          TimeSpan timeSpan;
          if (this.list_31.Contains((int) this.class142_2.UInt16_0))
          {
            timeSpan = DateTime.UtcNow.Subtract(this.dateTime_21);
            if (timeSpan.TotalSeconds > 2.0 && !this.bool_26)
            {
              if (this.Class29_0.string_5 != \u003CModule\u003E.smethod_6<string>(3991663225U))
              {
                this.bool_26 = true;
                this.method_62();
                this.Class29_0.method_36();
                this.dateTime_21 = DateTime.UtcNow;
                this.method_61();
                this.bool_26 = false;
                goto label_14;
              }
              else
                goto label_14;
            }
          }
          if (this.list_32.Contains((int) this.class142_2.UInt16_0))
          {
            timeSpan = DateTime.UtcNow.Subtract(this.dateTime_21);
            if (timeSpan.TotalSeconds > 2.0)
            {
              if (!this.bool_26)
              {
                if (this.Class29_0.string_5 != \u003CModule\u003E.smethod_7<string>(2849341681U))
                {
                  this.bool_26 = true;
                  this.method_62();
                  this.Class29_0.method_35();
                  this.dateTime_21 = DateTime.UtcNow;
                  this.method_61();
                  this.bool_26 = false;
                }
              }
            }
          }
        }
      }
      catch
      {
        this.bool_26 = false;
      }
label_14:
      if (flag1 | flag2)
      {
        if (num == 1 && direction == this.Class29_0.Direction_0)
        {
          if (this.Class29_0.Control2_0.checkBox_98.Checked && this.class142_2.Byte_1 > (byte) 30 && this.Class29_0.method_28(this.Class29_0.Class133_0[\u003CModule\u003E.smethod_6<string>(215163494U)]))
            this.Class29_0.method_30(\u003CModule\u003E.smethod_8<string>(1308786590U));
          foreach (string str in this.list_23)
          {
            foreach (KeyValuePair<string, Class132> keyValuePair in this.Class29_0.Class133_0.Dictionary_0)
            {
              if (keyValuePair.Key.Contains(str))
                this.Class29_0.method_30(keyValuePair.Key);
            }
          }
          // ISSUE: reference to a compiler-generated method
          if (class165.method_2())
          {
            TimeSpan timeSpan;
            if (this.Class29_0.Control2_0.checkBox_94.Checked && this.class142_2.Byte_1 >= (byte) 60 && direction == this.Class29_0.Direction_1 && this.Class29_0.Class143_0.Boolean_0 && this.Class29_0.Class143_0.Double_3 - DateTime.UtcNow.Subtract(this.Class29_0.Class143_0.DateTime_5).TotalSeconds > 8.0 && this.Class29_0.method_28(this.Class29_0.Class133_0[\u003CModule\u003E.smethod_7<string>(2770689069U)]))
            {
              bool flag3 = false;
              if ((!this.Class29_0.method_23(\u003CModule\u003E.smethod_5<string>(1372714507U)) || !this.Class29_0.method_28(this.Class29_0.Class133_0[\u003CModule\u003E.smethod_7<string>(1691097133U)])) && (!this.Class29_0.method_23(\u003CModule\u003E.smethod_6<string>(2621154693U)) || !this.Class29_0.method_28(this.Class29_0.Class133_0[\u003CModule\u003E.smethod_6<string>(2621154693U)])) && (!this.Class29_0.method_23(\u003CModule\u003E.smethod_9<string>(2512982469U)) || !this.Class29_0.method_28(this.Class29_0.Class133_0[\u003CModule\u003E.smethod_7<string>(1703945369U)])))
              {
                if (this.Class29_0.method_22(\u003CModule\u003E.smethod_6<string>(576825312U)) && this.Class29_0.method_27(this.Class29_0.Class21_0[\u003CModule\u003E.smethod_9<string>(3652768706U)]))
                {
                  timeSpan = DateTime.UtcNow.Subtract(this.Class29_0.Class21_0[\u003CModule\u003E.smethod_7<string>(2624852092U)].DateTime_0);
                  if (timeSpan.TotalSeconds <= 28.0)
                    goto label_34;
                }
                else
                  goto label_34;
              }
              flag3 = true;
label_34:
              if (flag3)
              {
                this.Class29_0.method_30(\u003CModule\u003E.smethod_5<string>(2385401635U));
                this.Class29_0.method_30(\u003CModule\u003E.smethod_7<string>(574975766U));
                this.Class29_0.method_30(\u003CModule\u003E.smethod_9<string>(277337945U));
                this.Class29_0.method_30(\u003CModule\u003E.smethod_5<string>(1372714507U));
                this.Class29_0.method_30(\u003CModule\u003E.smethod_6<string>(63433663U));
                this.Class29_0.method_30(\u003CModule\u003E.smethod_8<string>(3389958485U));
                this.Class29_0.method_29(\u003CModule\u003E.smethod_7<string>(2624852092U));
                this.dateTime_22 = DateTime.UtcNow;
                return;
              }
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated method
            foreach (string str in this.Class29_0.Control2_0.list_4.Where<string>(class165.func_0 ?? (class165.func_0 = new Func<string, bool>(class165.method_3))))
            {
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated method
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated method
              List<Class142> list = this.Class29_0.method_119(8).Where<Class142>(class165.func_1 ?? (class165.func_1 = new Func<Class142, bool>(class165.method_4))).Where<Class142>(class165.func_2 ?? (class165.func_2 = new Func<Class142, bool>(class165.method_5))).ToList<Class142>();
              if (this.list_30.Contains(str) && this.Class29_0.Struct16_0.method_4(this.class142_2.Struct16_0) == this.class142_2.Direction_0)
              {
                if ((Decimal) list.Count >= this.Class29_0.Control2_0.numericUpDown_24.Value)
                {
                  if (str == \u003CModule\u003E.smethod_7<string>(2089782609U))
                  {
                    timeSpan = DateTime.UtcNow.Subtract(this.Class29_0.Class133_0[str].DateTime_0);
                    if (timeSpan.TotalMilliseconds < 27.0)
                      continue;
                  }
                  this.Class29_0.method_30(str);
                }
              }
              else
              {
                // ISSUE: reference to a compiler-generated method
                if (class165.method_2())
                {
                  if (str == \u003CModule\u003E.smethod_7<string>(3965279841U))
                  {
                    timeSpan = DateTime.UtcNow.Subtract(this.Class29_0.Class133_0[str].DateTime_0);
                    if (timeSpan.TotalMilliseconds < 11.0)
                      continue;
                  }
                  if (!(str == \u003CModule\u003E.smethod_7<string>(2949379464U)) || !((Decimal) list.Count <= this.Class29_0.Control2_0.numericUpDown_24.Value))
                  {
                    this.Class29_0.method_30(str);
                    this.dateTime_22 = DateTime.UtcNow;
                    break;
                  }
                }
                else
                  break;
              }
            }
          }
        }
        else if (num >= 2 && num <= 11 && direction == this.Class29_0.Direction_0)
        {
          // ISSUE: reference to a compiler-generated method
          if (class165.method_2())
          {
            if (this.Class29_0.Control2_0.checkBox_95.Checked & flag1)
            {
              foreach (string str in this.Class29_0.Control2_0.list_4)
              {
                // ISSUE: object of a compiler-generated type is created
                // ISSUE: variable of a compiler-generated type
                Class26.Class166 class166 = new Class26.Class166();
                // ISSUE: reference to a compiler-generated field
                class166.string_0 = str;
                // ISSUE: reference to a compiler-generated method
                if (class165.method_2())
                {
                  if (num <= 5)
                  {
                    // ISSUE: reference to a compiler-generated method
                    if (this.list_27.Any<string>(new Func<string, bool>(class166.method_0)))
                    {
                      // ISSUE: reference to a compiler-generated field
                      this.method_48(class166.string_0);
                    }
                    if (num <= 3)
                    {
                      // ISSUE: reference to a compiler-generated field
                      if (this.list_26.Contains(class166.string_0))
                      {
                        // ISSUE: reference to a compiler-generated field
                        this.Class29_0.method_30(class166.string_0);
                      }
                      // ISSUE: reference to a compiler-generated method
                      if (this.list_26.Any<string>(new Func<string, bool>(class166.method_1)))
                      {
                        // ISSUE: reference to a compiler-generated field
                        this.method_48(class166.string_0);
                      }
                      // ISSUE: reference to a compiler-generated method
                      if (num <= 2 && this.list_25.Any<string>(new Func<string, bool>(class166.method_2)))
                      {
                        // ISSUE: reference to a compiler-generated field
                        this.method_48(class166.string_0);
                      }
                    }
                  }
                  // ISSUE: reference to a compiler-generated field
                  if (this.Class29_0.string_0.Contains(class166.string_0))
                    this.dateTime_22 = DateTime.UtcNow;
                }
                else
                  break;
              }
            }
            if (this.Class29_0.Control2_0.checkBox_96.Checked && num <= 4 && direction == this.Class29_0.Direction_0)
            {
              switch (this.Class29_0.temClass_0)
              {
                case TemClass.Warrior:
                  if (this.Class29_0.method_23(\u003CModule\u003E.smethod_5<string>(1130837101U)) && DateTime.UtcNow.Subtract(this.Class29_0.Class133_0[\u003CModule\u003E.smethod_7<string>(1655117323U)].DateTime_0).TotalMilliseconds > 30000.0)
                  {
                    this.Class29_0.method_30(\u003CModule\u003E.smethod_7<string>(1655117323U));
                    break;
                  }
                  break;
                case TemClass.Monk:
                  if (this.Class29_0.method_22(\u003CModule\u003E.smethod_6<string>(996372742U)) && DateTime.UtcNow.Subtract(this.Class29_0.Class21_0.method_2(\u003CModule\u003E.smethod_9<string>(1142886036U)).DateTime_0).TotalMilliseconds > 15000.0)
                  {
                    this.Class29_0.method_29(\u003CModule\u003E.smethod_6<string>(996372742U));
                    break;
                  }
                  break;
              }
            }
          }
          if (((!this.Class29_0.temClass_0.Equals((object) TemClass.Rogue) ? 0 : (this.Class29_0.Control2_0.checkBox_95.Checked ? 1 : 0)) & (flag2 ? 1 : 0)) != 0)
            this.method_48(\u003CModule\u003E.smethod_6<string>(845240984U));
        }
        Thread.Sleep(200);
      }
      else
      {
        if (this.bool_8)
          return;
        string str = string.Empty;
        switch (this.Class29_0.temClass_0)
        {
          case TemClass.Warrior:
            str = this.Class29_0.method_38();
            break;
          case TemClass.Rogue:
            str = this.Class29_0.method_39();
            break;
          case TemClass.Monk:
            str = this.Class29_0.method_37();
            break;
        }
        DateTime utcNow = DateTime.UtcNow;
        while (DateTime.UtcNow.Subtract(utcNow).TotalSeconds <= 1.5 && !(this.Class29_0.Class76_0[1].String_0 == str))
          Thread.Sleep(50);
      }
    }
  }

  private bool method_64(Control4 string_1)
  {
    if (string_1 == null)
      return false;
    return string_1.checkBox_11.Checked || string_1.checkBox_12.Checked;
  }

  private void method_65()
  {
    try
    {
      if (!(this.Class29_0.Control2_0?.button_73.Text == \u003CModule\u003E.smethod_8<string>(2351233537U)))
        return;
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      Class26.Class167 class167 = new Class26.Class167();
      // ISSUE: reference to a compiler-generated field
      class167.class26_0 = this;
      // ISSUE: reference to a compiler-generated field
      class167.bool_0 = this.Class29_0.Control2_0.checkBox_99.Checked;
      // ISSUE: reference to a compiler-generated field
      class167.bool_1 = this.Class29_0.Control2_0.checkBox_100.Checked;
      if (this.list_12.Count > 0 && this.Class29_0.Control2_0.checkBox_42.Checked)
        return;
      if (!this.Class29_0.Control2_0.checkBox_70.Checked)
        this.Class29_0.Control2_0.checkBox_70.Checked = true;
      if (!this.Class29_0.Control2_0.checkBox_97.Checked)
      {
        // ISSUE: object of a compiler-generated type is created
        // ISSUE: variable of a compiler-generated type
        Class26.Class168 class168 = new Class26.Class168()
        {
          class167_0 = class167,
          list_0 = this.Class29_0.method_125()
        };
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        class168.ienumerable_0 = class168.list_0.Where<Class143>((Func<Class143, bool>) (class143_0 => class143_0 != this.Class29_0.Class143_0 && !this.Class29_0.Control2_0.listBox_6.Items.OfType<string>().Contains<string>(class143_0.String_5, (IEqualityComparer<string>) StringComparer.OrdinalIgnoreCase)));
        List<Class142> source = this.Class29_0.method_119(10);
        // ISSUE: reference to a compiler-generated field
        class168.class143_2 = (Class143) null;
        // ISSUE: reference to a compiler-generated field
        class168.class143_0 = (Class143) null;
        // ISSUE: reference to a compiler-generated field
        class168.class143_1 = (Class143) null;
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated method
        if (this.Class29_0.Control2_0.checkBox_93.Checked && (class168.class143_0 = class168.list_0.FirstOrDefault<Class143>((Func<Class143, bool>) (class142_0 => class142_0.String_5.Equals(this.Class29_0.Control2_0.textBox_24.Text, StringComparison.OrdinalIgnoreCase)))) != null && source.Any<Class142>(new Func<Class142, bool>(class168.method_0)))
        {
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          class168.class143_2 = class168.class143_0;
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated method
        if (class168.class143_2 == null && this.Class29_0.Control2_0.checkBox_101.Checked && (class168.class143_1 = class168.list_0.FirstOrDefault<Class143>((Func<Class143, bool>) (class142_0 => class142_0.String_5.Equals(this.Class29_0.Control2_0.textBox_25.Text, StringComparison.OrdinalIgnoreCase)))) != null && source.Any<Class142>(new Func<Class142, bool>(class168.method_1)))
        {
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          class168.class143_2 = class168.class143_1;
        }
        // ISSUE: reference to a compiler-generated field
        if (class168.class143_2 == null)
        {
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          class168.class143_2 = class168.class143_0 ?? class168.class143_1;
        }
        // ISSUE: reference to a compiler-generated method
        // ISSUE: reference to a compiler-generated method
        List<Class142> list = source.OrderBy<Class142, Decimal>(new Func<Class142, Decimal>(class168.method_2)).Where<Class142>(new Func<Class142, bool>(class168.method_3)).Where<Class142>((Func<Class142, bool>) (class134_0 =>
        {
          Stack<Struct16> struct16Stack = this.Class29_0.Class103_0.method_2(this.Class29_0.Struct16_1, class134_0.Struct16_0, true, (short) 0);
          return struct16Stack.Count > 0 && struct16Stack.Count < 15;
        })).ToList<Class142>();
        if (list.Count > 0)
        {
          bool flag = true;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          if (this.class142_2 == null || (flag = !list.Contains(this.class142_2)) || (class168.class167_0.bool_0 ? (!this.class142_2.Boolean_1 ? 1 : 0) : 0) != 0 || (class168.class167_0.bool_1 ? (!this.class142_2.Boolean_2 ? 1 : 0) : 0) != 0 || this.class142_2.Struct16_0.method_0(this.Class29_0.Struct16_0) > 1)
          {
            // ISSUE: reference to a compiler-generated method
            this.class142_2 = list.FirstOrDefault<Class142>(new Func<Class142, bool>(class168.method_4)) ?? (!flag ? this.class142_2 : list.FirstOrDefault<Class142>());
          }
          if (this.class142_2 != null)
          {
            if (this.bool_25)
              this.Class29_0.method_62((byte) 2, this.class142_2.Int32_0, \u003CModule\u003E.smethod_5<string>(197201301U) + this.class142_2.Byte_1.ToString() + \u003CModule\u003E.smethod_9<string>(3731506540U));
            else
              this.Class29_0.method_62((byte) 2, this.class142_2.Int32_0, \u003CModule\u003E.smethod_9<string>(3300125202U));
            if (this.class142_2.Struct16_0.method_0(this.Class29_0.Struct16_0) > 4 && this.list_6.Any<Class143>((Func<Class143, bool>) (value => value.Boolean_6)))
              return;
            if (this.class142_2.Struct16_0.method_0(this.Class29_0.Struct16_0) > 1)
            {
              Direction int_11 = this.class142_2.Struct16_0.method_4(this.Class29_0.Struct16_0);
              this.Class29_0.method_50(this.class142_2.Struct16_0, (short) 1, true, true);
              if (this.Class29_0.Control2_0.checkBox_95.Checked && ((int) this.class142_2.Struct16_0.short_0 == (int) this.Class29_0.Struct16_0.short_0 || (int) this.class142_2.Struct16_0.short_1 == (int) this.Class29_0.Struct16_0.short_1))
              {
                if (this.Class29_0.Direction_0 != int_11)
                  this.Class29_0.method_48(int_11);
                this.method_63();
              }
            }
            else if (Struct16.smethod_0(this.class142_2.Struct16_0, this.Class29_0.Struct16_0) && !this.Class29_0.method_7(Enum10.BeagSuain) && !this.Class29_0.method_7(Enum10.Pramh) && !this.Class29_0.method_7(Enum10.Suain))
            {
              this.Class29_0.method_49(Class138.smethod_0<Direction>());
            }
            else
            {
              if (Struct16.smethod_1(this.Class29_0.Struct16_0, this.Class29_0.Struct16_1))
              {
                if (DateTime.UtcNow.Subtract(this.dateTime_23).TotalMilliseconds > 1000.0)
                {
                  this.Class29_0.method_105(true);
                  this.Class29_0.Direction_0 = this.Class29_0.Direction_1;
                  this.dateTime_23 = DateTime.UtcNow;
                  this.dateTime_24 = DateTime.UtcNow;
                }
              }
              else
                this.dateTime_23 = DateTime.UtcNow;
              Direction int_11 = this.class142_2.Struct16_0.method_4(this.Class29_0.Struct16_0);
              if (int_11 != this.Class29_0.Direction_0)
                this.Class29_0.method_48(int_11);
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              if ((this.bool_8 || this.method_64(this.control4_0)) && (class168.class167_0.bool_1 ? (source.Any<Class142>((Func<Class142, bool>) (value => !value.Boolean_2)) ? 1 : 0) : 1) != 0 && (class168.class167_0.bool_0 ? (source.Any<Class142>((Func<Class142, bool>) (ushort_0 => !ushort_0.Boolean_1)) ? 1 : 0) : 1) != 0)
              {
                Thread.Sleep(100);
                return;
              }
              this.method_63();
            }
          }
        }
        if (this.class142_2 != null && list.Count != 0)
          return;
        this.class142_2 = (Class142) null;
        this.method_32(false);
      }
      else
      {
        // ISSUE: object of a compiler-generated type is created
        // ISSUE: variable of a compiler-generated type
        Class26.Class170 class170 = new Class26.Class170();
        // ISSUE: reference to a compiler-generated field
        class170.class167_0 = class167;
        // ISSUE: reference to a compiler-generated field
        class170.string_0 = this.Class29_0.Control2_0.textBox_23.Text;
        // ISSUE: reference to a compiler-generated method
        List<Class142> list = this.Class29_0.method_119(8).Where<Class142>((Func<Class142, bool>) (class143_0 => !this.Class29_0.method_44(class143_0.Struct16_0))).Where<Class142>((Func<Class142, bool>) (class143_0 => !this.Class29_0.class88_0.method_3(class143_0.Struct16_0))).Where<Class142>(new Func<Class142, bool>(class170.method_0)).ToList<Class142>();
        // ISSUE: reference to a compiler-generated field
        this.Class29_0.Control2_0.textBox_17.Text = class170.string_0;
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated method
        this.class142_2 = !this.Class29_0.Control2_0.radioButton_4.Checked ? this.Class112_0.method_75(this.Class29_0.Control2_0.textBox_23.Text).Class26_0.class142_2 : (!list.Any<Class142>() ? (Class142) null : list.Where<Class142>(new Func<Class142, bool>(class170.class167_0.method_0)).OrderBy<Class142, int>((Func<Class142, int>) (class29_0 => class29_0.Struct16_0.method_0(this.Class29_0.Struct16_0))).First<Class142>());
        if (list.Count > 0)
        {
          if (this.class142_2 == null)
            return;
          this.Class29_0.Control2_0.checkBox_68.Checked = false;
          if (this.bool_25)
            this.Class29_0.method_62((byte) 2, this.class142_2.Int32_0, \u003CModule\u003E.smethod_5<string>(2312547688U));
          if (this.class142_2.Struct16_0.method_0(this.Class29_0.Struct16_0) > 5 && this.list_6.Any<Class143>((Func<Class143, bool>) (string_1 => string_1.Boolean_6)))
            return;
          if (this.class142_2.Struct16_0.method_0(this.Class29_0.Struct16_0) > 1)
          {
            Direction direction = this.class142_2.Struct16_0.method_4(this.Class29_0.Struct16_0);
            if (this.Class29_0.method_50(this.class142_2.Struct16_0, (short) 1, true, true))
              return;
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated method
            this.class142_2 = !this.Class29_0.Control2_0.radioButton_4.Checked ? this.Class112_0.method_75(this.Class29_0.Control2_0.textBox_23.Text).Class26_0.class142_2 : (!list.Any<Class142>() ? (Class142) null : list.Where<Class142>(new Func<Class142, bool>(class170.class167_0.method_1)).OrderBy<Class142, int>((Func<Class142, int>) (class145_0 => class145_0.Struct16_0.method_0(this.Class29_0.Struct16_0))).First<Class142>());
            if (this.class142_2 == null || (int) this.class142_2.Struct16_0.short_0 != (int) this.Class29_0.Struct16_0.short_0 && (int) this.class142_2.Struct16_0.short_1 != (int) this.Class29_0.Struct16_0.short_1 || direction != this.Class29_0.Direction_0 || !this.Class29_0.Control2_0.checkBox_95.Checked)
              return;
            this.method_63();
          }
          else if (Struct16.smethod_0(this.class142_2.Struct16_0, this.Class29_0.Struct16_0) && !this.Class29_0.method_7(Enum10.BeagSuain) && !this.Class29_0.method_7(Enum10.Pramh) && !this.Class29_0.method_7(Enum10.Suain))
          {
            this.Class29_0.method_49(Class138.smethod_0<Direction>());
          }
          else
          {
            if (Struct16.smethod_1(this.Class29_0.Struct16_0, this.Class29_0.Struct16_1))
              this.Class29_0.method_105(true);
            Direction int_11 = this.class142_2.Struct16_0.method_4(this.Class29_0.Struct16_0);
            if (int_11 != this.Class29_0.Direction_0)
              this.Class29_0.method_48(int_11);
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            if (!this.bool_8 && this.method_64(this.control4_0) && (class170.class167_0.bool_1 ? (list.All<Class142>((Func<Class142, bool>) (class177_1 => class177_1.Boolean_2)) ? 1 : 0) : 1) != 0 && (class170.class167_0.bool_0 ? (list.All<Class142>((Func<Class142, bool>) (obj0 => obj0.Boolean_1)) ? 1 : 0) : 1) != 0)
              return;
            this.method_63();
          }
        }
        else
        {
          this.class142_2 = (Class142) null;
          if (this.Class29_0.Control2_0.checkBox_68.Checked)
            return;
          this.Class29_0.Control2_0.checkBox_68.Checked = true;
        }
      }
    }
    catch
    {
    }
  }

  private void method_66()
  {
    if (this.Class29_0.Control2_0 != null && this.Class29_0.Control2_0.button_15.Text == \u003CModule\u003E.smethod_6<string>(2384646980U))
      this.method_69();
    if (this.Class29_0.Control2_0?.button_17.Text == \u003CModule\u003E.smethod_8<string>(3184522924U))
    {
      if (!this.Class29_0.Class21_0.method_0(\u003CModule\u003E.smethod_8<string>(3823161601U)) && !this.bool_20)
        this.method_74();
      else if (this.Class29_0.Class21_0.method_0(\u003CModule\u003E.smethod_9<string>(116508779U)) && !this.bool_20)
      {
        this.Class29_0.method_29(\u003CModule\u003E.smethod_8<string>(3823161601U));
        this.bool_20 = true;
      }
      else if (!this.method_80(this.list_33[0]))
        this.method_76(this.list_33[0]);
      else if (!this.method_80(this.list_33[1]))
        this.method_76(this.list_33[1]);
      else if (!this.method_80(this.list_33[2]))
        this.method_76(this.list_33[2]);
      else if (!this.method_80(this.list_33[3]))
        this.method_76(this.list_33[3]);
      else
        this.method_73();
    }
    Struct16 struct16;
    if (this.Class29_0.Control2_0?.button_16.Text == \u003CModule\u003E.smethod_6<string>(2384646980U))
    {
      if (!this.bool_21 && !this.bool_22)
      {
        this.Class29_0.method_107();
        this.bool_22 = true;
        Thread.Sleep(2000);
      }
      if (this.bool_23)
      {
        if (this.Class29_0.class88_0.Int16_0 == (short) 410 && this.Class29_0.Struct16_1.method_1((short) 12, (short) 8) <= 3)
        {
          for (int index = 0; index < 3; ++index)
            SystemSounds.Beep.Play();
          this.Class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_5<string>(2974813469U));
          this.Class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_6<string>(9025838U));
          this.Class29_0.Control2_0.button_16.Text = \u003CModule\u003E.smethod_6<string>(2929006759U);
          return;
        }
        this.Class29_0.method_51(new Struct17((short) 410, (short) 12, (short) 8), (short) 3, false, true, true);
        return;
      }
      if (!this.Class29_0.method_22(\u003CModule\u003E.smethod_5<string>(434778828U)) && !this.bool_21)
      {
        if (this.Class29_0.class88_0.Int16_0 == (short) 410)
        {
          struct16 = this.Class29_0.Struct16_1;
          if (struct16.method_1((short) 12, (short) 8) <= 3)
          {
            this.Class29_0.method_88((byte) 1, this.Class29_0.method_128(\u003CModule\u003E.smethod_9<string>(502922870U)).Int32_0, (ushort) 2883, Array.Empty<object>());
            while (this.Class29_0.Class75_0 == null)
              Thread.Sleep(100);
            for (int index = 0; index < 5; ++index)
              this.Class29_0.method_89(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) ((uint) this.Class29_0.Class75_0.UInt16_3 + 1U));
            this.Class29_0.method_90(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) ((uint) this.Class29_0.Class75_0.UInt16_3 + 1U), (byte) 1);
            for (int index = 0; index < 4; ++index)
              this.Class29_0.method_89(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) ((uint) this.Class29_0.Class75_0.UInt16_3 + 1U));
            this.Class29_0.Class75_0.method_4();
            Thread.Sleep(2000);
            goto label_131;
          }
        }
        this.Class29_0.method_51(new Struct17((short) 410, (short) 12, (short) 8), (short) 3, false, true, true);
        return;
      }
      this.bool_21 = true;
      this.Class29_0.method_29(\u003CModule\u003E.smethod_7<string>(3775573280U));
      if (!this.Class29_0.method_22(\u003CModule\u003E.smethod_7<string>(877018725U)))
      {
        if (!this.bool_23 && (this.Class29_0.Class21_0.method_1(\u003CModule\u003E.smethod_8<string>(1447572868U), true) < 12 || this.Class29_0.Class21_0.method_1(\u003CModule\u003E.smethod_7<string>(1396394327U), true) < 12))
        {
          if (this.Class29_0.class88_0.Int16_0 != (short) 2120)
            this.Class29_0.method_54((short) 2120);
          else
            this.method_83();
        }
        else
        {
          if (this.Class29_0.class88_0.Int16_0 == (short) 410)
          {
            struct16 = this.Class29_0.Struct16_1;
            if (struct16.method_1((short) 12, (short) 8) <= 3)
            {
              this.Class29_0.method_88((byte) 1, this.Class29_0.method_128(\u003CModule\u003E.smethod_5<string>(1504109804U)).Int32_0, (ushort) 2883, Array.Empty<object>());
              while (this.Class29_0.Class75_0 == null)
                Thread.Sleep(100);
              for (int index = 0; index < 3; ++index)
                this.Class29_0.method_89(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) ((uint) this.Class29_0.Class75_0.UInt16_3 + 1U));
              this.Class29_0.Class75_0.method_4();
              goto label_131;
            }
          }
          this.Class29_0.method_51(new Struct17((short) 410, (short) 12, (short) 8), (short) 3, false, true, true);
          return;
        }
      }
      else
      {
        // ISSUE: object of a compiler-generated type is created
        // ISSUE: variable of a compiler-generated type
        Class26.Class171 class171 = new Class26.Class171();
        // ISSUE: reference to a compiler-generated field
        class171.struct19_0 = new Struct19(new Struct16((short) ((int) this.Class29_0.Struct16_1.short_0 - 2), (short) ((int) this.Class29_0.Struct16_1.short_1 - 2)), new Struct18((short) 5, (short) 5));
        if (this.Class29_0.Class21_0.method_1(\u003CModule\u003E.smethod_6<string>(3223400084U), true) < this.Class29_0.Class21_0.method_1(\u003CModule\u003E.smethod_8<string>(433845707U), true))
        {
          bool flag = false;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated method
          foreach (Class140 class140 in this.Class29_0.method_123(4, new ushort[1]
          {
            (ushort) 45
          }).Where<Class141>(class171.func_0 ?? (class171.func_0 = new Func<Class141, bool>(class171.method_0))))
          {
            this.Class29_0.method_93((byte) 0, class140.Struct16_0);
            flag = true;
          }
          if (!flag && !this.bool_24)
          {
            SystemSounds.Beep.Play();
            this.Class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_5<string>(968495565U));
            this.bool_24 = true;
            return;
          }
          Thread.Sleep(2000);
          return;
        }
        if (this.Class29_0.Class21_0.method_1(\u003CModule\u003E.smethod_5<string>(2735782316U), true) > this.Class29_0.Class21_0.method_1(\u003CModule\u003E.smethod_7<string>(877018725U), true))
        {
          this.Class29_0.method_95(this.Class29_0.Class21_0.method_2(\u003CModule\u003E.smethod_7<string>(2143654784U)).Byte_0, this.Class29_0.Struct16_1, this.Class29_0.Class21_0.method_2(\u003CModule\u003E.smethod_5<string>(2735782316U)).Int32_0 - this.Class29_0.Class21_0.method_1(\u003CModule\u003E.smethod_9<string>(1132118721U), true));
          Thread.Sleep(2000);
          return;
        }
        switch (this.Class29_0.Class21_0.method_1(\u003CModule\u003E.smethod_7<string>(877018725U), true))
        {
          case 1:
            if (this.Class29_0.class88_0.Int16_0 == (short) 1960)
            {
              struct16 = this.Class29_0.Struct16_0;
              if (struct16.method_0(new Struct16(7, 7)) <= 2)
              {
                this.Class29_0.method_60((byte) 0, \u003CModule\u003E.smethod_7<string>(877018725U));
                while (this.Class29_0.Class75_0 == null)
                  Thread.Sleep(100);
                for (int index = 0; index < 8; ++index)
                  this.Class29_0.method_89(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) ((uint) this.Class29_0.Class75_0.UInt16_3 + 1U));
                Thread.Sleep(2000);
                this.bool_23 = true;
                break;
              }
            }
            this.Class29_0.method_51(new Struct17((short) 1960, (short) 7, (short) 7), (short) 1, false, true, true);
            return;
          case 2:
            if (this.Class29_0.class88_0.Int16_0 == (short) 498)
            {
              struct16 = this.Class29_0.Struct16_0;
              if (struct16.method_0(new Struct16(6, 6)) <= 2)
              {
                this.Class29_0.method_60((byte) 0, \u003CModule\u003E.smethod_6<string>(813845659U));
                while (this.Class29_0.Class75_0 == null)
                  Thread.Sleep(100);
                for (int index = 0; index < 8; ++index)
                  this.Class29_0.method_89(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) ((uint) this.Class29_0.Class75_0.UInt16_3 + 1U));
                Thread.Sleep(2000);
                break;
              }
            }
            this.Class29_0.method_51(new Struct17((short) 498, (short) 6, (short) 6), (short) 1, false, true, true);
            return;
          case 3:
            if (this.Class29_0.class88_0.Int16_0 == (short) 150)
            {
              struct16 = this.Class29_0.Struct16_0;
              if (struct16.method_0(new Struct16(6, 6)) <= 2)
              {
                this.Class29_0.method_60((byte) 0, \u003CModule\u003E.smethod_6<string>(813845659U));
                while (this.Class29_0.Class75_0 == null)
                  Thread.Sleep(100);
                for (int index = 0; index < 8; ++index)
                  this.Class29_0.method_89(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) ((uint) this.Class29_0.Class75_0.UInt16_3 + 1U));
                Thread.Sleep(2000);
                break;
              }
            }
            this.Class29_0.method_51(new Struct17((short) 150, (short) 6, (short) 6), (short) 1, false, true, true);
            return;
          case 4:
            if (this.Class29_0.class88_0.Int16_0 == (short) 169)
            {
              struct16 = this.Class29_0.Struct16_0;
              if (struct16.method_0(new Struct16(6, 6)) <= 2)
              {
                this.Class29_0.method_60((byte) 0, \u003CModule\u003E.smethod_6<string>(813845659U));
                while (this.Class29_0.Class75_0 == null)
                  Thread.Sleep(100);
                for (int index = 0; index < 8; ++index)
                  this.Class29_0.method_89(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) ((uint) this.Class29_0.Class75_0.UInt16_3 + 1U));
                Thread.Sleep(2000);
                break;
              }
            }
            this.Class29_0.method_51(new Struct17((short) 169, (short) 6, (short) 6), (short) 1, false, true, true);
            return;
          case 5:
            if (this.Class29_0.class88_0.Int16_0 == (short) 136)
            {
              struct16 = this.Class29_0.Struct16_0;
              if (struct16.method_0(new Struct16(6, 6)) <= 2)
              {
                this.Class29_0.method_60((byte) 0, \u003CModule\u003E.smethod_6<string>(813845659U));
                while (this.Class29_0.Class75_0 == null)
                  Thread.Sleep(100);
                for (int index = 0; index < 8; ++index)
                  this.Class29_0.method_89(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) ((uint) this.Class29_0.Class75_0.UInt16_3 + 1U));
                Thread.Sleep(2000);
                break;
              }
            }
            this.Class29_0.method_51(new Struct17((short) 136, (short) 6, (short) 6), (short) 1, false, true, true);
            return;
          case 6:
            if (this.Class29_0.class88_0.Int16_0 == (short) 950)
            {
              struct16 = this.Class29_0.Struct16_0;
              if (struct16.method_0(new Struct16(7, 5)) <= 2)
              {
                this.Class29_0.method_60((byte) 0, \u003CModule\u003E.smethod_9<string>(1132118721U));
                while (this.Class29_0.Class75_0 == null)
                  Thread.Sleep(100);
                for (int index = 0; index < 8; ++index)
                  this.Class29_0.method_89(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) ((uint) this.Class29_0.Class75_0.UInt16_3 + 1U));
                Thread.Sleep(2000);
                break;
              }
            }
            this.Class29_0.method_51(new Struct17((short) 950, (short) 7, (short) 5), (short) 1, false, true, true);
            return;
        }
      }
    }
label_131:
    if (this.Class29_0.Control2_0?.button_14.Text == \u003CModule\u003E.smethod_8<string>(3184522924U))
    {
      this.Class29_0.method_107();
      this.Class29_0.method_110();
      if (this.Class29_0.Class143_0.Class88_0.Int16_0 != (short) 511)
      {
        this.Class29_0.method_54((short) 511);
      }
      else
      {
        if (this.byte_0 >= (byte) 21)
        {
          this.Class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_5<string>(2293027127U));
          this.Class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_5<string>(2293027127U));
          this.Class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(93034293U));
          SystemSounds.Beep.Play();
          this.Class29_0.Control2_0.button_14.Text = \u003CModule\u003E.smethod_6<string>(2929006759U);
          return;
        }
        this.method_78(false);
      }
    }
    if (!(this.Class29_0.Control2_0?.button_71.Text == \u003CModule\u003E.smethod_7<string>(2099785200U)))
      return;
    if (!this.Class29_0.Class21_0.method_0(\u003CModule\u003E.smethod_6<string>(3428854228U)))
    {
      if (this.Class29_0.class88_0.Int16_0 == (short) 192)
      {
        struct16 = this.Class29_0.Struct16_1;
        if (struct16.method_0(new Struct16(9, 5)) <= 6)
        {
          Class142 sender = this.Class29_0.method_128(\u003CModule\u003E.smethod_7<string>(821033733U));
          if (!this.Class29_0.method_141(sender, \u003CModule\u003E.smethod_9<string>(396885838U), true))
            return;
          for (int index = 0; index < 17; ++index)
            this.Class29_0.method_89((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2);
          this.Class29_0.method_90((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2, (byte) 1);
          this.Class29_0.Class75_0.method_4();
          Thread.Sleep(2500);
          return;
        }
      }
      this.Class29_0.method_51(new Struct17((short) 192, (short) 9, (short) 5), (short) 0, false, true, true);
    }
    else
    {
      Struct17 int_11 = new Struct17((short) 500, (short) 97, (short) 50);
      this.Class29_0.method_51(int_11, (short) 0, false, true, true);
      struct16 = this.Class29_0.Struct16_1;
      if (struct16.method_0(int_11.Struct16_0) >= 6)
        return;
      this.Class29_0.Control2_0.button_71.Text = \u003CModule\u003E.smethod_5<string>(1564084447U);
    }
  }

  internal void method_67()
  {
    if (!this.bool_28)
    {
      Random random = new Random();
      for (int index = 0; index < 10; ++index)
      {
        this.int_5 = random.Next(0, (int) this.Class29_0.class88_0.Byte_0);
        this.int_6 = random.Next(0, (int) this.Class29_0.class88_0.Byte_1);
        Struct17 struct17 = new Struct17(this.Class29_0.class88_0.Int16_0, (short) this.int_5, (short) this.int_6);
        if (!this.Class29_0.class88_0.method_3(struct17.Struct16_0))
        {
          string[] strArray = new string[8];
          strArray[0] = \u003CModule\u003E.smethod_6<string>(142050134U);
          short num = struct17.Int16_1;
          strArray[1] = num.ToString();
          strArray[2] = \u003CModule\u003E.smethod_6<string>(3040958440U);
          num = struct17.Int16_2;
          strArray[3] = num.ToString();
          strArray[4] = \u003CModule\u003E.smethod_5<string>(1742636082U);
          strArray[5] = this.Class29_0.class88_0.String_0;
          strArray[6] = \u003CModule\u003E.smethod_8<string>(382084420U);
          num = this.Class29_0.class88_0.Int16_0;
          strArray[7] = num.ToString();
          this.Class29_0.Control2_0.form3_0.listBox_0.Items.Add((object) string.Concat(strArray));
          this.Class29_0.Class26_0.list_15.Add(struct17);
        }
      }
    }
    this.bool_28 = true;
  }

  internal void method_68()
  {
    if (!this.Class29_0.method_22(\u003CModule\u003E.smethod_6<string>(251549296U)) && this.Class29_0.class88_0.Int16_0 != (short) 616)
      this.Class29_0.method_54((short) 616);
    else if (!this.Class29_0.method_22(\u003CModule\u003E.smethod_7<string>(1580776012U)) && this.Class29_0.class88_0.Int16_0 == (short) 616)
      this.method_67();
    else if (this.Class29_0.method_22(\u003CModule\u003E.smethod_6<string>(251549296U)) && !this.Class29_0.method_22(\u003CModule\u003E.smethod_7<string>(1882452557U)) && this.Class29_0.class88_0.Int16_0 != (short) 449)
      this.Class29_0.method_54((short) 449);
    else if (this.Class29_0.method_22(\u003CModule\u003E.smethod_5<string>(1810705608U)) && !this.Class29_0.method_22(\u003CModule\u003E.smethod_6<string>(795909075U)) && this.Class29_0.class88_0.Int16_0 == (short) 449)
      this.method_67();
    else if (this.Class29_0.method_22(\u003CModule\u003E.smethod_6<string>(251549296U)) && this.Class29_0.method_22(\u003CModule\u003E.smethod_7<string>(1882452557U)) && !this.Class29_0.method_22(\u003CModule\u003E.smethod_5<string>(3604679385U)) && this.Class29_0.class88_0.Int16_0 != (short) 2090)
      this.Class29_0.method_54((short) 2090);
    else if (this.Class29_0.method_22(\u003CModule\u003E.smethod_5<string>(1810705608U)) && this.Class29_0.method_22(\u003CModule\u003E.smethod_8<string>(532261715U)) && !this.Class29_0.method_22(\u003CModule\u003E.smethod_7<string>(184363271U)) && this.Class29_0.class88_0.Int16_0 == (short) 2090)
      this.method_67();
    else if (this.Class29_0.method_22(\u003CModule\u003E.smethod_9<string>(1388688818U)) && this.Class29_0.method_22(\u003CModule\u003E.smethod_6<string>(795909075U)) && this.Class29_0.method_22(\u003CModule\u003E.smethod_8<string>(3760009297U)) && !this.Class29_0.method_22(\u003CModule\u003E.smethod_6<string>(1056369117U)) && this.Class29_0.class88_0.Int16_0 != (short) 187)
      this.Class29_0.method_54((short) 187);
    else if (this.Class29_0.method_22(\u003CModule\u003E.smethod_6<string>(251549296U)) && this.Class29_0.method_22(\u003CModule\u003E.smethod_7<string>(1882452557U)) && this.Class29_0.method_22(\u003CModule\u003E.smethod_9<string>(1339896859U)) && !this.Class29_0.method_22(\u003CModule\u003E.smethod_6<string>(1056369117U)) && this.Class29_0.class88_0.Int16_0 == (short) 187)
      this.method_67();
    else if (this.Class29_0.method_22(\u003CModule\u003E.smethod_7<string>(1580776012U)) && this.Class29_0.method_22(\u003CModule\u003E.smethod_7<string>(1882452557U)) && this.Class29_0.method_22(\u003CModule\u003E.smethod_8<string>(3760009297U)) && this.Class29_0.method_22(\u003CModule\u003E.smethod_8<string>(665335261U)) && !this.Class29_0.method_22(\u003CModule\u003E.smethod_7<string>(2513798143U)) && this.Class29_0.class88_0.Int16_0 != (short) 1)
      this.Class29_0.method_54((short) 1);
    else if (this.Class29_0.method_22(\u003CModule\u003E.smethod_9<string>(1388688818U)) && this.Class29_0.method_22(\u003CModule\u003E.smethod_8<string>(532261715U)) && this.Class29_0.method_22(\u003CModule\u003E.smethod_7<string>(184363271U)) && this.Class29_0.method_22(\u003CModule\u003E.smethod_7<string>(3440579363U)) && !this.Class29_0.method_22(\u003CModule\u003E.smethod_8<string>(1865628521U)) && this.Class29_0.class88_0.Int16_0 == (short) 1)
    {
      this.method_67();
    }
    else
    {
      if (!this.Class29_0.method_22(\u003CModule\u003E.smethod_6<string>(251549296U)) || !this.Class29_0.method_22(\u003CModule\u003E.smethod_9<string>(4183244473U)) || !this.Class29_0.method_22(\u003CModule\u003E.smethod_9<string>(1339896859U)) || !this.Class29_0.method_22(\u003CModule\u003E.smethod_6<string>(1056369117U)) || !this.Class29_0.method_22(\u003CModule\u003E.smethod_8<string>(1865628521U)) || this.Class29_0.method_22(\u003CModule\u003E.smethod_9<string>(2456208610U)) || this.Class29_0.class88_0.Int16_0 != (short) 707)
        return;
      this.Class29_0.method_54((short) 707);
    }
  }

  internal void method_69()
  {
    if (this.Class29_0.method_26(\u003CModule\u003E.smethod_6<string>(3973214007U)) != 1 && this.Class29_0.method_26(\u003CModule\u003E.smethod_6<string>(1691607962U)) != 1 && this.Class29_0.class88_0.Int16_0 != (short) 2141)
      this.Class29_0.method_54((short) 2141);
    else if (this.Class29_0.method_26(\u003CModule\u003E.smethod_8<string>(1634138967U)) != 1 && this.Class29_0.method_26(\u003CModule\u003E.smethod_8<string>(484706914U)) != 1 && this.Class29_0.class88_0.Int16_0 == (short) 2141)
      this.method_71();
    else if (this.Class29_0.method_26(\u003CModule\u003E.smethod_9<string>(3015119741U)) == 1 && this.Class29_0.method_26(\u003CModule\u003E.smethod_7<string>(1853544026U)) != 1 && this.Class29_0.class88_0.Int16_0 == (short) 2141)
      this.method_71();
    else if (this.Class29_0.method_26(\u003CModule\u003E.smethod_8<string>(1634138967U)) != 1 && this.Class29_0.method_26(\u003CModule\u003E.smethod_8<string>(484706914U)) == 1 && this.Class29_0.class88_0.Int16_0 == (short) 2141)
      this.method_71();
    else if (this.Class29_0.method_26(\u003CModule\u003E.smethod_6<string>(3973214007U)) == 1 && this.Class29_0.method_26(\u003CModule\u003E.smethod_7<string>(1853544026U)) == 1 && this.Class29_0.class88_0.Int16_0 != (short) 115)
    {
      this.Class29_0.method_54((short) 115);
    }
    else
    {
      if (this.Class29_0.method_26(\u003CModule\u003E.smethod_7<string>(4021264833U)) != 1 || this.Class29_0.method_26(\u003CModule\u003E.smethod_8<string>(484706914U)) != 1 || this.Class29_0.class88_0.Int16_0 != (short) 115)
        return;
      if (this.Class29_0.Struct16_1.method_0(this.struct16_2) > 4)
      {
        this.Class29_0.method_50(this.struct16_2, (short) 3, true, true);
      }
      else
      {
        if (this.Class29_0.Struct16_1.method_0(this.struct16_2) > 4)
          return;
        this.method_70();
      }
    }
  }

  private void method_70()
  {
    this.Class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_7<string>(1032491879U));
    this.Class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(1908397270U));
    this.Class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(966896760U));
    SystemSounds.Beep.Play();
    this.Class29_0.Control2_0.button_15.Text = \u003CModule\u003E.smethod_6<string>(2929006759U);
  }

  internal void method_71()
  {
    this.method_72();
    Struct16 struct16_1;
    if (this.class142_2 != null)
    {
      if (this.bool_28)
        this.bool_28 = false;
      struct16_1 = this.Class29_0.Struct16_0;
      if (struct16_1.method_0(this.class142_2.Struct16_0) != 0)
      {
        this.Class29_0.method_50(this.class142_2.Struct16_0, (short) 0, true, true);
        this.bool_27 = false;
      }
      else if (!this.bool_27)
      {
        this.Class29_0.method_105(true);
        this.bool_27 = true;
      }
    }
    if (this.class142_2 != null)
      return;
    if (!this.bool_28)
    {
      Random random = new Random();
      this.int_5 = random.Next(0, (int) this.Class29_0.class88_0.Byte_0);
      this.int_6 = random.Next(0, (int) this.Class29_0.class88_0.Byte_1);
      this.bool_28 = true;
    }
    if (!this.bool_28)
      return;
    Struct16 struct16_2 = new Struct16((short) this.int_5, (short) this.int_6);
    struct16_1 = this.Class29_0.Struct16_1;
    if (struct16_1.method_0(struct16_2) >= 1 && !this.Class29_0.class88_0.method_3(struct16_2))
      this.Class29_0.method_50(struct16_2, (short) 0, true, true);
    struct16_1 = this.Class29_0.Struct16_1;
    if (struct16_1.method_0(struct16_2) != 0 && !this.Class29_0.class88_0.method_3(struct16_2))
      return;
    this.bool_28 = false;
  }

  private void method_72()
  {
    try
    {
      List<Class142> source = new List<Class142>();
      if (!this.Class29_0.method_22(\u003CModule\u003E.smethod_8<string>(484706914U)))
        source.AddRange((IEnumerable<Class142>) this.Class29_0.method_118(12, new ushort[1]
        {
          (ushort) 741
        }));
      if (!this.Class29_0.method_22(\u003CModule\u003E.smethod_9<string>(3015119741U)))
        source.AddRange((IEnumerable<Class142>) this.Class29_0.method_118(12, new ushort[1]
        {
          (ushort) 740
        }));
      if (this.class142_2 == null)
      {
        if (source.Count > 0)
          source.RemoveAll((Predicate<Class142>) (class143_1 => this.Class29_0.class103_0.method_2(this.Class29_0.Struct16_0, class143_1.Struct16_0, true, (short) 1).Count >= 20));
        if (source.Count <= 0)
          return;
        this.class142_2 = source.OrderBy<Class142, int>((Func<Class142, int>) (string_0 => string_0.Struct16_0.method_0(this.Class29_0.Struct16_0))).First<Class142>();
      }
      else
      {
        if (source.Contains(this.class142_2))
          return;
        this.class142_2 = (Class142) null;
      }
    }
    catch
    {
      this.class142_2 = (Class142) null;
    }
  }

  private void method_73()
  {
    this.Class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(4144041794U));
    this.Class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_5<string>(80077935U));
    SystemSounds.Beep.Play();
    Thread.Sleep(500);
  }

  private void method_74()
  {
    this.Class29_0.method_107();
    if (Struct17.smethod_1(this.Class29_0.Struct17_0, new Struct17((short) 165, new Struct16(11, 11))))
    {
      this.Class29_0.method_51(new Struct17((short) 165, new Struct16(11, 11)), (short) 0, false, true, true);
    }
    else
    {
      this.method_75();
      Thread.Sleep(2000);
    }
  }

  private void method_75()
  {
    Class142 sender = this.Class29_0.method_128(\u003CModule\u003E.smethod_9<string>(2052126470U));
    if (!this.Class29_0.method_141(sender, \u003CModule\u003E.smethod_6<string>(1254038509U), false))
      return;
    this.Class29_0.method_90((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2, (byte) 1);
    this.Class29_0.method_89((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2);
    this.Class29_0.method_89((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2);
    this.Class29_0.method_90((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2, (byte) 1);
    this.Class29_0.method_89((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2);
    this.Class29_0.method_89((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2);
    this.Class29_0.method_89((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2);
    this.Class29_0.method_89((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2);
    this.Class29_0.method_89((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2);
    this.Class29_0.method_89((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2);
    this.Class29_0.method_90((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2, (byte) 1);
    this.Class29_0.method_89((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 1);
  }

  private void method_76([In] Class26.Class146 obj0)
  {
    if ((int) this.Class29_0.class88_0.Int16_0 != (int) obj0.Int16_0 && (int) this.Class29_0.class88_0.Int16_0 != (int) obj0.Int16_1)
      this.Class29_0.method_51(new Struct17(obj0.Int16_0, new Struct16(7, 7)), (short) 0, false, true, true);
    else if ((int) this.Class29_0.class88_0.Int16_0 != (int) obj0.Int16_1)
      this.method_79();
    if ((int) this.Class29_0.class88_0.Int16_0 != (int) obj0.Int16_1)
      return;
    if (this.bool_11)
      this.Class29_0.method_51(new Struct17(obj0.Int16_0, new Struct16(7, 8)), (short) 0, false, true, true);
    else
      this.method_78(true);
  }

  private void method_77()
  {
    try
    {
      List<Class142> list = this.Class29_0.method_118(12, new ushort[1]
      {
        this.ushort_0
      }).Where<Class142>((Func<Class142, bool>) (class142_0 => !this.dictionary_1.ContainsKey(class142_0.Int32_0) || DateTime.UtcNow.Subtract(this.dictionary_1[class142_0.Int32_0]).TotalSeconds > 5.0)).ToList<Class142>();
      if (list.Count > 0)
      {
        if (this.class142_2 != null && list.Contains(this.class142_2))
          return;
        this.class142_2 = list.OrderBy<Class142, int>((Func<Class142, int>) (class142_0 => class142_0.Struct16_0.method_0(this.Class29_0.Struct16_1))).First<Class142>();
      }
      else
        this.class142_2 = (Class142) null;
    }
    catch
    {
      this.class142_2 = (Class142) null;
    }
  }

  private void method_78([In] bool obj0)
  {
    if (Struct16.smethod_1(this.Class29_0.Struct16_0, this.Class29_0.Struct16_1) && (int) this.Class29_0.Byte_1 % 8 == 0)
    {
      DateTime utcNow = DateTime.UtcNow;
      while (Struct16.smethod_1(this.Class29_0.Struct16_0, this.Class29_0.Struct16_1))
      {
        if (DateTime.UtcNow.Subtract(utcNow).TotalMilliseconds > 800.0)
          this.Class29_0.method_105(true);
        Thread.Sleep(50);
      }
    }
    if (obj0)
      this.method_77();
    else
      this.method_60();
    if (this.class142_2 != null)
    {
      foreach (Class140 class140 in this.Class29_0.method_125().Where<Class143>((Func<Class143, bool>) (class142_0 => class142_0 != this.Class29_0.Class143_0)).ToList<Class143>())
      {
        if (class140.Struct16_0.method_0(this.class142_2.Struct16_0) <= 2)
        {
          this.dictionary_1[this.class142_2.Int32_0] = DateTime.UtcNow;
          return;
        }
      }
      if (this.bool_28)
        this.bool_28 = false;
      Direction int_11 = this.class142_2.Struct16_0.method_4(this.Class29_0.Struct16_0);
      TimeSpan timeSpan1;
      if (this.Class29_0.Struct16_0.method_0(this.class142_2.Struct16_0) <= 2)
      {
        timeSpan1 = DateTime.UtcNow.Subtract(this.class142_2.DateTime_4);
        if (timeSpan1.TotalSeconds <= 2.0 && (this.class142_2.Direction_0 != this.Class29_0.Direction_0 || (int) this.class142_2.Struct16_0.short_0 != (int) this.Class29_0.Struct16_0.short_0 && (int) this.class142_2.Struct16_0.short_1 != (int) this.Class29_0.Struct16_0.short_1))
        {
          if (this.Class29_0.Struct16_0.method_0(this.class142_2.Struct16_0) == 1 && int_11 != this.Class29_0.Direction_0)
          {
            timeSpan1 = DateTime.UtcNow.Subtract(this.dateTime_18);
            if (timeSpan1.TotalSeconds > 2.0)
            {
              this.Class29_0.method_48(int_11);
              goto label_24;
            }
            else
              goto label_24;
          }
          else
            goto label_24;
        }
      }
      this.Class29_0.method_50(this.class142_2.Struct16_0, (short) 1, true, true);
label_24:
      if (this.Class29_0.Struct16_0.method_0(this.class142_2.Struct16_0) == 1)
      {
        timeSpan1 = DateTime.UtcNow.Subtract(this.class142_2.DateTime_4);
        if (timeSpan1.TotalSeconds > 2.0 && int_11 != this.Class29_0.Direction_0)
          this.Class29_0.method_48(int_11);
      }
      if (((int) this.class142_2.Struct16_0.short_0 == (int) this.Class29_0.Struct16_0.short_0 || (int) this.class142_2.Struct16_0.short_1 == (int) this.Class29_0.Struct16_0.short_1) && int_11 == this.Class29_0.Direction_0)
      {
        TimeSpan timeSpan2 = DateTime.UtcNow.Subtract(this.class142_2.DateTime_4);
        if (this.class142_2.Struct16_0.method_0(this.Class29_0.Struct16_0) == 1 && (timeSpan2.TotalMilliseconds < 400.0 || timeSpan2.TotalMilliseconds > 1000.0))
        {
          foreach (string str in this.list_23)
            this.Class29_0.method_30(str);
        }
        else
        {
          if (this.class142_2.Struct16_0.method_0(this.Class29_0.Struct16_0) <= 2)
          {
            foreach (string class142_4 in this.list_25)
              this.method_48(class142_4);
          }
          if (this.class142_2.Struct16_0.method_0(this.Class29_0.Struct16_0) <= 3)
          {
            foreach (string str in this.list_24)
              this.Class29_0.method_30(str);
            foreach (string class142_4 in this.list_26)
              this.method_48(class142_4);
          }
          if (this.class142_2.Struct16_0.method_0(this.Class29_0.Struct16_0) <= 4)
          {
            switch (this.Class29_0.temClass_0)
            {
              case TemClass.Warrior:
                timeSpan1 = DateTime.UtcNow.Subtract(this.Class29_0.Class133_0[\u003CModule\u003E.smethod_9<string>(2898357263U)].DateTime_0);
                if (timeSpan1.TotalMilliseconds > 30000.0)
                {
                  this.Class29_0.method_30(\u003CModule\u003E.smethod_5<string>(1130837101U));
                  break;
                }
                break;
              case TemClass.Monk:
                if (this.Class29_0.method_22(\u003CModule\u003E.smethod_6<string>(996372742U)))
                {
                  timeSpan1 = DateTime.UtcNow.Subtract(this.Class29_0.Class21_0.method_2(\u003CModule\u003E.smethod_8<string>(3954244414U)).DateTime_0);
                  if (timeSpan1.TotalMilliseconds > 15000.0)
                  {
                    this.Class29_0.method_29(\u003CModule\u003E.smethod_8<string>(3954244414U));
                    break;
                  }
                  break;
                }
                break;
            }
          }
          if (this.class142_2.Struct16_0.method_0(this.Class29_0.Struct16_0) <= 5)
          {
            foreach (string class142_4 in this.list_27)
              this.method_48(class142_4);
          }
        }
      }
      else
      {
        timeSpan1 = DateTime.UtcNow.Subtract(this.Class29_0.DateTime_0);
        if (timeSpan1.TotalMilliseconds > 500.0 && this.class142_2.Struct16_0.method_0(this.Class29_0.Struct16_0) <= 2)
        {
          foreach (string str in this.list_23)
            this.Class29_0.method_30(str);
        }
      }
    }
    if (this.class142_2 != null)
      return;
    if (!this.bool_28)
    {
      this.int_5 = Class138.smethod_3(0, 28);
      this.int_6 = Class138.smethod_3(0, 28);
      this.bool_28 = true;
    }
    if (!this.bool_28)
      return;
    Struct16 struct16 = new Struct16((short) this.int_5, (short) this.int_6);
    if (this.Class29_0.Class103_0.method_2(this.Class29_0.Class143_0.Struct16_0, struct16, true, (short) 0).Count == 0)
      this.bool_28 = false;
    else if (this.Class29_0.Struct16_1.method_0(struct16) >= 1 && !this.Class29_0.class88_0.method_3(struct16))
    {
      this.Class29_0.method_50(struct16, (short) 0, true, true);
    }
    else
    {
      if (this.Class29_0.Struct16_1.method_0(struct16) != 0 && !this.Class29_0.class88_0.method_3(struct16))
        return;
      this.bool_28 = false;
    }
  }

  private void method_79()
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class26.Class172 class172 = new Class26.Class172();
    switch (this.Class29_0.class88_0.Int16_0)
    {
      case 6513:
        if (this.Class29_0.Struct16_1.method_1((short) 10, (short) 10) > 1)
        {
          this.Class29_0.method_50(new Struct16(10, 10), (short) 1, true, true);
          return;
        }
        break;
      case 10001:
        if (this.Class29_0.Struct16_1.method_1((short) 8, (short) 8) > 1)
        {
          this.Class29_0.method_50(new Struct16(8, 8), (short) 1, true, true);
          return;
        }
        break;
      case 10265:
        if (this.Class29_0.Struct16_1.method_1((short) 90, (short) 47) > 1)
        {
          this.Class29_0.method_50(new Struct16(90, 47), (short) 1, true, true);
          return;
        }
        break;
    }
    List<string> stringList = new List<string>()
    {
      \u003CModule\u003E.smethod_7<string>(1540118487U),
      \u003CModule\u003E.smethod_8<string>(1925058826U),
      \u003CModule\u003E.smethod_8<string>(598685978U),
      \u003CModule\u003E.smethod_5<string>(1340334975U)
    };
    Class142 class142 = (Class142) null;
    // ISSUE: reference to a compiler-generated field
    class172.string_0 = \u003CModule\u003E.smethod_7<string>(3165979279U);
    for (int index = 0; index < 4; ++index)
    {
      if ((class142 = this.Class29_0.method_128(stringList[index])) != null)
      {
        // ISSUE: reference to a compiler-generated field
        if (!this.Class112_0.SortedDictionary_0.Values.Contains<string>(string.Format(\u003CModule\u003E.smethod_9<string>(231663877U), (object) class172.string_0, (object) (index + 1))))
        {
          this.Class29_0.method_78(class142.Int32_0);
          DateTime utcNow = DateTime.UtcNow;
          while (this.Class29_0.Class75_0 == null)
          {
            if (DateTime.UtcNow.Subtract(utcNow).TotalSeconds > 2.0)
              return;
            Thread.Sleep(10);
          }
          this.Class29_0.Class75_0.method_4();
          break;
        }
        break;
      }
    }
    if (class142 == null)
      return;
    this.Class112_0.class61_0.method_17(this.Class29_0, \u003CModule\u003E.smethod_9<string>(1045634594U));
    Thread.Sleep(500);
    this.bool_11 = false;
    if (class142.String_0 == \u003CModule\u003E.smethod_8<string>(1192366753U))
    {
      // ISSUE: reference to a compiler-generated method
      this.Class29_0.method_88((byte) 1, class142.Int32_0, this.Class112_0.SortedDictionary_0.FirstOrDefault<KeyValuePair<ushort, string>>(new Func<KeyValuePair<ushort, string>, bool>(class172.method_0)).Key, Array.Empty<object>());
      this.Class29_0.method_90((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 2, (byte) 1);
    }
    if (class142.String_0 == \u003CModule\u003E.smethod_9<string>(1987135104U))
    {
      // ISSUE: reference to a compiler-generated method
      this.Class29_0.method_88((byte) 1, class142.Int32_0, this.Class112_0.SortedDictionary_0.FirstOrDefault<KeyValuePair<ushort, string>>(new Func<KeyValuePair<ushort, string>, bool>(class172.method_1)).Key, Array.Empty<object>());
      this.Class29_0.method_90((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 2, (byte) 1);
    }
    if (class142.String_0 == \u003CModule\u003E.smethod_7<string>(2367228338U))
    {
      // ISSUE: reference to a compiler-generated method
      this.Class29_0.method_88((byte) 1, class142.Int32_0, this.Class112_0.SortedDictionary_0.FirstOrDefault<KeyValuePair<ushort, string>>(new Func<KeyValuePair<ushort, string>, bool>(class172.method_2)).Key, Array.Empty<object>());
      this.Class29_0.method_90((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 2, (byte) 1);
    }
    if (class142.String_0 == \u003CModule\u003E.smethod_9<string>(55342125U))
    {
      // ISSUE: reference to a compiler-generated method
      this.Class29_0.method_88((byte) 1, class142.Int32_0, this.Class112_0.SortedDictionary_0.FirstOrDefault<KeyValuePair<ushort, string>>(new Func<KeyValuePair<ushort, string>, bool>(class172.method_3)).Key, Array.Empty<object>());
      this.Class29_0.method_90((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 2, (byte) 1);
    }
    Thread.Sleep(1000);
  }

  private bool method_80([In] Class26.Class146 obj0)
  {
    int num = 0;
    foreach (string str in obj0.List_0)
    {
      if (this.Class29_0.method_26(str) == 10)
        ++num;
    }
    return num == 5;
  }

  private bool method_81() => new List<int>() { 8996, 8997 }.Contains((int) this.Class29_0.class88_0.Int16_0) || this.Class29_0.class88_0.Int16_0 >= (short) 10000;

  private bool method_82() => new List<int>()
  {
    10000,
    10004,
    10000,
    10028,
    10008,
    10009,
    10001,
    10013,
    10012,
    10006,
    10015,
    10016,
    10017,
    10018,
    10019,
    10020,
    10021,
    10022,
    10023,
    10024,
    10026,
    10027
  }.Contains((int) this.Class29_0.class88_0.Int16_0);

  private void method_83()
  {
    List<Class142> class142List = new List<Class142>();
    if (this.Class29_0.method_26(\u003CModule\u003E.smethod_9<string>(3495293038U)) < 12)
      class142List.AddRange((IEnumerable<Class142>) this.Class29_0.method_118(12, new ushort[1]
      {
        (ushort) 878
      }));
    if (this.Class29_0.method_26(\u003CModule\u003E.smethod_6<string>(2884494449U)) < 12)
      class142List.AddRange((IEnumerable<Class142>) this.Class29_0.method_118(12, new ushort[1]
      {
        (ushort) 876
      }));
    foreach (Class142 class142 in new List<Class142>((IEnumerable<Class142>) class142List))
    {
      foreach (Class143 class143 in this.Class29_0.method_125())
      {
        if (class143 != this.Class29_0.Class143_0 && class143.Struct16_0.method_0(class142.Struct16_0) <= 1 && class142List.Contains(class142))
          class142List.Remove(class142);
      }
    }
    if (class142List.Count > 0)
      class142List = class142List.Where<Class142>((Func<Class142, bool>) (class143_0 => !this.Class29_0.method_44(class143_0.Struct16_0) && Struct16.smethod_1(class143_0.Struct16_0, this.Class29_0.Struct16_0))).ToList<Class142>();
    if (class142List.Count > 0)
    {
      if (this.class142_3 != null && class142List.Contains(this.class142_3))
      {
        if (this.class142_3.Struct16_0.method_0(this.Class29_0.Struct16_1) > 1)
        {
          if (this.class142_3.Struct16_0.method_0(this.Class29_0.Struct16_0) == 1)
            this.Class29_0.method_105(true);
          else
            this.Class29_0.method_50(this.class142_3.Struct16_0, (short) 1, true, true);
        }
        else
        {
          if (this.class142_3.Struct16_0.method_0(this.Class29_0.Struct16_1) != 1)
            return;
          Direction int_11 = this.class142_3.Struct16_0.method_4(this.Class29_0.Struct16_1);
          if (int_11 != this.Class29_0.Direction_1)
          {
            this.Class29_0.method_48(int_11);
            Thread.Sleep(300);
          }
          else
          {
            foreach (string str in this.list_23)
            {
              foreach (KeyValuePair<string, Class132> keyValuePair in this.Class29_0.Class133_0.Dictionary_0)
              {
                if (keyValuePair.Key.Contains(str))
                  this.Class29_0.method_30(keyValuePair.Key);
              }
            }
            Thread.Sleep(250);
          }
        }
      }
      else
      {
        this.Class29_0.method_105(true);
        this.class142_3 = class142List.OrderBy<Class142, int>((Func<Class142, int>) (class143_0 => class143_0.Struct16_0.method_0(this.Class29_0.Struct16_1))).First<Class142>();
      }
    }
    else
    {
      this.List_1 = new List<Struct16>()
      {
        new Struct16(33, 7),
        new Struct16(20, 7),
        new Struct16(7, 7)
      };
      this.int_1 = 0;
      this.Class29_0.method_55((short) 2, true);
    }
  }

  private void method_84()
  {
    if (this.Class29_0.Control2_0.button_23.Text == \u003CModule\u003E.smethod_7<string>(1818577791U))
    {
      if (this.Class29_0.bool_1)
        return;
      KeyValuePair<int, Class12> keyValuePair1 = this.Class29_0.dictionary_0.FirstOrDefault<KeyValuePair<int, Class12>>();
      if (keyValuePair1.Key == 0)
      {
        this.Class29_0.Control2_0.button_23.Text = \u003CModule\u003E.smethod_9<string>(2680518631U);
        this.Class29_0.Control2_0.groupBox_14.Text = \u003CModule\u003E.smethod_5<string>(485245628U);
        this.Class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_8<string>(2058132372U));
        SystemSounds.Beep.Play();
      }
      Class12 class12 = keyValuePair1.Value;
      bool flag = class12.List_0.IndexOf(this.Class29_0.class88_0.Int16_0) != -1;
      int result;
      if (int.TryParse(class12.String_1, out result) && !this.bool_36 && class12 != null)
      {
        GroupBox groupBox14 = this.Class29_0.Control2_0.groupBox_14;
        string str;
        if (!class12.Boolean_0)
        {
          if (!class12.Boolean_1)
            str = \u003CModule\u003E.smethod_9<string>(1447070057U) + class12.String_0 + \u003CModule\u003E.smethod_9<string>(2741214071U) + class12.String_3 + \u003CModule\u003E.smethod_8<string>(750854006U);
          else
            str = \u003CModule\u003E.smethod_9<string>(4114095919U) + class12.String_0 + \u003CModule\u003E.smethod_9<string>(2388570567U) + class12.String_3 + \u003CModule\u003E.smethod_5<string>(1526496951U);
        }
        else
          str = \u003CModule\u003E.smethod_9<string>(1398278098U) + class12.String_0 + \u003CModule\u003E.smethod_9<string>(329247795U) + class12.String_2;
        groupBox14.Text = str;
        this.bool_36 = true;
      }
      foreach (KeyValuePair<int, Class12> keyValuePair2 in this.Class29_0.dictionary_0.ToList<KeyValuePair<int, Class12>>())
      {
        // ISSUE: object of a compiler-generated type is created
        // ISSUE: variable of a compiler-generated type
        Class26.Class173 class173 = new Class26.Class173();
        // ISSUE: reference to a compiler-generated field
        class173.keyValuePair_0 = keyValuePair2;
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (this.Class29_0.Class21_0.method_1(class173.keyValuePair_0.Value.String_0, true) >= int.Parse(class173.keyValuePair_0.Value.String_1))
        {
          this.Class29_0.Control2_0.form3_0.listBox_0.Items.Clear();
          this.Class29_0.Class26_0.list_15.Clear();
          this.bool_28 = false;
          this.bool_36 = false;
          this.bool_37 = false;
          // ISSUE: reference to a compiler-generated field
          int stringExact = this.Class29_0.Control2_0.listBox_4.FindStringExact(class173.keyValuePair_0.Value.UInt16_0.ToString());
          // ISSUE: reference to a compiler-generated method
          if (!this.Class29_0.dictionary_0.Values.Any<Class12>(new Func<Class12, bool>(class173.method_0)) && stringExact >= 0)
            this.Class29_0.Control2_0.listBox_4.Items.RemoveAt(stringExact);
          this.Class29_0.Control2_0.groupBox_14.Text = \u003CModule\u003E.smethod_6<string>(3408037930U);
          // ISSUE: reference to a compiler-generated field
          this.Class29_0.dictionary_0.Remove(class173.keyValuePair_0.Key);
          return;
        }
      }
      if (class12.Boolean_0 && this.Class29_0.Class21_0.method_1(class12.String_0, true) < result && (int) this.Class29_0.class88_0.Int16_0 != (int) class12.List_0.First<short>())
      {
        this.Class29_0.Control2_0.form3_0.listBox_0.Items.Clear();
        this.Class29_0.Class26_0.list_15.Clear();
        if (class12.List_0.First<short>() != (short) 5255)
          this.Class29_0.method_54(class12.List_0.First<short>());
        if (class12.List_0.First<short>() == (short) 5255 && !this.Class29_0.bool_0)
          this.Class29_0.method_52();
        if (class12.List_0.First<short>() == (short) 5255 && this.Class29_0.bool_0)
          this.Class29_0.method_54(class12.List_0.First<short>());
      }
      if (class12.Boolean_0 && this.Class29_0.Class21_0.method_1(class12.String_0, true) < result && (int) this.Class29_0.class88_0.Int16_0 == (int) class12.List_0.First<short>())
      {
        Struct16 int_11 = new Struct16(class12.Int16_0, class12.Int16_1);
        if (Struct16.smethod_1(this.Class29_0.Struct16_0, int_11))
          this.Class29_0.method_50(int_11, (short) 0, true, true);
        else if (Struct16.smethod_0(this.Class29_0.Struct16_0, int_11))
        {
          this.Class29_0.method_83(this.Class29_0.method_128(class12.String_2).Int32_0, class12.String_0, result);
          Thread.Sleep(2000);
        }
      }
      if (!class12.Boolean_0 && this.Class29_0.Class21_0.method_1(class12.String_0, true) < result && !flag && !this.bool_37)
      {
        this.Class29_0.Control2_0.form3_0.checkBox_0.Checked = false;
        this.Class29_0.Control2_0.form3_0.listBox_0.Items.Clear();
        this.Class29_0.Class26_0.list_15.Clear();
        this.Class29_0.method_54(class12.List_0.First<short>());
      }
      else if (((class12.Boolean_0 ? 0 : (this.Class29_0.Class21_0.method_1(class12.String_0, true) < result ? 1 : 0)) & (flag ? 1 : 0)) != 0)
      {
        if (!class12.Boolean_1)
          this.Class29_0.Control2_0.form3_0.checkBox_0.Checked = true;
        if (!this.bool_28)
        {
          this.bool_37 = true;
          foreach (KeyValuePair<short, Class93> keyValuePair3 in this.Class112_0.dictionary_1)
          {
            if (class12.List_0.Contains(keyValuePair3.Value.Int16_0))
            {
              for (int index = 0; index < (((int) keyValuePair3.Value.Byte_0 + (int) keyValuePair3.Value.Byte_1) / 8 < 5 ? 5 : (((int) keyValuePair3.Value.Byte_0 + (int) keyValuePair3.Value.Byte_1) / 8 > 12 ? 12 : ((int) keyValuePair3.Value.Byte_0 + (int) keyValuePair3.Value.Byte_1) / 8)); ++index)
              {
                Struct17 struct17;
                do
                {
                  this.int_5 = Class138.smethod_3(1, (int) this.Class29_0.class88_0.Byte_0 - 2);
                  this.int_6 = Class138.smethod_3(1, (int) this.Class29_0.class88_0.Byte_1 - 2);
                  struct17 = new Struct17(keyValuePair3.Value.Int16_0, (short) this.int_5, (short) this.int_6);
                }
                while ((int) keyValuePair3.Value.Int16_0 == (int) this.Class29_0.class88_0.Int16_0 && (this.Class29_0.class88_0.method_3(struct17.Struct16_0) || this.Class29_0.Class103_0.method_2(this.Class29_0.Struct16_1, struct17.Struct16_0, true, (short) 0).Count == 0));
                this.Class29_0.Control2_0.form3_0.listBox_0.Items.Add((object) string.Format(\u003CModule\u003E.smethod_8<string>(3660277616U), (object) struct17.Int16_1, (object) struct17.Int16_2, (object) keyValuePair3.Value.String_0, (object) keyValuePair3.Value.Int16_0));
                this.Class29_0.Class26_0.list_15.Add(struct17);
              }
            }
          }
        }
        else
        {
          foreach (Struct17 struct17_1 in this.Class29_0.Class26_0.list_15)
          {
            // ISSUE: object of a compiler-generated type is created
            // ISSUE: variable of a compiler-generated type
            Class26.Class174 class174 = new Class26.Class174();
            // ISSUE: reference to a compiler-generated field
            class174.struct17_0 = struct17_1;
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            if ((int) this.Class29_0.class88_0.Int16_0 == (int) class174.struct17_0.Int16_0 && (this.Class29_0.class88_0.method_3(class174.struct17_0.Struct16_0) || this.Class29_0.Class103_0.method_2(this.Class29_0.Struct16_1, class174.struct17_0.Struct16_0, true, (short) 0).Count == 0))
            {
              // ISSUE: reference to a compiler-generated method
              int index = this.Class29_0.Class26_0.list_15.FindIndex(new Predicate<Struct17>(class174.method_0));
              Struct17 struct17_2;
              do
              {
                this.int_5 = Class138.smethod_3(1, (int) this.Class29_0.class88_0.Byte_0 - 2);
                this.int_6 = Class138.smethod_3(1, (int) this.Class29_0.class88_0.Byte_1 - 2);
                struct17_2 = new Struct17(this.Class29_0.class88_0.Int16_0, (short) this.int_5, (short) this.int_6);
              }
              while (this.Class29_0.class88_0.method_3(struct17_2.Struct16_0) || this.Class29_0.Class103_0.method_2(this.Class29_0.Struct16_1, struct17_2.Struct16_0, true, (short) 0).Count == 0);
              this.Class29_0.Control2_0.form3_0.listBox_0.Items[index] = (object) string.Format(\u003CModule\u003E.smethod_8<string>(3660277616U), (object) struct17_2.Int16_1, (object) struct17_2.Int16_2, (object) this.Class29_0.class88_0.String_0, (object) this.Class29_0.class88_0.Int16_0);
              this.Class29_0.Class26_0.list_15[index] = struct17_2;
              break;
            }
          }
        }
        this.bool_28 = true;
        if (class12.String_0.Contains(\u003CModule\u003E.smethod_9<string>(3517492620U)))
        {
          foreach (Class76 class76 in this.Class29_0.Class21_0)
          {
            if ((int) class76.UInt16_0 == (int) class12.UInt16_0)
            {
              this.Class29_0.method_106(class76.Byte_0, (byte) 1);
              while (!this.Class29_0.method_149())
                Thread.Sleep(1000);
            }
          }
        }
        if (class12.String_0.Contains(\u003CModule\u003E.smethod_8<string>(3180160312U)))
        {
          foreach (Class76 class76 in this.Class29_0.Class21_0)
          {
            if ((int) class76.UInt16_0 == (int) class12.UInt16_0)
            {
              this.Class29_0.method_106(class76.Byte_0, (byte) 1);
              while (!this.Class29_0.method_149())
                Thread.Sleep(1000);
            }
          }
        }
      }
    }
    if (this.Class29_0.Control2_0.button_30.Text == \u003CModule\u003E.smethod_7<string>(807819083U))
    {
      if (this.Class29_0.bool_1)
      {
        this.method_94();
        this.method_92();
      }
      else if (!this.Class29_0.bool_1 && (int) this.Class29_0.class88_0.Int16_0 != (int) this.short_2 && this.bool_38)
      {
        if (this.Class29_0.Class75_0 != null)
          this.Class29_0.Class75_0.method_4();
        this.method_94();
        this.Class29_0.method_54(this.short_2);
      }
      else if (!this.Class29_0.bool_1 && (int) this.Class29_0.class88_0.Int16_0 == (int) this.short_2 && this.bool_38)
        this.bool_38 = false;
      else if (!this.Class29_0.bool_1 && !this.bool_38)
        this.method_93();
    }
    if (this.Class29_0.Control2_0 != null && this.Class29_0.Control2_0.button_26.Text == \u003CModule\u003E.smethod_9<string>(268552355U))
    {
      if (this.Class29_0.method_26(\u003CModule\u003E.smethod_5<string>(3944644138U)) == 0)
      {
        this.method_90();
      }
      else
      {
        if (this.Class29_0.Control2_0.radioButton_3.Checked)
        {
          if (((IEnumerable<string>) new string[6]
          {
            \u003CModule\u003E.smethod_5<string>(1038482926U),
            \u003CModule\u003E.smethod_5<string>(1700748707U),
            \u003CModule\u003E.smethod_6<string>(1501467005U),
            \u003CModule\u003E.smethod_7<string>(2724340254U),
            \u003CModule\u003E.smethod_7<string>(2176972156U),
            \u003CModule\u003E.smethod_9<string>(3948873958U)
          }).Any<string>((Func<string, bool>) (class143_0 => this.Class29_0.Class21_0.method_1(class143_0, true) == 30)))
          {
            this.method_89();
            goto label_99;
          }
        }
        if (this.Class29_0.Control2_0.radioButton_2.Checked)
        {
          if (((IEnumerable<string>) new string[6]
          {
            \u003CModule\u003E.smethod_8<string>(672588686U),
            \u003CModule\u003E.smethod_8<string>(3366726411U),
            \u003CModule\u003E.smethod_5<string>(247668101U),
            \u003CModule\u003E.smethod_5<string>(3816095094U),
            \u003CModule\u003E.smethod_6<string>(2045826784U),
            \u003CModule\u003E.smethod_9<string>(3948873958U)
          }).Any<string>((Func<string, bool>) (class143_0 => this.Class29_0.Class21_0.method_1(class143_0, true) == 30)))
          {
            SystemSounds.Beep.Play();
            this.Class29_0.Control2_0.button_26.Text = \u003CModule\u003E.smethod_7<string>(1459536265U);
            this.Class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_5<string>(845659360U));
            goto label_99;
          }
        }
        if (this.Class29_0.Class21_0.method_0(\u003CModule\u003E.smethod_6<string>(2613626258U)))
          this.method_88();
      }
    }
label_99:
    this.int_7 = (int) this.Class29_0.Control2_0.numericUpDown_3.Value;
    Struct16 struct16_1;
    TimeSpan timeSpan;
    if (this.Class29_0.Control2_0.button_37.Text == \u003CModule\u003E.smethod_6<string>(1840287201U))
    {
      Struct17 int_11_1 = new Struct17((short) 393, (short) this.Class29_0.Control2_0.numericUpDown_2.Value, (short) this.Class29_0.Control2_0.numericUpDown_1.Value);
      if (Struct17.smethod_0(this.Class29_0.Struct17_0, int_11_1))
      {
        Class142 class142 = this.Class29_0.method_128(\u003CModule\u003E.smethod_5<string>(3569938142U));
        if (class142 == null)
          return;
        this.Class29_0.method_88((byte) 1, class142.Int32_0, (ushort) 1693, Array.Empty<object>());
        this.Class29_0.method_89((byte) 1, class142.Int32_0, (ushort) 669, (ushort) 38);
        this.Class29_0.method_89((byte) 1, class142.Int32_0, (ushort) 669, (ushort) 39);
        this.Class29_0.method_89((byte) 1, class142.Int32_0, (ushort) 669, (ushort) 40);
        this.Class29_0.method_90((byte) 1, class142.Int32_0, (ushort) 669, (ushort) 41, (byte) 1);
        while (this.Class29_0.Class75_0 == null)
          Thread.Sleep(10);
        Thread.Sleep(1000);
        if (this.Class29_0.string_2.StartsWith(\u003CModule\u003E.smethod_9<string>(3596230454U)))
        {
          this.Class29_0.Class75_0.method_4();
          while (!this.bool_10)
            Thread.Sleep(10);
          this.bool_10 = false;
          if ((this.Class29_0.method_30(\u003CModule\u003E.smethod_7<string>(2770689069U)) || this.Class29_0.method_29(\u003CModule\u003E.smethod_6<string>(836943598U)) || this.Class29_0.method_29(\u003CModule\u003E.smethod_9<string>(1409377889U))) && (this.Class29_0.method_29(\u003CModule\u003E.smethod_5<string>(4156988265U)) || this.Class29_0.method_29(\u003CModule\u003E.smethod_8<string>(512111027U)) || this.Class29_0.method_29(\u003CModule\u003E.smethod_9<string>(1387885128U))))
          {
            Thread.Sleep(2000);
            return;
          }
        }
        else
        {
          byte num = 0;
          if (this.Class29_0.Control2_0.comboBox_1.Text == \u003CModule\u003E.smethod_9<string>(1986331414U))
            num = (byte) 1;
          else if (this.Class29_0.Control2_0.comboBox_1.Text == \u003CModule\u003E.smethod_8<string>(2649822414U))
            num = (byte) 3;
          else if (this.Class29_0.Control2_0.comboBox_1.Text == \u003CModule\u003E.smethod_6<string>(806317224U))
            num = (byte) 4;
          else if (this.Class29_0.Control2_0.comboBox_1.Text == \u003CModule\u003E.smethod_9<string>(1044830904U))
            num = (byte) 2;
          else if (this.Class29_0.Control2_0.comboBox_1.Text == \u003CModule\u003E.smethod_8<string>(2062720004U))
            num = (byte) 5;
          this.Class29_0.Class75_0.method_2(num);
          Thread.Sleep(2000);
          if (this.Class29_0.string_2.Contains(\u003CModule\u003E.smethod_7<string>(3187730864U)) || this.Class29_0.string_2.Contains(\u003CModule\u003E.smethod_8<string>(3206248752U)) || this.Class29_0.string_2.Contains(\u003CModule\u003E.smethod_5<string>(3262857796U)) || this.Class29_0.string_2.Contains(\u003CModule\u003E.smethod_6<string>(2980876626U)) || this.Class29_0.string_2.Contains(\u003CModule\u003E.smethod_8<string>(4166483360U)))
          {
            this.Class29_0.Control2_0.button_37.Text = \u003CModule\u003E.smethod_5<string>(2903372482U);
            this.Class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(1428223973U));
          }
        }
      }
      else if (this.Class29_0.class88_0.Int16_0.Equals((short) 435))
      {
        if (this.Class29_0.Struct16_1.short_0 < (short) 6)
          this.Class29_0.method_50(new Struct16(4, 20), (short) 0, true, true);
        else
          this.Class29_0.method_50(new Struct16(6, 23), (short) 0, true, true);
      }
      else if (this.Class29_0.class88_0.Int16_0.Equals((short) 3085))
        this.Class29_0.method_50(new Struct16(10, 14), (short) 0, true, true);
      else if (this.Class29_0.class88_0.Int16_0.Equals((short) 3086))
      {
        Struct16 int_11_2 = new Struct16(5, 2);
        struct16_1 = this.Class29_0.Struct16_1;
        if (struct16_1.method_0(int_11_2) > 0)
        {
          this.Class29_0.method_50(int_11_2, (short) 0, true, true);
        }
        else
        {
          Class142 class142 = this.Class29_0.method_128(\u003CModule\u003E.smethod_9<string>(4199540749U));
          if (class142 == null)
            return;
          this.Class29_0.method_78(class142.Int32_0);
          DateTime utcNow = DateTime.UtcNow;
          while (this.Class29_0.Class75_0 == null)
          {
            Thread.Sleep(25);
            timeSpan = DateTime.UtcNow.Subtract(utcNow);
            if (timeSpan.TotalSeconds > 2.0)
            {
              if (class142 == null)
                return;
              this.Class29_0.method_78(class142.Int32_0);
              utcNow = DateTime.UtcNow;
            }
          }
          this.Class29_0.method_90((byte) 1, class142.Int32_0, (ushort) 626, (ushort) 2, (byte) 1);
          this.Class29_0.method_89((byte) 1, class142.Int32_0, (ushort) 626, (ushort) 28);
          while (this.Class29_0.string_2 == null || !this.Class29_0.string_2.Contains(\u003CModule\u003E.smethod_6<string>(691058634U)))
            Thread.Sleep(25);
          this.Class29_0.method_89((byte) 1, class142.Int32_0, (ushort) 626, (ushort) 30);
          for (int index1 = 0; index1 < 3; ++index1)
          {
            for (int index2 = 0; index2 < this.int_7; ++index2)
            {
              this.Class29_0.method_90((byte) 1, class142.Int32_0, (ushort) 626, (ushort) 51, (byte) 2);
              this.Class29_0.method_90((byte) 1, class142.Int32_0, (ushort) 626, (ushort) 80, (byte) 2);
              Thread.Sleep(5);
            }
            Thread.Sleep(1500);
          }
          this.Class29_0.method_90((byte) 1, class142.Int32_0, (ushort) 626, (ushort) 51, (byte) 1);
          Thread.Sleep(1000);
          this.Class29_0.method_90((byte) 1, class142.Int32_0, (ushort) 626, (ushort) 85, (byte) 3);
          Thread.Sleep(1000);
        }
      }
      else
        this.Class29_0.method_51(int_11_1, (short) 0, false, true, true);
    }
    if (this.Class29_0.Control2_0 != null && this.Class29_0.Control2_0.button_34.Text == \u003CModule\u003E.smethod_5<string>(3390458089U))
    {
      if (this.Class29_0.temClass_0 != TemClass.Monk)
      {
        if (!this.bool_29)
        {
          if (Struct17.smethod_1(this.Class29_0.Struct17_1, new Struct17((short) 395, (short) 6, (short) 6)))
          {
            this.Class29_0.method_51(new Struct17((short) 395, (short) 6, (short) 6), (short) 0, false, true, true);
            if (Struct17.smethod_0(this.Class29_0.Struct17_0, new Struct17((short) 3000, (short) 4, (short) 5)))
              Thread.Sleep(5000);
          }
        }
        else if (!this.bool_30)
        {
          if (Struct17.smethod_1(this.Class29_0.Struct17_1, new Struct17((short) 344, (short) 6, (short) 6)))
            this.Class29_0.method_51(new Struct17((short) 344, (short) 6, (short) 6), (short) 0, false, true, true);
        }
        else if (Struct17.smethod_1(this.Class29_0.Struct17_0, new Struct17((short) 348, (short) 6, (short) 6)))
        {
          this.Class29_0.method_51(new Struct17((short) 348, (short) 6, (short) 6), (short) 0, false, true, true);
        }
        else
        {
          this.Class29_0.method_78(this.Class29_0.method_128(\u003CModule\u003E.smethod_7<string>(3903053938U)).Int32_0);
          if (!this.Class29_0.method_142())
            return;
          this.Class29_0.method_89(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) 1);
          this.Class29_0.method_90(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) 60, (byte) 1);
          this.Class29_0.method_89(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) 174);
          this.Class29_0.temClass_0 = TemClass.Monk;
          this.Class29_0.method_29(\u003CModule\u003E.smethod_5<string>(826138799U));
          this.Class29_0.method_29(\u003CModule\u003E.smethod_5<string>(761864277U));
          this.Class29_0.method_29(\u003CModule\u003E.smethod_7<string>(2478648701U) + (this.Class29_0.Class143_0.Byte_2 == (byte) 16 ? \u003CModule\u003E.smethod_9<string>(120333491U) : \u003CModule\u003E.smethod_6<string>(2764843455U)));
          this.Class29_0.method_29(\u003CModule\u003E.smethod_7<string>(2541424225U));
          Thread.Sleep(1000);
        }
      }
      else
      {
        if (this.Class29_0.Byte_2 < (byte) 22)
        {
          if (Struct17.smethod_1(this.Class29_0.Struct17_0, new Struct17((short) 425, (short) 7, (short) 11)))
          {
            this.Class29_0.method_51(new Struct17((short) 425, (short) 7, (short) 11), (short) 0, false, true, true);
            return;
          }
          if (!this.Class29_0.method_22(\u003CModule\u003E.smethod_8<string>(111574716U)) && Form1.smethod_0(this.Class112_0.form5_0, this.Class29_0.string_3 + \u003CModule\u003E.smethod_7<string>(373153797U), (IWin32Window) this.Class112_0.form5_0, true) == DialogResult.Cancel)
          {
            this.Class29_0.Control2_0.button_34.Text = \u003CModule\u003E.smethod_5<string>(2896710892U);
            return;
          }
          this.Class29_0.method_29(\u003CModule\u003E.smethod_7<string>(3271708352U));
          ThreadPool.QueueUserWorkItem((WaitCallback) (class143_0 =>
          {
            Thread.Sleep(1000);
            while (this.Class29_0.Byte_9 < (byte) 20)
              Thread.Sleep(50);
            while (this.Class29_0.Byte_9 > (byte) 0)
            {
              this.Class29_0.method_111();
              Thread.Sleep(17);
            }
          }));
          return;
        }
        if (!this.bool_31)
        {
          if (!this.method_85(false))
          {
            Struct17 int_11 = new Struct17(this.short_0, this.struct16_3);
            while (this.short_0 != (short) 5 && this.short_0 != (short) 8 && this.short_0 != (short) 11)
              this.short_0 = (short) Class138.smethod_3(5, 11);
            while (true)
            {
              Struct16 struct163 = this.struct16_3;
              struct16_1 = new Struct16();
              Struct16 struct16_2 = struct16_1;
              if (Struct16.smethod_0(struct163, struct16_2) || this.Class29_0.class88_0.method_3(this.struct16_3) || this.Class29_0.method_121(new Struct16(0, 0)).Contains(this.struct16_3) || (int) this.Class29_0.class88_0.Int16_0 == (int) this.short_0 && this.Class29_0.Class103_0.method_2(this.Class29_0.Struct16_0, this.struct16_3, true, (short) 1).Count == 0)
                this.struct16_3 = new Struct16(Class138.smethod_2((int) this.Class29_0.class88_0.Byte_0 - 1), Class138.smethod_2((int) this.Class29_0.class88_0.Byte_1 - 1));
              else
                break;
            }
            if (Struct17.smethod_0(this.Class29_0.Struct17_0, int_11))
            {
              this.short_0 = (short) 0;
              this.struct16_3 = new Struct16();
              return;
            }
            this.Class29_0.method_51(int_11, (short) 0, false, true, true);
          }
        }
        else if (!this.bool_32)
        {
          if (!this.method_85(true))
          {
            Struct17 int_11 = new Struct17(this.short_0, this.struct16_3);
            while (this.short_0 != (short) 187 && this.short_0 != (short) 189 && this.short_0 != (short) 190)
              this.short_0 = (short) Class138.smethod_3(187, 190);
            while (true)
            {
              Struct16 struct163 = this.struct16_3;
              struct16_1 = new Struct16();
              Struct16 struct16_3 = struct16_1;
              if (Struct16.smethod_0(struct163, struct16_3) || this.Class29_0.class88_0.method_3(this.struct16_3) || this.Class29_0.method_121(new Struct16(0, 0)).Contains(this.struct16_3) || (int) this.Class29_0.class88_0.Int16_0 == (int) this.short_0 && this.Class29_0.Class103_0.method_2(this.Class29_0.Struct16_0, this.struct16_3, true, (short) 1).Count == 0)
                this.struct16_3 = new Struct16(Class138.smethod_2((int) this.Class29_0.class88_0.Byte_0 - 1), Class138.smethod_2((int) this.Class29_0.class88_0.Byte_1 - 1));
              else
                break;
            }
            if (Struct17.smethod_0(this.Class29_0.Struct17_0, int_11))
            {
              this.short_0 = (short) 0;
              this.struct16_3 = new Struct16();
              return;
            }
            this.Class29_0.method_51(int_11, (short) 0, false, true, true);
          }
        }
        else if (!this.bool_33)
        {
          if (!this.bool_34)
          {
            if (Struct17.smethod_1(this.Class29_0.Struct17_0, new Struct17((short) 5210, (short) 4, (short) 4)))
            {
              this.Class29_0.method_51(new Struct17((short) 5210, (short) 4, (short) 4), (short) 0, false, true, true);
            }
            else
            {
              this.Class29_0.method_60((byte) 0, \u003CModule\u003E.smethod_7<string>(2780325246U));
              if (!this.Class29_0.method_142())
                return;
              if (this.Class29_0.Class75_0.String_1.Contains(\u003CModule\u003E.smethod_8<string>(1638085986U)))
                this.Class29_0.Class75_0.method_1();
              else if (this.Class29_0.Class75_0.String_1.Contains(\u003CModule\u003E.smethod_7<string>(2279855584U)))
              {
                this.Class29_0.method_89(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) 215);
                this.Class29_0.method_89(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) 263);
              }
              else
              {
                this.Class29_0.method_90(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) 45, (byte) 2);
                this.Class29_0.method_91(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) 57, this.Class29_0.Control2_0.textBox_9.Text);
                this.Class29_0.Class75_0 = (Class75) null;
                while (this.Class29_0.Class75_0 == null || !this.Class29_0.Class75_0.String_1.Contains(\u003CModule\u003E.smethod_5<string>(1362237580U)))
                  Thread.Sleep(10);
                this.Class29_0.method_89(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) 215);
                this.Class29_0.method_89(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) 263);
              }
              this.bool_34 = true;
            }
          }
          else if (!this.bool_35)
          {
            if (Struct17.smethod_1(this.Class29_0.Struct17_0, new Struct17((short) 5219, (short) 4, (short) 4)))
            {
              this.Class29_0.method_51(new Struct17((short) 5219, (short) 4, (short) 4), (short) 0, false, true, true);
            }
            else
            {
              if (!this.Class29_0.method_142())
                return;
              this.Class29_0.Class75_0.method_2((byte) 2);
              this.bool_35 = true;
            }
          }
          else if (Struct17.smethod_1(this.Class29_0.Struct17_0, new Struct17((short) 5210, (short) 4, (short) 4)))
          {
            this.Class29_0.method_51(new Struct17((short) 5210, (short) 4, (short) 4), (short) 0, false, true, true);
          }
          else
          {
            this.Class29_0.method_60((byte) 0, \u003CModule\u003E.smethod_7<string>(3128900227U));
            while (this.Class29_0.Class75_0?.String_1 != \u003CModule\u003E.smethod_6<string>(4139829830U))
              Thread.Sleep(10);
            this.Class29_0.Class75_0.method_1();
            this.bool_33 = true;
            this.bool_34 = false;
            this.bool_35 = false;
            if (Form1.smethod_0(this.Class112_0.form5_0, \u003CModule\u003E.smethod_9<string>(1275141100U), (IWin32Window) null, true) == DialogResult.Cancel)
            {
              this.Class29_0.Control2_0.button_34.Text = \u003CModule\u003E.smethod_8<string>(972043196U);
              return;
            }
          }
        }
        else if (!this.bool_34)
        {
          if (Struct17.smethod_1(this.Class29_0.Struct17_0, new Struct17((short) 5210, (short) 4, (short) 4)))
          {
            this.Class29_0.method_51(new Struct17((short) 5210, (short) 4, (short) 4), (short) 0, false, true, true);
          }
          else
          {
            this.Class29_0.method_60((byte) 0, \u003CModule\u003E.smethod_6<string>(3004230882U));
            if (!this.Class29_0.method_142())
              return;
            if (this.Class29_0.Class75_0.String_1.Contains(\u003CModule\u003E.smethod_9<string>(765021928U)))
              this.Class29_0.Class75_0.method_1();
            else if (this.Class29_0.Class75_0.String_1.Contains(\u003CModule\u003E.smethod_8<string>(943998470U)))
            {
              this.Class29_0.method_89(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) ((uint) this.Class29_0.Class75_0.UInt16_3 + 1U));
              this.Class29_0.method_89(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) 228);
            }
            else
            {
              this.Class29_0.method_90(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) ((uint) this.Class29_0.Class75_0.UInt16_3 + 1U), (byte) 2);
              this.Class29_0.method_91(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) 47, this.Class29_0.Control2_0.textBox_9.Text);
              this.Class29_0.Class75_0 = (Class75) null;
              while (this.Class29_0.Class75_0 == null || !this.Class29_0.Class75_0.String_1.Contains(\u003CModule\u003E.smethod_6<string>(3832490398U)))
                Thread.Sleep(10);
              this.Class29_0.method_89(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) ((uint) this.Class29_0.Class75_0.UInt16_3 + 1U));
              this.Class29_0.method_89(this.Class29_0.Class75_0.Byte_1, this.Class29_0.Class75_0.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) 228);
            }
            this.bool_34 = true;
          }
        }
        else if (!this.bool_35)
        {
          if (Struct17.smethod_1(this.Class29_0.Struct17_0, new Struct17((short) 5219, (short) 14, (short) 10)))
          {
            this.Class29_0.method_51(new Struct17((short) 5219, (short) 14, (short) 10), (short) 0, false, true, true);
          }
          else
          {
            if (!this.Class29_0.method_142())
              return;
            this.Class29_0.Class75_0.method_2((byte) 2);
            this.bool_35 = true;
          }
        }
        else if (Struct17.smethod_1(this.Class29_0.Struct17_0, new Struct17((short) 5210, (short) 4, (short) 4)))
        {
          this.Class29_0.method_51(new Struct17((short) 5210, (short) 4, (short) 4), (short) 0, false, true, true);
        }
        else
        {
          this.Class29_0.method_60((byte) 0, \u003CModule\u003E.smethod_5<string>(2731523103U));
          while (this.Class29_0.Class75_0?.String_1 != \u003CModule\u003E.smethod_8<string>(3931687400U))
            Thread.Sleep(10);
          this.Class29_0.Class75_0.method_1();
          this.bool_34 = false;
          this.bool_35 = false;
          this.bool_33 = false;
          this.bool_31 = false;
          this.bool_32 = false;
          this.Class29_0.Control2_0.button_34.Text = \u003CModule\u003E.smethod_9<string>(2691618422U);
        }
      }
    }
    if (this.Class29_0.Control2_0.button_25.Text == \u003CModule\u003E.smethod_7<string>(2862189917U))
    {
      ushort num1;
      ushort num2;
      Struct17 int_11;
      switch (this.Class29_0.Enum6_0)
      {
        case Enum6.Mileth:
          num1 = (ushort) 1603;
          num2 = (ushort) 579;
          int_11 = new Struct17((short) 3026, (short) 6, (short) 12);
          break;
        case Enum6.Rucesion:
          num1 = (ushort) 1612;
          num2 = (ushort) 588;
          int_11 = new Struct17((short) 422, (short) 9, (short) 10);
          break;
        default:
          this.Class29_0.Control2_0.button_25.Text = \u003CModule\u003E.smethod_9<string>(189814521U);
          this.Class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_7<string>(2693502113U));
          return;
      }
      if ((int) this.Class29_0.class88_0.Int16_0 == (int) int_11.Int16_0 && this.Class29_0.struct16_1.method_0(int_11.Struct16_0) > 2)
      {
        Class142 class142 = int_11.Int16_0 == (short) 422 ? this.Class29_0.method_128(\u003CModule\u003E.smethod_8<string>(1610681873U)) : this.Class29_0.method_128(\u003CModule\u003E.smethod_6<string>(2282761692U));
        if (class142 == null)
        {
          this.Class29_0.method_105(true);
          return;
        }
        this.Class29_0.method_88((byte) 1, class142.Int32_0, num1, Array.Empty<object>());
        Thread.Sleep(1000);
        this.Class29_0.method_90((byte) 1, class142.Int32_0, num2, (ushort) 67, (byte) 1);
        Thread.Sleep(1000);
        this.Class29_0.method_90((byte) 1, class142.Int32_0, num2, (ushort) 265, (byte) 2);
        Thread.Sleep(1000);
        this.Class29_0.method_91((byte) 1, class142.Int32_0, num2, (ushort) 271, this.Class29_0.Control2_0.textBox_8.Text);
        this.Class29_0.Control2_0.button_25.Text = \u003CModule\u003E.smethod_6<string>(2520123795U);
        this.Class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_8<string>(2624409034U) + this.Class29_0.Control2_0.textBox_8.Text);
      }
      else
        this.Class29_0.method_51(int_11, (short) 1, false, true, true);
    }
    if (this.Class29_0.Control2_0.button_35.Text == \u003CModule\u003E.smethod_6<string>(3087325196U))
      this.Class29_0.method_143(this.Class29_0.Control2_0.textBox_10.Text, this.Class29_0.Control2_0.checkBox_88.Checked);
    if (this.Class29_0.Control2_0.button_36.Text == \u003CModule\u003E.smethod_6<string>(3915584712U))
      this.Class29_0.method_144();
    if (this.Class29_0.bool_41)
    {
      Class142 class142 = this.Class29_0.method_116().OfType<Class142>().Where<Class142>((Func<Class142, bool>) (class142_0 => class142_0.UInt16_0 == (ushort) 362 && class142_0.Struct16_0.method_0(this.Class29_0.Struct16_1) < 4)).FirstOrDefault<Class142>();
      if (class142 != null)
        this.Class29_0.method_78(class142 != null ? class142.Int32_0 : 0);
      Thread.Sleep(250);
    }
    if (this.Class29_0.Control2_0.button_68.Text == \u003CModule\u003E.smethod_9<string>(2207052330U))
    {
      if (this.Class29_0.Control2_0.checkBox_91.Checked)
      {
        if (this.Class29_0.Control2_0.textBox_0.Text.Contains(\u003CModule\u003E.smethod_5<string>(1683610190U)))
        {
          this.Class29_0.Class75_0.method_2((byte) 2);
          this.Class29_0.Control2_0.textBox_0.Text = string.Empty;
        }
      }
      else
      {
        string empty = string.Empty;
        foreach (Class134 class134 in this.Class29_0.Class136_0.Where<Class134>((Func<Class134, bool>) (disposing => disposing != null)))
        {
          Match match;
          if ((match = Regex.Match(class134.String_0, \u003CModule\u003E.smethod_5<string>(892795365U))).Success)
          {
            empty = match.Groups[1].Value;
            break;
          }
        }
        Class76 class76 = this.Class29_0.Class21_0.method_2(empty + \u003CModule\u003E.smethod_7<string>(1570773421U));
        byte num3 = class76 != null ? class76.Byte_0 : (byte) 0;
        if (!string.IsNullOrEmpty(empty) && num3 != (byte) 0)
        {
          if (this.Class29_0.class134_1 == null || this.Class29_0.class134_1.String_0 != empty + \u003CModule\u003E.smethod_7<string>(3943711463U) || DateTime.UtcNow.Subtract(this.Class29_0.class134_1.DateTime_0).TotalSeconds > 30.0)
            this.Class29_0.method_31(empty + \u003CModule\u003E.smethod_5<string>(739012921U), (Class142) null, true, true);
          this.Class29_0.method_95(num3, this.Class29_0.Struct16_0, 1);
          Thread.Sleep(500);
          this.Class29_0.method_93((byte) 0, this.Class29_0.Struct16_0);
          DateTime utcNow1 = DateTime.UtcNow;
          while (this.Class29_0.Class75_0 == null)
          {
            if (DateTime.UtcNow.Subtract(utcNow1).TotalSeconds > 2.0)
              return;
            if (this.Class29_0.bool_28)
            {
              Thread.Sleep(25);
            }
            else
            {
              this.Class29_0.Control2_0.button_68.Text = \u003CModule\u003E.smethod_6<string>(2306543143U);
              return;
            }
          }
          byte byte0 = this.Class29_0.Class75_0.Byte_0;
          int int320 = this.Class29_0.Class75_0.Int32_0;
          ushort uint162 = this.Class29_0.Class75_0.UInt16_2;
          ushort uint163 = this.Class29_0.Class75_0.UInt16_3;
          byte num4 = this.Class29_0.Control2_0.checkBox_90.Checked ? (byte) 1 : (byte) 2;
          if (this.method_38())
            Thread.Sleep(500);
          this.Class29_0.method_90(byte0, int320, uint162, (ushort) ((uint) uint163 + 1U), num4);
          if (num4 == (byte) 1)
            this.Class29_0.method_91(byte0, int320, uint162, (ushort) ((uint) uint163 + 5U), this.Class29_0.Control2_0.textBox_22.Text);
          this.Class29_0.Class75_0 = (Class75) null;
          DateTime utcNow2 = DateTime.UtcNow;
          while (this.Class29_0.Class75_0 == null)
          {
            if (DateTime.UtcNow.Subtract(utcNow2).TotalSeconds > 3.0)
              return;
            Thread.Sleep(25);
          }
          this.Class29_0.method_90(byte0, int320, uint162, (ushort) 248, (byte) 4);
          this.Class29_0.Class75_0 = (Class75) null;
        }
        else
        {
          this.Class29_0.method_75((byte) 3, \u003CModule\u003E.smethod_8<string>(3344584990U));
          this.Class29_0.Control2_0.button_68.Text = \u003CModule\u003E.smethod_5<string>(1745482335U);
          return;
        }
      }
    }
    if (this.Class29_0.Control2_0.button_69.Text == \u003CModule\u003E.smethod_7<string>(3959588551U))
    {
      bool flag = this.Class29_0.Control2_0.comboBox_12.Text == \u003CModule\u003E.smethod_7<string>(3907182032U);
      Struct16 int_11 = new Struct16(5, 2);
      short int160 = this.Class29_0.class88_0.Int16_0;
      if (int160.Equals((short) 3086))
      {
        struct16_1 = this.Class29_0.Struct16_1;
        if (struct16_1.method_0(int_11) > 2)
        {
          this.Class29_0.method_50(int_11, (short) 1, true, true);
        }
        else
        {
          this.Class29_0.method_105(true);
          struct16_1 = this.Class29_0.Struct16_1;
          if (struct16_1.method_0(int_11) > 2)
            return;
          Thread.Sleep(2500);
          this.Class112_0.class61_0.method_17(this.Class29_0, \u003CModule\u003E.smethod_8<string>(2066026410U));
          this.Class29_0.Control2_0.Invoke((Delegate) (() => this.Class29_0.Control2_0.button_69.Text = \u003CModule\u003E.smethod_7<string>(3030144893U)));
        }
      }
      else
      {
        int160 = this.Class29_0.class88_0.Int16_0;
        if (int160.Equals((short) 3087))
        {
          struct16_1 = this.Class29_0.Struct16_1;
          if (struct16_1.method_0(int_11) > 2)
          {
            this.Class29_0.method_50(int_11, (short) 1, true, true);
          }
          else
          {
            this.Class29_0.method_105(true);
            struct16_1 = this.Class29_0.Struct16_1;
            if (struct16_1.method_0(int_11) > 2)
              return;
            Thread.Sleep(2500);
            this.Class112_0.class61_0.method_17(this.Class29_0, \u003CModule\u003E.smethod_5<string>(674738399U));
            this.Class29_0.Control2_0.Invoke((Delegate) (() => this.Class29_0.Control2_0.button_69.Text = \u003CModule\u003E.smethod_7<string>(3030144893U)));
          }
        }
        else
        {
          int160 = this.Class29_0.class88_0.Int16_0;
          if (int160.Equals((short) 3085))
          {
            if (flag)
              this.Class29_0.method_50(new Struct16(10, 14), (short) 0, true, true);
            else
              this.Class29_0.method_50(new Struct16(10, 5), (short) 0, true, true);
          }
          else
          {
            int160 = this.Class29_0.class88_0.Int16_0;
            if (int160.Equals((short) 435))
            {
              if (this.Class29_0.Struct16_1.short_0 < (short) 6)
                this.Class29_0.method_50(new Struct16(4, 20), (short) 0, true, true);
              else
                this.Class29_0.method_50(new Struct16(6, 23), (short) 0, true, true);
            }
            else if (!this.Class29_0.HashSet_0.Contains((ushort) 89))
            {
              if (!this.Class29_0.Class21_0.method_0(\u003CModule\u003E.smethod_9<string>(4280024701U)))
              {
                if (this.Class29_0.class88_0.Int16_0 == (short) 3052)
                {
                  struct16_1 = this.Class29_0.Struct16_1;
                  if (struct16_1.method_0(new Struct16(49, 22)) <= 18)
                  {
                    this.Class29_0.method_58(\u003CModule\u003E.smethod_5<string>(4243165392U));
                    DateTime utcNow = DateTime.UtcNow;
                    while (!this.Class29_0.Class21_0.method_0(\u003CModule\u003E.smethod_9<string>(4280024701U)))
                    {
                      Thread.Sleep(10);
                      timeSpan = DateTime.UtcNow.Subtract(utcNow);
                      if (timeSpan.TotalSeconds > 5.0)
                      {
                        this.Class29_0.Control2_0.button_69.Text = \u003CModule\u003E.smethod_6<string>(3629659651U);
                        int num = (int) Form1.smethod_0(this.Class112_0.form5_0, \u003CModule\u003E.smethod_8<string>(998806696U), (IWin32Window) null, true);
                      }
                    }
                    goto label_336;
                  }
                }
                this.Class29_0.method_51(new Struct17((short) 3052, (short) 49, (short) 22), (short) 8, false, true, true);
              }
              else if (this.Class29_0.class88_0.Int16_0 == (short) 500 && this.dictionary_4.Keys.Contains<Struct16>(this.Class29_0.Struct16_1))
              {
                this.Class29_0.method_95(this.Class29_0.Class21_0[\u003CModule\u003E.smethod_5<string>(1895469775U)].Byte_0, this.dictionary_4[this.Class29_0.Struct16_1], 1);
                Thread.Sleep(2000);
              }
              else
              {
                // ISSUE: object of a compiler-generated type is created
                // ISSUE: reference to a compiler-generated method
                this.Class29_0.method_51(new Struct17((short) 500, this.dictionary_4.FirstOrDefault<KeyValuePair<Struct16, Struct16>>((Func<KeyValuePair<Struct16, Struct16>, bool>) (class142_0 => !this.Class29_0.method_125().Any<Class143>(new Func<Class143, bool>(new Class26.Class175()
                {
                  keyValuePair_0 = class142_0
                }.method_0)))).Key), (short) 0, false, true, true);
              }
            }
            else if (this.Class29_0.Control2_0.checkBox_92.Checked)
            {
              if (this.Class29_0.class88_0.Int16_0 == (short) 3052 && this.list_34.Contains(this.Class29_0.Struct16_1))
              {
                Thread.Sleep(100);
              }
              else
              {
                // ISSUE: object of a compiler-generated type is created
                // ISSUE: reference to a compiler-generated method
                this.Class29_0.method_51(new Struct17((short) 3052, this.list_34.FirstOrDefault<Struct16>((Func<Struct16, bool>) (class142_0 => !this.Class29_0.method_125().Any<Class143>(new Func<Class143, bool>(new Class26.Class176()
                {
                  struct16_0 = class142_0
                }.method_0))))), (short) 0, false, true, true);
              }
            }
            else
              Thread.Sleep(100);
          }
        }
      }
    }
label_336:
    if (!(this.Class29_0.Control2_0.button_72.Text == \u003CModule\u003E.smethod_6<string>(1038090777U)))
      return;
    if (this.Class29_0.class88_0.Int16_0 != (short) 130)
    {
      this.Class29_0.method_75((byte) 1, \u003CModule\u003E.smethod_5<string>(3323801523U));
      this.Class29_0.Control2_0.button_72.Text = \u003CModule\u003E.smethod_6<string>(2694609809U);
    }
    else if (this.Class29_0.Class21_0.Boolean_0)
    {
      this.Class29_0.method_75((byte) 1, \u003CModule\u003E.smethod_7<string>(1782231567U));
      this.Class29_0.Control2_0.button_72.Text = \u003CModule\u003E.smethod_6<string>(2694609809U);
    }
    else
    {
      Class142 sender = this.Class29_0.method_128(\u003CModule\u003E.smethod_6<string>(1652684202U));
      if (!this.Class29_0.Class21_0.method_0(\u003CModule\u003E.smethod_8<string>(651762938U)))
      {
        if (sender == null)
        {
          this.Class29_0.method_75((byte) 1, \u003CModule\u003E.smethod_5<string>(2528707152U));
          this.Class29_0.Control2_0.button_72.Text = \u003CModule\u003E.smethod_9<string>(432735019U);
          return;
        }
        this.Class29_0.method_80(sender.Int32_0, \u003CModule\u003E.smethod_9<string>(1079973264U));
      }
      else if (this.Class29_0.method_141(sender, \u003CModule\u003E.smethod_6<string>(1855600388U), true))
      {
        if (this.Class29_0.Class75_0.String_1.Contains(\u003CModule\u003E.smethod_6<string>(1571700651U)))
        {
          this.Class29_0.method_75((byte) 1, \u003CModule\u003E.smethod_6<string>(1287800914U));
          this.Class29_0.bool_28 = false;
          this.Class29_0.Control2_0.button_72.Text = \u003CModule\u003E.smethod_8<string>(2486713409U);
          return;
        }
        this.Class29_0.method_90(this.Class29_0.Class75_0.Byte_1, sender.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) 30, (byte) 1);
        this.Class29_0.method_90(this.Class29_0.Class75_0.Byte_1, sender.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) 38, (byte) 2);
        this.Class29_0.method_95((byte) 1, this.Class29_0.Struct16_1, 1);
      }
      Thread.Sleep(1000);
    }
  }

  private bool method_85(bool class143_0)
  {
    if (class143_0)
    {
      if (this.bool_32)
        this.class142_1 = (Class142) null;
      else
        this.method_86();
    }
    else if (this.bool_31)
      this.class142_1 = (Class142) null;
    else
      this.method_87();
    if (this.class142_1 == null)
      return false;
    if (class143_0 && this.class142_1.UInt16_0 != (ushort) 99)
      this.class142_1 = (Class142) null;
    Struct16 struct160 = this.class142_1.Struct16_0;
    if (struct160.method_0(this.Class29_0.Struct16_1) != 1)
    {
      this.Class29_0.method_50(this.class142_1.Struct16_0, (short) 1, true, true);
    }
    else
    {
      struct160 = this.class142_1.Struct16_0;
      Direction int_11 = struct160.method_4(this.Class29_0.Struct16_1);
      if (int_11 != this.Class29_0.Direction_1)
        this.Class29_0.method_48(int_11);
      else
        this.Class29_0.method_30(\u003CModule\u003E.smethod_9<string>(2846211806U));
    }
    return true;
  }

  private void method_86()
  {
    List<Class142> source = this.Class29_0.method_120(12, new ushort[1]
    {
      (ushort) 99
    });
    if (source.Count <= 0)
      return;
    this.class142_1 = source.OrderBy<Class142, int>((Func<Class142, int>) (class142_0 => class142_0.Struct16_0.method_0(this.Class29_0.struct16_1))).FirstOrDefault<Class142>();
  }

  private void method_87()
  {
    List<Class142> source = this.Class29_0.method_120(12, new ushort[1]
    {
      (ushort) 47
    });
    if (source.Count <= 0)
      return;
    this.class142_1 = source.OrderBy<Class142, int>((Func<Class142, int>) (class142_0 => class142_0.Struct16_0.method_0(this.Class29_0.struct16_1))).FirstOrDefault<Class142>();
  }

  internal void method_88()
  {
    if (this.Class29_0.method_116().OfType<Class142>().Any<Class142>((Func<Class142, bool>) (class142_0 => class142_0.Byte_0 != (byte) 4 && class142_0.String_0 != \u003CModule\u003E.smethod_9<string>(746175844U) && class142_0.Struct16_0.method_0(this.Class29_0.Struct16_0) <= 5)))
    {
      try
      {
        List<Class142> list = this.Class29_0.method_116().OfType<Class142>().Where<Class142>((Func<Class142, bool>) (class141_0 => class141_0.Byte_0 != (byte) 4 && class141_0.String_0 != \u003CModule\u003E.smethod_8<string>(3292408110U) && class141_0.Struct16_0.method_0(this.Class29_0.Struct16_0) <= 5)).OrderBy<Class142, int>((Func<Class142, int>) (class141_0 => class141_0.Struct16_0.method_0(this.Class29_0.Struct16_0))).ToList<Class142>();
        Direction int_11 = list.First<Class142>().Struct16_0.method_4(this.Class29_0.Struct16_0);
        if (this.Class29_0.Direction_0 != int_11)
          this.Class29_0.method_48(int_11);
        this.Class29_0.method_78(list.First<Class142>().Int32_0);
        this.Class29_0.method_78(list.First<Class142>().Int32_0);
        ++list.First<Class142>().int_1;
        this.Class29_0.method_75((byte) 18, \u003CModule\u003E.smethod_6<string>(459541398U) + list.First<Class142>().int_1.ToString());
        Thread.Sleep(1000);
      }
      catch
      {
      }
    }
    else
      this.method_32(true);
  }

  internal void method_89()
  {
    if (this.Class29_0.class88_0.Int16_0 != (short) 390)
      this.Class29_0.method_54((short) 390);
    if (this.Class29_0.class88_0.Int16_0 == (short) 390 && Struct16.smethod_1(this.Class29_0.Struct16_1, new Struct16(8, 6)))
      this.Class29_0.method_50(new Struct16(8, 6), (short) 0, true, true);
    if (this.Class29_0.class88_0.Int16_0 != (short) 390 || !Struct16.smethod_0(this.Class29_0.Struct16_1, new Struct16(8, 6)))
      return;
    Class142 class142 = this.Class29_0.method_128(\u003CModule\u003E.smethod_8<string>(3052349458U));
    this.Class29_0.method_88((byte) 1, class142.Int32_0, (ushort) 3012, Array.Empty<object>());
    while (this.Class29_0.Class75_0 == null)
      Thread.Sleep(10);
    this.Class29_0.method_90((byte) 1, class142.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) ((uint) this.Class29_0.Class75_0.UInt16_3 + 1U), (byte) 2);
    this.Class29_0.method_89((byte) 1, class142.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) ((uint) this.Class29_0.Class75_0.UInt16_3 + 1U));
    this.Class29_0.method_89((byte) 1, class142.Int32_0, this.Class29_0.Class75_0.UInt16_2, (ushort) ((uint) this.Class29_0.Class75_0.UInt16_3 + 1U));
    this.Class29_0.Class75_0.method_4();
    Thread.Sleep(10000);
  }

  internal void method_90()
  {
    if (this.Class29_0.class88_0.Int16_0 != (short) 390)
      this.Class29_0.method_54((short) 390);
    if (this.Class29_0.class88_0.Int16_0 == (short) 390 && Struct16.smethod_1(this.Class29_0.Struct16_1, new Struct16(8, 6)))
      this.Class29_0.method_50(new Struct16(8, 6), (short) 0, true, true);
    if (this.Class29_0.class88_0.Int16_0 != (short) 390 || !Struct16.smethod_0(this.Class29_0.Struct16_1, new Struct16(8, 6)))
      return;
    this.Class29_0.method_83(this.Class29_0.method_128(\u003CModule\u003E.smethod_8<string>(3052349458U)).Int32_0, \u003CModule\u003E.smethod_9<string>(1281848096U), 100);
  }

  internal void method_91()
  {
    int num = int.MaxValue;
    short key = 0;
    foreach (KeyValuePair<short, Struct16> keyValuePair in this.dictionary_5)
    {
      int count = this.Class29_0.class109_0.method_0(this.Class29_0.Struct17_0, new Struct17(keyValuePair.Key, keyValuePair.Value)).Count;
      if (count < num && count > 0)
      {
        num = count;
        key = keyValuePair.Key;
      }
    }
    this.short_1 = key;
    this.struct16_4 = this.dictionary_5[key];
  }

  internal void method_92()
  {
    if ((int) this.Class29_0.class88_0.Int16_0 != (int) this.short_1)
      this.Class29_0.method_51(new Struct17(this.short_1, new Struct16(this.struct16_4.short_0, this.struct16_4.short_1)), (short) 0, false, true, true);
    else if ((int) this.Class29_0.class88_0.Int16_0 == (int) this.short_1 && this.Class29_0.Struct16_1.method_0(this.struct16_4) >= 1)
      this.Class29_0.method_50(this.struct16_4, (short) 0, false, true);
    else if ((int) this.Class29_0.class88_0.Int16_0 == (int) this.short_1 && this.Class29_0.Struct16_1.method_0(this.struct16_4) == 0 && !this.bool_38)
    {
      Class142 class142 = this.short_1 == (short) 422 || this.short_1 == (short) 950 ? (this.short_1 == (short) 422 ? this.Class29_0.method_128(\u003CModule\u003E.smethod_8<string>(3804292139U)) : this.Class29_0.method_128(\u003CModule\u003E.smethod_9<string>(2775552741U))) : this.Class29_0.method_129().OrderBy<Class142, int>((Func<Class142, int>) (class142_0 => class142_0.Struct16_0.method_0(this.Class29_0.Struct16_1))).FirstOrDefault<Class142>();
      if (class142 != null && class142.Struct16_0.method_0(this.Class29_0.Struct16_1) <= 12)
      {
        this.Class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_8<string>(731343931U));
        foreach (Class76 class76 in this.Class29_0.Class21_0)
        {
          if (this.Class29_0.Control2_0.listBox_4.Items.Contains((object) ((int) class76.UInt16_0 - 32768).ToString()))
          {
            this.Class29_0.method_85(class142.Int32_0, class76.String_0, class76.Int32_0);
            Thread.Sleep(1000);
          }
        }
      }
      else
        this.Class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_5<string>(1253209097U));
      this.bool_38 = true;
    }
    else
    {
      if (!this.bool_38)
        return;
      this.Class29_0.bool_1 = false;
    }
  }

  internal void method_93() => this.method_32(false);

  private bool method_94()
  {
    string class143_1;
    if (this.Class29_0.method_24(\u003CModule\u003E.smethod_6<string>(3327481574U)))
    {
      class143_1 = \u003CModule\u003E.smethod_6<string>(3327481574U);
    }
    else
    {
      if (!this.Class29_0.method_24(\u003CModule\u003E.smethod_7<string>(4201701631U)))
        return false;
      class143_1 = \u003CModule\u003E.smethod_5<string>(2276837361U);
    }
    if (!this.Class29_0.method_7(Enum10.Hide) || DateTime.UtcNow.Subtract(this.dateTime_1).TotalSeconds > 50.0)
    {
      this.Class29_0.method_30(\u003CModule\u003E.smethod_5<string>(2759602756U));
      this.Class29_0.method_31(class143_1, (Class142) null, true, true);
      this.dateTime_1 = DateTime.UtcNow;
    }
    return true;
  }

  internal class Class146
  {
    internal string String_0 { get; }

    internal short Int16_0 { get; }

    internal short Int16_1 { get; }

    internal List<string> List_0 { get; }

    internal Class146(string string_1, [In] short obj1, [In] short obj2, [In] List<string> obj3)
    {
      this.String_0 = string_1;
      this.Int16_0 = obj1;
      this.Int16_1 = obj2;
      this.List_0 = obj3;
    }
  }
}
