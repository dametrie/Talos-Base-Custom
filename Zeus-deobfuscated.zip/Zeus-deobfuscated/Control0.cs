﻿// Decompiled with JetBrains decompiler
// Type: Control0
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using Accolade.Properties;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Windows.Forms;

internal class Control0 : UserControl
{
  private Bitmap bitmap_0 = new Bitmap(1, 1);
  private Bitmap bitmap_1 = new Bitmap(1, 1);
  private GClass5 gclass5_0;
  private GClass5 gclass5_1;
  private Bitmap bitmap_2 = new Bitmap(1, 1);
  private Bitmap bitmap_3 = new Bitmap(1, 1);
  private Bitmap bitmap_4 = new Bitmap(1, 1);
  private Bitmap bitmap_5 = new Bitmap(1, 1);
  private GClass5 gclass5_2;
  private GClass5 gclass5_3;
  private Bitmap bitmap_6 = new Bitmap(1, 1);
  private Bitmap bitmap_7 = new Bitmap(1, 1);
  private GClass5 gclass5_4;
  private GClass5 gclass5_5;
  private Bitmap bitmap_8 = new Bitmap(1, 1);
  private Bitmap bitmap_9 = new Bitmap(1, 1);
  private GClass5 gclass5_6;
  private Bitmap bitmap_10 = new Bitmap(1, 1);
  private GClass5 gclass5_7;
  private Bitmap bitmap_11 = new Bitmap(1, 1);
  private GClass5 gclass5_8;
  private Bitmap bitmap_12 = new Bitmap(1, 1);
  private GClass5 gclass5_9;
  private Bitmap bitmap_13 = new Bitmap(1, 1);
  private GClass5 gclass5_10;
  private Bitmap bitmap_14 = new Bitmap(1, 1);
  private Bitmap bitmap_15 = new Bitmap(1, 1);
  private Bitmap bitmap_16 = new Bitmap(1, 1);
  private Bitmap bitmap_17 = new Bitmap(1, 1);
  private GClass5 gclass5_11;
  private GClass5 gclass5_12;
  private GClass5 gclass5_13;
  private Bitmap bitmap_18 = new Bitmap(1, 1);
  private Bitmap bitmap_19 = new Bitmap(1, 1);
  private Bitmap bitmap_20 = new Bitmap(1, 1);
  private Bitmap bitmap_21 = new Bitmap(1, 1);
  private GClass5 gclass5_14;
  private Bitmap bitmap_22 = new Bitmap(1, 1);
  private Bitmap bitmap_23 = new Bitmap(1, 1);
  private Bitmap bitmap_24 = new Bitmap(1, 1);
  private GClass5 gclass5_15;
  private GClass5 gclass5_16;
  private Bitmap bitmap_25 = new Bitmap(1, 1);
  private Bitmap bitmap_26 = new Bitmap(1, 1);
  internal GClass6 gclass6_0;
  internal GClass6 gclass6_1;
  internal GClass6 gclass6_2;
  internal GClass6 gclass6_3;
  internal GClass6 gclass6_4;
  internal GClass6 gclass6_5;
  internal GClass7 gclass7_0 = new GClass7();
  internal GClass7 gclass7_1 = new GClass7();
  internal GClass6 gclass6_6;
  internal GClass7 gclass7_2 = new GClass7();
  internal GClass7 gclass7_3 = new GClass7();
  internal GClass7 gclass7_4 = new GClass7();
  internal GClass7 gclass7_5 = new GClass7();
  internal GClass6 gclass6_7;
  private readonly Class29 class29_0;
  internal GClass7 gclass7_6 = new GClass7();
  internal GClass7 gclass7_7 = new GClass7();
  internal GClass6 gclass6_8;
  internal GClass6 gclass6_9;
  internal GClass6 gclass6_10;
  internal GClass7 gclass7_8 = new GClass7();
  internal bool bool_0;
  internal Class143 class143_0;
  internal Form5 form5_0;
  private string string_0;
  private Button button_0;
  internal GClass6 gclass6_11;
  private PictureBox pictureBox_0;
  internal GClass7 gclass7_9 = new GClass7();
  internal GClass7 gclass7_10 = new GClass7();

  internal Control0(Class143 sender, Class29 e)
  {
    this.method_0();
    this.form5_0 = e.Control2_0.class29_0.Class112_0.form5_0;
    this.class143_0 = sender;
    this.class29_0 = e;
    this.button_0.Text = \u003CModule\u003E.smethod_7<string>(3387256809U) + sender.String_5;
    if (((int) sender.Byte_2 & 16) != 16 && ((int) sender.Byte_2 & 32) != 32)
    {
      if (sender.Byte_2 != (byte) 0)
        return;
      string string_2 = string.Format(\u003CModule\u003E.smethod_5<string>(2377286419U), (object) (sender.UInt16_0 == (ushort) 0 ? 910 : (int) sender.UInt16_0));
      GClass22 bool_0 = GClass22.smethod_0(Settings.Default.DarkAgesPath.Replace(\u003CModule\u003E.smethod_7<string>(152792302U), \u003CModule\u003E.smethod_7<string>(1219536002U)));
      if (!bool_0.method_0(string_2))
        return;
      GClass14 gclass14 = GClass14.smethod_2(string_2, bool_0);
      int num = gclass14.byte_5 == (byte) 0 || (int) gclass14.byte_0 == (int) gclass14.byte_4 ? (int) gclass14.byte_0 + (int) gclass14.byte_1 : (int) gclass14.byte_0 - (int) gclass14.byte_5;
      if (num < 0)
        num = 0;
      if (num >= gclass14.Int32_2)
        num = gclass14.Int32_2 - 1;
      GClass16 gclass16 = GClass16.smethod_2(gclass14.string_0, bool_0);
      Bitmap bitmap = GClass9.smethod_2(gclass14[num], gclass16);
      bitmap.RotateFlip(RotateFlipType.RotateNoneFlipX);
      this.pictureBox_0.SizeMode = bitmap.Width > 100 || bitmap.Height > 100 ? PictureBoxSizeMode.Zoom : PictureBoxSizeMode.CenterImage;
      this.pictureBox_0.Image = (Image) bitmap;
    }
    else
    {
      this.gclass7_3.method_4(\u003CModule\u003E.smethod_7<string>(2839888711U), Form5.dictionary_0[\u003CModule\u003E.smethod_5<string>(3763710459U)]);
      this.gclass7_3.method_2(\u003CModule\u003E.smethod_9<string>(3621215451U), Form5.dictionary_0[\u003CModule\u003E.smethod_5<string>(3763710459U)]);
      this.gclass7_4.method_4(\u003CModule\u003E.smethod_7<string>(1225776913U), Form5.dictionary_0[\u003CModule\u003E.smethod_9<string>(1816952265U)]);
      this.gclass7_4.method_2(\u003CModule\u003E.smethod_8<string>(3866769383U), Form5.dictionary_0[\u003CModule\u003E.smethod_6<string>(1600472579U)]);
      this.gclass7_6.method_4(\u003CModule\u003E.smethod_8<string>(3519725625U), Form5.dictionary_0[\u003CModule\u003E.smethod_6<string>(1600472579U)]);
      this.gclass7_6.method_2(\u003CModule\u003E.smethod_9<string>(3797537203U), Form5.dictionary_0[\u003CModule\u003E.smethod_5<string>(3763710459U)]);
      this.gclass7_7.method_4(\u003CModule\u003E.smethod_8<string>(1252212651U), Form5.dictionary_0[\u003CModule\u003E.smethod_9<string>(1816952265U)]);
      this.gclass7_7.method_2(\u003CModule\u003E.smethod_6<string>(3256991611U), Form5.dictionary_0[\u003CModule\u003E.smethod_9<string>(1816952265U)]);
      this.gclass7_8.method_4(\u003CModule\u003E.smethod_7<string>(1801137507U), Form5.dictionary_0[\u003CModule\u003E.smethod_7<string>(159033213U)]);
      this.gclass7_8.method_2(\u003CModule\u003E.smethod_8<string>(3279666973U), Form5.dictionary_0[\u003CModule\u003E.smethod_5<string>(3763710459U)]);
      this.gclass7_5.method_4(\u003CModule\u003E.smethod_7<string>(3415249305U), Form5.dictionary_0[\u003CModule\u003E.smethod_7<string>(159033213U)]);
      this.gclass7_5.method_2(\u003CModule\u003E.smethod_8<string>(1012153999U), Form5.dictionary_0[\u003CModule\u003E.smethod_5<string>(3763710459U)]);
      this.gclass7_1.method_4(\u003CModule\u003E.smethod_8<string>(3039608321U), Form5.dictionary_0[\u003CModule\u003E.smethod_5<string>(3763710459U)]);
      this.gclass7_1.method_2(\u003CModule\u003E.smethod_5<string>(2182080809U), Form5.dictionary_0[\u003CModule\u003E.smethod_5<string>(3763710459U)]);
      this.gclass7_2.method_4(\u003CModule\u003E.smethod_6<string>(618543347U), Form5.dictionary_0[\u003CModule\u003E.smethod_8<string>(4106828035U)]);
      this.gclass7_2.method_2(\u003CModule\u003E.smethod_6<string>(618543347U), Form5.dictionary_0[\u003CModule\u003E.smethod_9<string>(1816952265U)]);
      this.gclass7_9.method_4(\u003CModule\u003E.smethod_6<string>(204413589U), Form5.dictionary_0[\u003CModule\u003E.smethod_7<string>(159033213U)]);
      this.gclass7_9.method_2(\u003CModule\u003E.smethod_5<string>(3570886893U), Form5.dictionary_0[\u003CModule\u003E.smethod_5<string>(3763710459U)]);
      this.gclass7_10.method_4(\u003CModule\u003E.smethod_7<string>(1253769409U), Form5.dictionary_0[\u003CModule\u003E.smethod_9<string>(1816952265U)]);
      this.gclass7_10.method_2(\u003CModule\u003E.smethod_6<string>(4085251127U), Form5.dictionary_0[\u003CModule\u003E.smethod_6<string>(1600472579U)]);
      this.gclass7_0.method_4(\u003CModule\u003E.smethod_5<string>(3830367025U), Form5.dictionary_0[\u003CModule\u003E.smethod_8<string>(4106828035U)]);
      this.gclass7_0.method_2(\u003CModule\u003E.smethod_7<string>(426476351U), Form5.dictionary_0[\u003CModule\u003E.smethod_6<string>(1600472579U)]);
      this.method_12(this.class143_0);
      this.method_8(this.class143_0);
      this.method_7(this.class143_0);
      this.method_13(this.class143_0);
      this.method_6(this.class143_0);
      this.method_4(this.class143_0);
      this.method_3(this.class143_0);
      this.method_9(this.class143_0);
      this.method_10(this.class143_0);
      this.method_11(this.class143_0);
      this.method_1();
      this.gclass7_3 = (GClass7) null;
      this.gclass7_4 = (GClass7) null;
      this.gclass7_6 = (GClass7) null;
      this.gclass7_7 = (GClass7) null;
      this.gclass7_8 = (GClass7) null;
      this.gclass7_5 = (GClass7) null;
      this.gclass7_1 = (GClass7) null;
      this.gclass7_2 = (GClass7) null;
      this.gclass7_9 = (GClass7) null;
      this.gclass7_10 = (GClass7) null;
      this.gclass7_0 = (GClass7) null;
      GC.Collect();
    }
  }

  private void method_0()
  {
    this.pictureBox_0 = new PictureBox();
    this.button_0 = new Button();
    ((ISupportInitialize) this.pictureBox_0).BeginInit();
    this.SuspendLayout();
    this.pictureBox_0.BackColor = Color.White;
    this.pictureBox_0.Location = new Point(0, -1);
    this.pictureBox_0.Margin = new Padding(0);
    this.pictureBox_0.Name = \u003CModule\u003E.smethod_6<string>(2631904598U);
    this.pictureBox_0.Size = new Size(128, 114);
    this.pictureBox_0.SizeMode = PictureBoxSizeMode.CenterImage;
    this.pictureBox_0.TabIndex = 11;
    this.pictureBox_0.TabStop = false;
    this.button_0.Font = new Font(\u003CModule\u003E.smethod_9<string>(868744759U), 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.button_0.ForeColor = Color.Black;
    this.button_0.Location = new Point(-1, 116);
    this.button_0.Name = \u003CModule\u003E.smethod_7<string>(180784798U);
    this.button_0.Size = new Size(130, 38);
    this.button_0.TabIndex = 10;
    this.button_0.Text = \u003CModule\u003E.smethod_8<string>(1578430661U);
    this.button_0.UseVisualStyleBackColor = true;
    this.button_0.Click += new EventHandler(this.button_0_Click);
    this.AutoScaleMode = AutoScaleMode.None;
    this.BackColor = Color.White;
    this.BorderStyle = BorderStyle.FixedSingle;
    this.Controls.Add((Control) this.pictureBox_0);
    this.Controls.Add((Control) this.button_0);
    this.Name = \u003CModule\u003E.smethod_6<string>(253916376U);
    this.Size = new Size(128, 153);
    this.Load += new EventHandler(this.Control0_Load);
    ((ISupportInitialize) this.pictureBox_0).EndInit();
    this.ResumeLayout(false);
  }

  internal void method_1()
  {
    Bitmap bitmap = new Bitmap(100, 85, PixelFormat.Format32bppArgb);
    Graphics graphics = Graphics.FromImage((Image) bitmap);
    graphics.DrawImage((Image) this.bitmap_3, -5, 0);
    graphics.DrawImage((Image) this.bitmap_7, -5, 0);
    graphics.DrawImage((Image) this.bitmap_9, -5, 0);
    graphics.DrawImage((Image) this.bitmap_12, 22, 0);
    graphics.DrawImage((Image) this.bitmap_21, 22, 0);
    graphics.DrawImage((Image) this.bitmap_14, 22, 0);
    graphics.DrawImage((Image) this.bitmap_18, 22, 0);
    graphics.DrawImage((Image) this.bitmap_19, 22, 0);
    graphics.DrawImage((Image) this.bitmap_20, 22, 0);
    graphics.DrawImage((Image) this.bitmap_13, 22, 0);
    graphics.DrawImage((Image) this.bitmap_10, 22, 0);
    graphics.DrawImage((Image) this.bitmap_11, 22, 0);
    graphics.DrawImage((Image) this.bitmap_25, -5, 0);
    graphics.DrawImage((Image) this.bitmap_26, -5, 0);
    graphics.DrawImage((Image) this.bitmap_22, 22, 0);
    graphics.DrawImage((Image) this.bitmap_2, -5, 0);
    graphics.DrawImage((Image) this.bitmap_6, -5, 0);
    graphics.DrawImage((Image) this.bitmap_8, -5, 0);
    this.pictureBox_0.Image = (Image) bitmap;
  }

  private GClass0 method_2(string sender, bool e)
  {
    int num = int.Parse(Regex.Match(sender, \u003CModule\u003E.smethod_6<string>(3720624156U)).Value);
    if (e)
    {
      if (num >= 97 && num <= 100)
        return Form5.dictionary_0[\u003CModule\u003E.smethod_7<string>(96807310U)];
      if (num >= 101 && num <= 104)
        return Form5.dictionary_0[\u003CModule\u003E.smethod_8<string>(3792451082U)];
      if (num >= 105 && num <= 109)
        return Form5.dictionary_0[\u003CModule\u003E.smethod_8<string>(3552392430U)];
      if (num >= 110 && num <= 115)
        return Form5.dictionary_0[\u003CModule\u003E.smethod_8<string>(937835698U)];
      if (num >= 116 && num <= 122)
        return Form5.dictionary_0[\u003CModule\u003E.smethod_7<string>(124799806U)];
    }
    else
    {
      if (num >= 97 && num <= 100)
        return Form5.dictionary_0[\u003CModule\u003E.smethod_9<string>(3565716496U)];
      if (num >= 101 && num <= 104)
        return Form5.dictionary_0[\u003CModule\u003E.smethod_8<string>(217659742U)];
      if (num >= 105 && num <= 109)
        return Form5.dictionary_0[\u003CModule\u003E.smethod_9<string>(1348918056U)];
      if (num >= 110 && num <= 115)
        return Form5.dictionary_0[\u003CModule\u003E.smethod_5<string>(3746571942U)];
      if (num >= 116 && num <= 122)
        return Form5.dictionary_0[\u003CModule\u003E.smethod_9<string>(2721799904U)];
    }
    return (GClass0) null;
  }

  private void button_0_Click(object sender, EventArgs e) => this.class29_0.Control2_0.method_15(this.Name, this.pictureBox_0.Image);

  private void Control0_Load(object disposing, [In] EventArgs obj1) => this.bool_0 = true;

  internal void method_3(Class143 disposing)
  {
    if (this.string_0 == \u003CModule\u003E.smethod_9<string>(2035358980U))
    {
      GClass0 gclass0 = this.method_2(\u003CModule\u003E.smethod_5<string>(776136208U), this.string_0.StartsWith(\u003CModule\u003E.smethod_6<string>(2355789613U)));
      this.gclass5_14 = GClass5.smethod_2(\u003CModule\u003E.smethod_7<string>(3520978378U) + disposing.Byte_4.ToString(\u003CModule\u003E.smethod_8<string>(590791940U)) + \u003CModule\u003E.smethod_6<string>(360706702U), gclass0);
      this.bitmap_22 = this.gclass5_14 != null ? GClass3.smethod_0(this.gclass5_14[5], this.gclass7_2.method_0(\u003CModule\u003E.smethod_6<string>(490936723U))) : new Bitmap(1, 1);
    }
    else
    {
      GClass0 gclass0 = this.method_2(\u003CModule\u003E.smethod_7<string>(1906866580U), this.string_0.StartsWith(\u003CModule\u003E.smethod_7<string>(2221024947U)));
      this.gclass5_14 = GClass5.smethod_2(\u003CModule\u003E.smethod_6<string>(2431355492U) + disposing.Byte_4.ToString(\u003CModule\u003E.smethod_7<string>(2973610280U)) + \u003CModule\u003E.smethod_5<string>(711861686U), gclass0);
      this.bitmap_22 = this.gclass5_14 != null ? GClass3.smethod_0(this.gclass5_14[5], this.gclass7_2.method_0(\u003CModule\u003E.smethod_7<string>(19070733U))) : new Bitmap(1, 1);
    }
  }

  internal void method_4(Class143 sender)
  {
    if (sender.Byte_14 != (byte) 0)
    {
      GClass0 gclass0 = this.method_2(\u003CModule\u003E.smethod_8<string>(2138128958U), this.string_0.StartsWith(\u003CModule\u003E.smethod_9<string>(579346503U)));
      if (this.string_0 == \u003CModule\u003E.smethod_9<string>(2035358980U))
        this.gclass5_10 = GClass5.smethod_2(\u003CModule\u003E.smethod_9<string>(54774042U) + sender.Byte_14.ToString() + \u003CModule\u003E.smethod_7<string>(292754782U), gclass0);
      if (this.string_0 == \u003CModule\u003E.smethod_6<string>(207036986U))
        this.gclass5_10 = GClass5.smethod_2(\u003CModule\u003E.smethod_7<string>(3163316841U) + sender.Byte_14.ToString() + \u003CModule\u003E.smethod_7<string>(292754782U), gclass0);
      if (this.string_0 == \u003CModule\u003E.smethod_5<string>(2229216814U) && this.gclass5_10 == null)
        this.gclass5_10 = GClass5.smethod_2(\u003CModule\u003E.smethod_6<string>(4218104545U), gclass0);
      if (this.string_0 == \u003CModule\u003E.smethod_5<string>(583312642U) && this.gclass5_10 == null)
        this.gclass5_10 = GClass5.smethod_2(\u003CModule\u003E.smethod_8<string>(2084636405U), gclass0);
      this.bitmap_14 = GClass3.smethod_0(this.gclass5_10[5], this.gclass7_3[(int) sender.Byte_13]);
    }
    if (sender.Byte_14 != (byte) 0)
      return;
    GClass0 gclass0_1 = this.method_2(\u003CModule\u003E.smethod_9<string>(3584562580U), this.string_0.StartsWith(\u003CModule\u003E.smethod_6<string>(2355789613U)));
    if (this.string_0 == \u003CModule\u003E.smethod_7<string>(2398249686U))
      this.gclass5_10 = GClass5.smethod_2(\u003CModule\u003E.smethod_7<string>(1822889092U) + sender.Byte_14.ToString() + \u003CModule\u003E.smethod_6<string>(360706702U), gclass0_1);
    if (this.string_0 == \u003CModule\u003E.smethod_9<string>(2545478152U))
      this.gclass5_10 = GClass5.smethod_2(\u003CModule\u003E.smethod_9<string>(613685173U) + sender.Byte_14.ToString() + \u003CModule\u003E.smethod_7<string>(292754782U), gclass0_1);
    if (this.string_0 == \u003CModule\u003E.smethod_9<string>(2035358980U) && this.gclass5_10 == null)
      this.gclass5_10 = GClass5.smethod_2(\u003CModule\u003E.smethod_6<string>(4218104545U), gclass0_1);
    if (this.string_0 == \u003CModule\u003E.smethod_7<string>(3437000890U) && this.gclass5_10 == null)
      this.gclass5_10 = GClass5.smethod_2(\u003CModule\u003E.smethod_5<string>(1181303901U), gclass0_1);
    this.bitmap_14 = GClass3.smethod_0(this.gclass5_10[5], this.gclass7_3[(int) sender.Byte_13]);
  }

  internal void method_5([In] Class143 obj0)
  {
    if (this.string_0 == \u003CModule\u003E.smethod_5<string>(2229216814U))
    {
      GClass5 gclass5 = GClass5.smethod_2(\u003CModule\u003E.smethod_7<string>(510453839U), Form5.dictionary_0[\u003CModule\u003E.smethod_7<string>(3353023402U)]);
      if (gclass5 != null)
      {
        this.gclass6_11 = GClass6.smethod_5(this.gclass7_4.method_0(\u003CModule\u003E.smethod_7<string>(1577197539U)), 1);
        this.bitmap_21 = GClass3.smethod_0(gclass5[5], this.gclass6_11);
      }
      else
        this.bitmap_21 = new Bitmap(1, 1);
    }
    if (!(this.string_0 == \u003CModule\u003E.smethod_6<string>(207036986U)))
      return;
    GClass5 gclass5_1 = GClass5.smethod_2(\u003CModule\u003E.smethod_6<string>(2691815534U), Form5.dictionary_0[\u003CModule\u003E.smethod_8<string>(1658011654U)]);
    if (gclass5_1 != null)
    {
      this.gclass6_11 = GClass6.smethod_5(this.gclass7_4.method_0(\u003CModule\u003E.smethod_7<string>(1303513490U)), 1);
      this.bitmap_21 = GClass3.smethod_0(gclass5_1[5], this.gclass6_11);
    }
    else
      this.bitmap_21 = new Bitmap(1, 1);
  }

  internal void method_6(Class143 sender)
  {
    GClass0 gclass0_1 = this.method_2(\u003CModule\u003E.smethod_8<string>(777358039U), this.string_0.StartsWith(\u003CModule\u003E.smethod_5<string>(2517261141U)));
    GClass0 gclass0_2 = this.method_2(\u003CModule\u003E.smethod_7<string>(202536383U), this.string_0.StartsWith(\u003CModule\u003E.smethod_7<string>(2221024947U)));
    if (this.string_0 == \u003CModule\u003E.smethod_7<string>(2398249686U))
    {
      this.gclass5_15 = GClass5.smethod_2(\u003CModule\u003E.smethod_7<string>(1816648181U) + sender.UInt16_4.ToString(\u003CModule\u003E.smethod_9<string>(4015943918U)) + \u003CModule\u003E.smethod_5<string>(711861686U), gclass0_1);
      this.gclass5_16 = GClass5.smethod_2(\u003CModule\u003E.smethod_7<string>(1269280083U) + sender.UInt16_4.ToString(\u003CModule\u003E.smethod_9<string>(4015943918U)) + \u003CModule\u003E.smethod_9<string>(2211680732U), gclass0_2);
      if (this.gclass5_15 != null && this.gclass5_16 == null)
      {
        this.bitmap_25 = GClass3.smethod_0(this.gclass5_15.GClass4_0[5], this.gclass7_10.method_0(\u003CModule\u003E.smethod_7<string>(1816648181U) + sender.UInt16_4.ToString(\u003CModule\u003E.smethod_9<string>(4015943918U))));
        gclass0_1 = (GClass0) null;
        gclass0_2 = (GClass0) null;
      }
      else if (this.gclass5_15 == null && this.gclass5_16 != null)
      {
        this.bitmap_26 = GClass3.smethod_0(this.gclass5_16.GClass4_0[5], this.gclass7_9.method_0(\u003CModule\u003E.smethod_6<string>(2595433357U) + sender.UInt16_4.ToString(\u003CModule\u003E.smethod_6<string>(774836460U))));
        gclass0_1 = (GClass0) null;
        gclass0_2 = (GClass0) null;
      }
      else if (this.gclass5_15 != null && this.gclass5_16 != null)
      {
        this.bitmap_25 = GClass3.smethod_0(this.gclass5_15.GClass4_0[5], this.gclass7_10.method_0(\u003CModule\u003E.smethod_9<string>(2987959281U) + sender.UInt16_4.ToString(\u003CModule\u003E.smethod_8<string>(590791940U))));
        this.bitmap_26 = GClass3.smethod_0(this.gclass5_16.GClass4_0[5], this.gclass7_9.method_0(\u003CModule\u003E.smethod_9<string>(4105781543U) + sender.UInt16_4.ToString(\u003CModule\u003E.smethod_7<string>(2973610280U))));
        gclass0_1 = (GClass0) null;
        gclass0_2 = (GClass0) null;
      }
    }
    if (!(this.string_0 == \u003CModule\u003E.smethod_6<string>(207036986U)))
      return;
    this.gclass5_15 = GClass5.smethod_2(\u003CModule\u003E.smethod_7<string>(2883391881U) + sender.UInt16_4.ToString(\u003CModule\u003E.smethod_9<string>(4015943918U)) + \u003CModule\u003E.smethod_7<string>(292754782U), gclass0_1);
    this.gclass5_16 = GClass5.smethod_2(\u003CModule\u003E.smethod_7<string>(2336023783U) + sender.UInt16_4.ToString(\u003CModule\u003E.smethod_5<string>(2164942292U)) + \u003CModule\u003E.smethod_6<string>(360706702U), gclass0_2);
    GClass0 gclass0_3;
    GClass0 gclass0_4;
    if (this.gclass5_15 != null && this.gclass5_16 == null)
    {
      this.bitmap_25 = GClass3.smethod_0(this.gclass5_15.GClass4_0[5], this.gclass7_10.method_0(\u003CModule\u003E.smethod_7<string>(2883391881U) + sender.UInt16_4.ToString(\u003CModule\u003E.smethod_6<string>(774836460U))));
      gclass0_3 = (GClass0) null;
      gclass0_4 = (GClass0) null;
    }
    else if (this.gclass5_15 == null && this.gclass5_16 != null)
    {
      this.bitmap_26 = GClass3.smethod_0(this.gclass5_16.GClass4_0[5], this.gclass7_9.method_0(\u003CModule\u003E.smethod_7<string>(2336023783U) + sender.UInt16_4.ToString(\u003CModule\u003E.smethod_9<string>(4015943918U))));
      gclass0_3 = (GClass0) null;
      gclass0_4 = (GClass0) null;
    }
    else
    {
      if (this.gclass5_15 == null || this.gclass5_16 == null)
        return;
      this.bitmap_25 = GClass3.smethod_0(this.gclass5_15.GClass4_0[5], this.gclass7_10.method_0(\u003CModule\u003E.smethod_5<string>(963246935U) + sender.UInt16_4.ToString(\u003CModule\u003E.smethod_5<string>(2164942292U))));
      this.bitmap_26 = GClass3.smethod_0(this.gclass5_16.GClass4_0[5], this.gclass7_9.method_0(\u003CModule\u003E.smethod_9<string>(1870137019U) + sender.UInt16_4.ToString(\u003CModule\u003E.smethod_5<string>(2164942292U))));
      gclass0_3 = (GClass0) null;
      gclass0_4 = (GClass0) null;
    }
  }

  internal void method_7([In] Class143 obj0)
  {
    byte byte3;
    if (this.string_0 == \u003CModule\u003E.smethod_8<string>(1177894350U))
    {
      GClass0 gclass0 = this.method_2(\u003CModule\u003E.smethod_7<string>(3950135581U), this.string_0.StartsWith(\u003CModule\u003E.smethod_6<string>(2355789613U)));
      this.bitmap_13 = new Bitmap(1, 1);
      this.gclass5_9 = GClass5.smethod_2(\u003CModule\u003E.smethod_6<string>(4251952389U) + obj0.Byte_3.ToString(\u003CModule\u003E.smethod_5<string>(2164942292U)) + \u003CModule\u003E.smethod_9<string>(2211680732U), gclass0);
      GClass7 gclass75 = this.gclass7_5;
      string str1 = \u003CModule\u003E.smethod_5<string>(898972413U);
      byte3 = obj0.Byte_3;
      string str2 = byte3.ToString(\u003CModule\u003E.smethod_6<string>(774836460U));
      string int_3 = str1 + str2;
      this.gclass6_7 = GClass6.smethod_5(gclass75.method_0(int_3), (int) obj0.Byte_6);
      if (this.gclass5_9 != null)
        this.bitmap_13 = GClass3.smethod_0(this.gclass5_9[5], this.gclass6_7);
    }
    if (!(this.string_0 == \u003CModule\u003E.smethod_5<string>(583312642U)))
      return;
    GClass0 gclass0_1 = this.method_2(\u003CModule\u003E.smethod_6<string>(371114851U), this.string_0.StartsWith(\u003CModule\u003E.smethod_7<string>(2221024947U)));
    this.bitmap_13 = new Bitmap(1, 1);
    string str3 = \u003CModule\u003E.smethod_8<string>(3553708103U);
    byte3 = obj0.Byte_3;
    string str4 = byte3.ToString(\u003CModule\u003E.smethod_8<string>(590791940U));
    string str5 = \u003CModule\u003E.smethod_8<string>(2618246262U);
    this.gclass5_9 = GClass5.smethod_2(str3 + str4 + str5, gclass0_1);
    GClass7 gclass75_1 = this.gclass7_5;
    string str6 = \u003CModule\u003E.smethod_6<string>(3837822631U);
    byte3 = obj0.Byte_3;
    string str7 = byte3.ToString(\u003CModule\u003E.smethod_7<string>(2973610280U));
    string int_3_1 = str6 + str7;
    this.gclass6_7 = GClass6.smethod_5(gclass75_1.method_0(int_3_1), (int) obj0.Byte_6);
    if (this.gclass5_9 != null)
      this.bitmap_13 = GClass3.smethod_0(this.gclass5_9[5], this.gclass6_7);
  }

  internal void method_8(Class143 sender)
  {
    ushort uint161_1;
    if (this.string_0 == \u003CModule\u003E.smethod_7<string>(2398249686U))
    {
      GClass0 gclass0_1 = this.method_2(\u003CModule\u003E.smethod_6<string>(2441763641U), this.string_0.StartsWith(\u003CModule\u003E.smethod_5<string>(2517261141U)));
      GClass0 gclass0_2 = this.method_2(\u003CModule\u003E.smethod_9<string>(242195585U), this.string_0.StartsWith(\u003CModule\u003E.smethod_9<string>(579346503U)));
      GClass0 gclass0_3 = this.method_2(\u003CModule\u003E.smethod_8<string>(2966605693U), this.string_0.StartsWith(\u003CModule\u003E.smethod_9<string>(579346503U)));
      this.bitmap_18 = new Bitmap(1, 1);
      this.bitmap_19 = new Bitmap(1, 1);
      this.bitmap_20 = new Bitmap(1, 1);
      string str1 = \u003CModule\u003E.smethod_5<string>(2223503975U);
      ushort uint161_2 = sender.UInt16_1;
      string str2 = uint161_2.ToString(\u003CModule\u003E.smethod_6<string>(774836460U));
      string str3 = \u003CModule\u003E.smethod_6<string>(360706702U);
      this.gclass5_11 = GClass5.smethod_2(str1 + str2 + str3, gclass0_1);
      string str4 = \u003CModule\u003E.smethod_9<string>(3419340619U);
      uint161_2 = sender.UInt16_1;
      string str5 = uint161_2.ToString(\u003CModule\u003E.smethod_9<string>(4015943918U));
      string str6 = \u003CModule\u003E.smethod_6<string>(360706702U);
      this.gclass5_12 = GClass5.smethod_2(str4 + str5 + str6, gclass0_2);
      string str7 = \u003CModule\u003E.smethod_6<string>(3684152915U);
      uint161_2 = sender.UInt16_1;
      string str8 = uint161_2.ToString(\u003CModule\u003E.smethod_5<string>(2164942292U));
      string str9 = \u003CModule\u003E.smethod_9<string>(2211680732U);
      this.gclass5_13 = GClass5.smethod_2(str7 + str8 + str9, gclass0_3);
      this.gclass6_8 = GClass6.smethod_5(this.gclass7_6.method_0(\u003CModule\u003E.smethod_8<string>(699092719U) + sender.UInt16_1.ToString(\u003CModule\u003E.smethod_5<string>(2164942292U))), (int) sender.Byte_5);
      this.gclass6_9 = GClass6.smethod_5(this.gclass7_6.method_0(\u003CModule\u003E.smethod_8<string>(2726547041U) + sender.UInt16_1.ToString(\u003CModule\u003E.smethod_5<string>(2164942292U))), (int) sender.Byte_5);
      GClass7 gclass76 = this.gclass7_6;
      string str10 = \u003CModule\u003E.smethod_7<string>(3978128077U);
      uint161_1 = sender.UInt16_1;
      string str11 = uint161_1.ToString(\u003CModule\u003E.smethod_5<string>(2164942292U));
      string int_3 = str10 + str11;
      this.gclass6_10 = GClass6.smethod_5(gclass76.method_0(int_3), (int) sender.Byte_5);
      if (this.gclass5_11 != null)
        this.bitmap_18 = GClass3.smethod_0(this.gclass5_11[5], this.gclass6_8);
      if (this.gclass5_12 != null)
        this.bitmap_19 = GClass3.smethod_0(this.gclass5_12[5], this.gclass6_9);
      if (this.gclass5_13 != null)
        this.bitmap_20 = GClass3.smethod_0(this.gclass5_13[5], this.gclass6_10);
    }
    if (!(this.string_0 == \u003CModule\u003E.smethod_7<string>(3437000890U)))
      return;
    GClass0 gclass0_4 = this.method_2(\u003CModule\u003E.smethod_8<string>(3206664345U), this.string_0.StartsWith(\u003CModule\u003E.smethod_8<string>(4135547821U)));
    GClass0 gclass0_5 = this.method_2(\u003CModule\u003E.smethod_9<string>(242195585U), this.string_0.StartsWith(\u003CModule\u003E.smethod_9<string>(579346503U)));
    GClass0 gclass0_6 = this.method_2(\u003CModule\u003E.smethod_7<string>(1297272579U), this.string_0.StartsWith(\u003CModule\u003E.smethod_6<string>(2355789613U)));
    this.bitmap_18 = new Bitmap(1, 1);
    this.bitmap_19 = new Bitmap(1, 1);
    this.bitmap_20 = new Bitmap(1, 1);
    string str12 = \u003CModule\u003E.smethod_6<string>(3270023157U);
    uint161_1 = sender.UInt16_1;
    string str13 = uint161_1.ToString(\u003CModule\u003E.smethod_9<string>(4015943918U));
    string str14 = \u003CModule\u003E.smethod_5<string>(711861686U);
    this.gclass5_11 = GClass5.smethod_2(str12 + str13 + str14, gclass0_4);
    string str15 = \u003CModule\u003E.smethod_7<string>(749904481U);
    uint161_1 = sender.UInt16_1;
    string str16 = uint161_1.ToString(\u003CModule\u003E.smethod_7<string>(2973610280U));
    string str17 = \u003CModule\u003E.smethod_5<string>(711861686U);
    this.gclass5_12 = GClass5.smethod_2(str15 + str16 + str17, gclass0_5);
    string str18 = \u003CModule\u003E.smethod_9<string>(1693815267U);
    uint161_1 = sender.UInt16_1;
    string str19 = uint161_1.ToString(\u003CModule\u003E.smethod_7<string>(2973610280U));
    string str20 = \u003CModule\u003E.smethod_6<string>(360706702U);
    this.gclass5_13 = GClass5.smethod_2(str18 + str19 + str20, gclass0_6);
    GClass7 gclass78 = this.gclass7_8;
    string str21 = \u003CModule\u003E.smethod_7<string>(3430759979U);
    uint161_1 = sender.UInt16_1;
    string str22 = uint161_1.ToString(\u003CModule\u003E.smethod_8<string>(590791940U));
    string int_3_1 = str21 + str22;
    this.gclass6_8 = GClass6.smethod_5(gclass78.method_0(int_3_1), (int) sender.Byte_5);
    GClass7 gclass76_1 = this.gclass7_6;
    string str23 = \u003CModule\u003E.smethod_9<string>(928636509U);
    uint161_1 = sender.UInt16_1;
    string str24 = uint161_1.ToString(\u003CModule\u003E.smethod_5<string>(2164942292U));
    string int_3_2 = str23 + str24;
    this.gclass6_9 = GClass6.smethod_5(gclass76_1.method_0(int_3_2), (int) sender.Byte_5);
    GClass7 gclass77 = this.gclass7_7;
    string str25 = \u003CModule\u003E.smethod_7<string>(146551391U);
    uint161_1 = sender.UInt16_1;
    string str26 = uint161_1.ToString(\u003CModule\u003E.smethod_7<string>(2973610280U));
    string int_3_3 = str25 + str26;
    this.gclass6_10 = GClass6.smethod_5(gclass77.method_0(int_3_3), (int) sender.Byte_5);
    if (this.gclass5_11 != null)
      this.bitmap_18 = GClass3.smethod_0(this.gclass5_11[5], this.gclass6_8);
    if (this.gclass5_12 != null)
      this.bitmap_19 = GClass3.smethod_0(this.gclass5_12[5], this.gclass6_9);
    if (this.gclass5_13 != null)
      this.bitmap_20 = GClass3.smethod_0(this.gclass5_13[5], this.gclass6_10);
  }

  internal void method_9([In] Class143 obj0)
  {
    ushort uint165_1;
    if (this.string_0 == \u003CModule\u003E.smethod_8<string>(1177894350U))
    {
      GClass0 gclass0_1 = this.method_2(\u003CModule\u003E.smethod_5<string>(2094954931U), this.string_0.StartsWith(\u003CModule\u003E.smethod_5<string>(2517261141U)));
      GClass0 gclass0_2 = this.method_2(\u003CModule\u003E.smethod_9<string>(1007374343U), this.string_0.StartsWith(\u003CModule\u003E.smethod_9<string>(579346503U)));
      string str1 = \u003CModule\u003E.smethod_5<string>(3483761015U);
      ushort uint165_2 = obj0.UInt16_5;
      string str2 = uint165_2.ToString(\u003CModule\u003E.smethod_5<string>(2164942292U));
      string str3 = \u003CModule\u003E.smethod_5<string>(711861686U);
      this.gclass5_0 = GClass5.smethod_2(str1 + str2 + str3, gclass0_1);
      string str4 = \u003CModule\u003E.smethod_5<string>(2030680409U);
      uint165_2 = obj0.UInt16_5;
      string str5 = uint165_2.ToString(\u003CModule\u003E.smethod_9<string>(4015943918U));
      string str6 = \u003CModule\u003E.smethod_7<string>(292754782U);
      this.gclass5_1 = GClass5.smethod_2(str4 + str5 + str6, gclass0_2);
      this.bitmap_2 = new Bitmap(1, 1);
      this.gclass6_0 = GClass6.smethod_5(this.gclass7_0.method_0(\u003CModule\u003E.smethod_8<string>(1659327327U) + obj0.UInt16_5.ToString(\u003CModule\u003E.smethod_7<string>(2973610280U))), (int) obj0.Byte_7);
      GClass7 gclass70 = this.gclass7_0;
      string str7 = \u003CModule\u003E.smethod_5<string>(2030680409U);
      uint165_1 = obj0.UInt16_5;
      string str8 = uint165_1.ToString(\u003CModule\u003E.smethod_5<string>(2164942292U));
      string int_3 = str7 + str8;
      this.gclass6_1 = GClass6.smethod_5(gclass70.method_0(int_3), (int) obj0.Byte_7);
      if (this.gclass5_0 != null && this.gclass5_1 == null)
      {
        this.bitmap_2 = GClass3.smethod_0(this.gclass5_0[5], this.gclass6_0);
        this.bitmap_3 = new Bitmap(1, 1);
      }
      else if (this.gclass5_0 != null && this.gclass5_1 != null)
      {
        this.bitmap_2 = GClass3.smethod_0(this.gclass5_0[5], this.gclass6_0);
        this.bitmap_3 = GClass3.smethod_0(this.gclass5_1[5], this.gclass6_1);
      }
      else if (this.gclass5_0 == null && this.gclass5_1 != null)
      {
        this.bitmap_3 = GClass3.smethod_0(this.gclass5_1[5], this.gclass6_2);
        this.bitmap_2 = new Bitmap(1, 1);
      }
      else
      {
        this.bitmap_2 = new Bitmap(1, 1);
        this.bitmap_3 = new Bitmap(1, 1);
      }
    }
    if (!(this.string_0 == \u003CModule\u003E.smethod_9<string>(2545478152U)))
      return;
    GClass0 gclass0_3 = this.method_2(\u003CModule\u003E.smethod_5<string>(2094954931U), this.string_0.StartsWith(\u003CModule\u003E.smethod_6<string>(2355789613U)));
    GClass0 gclass0_4 = this.method_2(\u003CModule\u003E.smethod_5<string>(641874325U), this.string_0.StartsWith(\u003CModule\u003E.smethod_8<string>(4135547821U)));
    string str9 = \u003CModule\u003E.smethod_8<string>(1419268675U);
    uint165_1 = obj0.UInt16_5;
    string str10 = uint165_1.ToString(\u003CModule\u003E.smethod_7<string>(2973610280U));
    string str11 = \u003CModule\u003E.smethod_7<string>(292754782U);
    this.gclass5_0 = GClass5.smethod_2(str9 + str10 + str11, gclass0_3);
    string str12 = \u003CModule\u003E.smethod_7<string>(3346782491U);
    uint165_1 = obj0.UInt16_5;
    string str13 = uint165_1.ToString(\u003CModule\u003E.smethod_5<string>(2164942292U));
    string str14 = \u003CModule\u003E.smethod_7<string>(292754782U);
    this.gclass5_1 = GClass5.smethod_2(str12 + str13 + str14, gclass0_4);
    this.bitmap_2 = new Bitmap(1, 1);
    GClass7 gclass70_1 = this.gclass7_0;
    string str15 = \u003CModule\u003E.smethod_6<string>(2702223683U);
    uint165_1 = obj0.UInt16_5;
    string str16 = uint165_1.ToString(\u003CModule\u003E.smethod_7<string>(2973610280U));
    string int_3_1 = str15 + str16;
    this.gclass6_0 = GClass6.smethod_5(gclass70_1.method_0(int_3_1), (int) obj0.Byte_7);
    GClass7 gclass70_2 = this.gclass7_0;
    string str17 = \u003CModule\u003E.smethod_5<string>(3419486493U);
    uint165_1 = obj0.UInt16_5;
    string str18 = uint165_1.ToString(\u003CModule\u003E.smethod_7<string>(2973610280U));
    string int_3_2 = str17 + str18;
    this.gclass6_1 = GClass6.smethod_5(gclass70_2.method_0(int_3_2), (int) obj0.Byte_7);
    if (this.gclass5_0 != null && this.gclass5_1 == null)
    {
      this.bitmap_2 = GClass3.smethod_0(this.gclass5_0[5], this.gclass6_0);
      this.bitmap_3 = new Bitmap(1, 1);
    }
    else if (this.gclass5_0 != null && this.gclass5_1 != null)
    {
      this.bitmap_2 = GClass3.smethod_0(this.gclass5_0[5], this.gclass6_0);
      this.bitmap_3 = GClass3.smethod_0(this.gclass5_1[5], this.gclass6_1);
    }
    else if (this.gclass5_0 == null && this.gclass5_1 != null)
    {
      this.bitmap_3 = GClass3.smethod_0(this.gclass5_1[5], this.gclass6_2);
      this.bitmap_2 = new Bitmap(1, 1);
    }
    else
    {
      this.bitmap_2 = new Bitmap(1, 1);
      this.bitmap_3 = new Bitmap(1, 1);
    }
  }

  internal void method_10(Class143 sender)
  {
    ushort uint166_1;
    if (this.string_0 == \u003CModule\u003E.smethod_5<string>(2229216814U))
    {
      GClass0 gclass0_1 = this.method_2(\u003CModule\u003E.smethod_9<string>(4184519377U), this.string_0.StartsWith(\u003CModule\u003E.smethod_9<string>(579346503U)));
      GClass0 gclass0_2 = this.method_2(\u003CModule\u003E.smethod_9<string>(1007374343U), this.string_0.StartsWith(\u003CModule\u003E.smethod_7<string>(2221024947U)));
      string str1 = \u003CModule\u003E.smethod_6<string>(217445135U);
      ushort uint166_2 = sender.UInt16_6;
      string str2 = uint166_2.ToString(\u003CModule\u003E.smethod_6<string>(774836460U));
      string str3 = \u003CModule\u003E.smethod_8<string>(2618246262U);
      this.gclass5_2 = GClass5.smethod_2(str1 + str2 + str3, gclass0_1);
      string str4 = \u003CModule\u003E.smethod_6<string>(3116353441U);
      uint166_2 = sender.UInt16_6;
      string str5 = uint166_2.ToString(\u003CModule\u003E.smethod_9<string>(4015943918U));
      string str6 = \u003CModule\u003E.smethod_9<string>(2211680732U);
      this.gclass5_3 = GClass5.smethod_2(str4 + str5 + str6, gclass0_2);
      this.bitmap_6 = new Bitmap(1, 1);
      this.gclass6_2 = GClass6.smethod_5(this.gclass7_0.method_0(\u003CModule\u003E.smethod_6<string>(217445135U) + sender.UInt16_6.ToString(\u003CModule\u003E.smethod_6<string>(774836460U))), (int) sender.Byte_8);
      GClass7 gclass70 = this.gclass7_0;
      string str7 = \u003CModule\u003E.smethod_6<string>(3116353441U);
      uint166_1 = sender.UInt16_6;
      string str8 = uint166_1.ToString(\u003CModule\u003E.smethod_8<string>(590791940U));
      string int_3 = str7 + str8;
      this.gclass6_3 = GClass6.smethod_5(gclass70.method_0(int_3), (int) sender.Byte_8);
      if (this.gclass5_2 != null && this.gclass5_3 == null)
      {
        this.bitmap_6 = GClass3.smethod_0(this.gclass5_2[5], this.gclass6_2);
        this.bitmap_7 = new Bitmap(1, 1);
      }
      else if (this.gclass5_2 != null && this.gclass5_3 != null)
      {
        this.bitmap_6 = GClass3.smethod_0(this.gclass5_2[5], this.gclass6_2);
        this.bitmap_7 = GClass3.smethod_0(this.gclass5_3[5], this.gclass6_3);
      }
      else if (this.gclass5_2 == null && this.gclass5_3 != null)
      {
        this.bitmap_7 = GClass3.smethod_0(this.gclass5_3[5], this.gclass6_2);
        this.bitmap_6 = new Bitmap(1, 1);
      }
      else
      {
        this.bitmap_6 = new Bitmap(1, 1);
        this.bitmap_7 = new Bitmap(1, 1);
      }
    }
    if (!(this.string_0 == \u003CModule\u003E.smethod_9<string>(2545478152U)))
      return;
    GClass0 gclass0_3 = this.method_2(\u003CModule\u003E.smethod_8<string>(1899385979U), this.string_0.StartsWith(\u003CModule\u003E.smethod_6<string>(2355789613U)));
    GClass0 gclass0_4 = this.method_2(\u003CModule\u003E.smethod_9<string>(1007374343U), this.string_0.StartsWith(\u003CModule\u003E.smethod_7<string>(2221024947U)));
    string str9 = \u003CModule\u003E.smethod_6<string>(2702223683U);
    uint166_1 = sender.UInt16_6;
    string str10 = uint166_1.ToString(\u003CModule\u003E.smethod_7<string>(2973610280U));
    string str11 = \u003CModule\u003E.smethod_7<string>(292754782U);
    this.gclass5_2 = GClass5.smethod_2(str9 + str10 + str11, gclass0_3);
    string str12 = \u003CModule\u003E.smethod_6<string>(2288093925U);
    uint166_1 = sender.UInt16_6;
    string str13 = uint166_1.ToString(\u003CModule\u003E.smethod_5<string>(2164942292U));
    string str14 = \u003CModule\u003E.smethod_5<string>(711861686U);
    this.gclass5_3 = GClass5.smethod_2(str12 + str13 + str14, gclass0_4);
    this.bitmap_6 = new Bitmap(1, 1);
    GClass7 gclass70_1 = this.gclass7_0;
    string str15 = \u003CModule\u003E.smethod_5<string>(577599803U);
    uint166_1 = sender.UInt16_6;
    string str16 = uint166_1.ToString(\u003CModule\u003E.smethod_9<string>(4015943918U));
    string int_3_1 = str15 + str16;
    this.gclass6_2 = GClass6.smethod_5(gclass70_1.method_0(int_3_1), (int) sender.Byte_8);
    GClass7 gclass70_2 = this.gclass7_0;
    string str17 = \u003CModule\u003E.smethod_6<string>(2288093925U);
    uint166_1 = sender.UInt16_6;
    string str18 = uint166_1.ToString(\u003CModule\u003E.smethod_7<string>(2973610280U));
    string int_3_2 = str17 + str18;
    this.gclass6_3 = GClass6.smethod_5(gclass70_2.method_0(int_3_2), (int) sender.Byte_8);
    if (this.gclass5_2 != null && this.gclass5_3 == null)
    {
      this.bitmap_6 = GClass3.smethod_0(this.gclass5_2[5], this.gclass6_2);
      this.bitmap_7 = new Bitmap(1, 1);
    }
    else if (this.gclass5_2 != null && this.gclass5_3 != null)
    {
      this.bitmap_6 = GClass3.smethod_0(this.gclass5_2[5], this.gclass6_2);
      this.bitmap_7 = GClass3.smethod_0(this.gclass5_3[5], this.gclass6_3);
    }
    else if (this.gclass5_2 == null && this.gclass5_3 != null)
    {
      this.bitmap_7 = GClass3.smethod_0(this.gclass5_3[5], this.gclass6_2);
      this.bitmap_6 = new Bitmap(1, 1);
    }
    else
    {
      this.bitmap_6 = new Bitmap(1, 1);
      this.bitmap_7 = new Bitmap(1, 1);
    }
  }

  internal void method_11([In] Class143 obj0)
  {
    ushort uint167_1;
    if (this.string_0 == \u003CModule\u003E.smethod_8<string>(1177894350U))
    {
      GClass0 gclass0_1 = this.method_2(\u003CModule\u003E.smethod_8<string>(1899385979U), this.string_0.StartsWith(\u003CModule\u003E.smethod_9<string>(579346503U)));
      GClass0 gclass0_2 = this.method_2(\u003CModule\u003E.smethod_5<string>(641874325U), this.string_0.StartsWith(\u003CModule\u003E.smethod_5<string>(2517261141U)));
      string str1 = \u003CModule\u003E.smethod_5<string>(3483761015U);
      ushort uint167_2 = obj0.UInt16_7;
      string str2 = uint167_2.ToString(\u003CModule\u003E.smethod_6<string>(774836460U));
      string str3 = \u003CModule\u003E.smethod_9<string>(2211680732U);
      this.gclass5_4 = GClass5.smethod_2(str1 + str2 + str3, gclass0_1);
      string str4 = \u003CModule\u003E.smethod_7<string>(2280038791U);
      uint167_2 = obj0.UInt16_7;
      string str5 = uint167_2.ToString(\u003CModule\u003E.smethod_7<string>(2973610280U));
      string str6 = \u003CModule\u003E.smethod_9<string>(2211680732U);
      this.gclass5_5 = GClass5.smethod_2(str4 + str5 + str6, gclass0_2);
      this.bitmap_8 = new Bitmap(1, 1);
      this.gclass6_4 = GClass6.smethod_5(this.gclass7_0.method_0(\u003CModule\u003E.smethod_6<string>(217445135U) + obj0.UInt16_7.ToString(\u003CModule\u003E.smethod_8<string>(590791940U))), (int) obj0.Byte_9);
      GClass7 gclass70 = this.gclass7_0;
      string str7 = \u003CModule\u003E.smethod_7<string>(2280038791U);
      uint167_1 = obj0.UInt16_7;
      string str8 = uint167_1.ToString(\u003CModule\u003E.smethod_9<string>(4015943918U));
      string int_3 = str7 + str8;
      this.gclass6_5 = GClass6.smethod_5(gclass70.method_0(int_3), (int) obj0.Byte_9);
      if (this.gclass5_4 != null && this.gclass5_5 == null)
      {
        this.bitmap_8 = GClass3.smethod_0(this.gclass5_4[5], this.gclass6_4);
        this.bitmap_9 = new Bitmap(1, 1);
      }
      else if (this.gclass5_4 != null && this.gclass5_5 != null)
      {
        this.bitmap_8 = GClass3.smethod_0(this.gclass5_4[5], this.gclass6_4);
        this.bitmap_9 = GClass3.smethod_0(this.gclass5_5[5], this.gclass6_5);
      }
      else if (this.gclass5_4 == null && this.gclass5_5 != null)
      {
        this.bitmap_9 = GClass3.smethod_0(this.gclass5_5[5], this.gclass6_4);
        this.bitmap_8 = new Bitmap(1, 1);
      }
      else
      {
        this.bitmap_8 = new Bitmap(1, 1);
        this.bitmap_9 = new Bitmap(1, 1);
      }
    }
    if (!(this.string_0 == \u003CModule\u003E.smethod_7<string>(3437000890U)))
      return;
    GClass0 gclass0_3 = this.method_2(\u003CModule\u003E.smethod_7<string>(1760663189U), this.string_0.StartsWith(\u003CModule\u003E.smethod_8<string>(4135547821U)));
    GClass0 gclass0_4 = this.method_2(\u003CModule\u003E.smethod_5<string>(641874325U), this.string_0.StartsWith(\u003CModule\u003E.smethod_7<string>(2221024947U)));
    string str9 = \u003CModule\u003E.smethod_8<string>(1419268675U);
    uint167_1 = obj0.UInt16_7;
    string str10 = uint167_1.ToString(\u003CModule\u003E.smethod_5<string>(2164942292U));
    string str11 = \u003CModule\u003E.smethod_8<string>(2618246262U);
    this.gclass5_4 = GClass5.smethod_2(str9 + str10 + str11, gclass0_3);
    string str12 = \u003CModule\u003E.smethod_9<string>(2380256191U);
    uint167_1 = obj0.UInt16_7;
    string str13 = uint167_1.ToString(\u003CModule\u003E.smethod_9<string>(4015943918U));
    string str14 = \u003CModule\u003E.smethod_7<string>(292754782U);
    this.gclass5_5 = GClass5.smethod_2(str12 + str13 + str14, gclass0_4);
    this.bitmap_8 = new Bitmap(1, 1);
    GClass7 gclass70_1 = this.gclass7_0;
    string str15 = \u003CModule\u003E.smethod_9<string>(1262433929U);
    uint167_1 = obj0.UInt16_7;
    string str16 = uint167_1.ToString(\u003CModule\u003E.smethod_6<string>(774836460U));
    string int_3_1 = str15 + str16;
    this.gclass6_4 = GClass6.smethod_5(gclass70_1.method_0(int_3_1), (int) obj0.Byte_9);
    GClass7 gclass70_2 = this.gclass7_0;
    string str17 = \u003CModule\u003E.smethod_7<string>(3346782491U);
    uint167_1 = obj0.UInt16_7;
    string str18 = uint167_1.ToString(\u003CModule\u003E.smethod_6<string>(774836460U));
    string int_3_2 = str17 + str18;
    this.gclass6_5 = GClass6.smethod_5(gclass70_2.method_0(int_3_2), (int) obj0.Byte_9);
    if (this.gclass5_4 != null && this.gclass5_5 == null)
    {
      this.bitmap_8 = GClass3.smethod_0(this.gclass5_4[5], this.gclass6_4);
      this.bitmap_9 = new Bitmap(1, 1);
    }
    else if (this.gclass5_4 != null && this.gclass5_5 != null)
    {
      this.bitmap_8 = GClass3.smethod_0(this.gclass5_4[5], this.gclass6_4);
      this.bitmap_9 = GClass3.smethod_0(this.gclass5_5[5], this.gclass6_5);
    }
    else if (this.gclass5_4 == null && this.gclass5_5 != null)
    {
      this.bitmap_9 = GClass3.smethod_0(this.gclass5_5[5], this.gclass6_4);
      this.bitmap_8 = new Bitmap(1, 1);
    }
    else
    {
      this.bitmap_8 = new Bitmap(1, 1);
      this.bitmap_9 = new Bitmap(1, 1);
    }
  }

  internal void method_12(Class143 sender)
  {
    if (((int) sender.Byte_2 & 16) == 16)
      this.string_0 = \u003CModule\u003E.smethod_9<string>(2035358980U);
    if (((int) sender.Byte_2 & 32) == 32)
      this.string_0 = \u003CModule\u003E.smethod_5<string>(583312642U);
    if (this.string_0 == \u003CModule\u003E.smethod_5<string>(2229216814U))
    {
      GClass0 gclass0 = this.method_2(\u003CModule\u003E.smethod_5<string>(1966405887U), true);
      this.gclass5_8 = GClass5.smethod_2(\u003CModule\u003E.smethod_6<string>(477905177U), gclass0);
      this.bitmap_12 = GClass3.smethod_0(this.gclass5_8[5], this.gclass7_3[(int) sender.Byte_13]);
    }
    else
    {
      GClass0 gclass0 = this.method_2(\u003CModule\u003E.smethod_6<string>(1873964167U), false);
      this.gclass5_8 = GClass5.smethod_2(\u003CModule\u003E.smethod_7<string>(1241287587U), gclass0);
      this.bitmap_12 = GClass3.smethod_0(this.gclass5_8[5], this.gclass7_3[(int) sender.Byte_13]);
    }
  }

  internal void method_13([In] Class143 obj0)
  {
    ushort num1;
    GClass0 gclass0_1;
    if (obj0.UInt16_8 != (ushort) 0 && obj0.UInt16_8 <= (ushort) 999)
    {
      if (this.string_0 == \u003CModule\u003E.smethod_8<string>(1177894350U))
      {
        GClass0 gclass0_2 = this.method_2(\u003CModule\u003E.smethod_9<string>(320933419U), true);
        string str1 = \u003CModule\u003E.smethod_6<string>(1720294451U);
        num1 = obj0.UInt16_8;
        string str2 = num1.ToString(\u003CModule\u003E.smethod_7<string>(2973610280U));
        string str3 = \u003CModule\u003E.smethod_9<string>(2211680732U);
        this.gclass5_6 = GClass5.smethod_2(str1 + str2 + str3, gclass0_2);
        GClass7 gclass72 = this.gclass7_2;
        string str4 = \u003CModule\u003E.smethod_6<string>(1720294451U);
        num1 = obj0.UInt16_8;
        string str5 = num1.ToString(\u003CModule\u003E.smethod_9<string>(4015943918U));
        string int_3 = str4 + str5;
        this.gclass6_6 = GClass6.smethod_5(gclass72.method_0(int_3), (int) obj0.Byte_12);
        this.bitmap_10 = new Bitmap(1, 1);
        if (this.gclass5_6 != null)
          this.bitmap_10 = GClass3.smethod_0(this.gclass5_6[5], this.gclass6_6);
        string str6 = \u003CModule\u003E.smethod_6<string>(1306164693U);
        num1 = obj0.UInt16_8;
        string str7 = num1.ToString(\u003CModule\u003E.smethod_6<string>(774836460U));
        string str8 = \u003CModule\u003E.smethod_6<string>(360706702U);
        this.gclass5_7 = GClass5.smethod_2(str6 + str7 + str8, gclass0_2);
        this.bitmap_11 = this.gclass5_7 == null ? new Bitmap(1, 1) : GClass3.smethod_0(this.gclass5_7[5], this.gclass6_6);
        gclass0_1 = (GClass0) null;
      }
      else
      {
        GClass0 gclass0_3 = this.method_2(\u003CModule\u003E.smethod_7<string>(2308031287U), false);
        string str9 = \u003CModule\u003E.smethod_6<string>(892034935U);
        num1 = obj0.UInt16_8;
        string str10 = num1.ToString(\u003CModule\u003E.smethod_9<string>(4015943918U));
        string str11 = \u003CModule\u003E.smethod_5<string>(711861686U);
        this.gclass5_6 = GClass5.smethod_2(str9 + str10 + str11, gclass0_3);
        GClass7 gclass72 = this.gclass7_2;
        string str12 = \u003CModule\u003E.smethod_8<string>(2139444631U);
        num1 = obj0.UInt16_8;
        string str13 = num1.ToString(\u003CModule\u003E.smethod_9<string>(4015943918U));
        string int_3 = str12 + str13;
        this.gclass6_6 = GClass6.smethod_5(gclass72.method_0(int_3), (int) obj0.Byte_12);
        this.bitmap_10 = new Bitmap(1, 1);
        if (this.gclass5_6 != null)
          this.bitmap_10 = GClass3.smethod_0(this.gclass5_6[5], this.gclass6_6);
        string str14 = \u003CModule\u003E.smethod_8<string>(1792400873U);
        num1 = obj0.UInt16_8;
        string str15 = num1.ToString(\u003CModule\u003E.smethod_8<string>(590791940U));
        string str16 = \u003CModule\u003E.smethod_6<string>(360706702U);
        this.gclass5_7 = GClass5.smethod_2(str14 + str15 + str16, gclass0_3);
        this.bitmap_11 = this.gclass5_7 == null ? new Bitmap(1, 1) : GClass3.smethod_0(this.gclass5_7[5], this.gclass6_6);
        gclass0_1 = (GClass0) null;
      }
    }
    if (obj0.UInt16_8 != (ushort) 0 && obj0.UInt16_8 >= (ushort) 1000)
    {
      if (this.string_0 == \u003CModule\u003E.smethod_5<string>(2229216814U))
      {
        GClass0 gclass0_4 = this.method_2(\u003CModule\u003E.smethod_6<string>(3376813483U), true);
        int num2 = (int) obj0.UInt16_8 - 1000;
        this.gclass5_6 = GClass5.smethod_2(\u003CModule\u003E.smethod_7<string>(1381250067U) + num2.ToString(\u003CModule\u003E.smethod_7<string>(2973610280U)) + \u003CModule\u003E.smethod_6<string>(360706702U), gclass0_4);
        this.gclass6_6 = GClass6.smethod_5(this.gclass7_1.method_0(\u003CModule\u003E.smethod_9<string>(1712661351U) + num2.ToString(\u003CModule\u003E.smethod_8<string>(590791940U))), (int) obj0.Byte_12);
        this.bitmap_10 = new Bitmap(1, 1);
        if (this.gclass5_6 != null)
          this.bitmap_10 = GClass3.smethod_0(this.gclass5_6[5], this.gclass6_6);
        this.gclass5_7 = GClass5.smethod_2(\u003CModule\u003E.smethod_8<string>(111990309U) + num2.ToString(\u003CModule\u003E.smethod_7<string>(2973610280U)) + \u003CModule\u003E.smethod_6<string>(360706702U), gclass0_4);
        this.bitmap_11 = this.gclass5_7 == null ? new Bitmap(1, 1) : GClass3.smethod_0(this.gclass5_7[5], this.gclass6_6);
        gclass0_1 = (GClass0) null;
      }
      else
      {
        GClass0 gclass0_5 = this.method_2(\u003CModule\u003E.smethod_5<string>(3123347283U), false);
        int num3 = (int) obj0.UInt16_8 - 1000;
        this.gclass5_6 = GClass5.smethod_2(\u003CModule\u003E.smethod_6<string>(2548553967U) + num3.ToString(\u003CModule\u003E.smethod_9<string>(4015943918U)) + \u003CModule\u003E.smethod_5<string>(711861686U), gclass0_5);
        this.gclass6_6 = GClass6.smethod_5(this.gclass7_1.method_0(\u003CModule\u003E.smethod_9<string>(4203365461U) + num3.ToString(\u003CModule\u003E.smethod_8<string>(590791940U))), (int) obj0.Byte_12);
        this.bitmap_10 = new Bitmap(1, 1);
        if (this.gclass5_6 != null)
          this.bitmap_10 = GClass3.smethod_0(this.gclass5_6[5], this.gclass6_6);
        this.gclass5_7 = GClass5.smethod_2(\u003CModule\u003E.smethod_7<string>(314506367U) + num3.ToString(\u003CModule\u003E.smethod_8<string>(590791940U)) + \u003CModule\u003E.smethod_9<string>(2211680732U), gclass0_5);
        this.bitmap_11 = this.gclass5_7 == null ? new Bitmap(1, 1) : GClass3.smethod_0(this.gclass5_7[5], this.gclass6_6);
        gclass0_1 = (GClass0) null;
      }
    }
    if (obj0.UInt16_8 == (ushort) 0 && obj0.UInt16_2 <= (ushort) 999)
    {
      if (this.string_0 == \u003CModule\u003E.smethod_8<string>(1177894350U))
      {
        GClass0 gclass0_6 = this.method_2(\u003CModule\u003E.smethod_5<string>(3290937449U), true);
        string str17 = \u003CModule\u003E.smethod_6<string>(1720294451U);
        num1 = obj0.UInt16_2;
        string str18 = num1.ToString(\u003CModule\u003E.smethod_5<string>(2164942292U));
        string str19 = \u003CModule\u003E.smethod_7<string>(292754782U);
        this.gclass5_6 = GClass5.smethod_2(str17 + str18 + str19, gclass0_6);
        GClass7 gclass72 = this.gclass7_2;
        string str20 = \u003CModule\u003E.smethod_5<string>(1837856843U);
        num1 = obj0.UInt16_2;
        string str21 = num1.ToString(\u003CModule\u003E.smethod_6<string>(774836460U));
        string int_3 = str20 + str21;
        this.gclass6_6 = GClass6.smethod_5(gclass72.method_0(int_3), 0);
        this.bitmap_10 = new Bitmap(1, 1);
        if (this.gclass5_6 != null)
          this.bitmap_10 = GClass3.smethod_0(this.gclass5_6[5], this.gclass6_6);
        string str22 = \u003CModule\u003E.smethod_9<string>(3929459791U);
        num1 = obj0.UInt16_2;
        string str23 = num1.ToString(\u003CModule\u003E.smethod_5<string>(2164942292U));
        string str24 = \u003CModule\u003E.smethod_6<string>(360706702U);
        this.gclass5_7 = GClass5.smethod_2(str22 + str23 + str24, gclass0_6);
        this.bitmap_11 = this.gclass5_7 == null ? new Bitmap(1, 1) : GClass3.smethod_0(this.gclass5_7[5], this.gclass6_6);
        gclass0_1 = (GClass0) null;
      }
      else
      {
        GClass0 gclass0_7 = this.method_2(\u003CModule\u003E.smethod_5<string>(3290937449U), false);
        string str25 = \u003CModule\u003E.smethod_7<string>(693919489U);
        num1 = obj0.UInt16_2;
        string str26 = num1.ToString(\u003CModule\u003E.smethod_8<string>(590791940U));
        string str27 = \u003CModule\u003E.smethod_6<string>(360706702U);
        this.gclass5_6 = GClass5.smethod_2(str25 + str26 + str27, gclass0_7);
        GClass7 gclass72 = this.gclass7_2;
        string str28 = \u003CModule\u003E.smethod_9<string>(2125196605U);
        num1 = obj0.UInt16_2;
        string str29 = num1.ToString(\u003CModule\u003E.smethod_5<string>(2164942292U));
        string int_3 = str28 + str29;
        this.gclass6_6 = GClass6.smethod_5(gclass72.method_0(int_3), 0);
        this.bitmap_10 = new Bitmap(1, 1);
        if (this.gclass5_6 != null)
          this.bitmap_10 = GClass3.smethod_0(this.gclass5_6[5], this.gclass6_6);
        string str30 = \u003CModule\u003E.smethod_8<string>(1792400873U);
        num1 = obj0.UInt16_2;
        string str31 = num1.ToString(\u003CModule\u003E.smethod_9<string>(4015943918U));
        string str32 = \u003CModule\u003E.smethod_8<string>(2618246262U);
        this.gclass5_7 = GClass5.smethod_2(str30 + str31 + str32, gclass0_7);
        this.bitmap_11 = this.gclass5_7 == null ? new Bitmap(1, 1) : GClass3.smethod_0(this.gclass5_7[5], this.gclass6_6);
        gclass0_1 = (GClass0) null;
      }
    }
    if (obj0.UInt16_8 != (ushort) 0 || obj0.UInt16_2 < (ushort) 1000)
      return;
    if (this.string_0 == \u003CModule\u003E.smethod_8<string>(1177894350U))
    {
      GClass0 gclass0_8 = this.method_2(\u003CModule\u003E.smethod_7<string>(1928618165U), true);
      int num4 = (int) obj0.UInt16_2 - 1000;
      this.gclass5_6 = GClass5.smethod_2(\u003CModule\u003E.smethod_5<string>(1670266677U) + num4.ToString(\u003CModule\u003E.smethod_9<string>(4015943918U)) + \u003CModule\u003E.smethod_5<string>(711861686U), gclass0_8);
      this.gclass6_6 = GClass6.smethod_5(this.gclass7_1.method_0(\u003CModule\u003E.smethod_6<string>(2962683725U) + num4.ToString(\u003CModule\u003E.smethod_5<string>(2164942292U))), 0);
      this.bitmap_10 = new Bitmap(1, 1);
      if (this.gclass5_6 != null)
        this.bitmap_10 = GClass3.smethod_0(this.gclass5_6[5], this.gclass6_6);
      this.gclass5_7 = GClass5.smethod_2(\u003CModule\u003E.smethod_8<string>(111990309U) + num4.ToString(\u003CModule\u003E.smethod_6<string>(774836460U)) + \u003CModule\u003E.smethod_9<string>(2211680732U), gclass0_8);
      this.bitmap_11 = this.gclass5_7 == null ? new Bitmap(1, 1) : GClass3.smethod_0(this.gclass5_7[5], this.gclass6_6);
      gclass0_1 = (GClass0) null;
    }
    else
    {
      GClass0 gclass0_9 = this.method_2(\u003CModule\u003E.smethod_7<string>(1928618165U), false);
      int num5 = (int) obj0.UInt16_2 - 1000;
      this.gclass5_6 = GClass5.smethod_2(\u003CModule\u003E.smethod_8<string>(3579796543U) + num5.ToString(\u003CModule\u003E.smethod_8<string>(590791940U)) + \u003CModule\u003E.smethod_9<string>(2211680732U), gclass0_9);
      this.gclass6_6 = GClass6.smethod_5(this.gclass7_1.method_0(\u003CModule\u003E.smethod_5<string>(217186071U) + num5.ToString(\u003CModule\u003E.smethod_8<string>(590791940U))), 0);
      this.bitmap_10 = new Bitmap(1, 1);
      if (this.gclass5_6 != null)
        this.bitmap_10 = GClass3.smethod_0(this.gclass5_6[5], this.gclass6_6);
      this.gclass5_7 = GClass5.smethod_2(\u003CModule\u003E.smethod_7<string>(314506367U) + num5.ToString(\u003CModule\u003E.smethod_9<string>(4015943918U)) + \u003CModule\u003E.smethod_5<string>(711861686U), gclass0_9);
      this.bitmap_11 = this.gclass5_7 == null ? new Bitmap(1, 1) : GClass3.smethod_0(this.gclass5_7[5], this.gclass6_6);
      gclass0_1 = (GClass0) null;
    }
  }
}
