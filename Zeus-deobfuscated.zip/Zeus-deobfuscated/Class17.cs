﻿// Decompiled with JetBrains decompiler
// Type: Class17
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using Accolade;
using System.Runtime.InteropServices;

internal sealed class Class17
{
  private readonly TemClass temClass_0;

  internal string String_0 { get; set; }

  internal int Int32_0 { get; set; }

  internal int Int32_1 { get; set; }

  internal bool Boolean_0 { get; set; }

  internal bool Boolean_1 { get; [param: In] set; }

  internal Class17()
  {
    this.String_0 = \u003CModule\u003E.smethod_5<string>(2064008692U);
    this.Int32_0 = 0;
    this.Int32_1 = 0;
    this.Boolean_0 = false;
    this.Boolean_1 = true;
    this.temClass_0 = TemClass.Peasant;
  }

  internal Class17(
    [In] string obj0,
    [In] int obj1,
    int int_2,
    bool int_3,
    bool bool_1,
    TemClass temClass_1 = TemClass.Peasant)
  {
    this.String_0 = obj0;
    this.Int32_0 = obj1;
    this.Int32_1 = int_2;
    this.Boolean_0 = int_3;
    this.Boolean_1 = bool_1;
    this.temClass_0 = temClass_1;
  }

  internal Class17([In] Class17 obj0)
  {
    this.String_0 = string.Copy(obj0.String_0);
    this.Int32_0 = obj0.Int32_0;
    this.Int32_1 = obj0.Int32_1;
    this.Boolean_0 = obj0.Boolean_0;
    this.Boolean_1 = obj0.Boolean_1;
    this.temClass_0 = obj0.temClass_0;
  }

  internal bool method_0([In] byte obj0, [In] byte obj1, uint uint_0, TemClass temClass_1)
  {
    if ((int) obj0 < this.Int32_0 || (int) obj1 < this.Int32_1 || (!this.Boolean_0 || uint_0 == 0U ? 1 : 0) == 0)
      return false;
    return this.temClass_0 == TemClass.Peasant || this.temClass_0 == temClass_1;
  }
}
