﻿// Decompiled with JetBrains decompiler
// Type: GClass6
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

public class GClass6
{
  public Color this[[In] int obj0]
  {
    get => this.Color_0[obj0];
    set => this.Color_0[string_0] = value;
  }

  public Color[] Color_0 { get; } = new Color[256];

  public static GClass6 smethod_0([In] string obj0) => GClass6.smethod_4((Stream) new FileStream(obj0, FileMode.Open, FileAccess.Read, FileShare.Read));

  public static GClass6 smethod_1(byte[] stream_0) => GClass6.smethod_4((Stream) new MemoryStream(stream_0));

  public static GClass6 smethod_2(string value, [In] GClass0 obj1) => obj1.method_0(value) ? GClass6.smethod_1(obj1.method_4(value)) : (GClass6) null;

  public static GClass6 smethod_3(string int_4, bool int_5, GClass0 int_6) => int_6.method_1(int_4, int_5) ? GClass6.smethod_1(int_6.method_5(int_4, int_5)) : (GClass6) null;

  private static GClass6 smethod_4([In] Stream obj0)
  {
    obj0.Seek(0L, SeekOrigin.Begin);
    BinaryReader binaryReader = new BinaryReader(obj0);
    GClass6 gclass6 = new GClass6();
    for (int index = 0; index < 256; ++index)
      gclass6.Color_0[index] = Color.FromArgb((int) binaryReader.ReadByte(), (int) binaryReader.ReadByte(), (int) binaryReader.ReadByte());
    return gclass6;
  }

  public static GClass6 smethod_5([In] GClass6 obj0, [In] int obj1)
  {
    if (obj1 <= 0)
      return obj0;
    StreamReader streamReader = new StreamReader((Stream) new MemoryStream(Class9.Byte_0), Encoding.Default);
    Color[,] colorArray = new Color[Convert.ToInt32(streamReader.ReadLine()), 6];
    while (!streamReader.EndOfStream)
    {
      int int32_1 = Convert.ToInt32(streamReader.ReadLine());
      for (int index = 0; index < 6; ++index)
      {
        string[] strArray = streamReader.ReadLine().Trim().Split(',');
        if (strArray.Length == 3)
        {
          int int32_2 = Convert.ToInt32(strArray[0]);
          int int32_3 = Convert.ToInt32(strArray[1]);
          int int32_4 = Convert.ToInt32(strArray[2]);
          if (int32_2 > (int) byte.MaxValue)
            int32_2 -= (int) byte.MaxValue;
          if (int32_3 > (int) byte.MaxValue)
            int32_3 -= (int) byte.MaxValue;
          if (int32_4 > (int) byte.MaxValue)
            int32_4 -= (int) byte.MaxValue;
          colorArray[int32_1, index] = Color.FromArgb((int) byte.MaxValue, int32_2, int32_3, int32_4);
        }
      }
    }
    streamReader.Close();
    GClass6 gclass6 = new GClass6();
    for (int index = 0; index < 256; ++index)
      gclass6[index] = obj0[index];
    gclass6[98] = colorArray[obj1, 0];
    gclass6[99] = colorArray[obj1, 1];
    gclass6[100] = colorArray[obj1, 2];
    gclass6[101] = colorArray[obj1, 3];
    gclass6[102] = colorArray[obj1, 4];
    gclass6[103] = colorArray[obj1, 5];
    return gclass6;
  }
}
