﻿// Decompiled with JetBrains decompiler
// Type: Class139
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Runtime.InteropServices;

internal abstract class Class139
{
  protected internal int Int32_0 { get; }

  protected internal string String_0 { get; protected set; }

  protected internal DateTime DateTime_0 { get; private set; }

  internal Class139(int value, [In] string obj1)
  {
    this.Int32_0 = value;
    this.String_0 = obj1;
    this.DateTime_0 = DateTime.UtcNow;
  }

  internal void method_0(DateTime value) => this.DateTime_0 = value;
}
