﻿// Decompiled with JetBrains decompiler
// Type: Class103
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;

internal class Class103
{
  internal static Dictionary<short, Struct16[]> dictionary_0;
  private readonly Class29 class29_0;
  private readonly Class88 class88_0;
  private readonly List<Class105> list_0;
  private readonly byte byte_0;
  private readonly byte byte_1;
  private Class105[,] class105_0;

  internal Class103(Class29 value)
  {
    this.class29_0 = value;
    this.class88_0 = value.class88_0;
    this.byte_0 = this.class88_0.Byte_0;
    this.byte_1 = this.class88_0.Byte_1;
    this.list_0 = new List<Class105>();
    this.method_0(true, new Struct16(), true);
  }

  private void method_0(bool class29_0_1, Struct16 class99_0, [In] bool obj2)
  {
    if (class29_0_1)
    {
      this.class105_0 = new Class105[(int) this.byte_0, (int) this.byte_1];
      for (short index1 = 0; (int) index1 < (int) this.byte_0; ++index1)
      {
        for (short index2 = 0; (int) index2 < (int) this.byte_1; ++index2)
          this.class105_0[(int) index1, (int) index2] = new Class105(index1, index2)
          {
            Boolean_0 = !this.class88_0.method_4(index1, index2)
          };
      }
      for (short index3 = 0; (int) index3 < (int) this.byte_0; ++index3)
      {
        for (short index4 = 0; (int) index4 < (int) this.byte_1; ++index4)
        {
          Class105 class105 = this.class105_0[(int) index3, (int) index4];
          Struct16 struct160 = class105.Struct16_0;
          if (struct160.short_1 > (short) 0)
            class105.Class105_1[0] = this.class105_0[(int) struct160.short_0, (int) struct160.short_1 - 1];
          if ((int) struct160.short_0 < (int) this.byte_0 - 1)
            class105.Class105_1[1] = this.class105_0[(int) struct160.short_0 + 1, (int) struct160.short_1];
          if ((int) struct160.short_1 < (int) this.byte_1 - 1)
            class105.Class105_1[2] = this.class105_0[(int) struct160.short_0, (int) struct160.short_1 + 1];
          if (struct160.short_0 > (short) 0)
            class105.Class105_1[3] = this.class105_0[(int) struct160.short_0 - 1, (int) struct160.short_1];
        }
      }
    }
    List<Struct16> struct16List = new List<Struct16>(this.class29_0.method_116().OfType<Class142>().Where<Class142>((Func<Class142, bool>) (obj0 =>
    {
      if (obj0.Byte_0 != (byte) 4 && obj0.Byte_0 != (byte) 2 && obj0.Byte_0 != (byte) 0 || obj0 == this.class29_0.Class143_0)
        return false;
      return !this.class29_0.Class26_0.list_14.Contains(obj0.String_0) || this.class29_0.Struct16_1.method_0(obj0.Struct16_0) <= 1;
    })).Select<Class142, Struct16>((Func<Class142, Struct16>) (class29_0_2 => class29_0_2.Struct16_0)));
    Struct16[] struct16Array;
    if (Class103.dictionary_0.TryGetValue(this.class88_0.Int16_0, out struct16Array))
    {
      for (int index = 0; index < struct16Array.Length; ++index)
      {
        if (!struct16List.Contains(struct16Array[index]))
          struct16List.Add(struct16Array[index]);
      }
    }
    if (obj2)
    {
      foreach (Struct16 struct16 in this.class29_0.method_121(class99_0))
      {
        if (!struct16List.Contains(struct16))
          struct16List.Add(struct16);
      }
    }
    foreach (Class142 int_11 in this.class29_0.method_118(12, this.class29_0.Class112_0.list_5.ToArray()))
    {
      foreach (Struct16 struct16 in this.class29_0.method_56(int_11))
      {
        if (!struct16List.Contains(struct16))
          struct16List.Add(struct16);
      }
    }
    for (short index5 = 0; (int) index5 < (int) this.byte_0; ++index5)
    {
      for (short index6 = 0; (int) index6 < (int) this.byte_1; ++index6)
      {
        Class105 class105 = this.class105_0[(int) index5, (int) index6];
        class105.Boolean_0 = !this.class88_0.method_3(this.class105_0[(int) index5, (int) index6].Struct16_0);
        class105.Boolean_1 = false;
        class105.Boolean_2 = false;
        class105.Single_0 = 0.0f;
        class105.Single_1 = 0.0f;
      }
    }
    foreach (Struct16 struct16 in struct16List)
      this.class105_0[(int) struct16.short_0, (int) struct16.short_1].Boolean_0 = false;
    this.list_0.Clear();
  }

  private Class105 method_1()
  {
    Class105 class105_1 = (Class105) null;
    float num = float.MaxValue;
    foreach (Class105 class105_2 in this.list_0)
    {
      if ((double) class105_2.Single_0 < (double) num)
      {
        class105_1 = class105_2;
        num = class105_2.Single_0;
      }
    }
    return class105_1;
  }

  internal Stack<Struct16> method_2(
    [In] Struct16 obj0,
    Struct16 class99_0,
    [In] bool obj2,
    [In] short obj3)
  {
    this.method_0(false, class99_0, obj2);
    if (Struct16.smethod_0(obj0, class99_0))
      return new Stack<Struct16>();
    Class105 class105_1 = this.class105_0[(int) obj0.short_0, (int) obj0.short_1];
    Class105 class105_2 = this.class105_0[(int) class99_0.short_0, (int) class99_0.short_1];
    if (!obj0.bool_0 || !class99_0.bool_0 || class105_1 == null || class105_2 == null)
      return new Stack<Struct16>();
    class105_1.Boolean_1 = true;
    class105_1.Single_0 = (float) obj0.method_0(class99_0);
    class105_1.Single_1 = 0.0f;
    this.list_0.Add(class105_1);
    while (this.list_0.Count > 0)
    {
      Class105 class105_3 = this.method_1();
      Struct16 struct160;
      if (class105_3 != null)
      {
        if (class105_3 != class105_2)
        {
          foreach (Class105 class105_4 in class105_3.Class105_1)
          {
            if (class105_4 != null && !class105_4.Boolean_2 && (class105_4 == class105_2 || class105_4.Boolean_0))
            {
              float num1 = class105_3.Single_1 + 1f;
              struct160 = class105_4.Struct16_0;
              float num2 = (float) struct160.method_0(class99_0);
              if (!class105_4.Boolean_1)
              {
                class105_4.Single_1 = num1;
                class105_4.Single_0 = num1 + num2;
                class105_4.Class105_0 = class105_3;
                class105_4.Boolean_1 = true;
                this.list_0.Add(class105_4);
              }
              else if ((double) class105_4.Single_1 > (double) num1)
              {
                class105_4.Single_1 = num1;
                class105_4.Single_0 = num1 + num2;
                class105_4.Class105_0 = class105_3;
              }
            }
          }
          this.list_0.Remove(class105_3);
          class105_3.Boolean_1 = false;
          class105_3.Boolean_2 = true;
        }
        else
        {
          Stack<Struct16> struct16Stack = new Stack<Struct16>();
          for (; class105_3 != class105_1; class105_3 = class105_3.Class105_0)
          {
            struct160 = class105_3.Struct16_0;
            if (struct160.method_0(class99_0) >= (int) obj3)
              struct16Stack.Push(class105_3.Struct16_0);
          }
          return struct16Stack;
        }
      }
      else
      {
        this.class29_0.method_105(true);
        return new Stack<Struct16>();
      }
    }
    return new Stack<Struct16>();
  }

  static Class103()
  {
    Dictionary<short, Struct16[]> dictionary = new Dictionary<short, Struct16[]>();
    Struct19 struct19 = new Struct19(new Struct16(3, 9), new Struct18((short) 3, (short) 3));
    List<Struct16> list0_1 = struct19.List_0;
    struct19 = new Struct19(new Struct16(9, 1), new Struct18((short) 3, (short) 3));
    List<Struct16> list0_2 = struct19.List_0;
    dictionary.Add((short) 3058, list0_1.Concat<Struct16>((IEnumerable<Struct16>) list0_2).ToArray<Struct16>());
    Class103.dictionary_0 = dictionary;
  }
}
