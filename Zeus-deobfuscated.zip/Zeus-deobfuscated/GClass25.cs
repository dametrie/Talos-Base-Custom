﻿// Decompiled with JetBrains decompiler
// Type: GClass25
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

public class GClass25 : RichTextBox
{
  private const int int_0 = 1024;
  private const int int_1 = 1082;
  private const int int_2 = 1092;
  private const int int_3 = 1246;
  private const int int_4 = 1245;
  private const int int_5 = 1;
  private const int int_6 = 1;
  private const int int_7 = 2;
  private const int int_8 = 4;
  private const uint uint_0 = 1;
  private const uint uint_1 = 2;
  private const uint uint_2 = 4;
  private const uint uint_3 = 8;
  private const uint uint_4 = 16;
  private const uint uint_5 = 32;
  private const uint uint_6 = 1073741824;
  private const uint uint_7 = 65536;
  private const uint uint_8 = 131072;
  private const int int_9 = 64;
  private const int int_10 = 128;
  private const int int_11 = 256;
  private const int int_12 = 512;
  private const int int_13 = 1024;
  private const int int_14 = 2048;
  private const int int_15 = 4096;
  private const int int_16 = 8192;
  private const int int_17 = 16384;
  private const int int_18 = 67108864;
  private const int int_19 = 33554432;
  private const int int_20 = 8388608;
  private const int int_21 = 4194304;
  private const int int_22 = 2097152;
  private const int int_23 = 1048576;
  private const int int_24 = 524288;
  private const int int_25 = 262144;
  private const int int_26 = 32768;
  private const uint uint_9 = 1;
  private const uint uint_10 = 2;
  private const uint uint_11 = 4;
  private const uint uint_12 = 8;
  private const uint uint_13 = 16;
  private const uint uint_14 = 32;
  private const uint uint_15 = 2147483648;
  private const uint uint_16 = 1073741824;
  private const uint uint_17 = 536870912;
  private const uint uint_18 = 268435456;
  private const uint uint_19 = 134217728;
  private const uint uint_20 = 196608;
  private const uint uint_21 = 196608;
  private const byte byte_0 = 0;
  private const byte byte_1 = 1;
  private const byte byte_2 = 2;
  private const byte byte_3 = 3;
  private const byte byte_4 = 4;
  private const byte byte_5 = 5;
  private const byte byte_6 = 6;
  private const byte byte_7 = 7;
  private const byte byte_8 = 8;
  private const byte byte_9 = 9;
  private const byte byte_10 = 10;

  [DefaultValue(false)]
  public bool Boolean_0
  {
    get => this.DetectUrls;
    set => this.DetectUrls = value;
  }

  public GClass25() => this.Boolean_0 = false;

  public void method_0([In] string obj0) => this.method_1(obj0, this.SelectionStart);

  public void method_1(string sender, int e)
  {
    if (e < 0 || e > this.Text.Length)
      throw new ArgumentOutOfRangeException(\u003CModule\u003E.smethod_8<string>(1312283569U));
    this.SelectionStart = e;
    this.SelectedText = sender;
    this.Select(e, sender.Length);
    this.method_4(true);
    this.Select(e + sender.Length, 0);
  }

  public void method_2(string sender, string e) => this.method_3(sender, e, this.SelectionStart);

  public void method_3(string sender, string e, [In] int obj2)
  {
    if (obj2 < 0 || obj2 > this.Text.Length)
      throw new ArgumentOutOfRangeException(\u003CModule\u003E.smethod_6<string>(1152494977U));
    this.SelectionStart = obj2;
    this.SelectedRtf = \u003CModule\u003E.smethod_5<string>(2332532458U) + sender + \u003CModule\u003E.smethod_8<string>(2085952078U) + e + \u003CModule\u003E.smethod_8<string>(1738908320U);
    this.Select(obj2, sender.Length + e.Length + 1);
    this.method_4(true);
    this.Select(obj2 + sender.Length + e.Length + 1, 0);
  }

  public void method_4([In] bool obj0) => this.method_6(32U, obj0 ? 32U : 0U);

  public int method_5() => this.method_7(32U, 32U);

  private void method_6(uint value, [In] uint obj1)
  {
    GClass25.Struct6 struct6 = new GClass25.Struct6();
    struct6.uint_0 = (uint) Marshal.SizeOf<GClass25.Struct6>(struct6);
    struct6.uint_2 = value;
    struct6.uint_1 = obj1;
    IntPtr num1 = new IntPtr(1);
    IntPtr num2 = Marshal.AllocCoTaskMem(Marshal.SizeOf<GClass25.Struct6>(struct6));
    Marshal.StructureToPtr<GClass25.Struct6>(struct6, num2, false);
    GClass25.SendMessage(this.Handle, 1092, num1, num2);
    Marshal.FreeCoTaskMem(num2);
  }

  private int method_7(uint value, [In] uint obj1)
  {
    GClass25.Struct6 struct6 = new GClass25.Struct6();
    struct6.uint_0 = (uint) Marshal.SizeOf<GClass25.Struct6>(struct6);
    struct6.char_0 = new char[32];
    IntPtr num1 = new IntPtr(1);
    IntPtr num2 = Marshal.AllocCoTaskMem(Marshal.SizeOf<GClass25.Struct6>(struct6));
    Marshal.StructureToPtr<GClass25.Struct6>(struct6, num2, false);
    GClass25.SendMessage(this.Handle, 1082, num1, num2);
    GClass25.Struct6 structure = (GClass25.Struct6) Marshal.PtrToStructure(num2, typeof (GClass25.Struct6));
    int num3 = ((int) structure.uint_2 & (int) value) != (int) value ? -1 : (((int) structure.uint_1 & (int) obj1) != (int) obj1 ? 0 : 1);
    Marshal.FreeCoTaskMem(num2);
    return num3;
  }

  internal bool method_8()
  {
    int int_3;
    int num;
    GClass25.GetScrollRange(this.Handle, 1, ref int_3, ref num);
    Point empty = Point.Empty;
    GClass25.SendMessage_1(this.Handle, 1245, 0, ref empty);
    return empty.Y + this.ClientSize.Height >= num;
  }

  [DllImport("user32.dll")]
  private static extern bool GetScrollRange(IntPtr value, int int_2, ref int int_3, [In] ref int obj3);

  [DllImport("user32.dll", CharSet = CharSet.Auto)]
  private static extern IntPtr SendMessage(
    [In] IntPtr obj0,
    [In] int obj1,
    [In] IntPtr obj2,
    IntPtr bool_2);

  [DllImport("user32.dll", EntryPoint = "SendMessage")]
  private static extern IntPtr SendMessage_1(
    IntPtr byte_0,
    int byte_1,
    int uint_0,
    ref Point temClass_1);

  private struct Struct6
  {
    public readonly byte byte_0;
    public readonly byte byte_1;
    public readonly byte byte_2;
    public readonly byte byte_3;
    public readonly byte byte_4;
    public readonly byte byte_5;
    public uint uint_0;
    public readonly int int_0;
    public readonly int int_1;
    public uint uint_1;
    public uint uint_2;
    public readonly int int_2;
    public readonly int int_3;
    public readonly ushort ushort_0;
    public readonly short short_0;
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
    public char[] char_0;
    public readonly short short_1;
    public readonly ushort ushort_1;
    public readonly int int_4;
    public readonly int int_5;
  }
}
