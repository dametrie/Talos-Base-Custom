﻿// Decompiled with JetBrains decompiler
// Type: Control3
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

internal class Control3 : UserControl
{
  internal GroupBox groupBox_0;
  internal GroupBox groupBox_1;
  internal RadioButton radioButton_0;
  internal RadioButton radioButton_1;
  internal RadioButton radioButton_2;
  internal GroupBox groupBox_2;
  internal Label label_0;
  internal Label label_1;
  internal RadioButton radioButton_3;
  internal PictureBox pictureBox_0;
  internal Button button_0;
  internal Class29 class29_0;
  internal IContainer icontainer_0;
  internal CheckBox checkBox_0;
  internal ComboBox comboBox_0;
  internal CheckBox checkBox_1;
  internal CheckBox checkBox_2;
  internal CheckBox checkBox_3;
  internal ComboBox comboBox_1;
  internal CheckBox checkBox_4;
  internal ComboBox comboBox_2;
  internal NumericUpDown numericUpDown_0;
  internal CheckBox checkBox_5;
  internal CheckBox checkBox_6;
  internal CheckBox checkBox_7;
  internal CheckBox checkBox_8;
  private readonly Class145 class145_0;
  internal Label label_2;
  internal CheckBox checkBox_9;
  internal TextBox textBox_0;

  internal Control3(Class145 class142_4, [In] Class29 obj1)
  {
    this.Name = class142_4.String_0;
    this.method_0();
    this.class145_0 = class142_4;
    this.class29_0 = obj1;
  }

  void ContainerControl.Dispose(bool class142_4)
  {
    if (class142_4 && this.icontainer_0 != null)
      this.icontainer_0.Dispose();
    // ISSUE: explicit non-virtual call
    __nonvirtual (((ContainerControl) this).Dispose(class142_4));
  }

  private void method_0()
  {
    this.button_0 = new Button();
    this.groupBox_0 = new GroupBox();
    this.numericUpDown_0 = new NumericUpDown();
    this.checkBox_5 = new CheckBox();
    this.checkBox_2 = new CheckBox();
    this.checkBox_1 = new CheckBox();
    this.comboBox_2 = new ComboBox();
    this.checkBox_4 = new CheckBox();
    this.comboBox_1 = new ComboBox();
    this.checkBox_3 = new CheckBox();
    this.checkBox_0 = new CheckBox();
    this.comboBox_0 = new ComboBox();
    this.groupBox_1 = new GroupBox();
    this.checkBox_6 = new CheckBox();
    this.checkBox_8 = new CheckBox();
    this.checkBox_7 = new CheckBox();
    this.groupBox_2 = new GroupBox();
    this.label_2 = new Label();
    this.textBox_0 = new TextBox();
    this.checkBox_9 = new CheckBox();
    this.label_0 = new Label();
    this.label_1 = new Label();
    this.radioButton_0 = new RadioButton();
    this.radioButton_1 = new RadioButton();
    this.radioButton_2 = new RadioButton();
    this.radioButton_3 = new RadioButton();
    this.pictureBox_0 = new PictureBox();
    this.groupBox_0.SuspendLayout();
    this.numericUpDown_0.BeginInit();
    this.groupBox_1.SuspendLayout();
    this.groupBox_2.SuspendLayout();
    ((ISupportInitialize) this.pictureBox_0).BeginInit();
    this.SuspendLayout();
    this.button_0.FlatStyle = FlatStyle.Flat;
    this.button_0.Location = new Point(392, 110);
    this.button_0.Name = \u003CModule\u003E.smethod_7<string>(2867331586U);
    this.button_0.Size = new Size(75, 23);
    this.button_0.TabIndex = 10;
    this.button_0.Text = \u003CModule\u003E.smethod_9<string>(781553811U);
    this.button_0.UseVisualStyleBackColor = true;
    this.button_0.Click += new EventHandler(this.button_0_Click);
    this.groupBox_0.Controls.Add((Control) this.numericUpDown_0);
    this.groupBox_0.Controls.Add((Control) this.checkBox_5);
    this.groupBox_0.Controls.Add((Control) this.checkBox_2);
    this.groupBox_0.Controls.Add((Control) this.checkBox_1);
    this.groupBox_0.Controls.Add((Control) this.comboBox_2);
    this.groupBox_0.Controls.Add((Control) this.checkBox_4);
    this.groupBox_0.Controls.Add((Control) this.comboBox_1);
    this.groupBox_0.Controls.Add((Control) this.checkBox_3);
    this.groupBox_0.Controls.Add((Control) this.checkBox_0);
    this.groupBox_0.Controls.Add((Control) this.comboBox_0);
    this.groupBox_0.Location = new Point(202, 162);
    this.groupBox_0.Name = \u003CModule\u003E.smethod_9<string>(222642680U);
    this.groupBox_0.Size = new Size(278, 156);
    this.groupBox_0.TabIndex = 11;
    this.groupBox_0.TabStop = false;
    this.groupBox_0.Text = \u003CModule\u003E.smethod_8<string>(4101149750U);
    this.numericUpDown_0.ForeColor = Color.Black;
    this.numericUpDown_0.Location = new Point(169, 109);
    this.numericUpDown_0.Name = \u003CModule\u003E.smethod_6<string>(4066801909U);
    this.numericUpDown_0.Size = new Size(41, 23);
    this.numericUpDown_0.TabIndex = 11;
    this.numericUpDown_0.TextAlign = HorizontalAlignment.Center;
    this.numericUpDown_0.Value = new Decimal(new int[4]
    {
      80,
      0,
      0,
      0
    });
    this.checkBox_5.AutoSize = true;
    this.checkBox_5.Location = new Point(169, 71);
    this.checkBox_5.Name = \u003CModule\u003E.smethod_9<string>(428910307U);
    this.checkBox_5.Size = new Size(96, 19);
    this.checkBox_5.TabIndex = 10;
    this.checkBox_5.Text = \u003CModule\u003E.smethod_9<string>(3951423766U);
    this.checkBox_5.UseVisualStyleBackColor = true;
    this.checkBox_2.AutoSize = true;
    this.checkBox_2.Location = new Point(169, 46);
    this.checkBox_2.Name = \u003CModule\u003E.smethod_7<string>(3085030643U);
    this.checkBox_2.Size = new Size(85, 19);
    this.checkBox_2.TabIndex = 8;
    this.checkBox_2.Text = \u003CModule\u003E.smethod_6<string>(2947199660U);
    this.checkBox_2.UseVisualStyleBackColor = true;
    this.checkBox_1.AutoSize = true;
    this.checkBox_1.Location = new Point(169, 21);
    this.checkBox_1.Name = \u003CModule\u003E.smethod_9<string>(3478525548U);
    this.checkBox_1.Size = new Size(73, 19);
    this.checkBox_1.TabIndex = 7;
    this.checkBox_1.Text = \u003CModule\u003E.smethod_5<string>(1382222350U);
    this.checkBox_1.UseVisualStyleBackColor = true;
    this.comboBox_2.ForeColor = Color.Black;
    this.comboBox_2.FormattingEnabled = true;
    this.comboBox_2.Items.AddRange(new object[7]
    {
      (object) \u003CModule\u003E.smethod_5<string>(1521248321U),
      (object) \u003CModule\u003E.smethod_7<string>(4112216060U),
      (object) \u003CModule\u003E.smethod_9<string>(2104271927U),
      (object) \u003CModule\u003E.smethod_5<string>(3508045664U),
      (object) \u003CModule\u003E.smethod_6<string>(4228598133U),
      (object) \u003CModule\u003E.smethod_8<string>(790514769U),
      (object) \u003CModule\u003E.smethod_5<string>(4106036923U)
    });
    this.comboBox_2.Location = new Point(27, 109);
    this.comboBox_2.Name = \u003CModule\u003E.smethod_9<string>(1115351231U);
    this.comboBox_2.Size = new Size(121, 23);
    this.comboBox_2.TabIndex = 6;
    this.comboBox_2.Text = \u003CModule\u003E.smethod_7<string>(638300911U);
    this.checkBox_4.AutoSize = true;
    this.checkBox_4.Location = new Point(6, 113);
    this.checkBox_4.Name = \u003CModule\u003E.smethod_7<string>(2046279439U);
    this.checkBox_4.Size = new Size(15, 14);
    this.checkBox_4.TabIndex = 5;
    this.checkBox_4.UseVisualStyleBackColor = true;
    this.comboBox_1.ForeColor = Color.Black;
    this.comboBox_1.FormattingEnabled = true;
    this.comboBox_1.Items.AddRange(new object[4]
    {
      (object) \u003CModule\u003E.smethod_6<string>(3728579786U),
      (object) \u003CModule\u003E.smethod_7<string>(3073281649U),
      (object) \u003CModule\u003E.smethod_8<string>(860886051U),
      (object) \u003CModule\u003E.smethod_9<string>(516336862U)
    });
    this.comboBox_1.Location = new Point(27, 63);
    this.comboBox_1.Name = \u003CModule\u003E.smethod_6<string>(446424413U);
    this.comboBox_1.Size = new Size(121, 23);
    this.comboBox_1.TabIndex = 4;
    this.comboBox_1.Text = \u003CModule\u003E.smethod_6<string>(3728579786U);
    this.checkBox_3.AutoSize = true;
    this.checkBox_3.Location = new Point(6, 67);
    this.checkBox_3.Name = \u003CModule\u003E.smethod_7<string>(4179766839U);
    this.checkBox_3.Size = new Size(15, 14);
    this.checkBox_3.TabIndex = 3;
    this.checkBox_3.UseVisualStyleBackColor = true;
    this.checkBox_0.AutoSize = true;
    this.checkBox_0.Location = new Point(6, 26);
    this.checkBox_0.Name = \u003CModule\u003E.smethod_5<string>(525235501U);
    this.checkBox_0.Size = new Size(15, 14);
    this.checkBox_0.TabIndex = 2;
    this.checkBox_0.UseVisualStyleBackColor = true;
    this.comboBox_0.ForeColor = Color.Black;
    this.comboBox_0.FormattingEnabled = true;
    this.comboBox_0.Items.AddRange(new object[4]
    {
      (object) \u003CModule\u003E.smethod_5<string>(3265704049U),
      (object) \u003CModule\u003E.smethod_7<string>(3207003218U),
      (object) \u003CModule\u003E.smethod_8<string>(3421950230U),
      (object) \u003CModule\u003E.smethod_7<string>(4028055365U)
    });
    this.comboBox_0.Location = new Point(27, 22);
    this.comboBox_0.Name = \u003CModule\u003E.smethod_5<string>(421919857U);
    this.comboBox_0.Size = new Size(121, 23);
    this.comboBox_0.TabIndex = 1;
    this.comboBox_0.Text = \u003CModule\u003E.smethod_8<string>(3608516329U);
    this.groupBox_1.Controls.Add((Control) this.checkBox_6);
    this.groupBox_1.Controls.Add((Control) this.checkBox_8);
    this.groupBox_1.Controls.Add((Control) this.checkBox_7);
    this.groupBox_1.Location = new Point(486, 162);
    this.groupBox_1.Name = \u003CModule\u003E.smethod_8<string>(1673159117U);
    this.groupBox_1.Size = new Size(94, 97);
    this.groupBox_1.TabIndex = 0;
    this.groupBox_1.TabStop = false;
    this.groupBox_1.Text = \u003CModule\u003E.smethod_7<string>(451989616U);
    this.checkBox_6.AutoSize = true;
    this.checkBox_6.Location = new Point(6, 47);
    this.checkBox_6.Name = \u003CModule\u003E.smethod_9<string>(3752431218U);
    this.checkBox_6.Size = new Size(70, 19);
    this.checkBox_6.TabIndex = 11;
    this.checkBox_6.Text = \u003CModule\u003E.smethod_7<string>(2705617521U);
    this.checkBox_6.UseVisualStyleBackColor = true;
    this.checkBox_8.AutoSize = true;
    this.checkBox_8.Location = new Point(6, 22);
    this.checkBox_8.Name = \u003CModule\u003E.smethod_9<string>(3928752970U);
    this.checkBox_8.Size = new Size(70, 19);
    this.checkBox_8.TabIndex = 10;
    this.checkBox_8.Text = \u003CModule\u003E.smethod_8<string>(1159699948U);
    this.checkBox_8.UseVisualStyleBackColor = true;
    this.checkBox_7.AutoSize = true;
    this.checkBox_7.Location = new Point(6, 72);
    this.checkBox_7.Name = \u003CModule\u003E.smethod_8<string>(365880751U);
    this.checkBox_7.Size = new Size(78, 19);
    this.checkBox_7.TabIndex = 9;
    this.checkBox_7.Text = \u003CModule\u003E.smethod_6<string>(2907763266U);
    this.checkBox_7.UseVisualStyleBackColor = true;
    this.groupBox_2.Controls.Add((Control) this.label_2);
    this.groupBox_2.Controls.Add((Control) this.textBox_0);
    this.groupBox_2.Controls.Add((Control) this.checkBox_9);
    this.groupBox_2.Location = new Point(486, 265);
    this.groupBox_2.Name = \u003CModule\u003E.smethod_7<string>(4074037766U);
    this.groupBox_2.Size = new Size(148, 53);
    this.groupBox_2.TabIndex = 12;
    this.groupBox_2.TabStop = false;
    this.groupBox_2.Text = \u003CModule\u003E.smethod_7<string>(3197000627U);
    this.label_2.AutoSize = true;
    this.label_2.Location = new Point(64, 25);
    this.label_2.Name = \u003CModule\u003E.smethod_6<string>(1381474255U);
    this.label_2.Size = new Size(15, 15);
    this.label_2.TabIndex = 5;
    this.label_2.Text = \u003CModule\u003E.smethod_9<string>(3141845844U);
    this.textBox_0.ForeColor = Color.Black;
    this.textBox_0.Location = new Point(85, 22);
    this.textBox_0.Name = \u003CModule\u003E.smethod_9<string>(1899376073U);
    this.textBox_0.Size = new Size(52, 23);
    this.textBox_0.TabIndex = 4;
    this.textBox_0.Text = \u003CModule\u003E.smethod_9<string>(2782730951U);
    this.textBox_0.TextAlign = HorizontalAlignment.Center;
    this.checkBox_9.AutoSize = true;
    this.checkBox_9.Location = new Point(6, 24);
    this.checkBox_9.Name = \u003CModule\u003E.smethod_8<string>(4127238190U);
    this.checkBox_9.Size = new Size(55, 19);
    this.checkBox_9.TabIndex = 3;
    this.checkBox_9.Text = \u003CModule\u003E.smethod_7<string>(3224993123U);
    this.checkBox_9.UseVisualStyleBackColor = true;
    this.label_0.AutoSize = true;
    this.label_0.Location = new Point(531, 321);
    this.label_0.Name = \u003CModule\u003E.smethod_7<string>(1884565374U);
    this.label_0.Size = new Size(64, 15);
    this.label_0.TabIndex = 6;
    this.label_0.Text = \u003CModule\u003E.smethod_9<string>(271434639U);
    this.label_1.AutoSize = true;
    this.label_1.Location = new Point(506, 336);
    this.label_1.Name = \u003CModule\u003E.smethod_9<string>(88405891U);
    this.label_1.Size = new Size(117, 15);
    this.label_1.TabIndex = 7;
    this.label_1.Text = \u003CModule\u003E.smethod_9<string>(647317022U);
    this.radioButton_0.AutoSize = true;
    this.radioButton_0.Location = new Point(260, 324);
    this.radioButton_0.Name = \u003CModule\u003E.smethod_5<string>(4205073021U);
    this.radioButton_0.Size = new Size(52, 19);
    this.radioButton_0.TabIndex = 13;
    this.radioButton_0.Text = \u003CModule\u003E.smethod_5<string>(1298911809U);
    this.radioButton_0.UseVisualStyleBackColor = true;
    this.radioButton_0.Visible = false;
    this.radioButton_1.AutoSize = true;
    this.radioButton_1.Location = new Point(318, 324);
    this.radioButton_1.Name = \u003CModule\u003E.smethod_8<string>(1305289611U);
    this.radioButton_1.Size = new Size(85, 19);
    this.radioButton_1.TabIndex = 14;
    this.radioButton_1.Text = \u003CModule\u003E.smethod_9<string>(392257436U);
    this.radioButton_1.UseVisualStyleBackColor = true;
    this.radioButton_1.Visible = false;
    this.radioButton_2.AutoSize = true;
    this.radioButton_2.Location = new Point(409, 324);
    this.radioButton_2.Name = \u003CModule\u003E.smethod_6<string>(2389466579U);
    this.radioButton_2.Size = new Size(80, 19);
    this.radioButton_2.TabIndex = 15;
    this.radioButton_2.Text = \u003CModule\u003E.smethod_6<string>(3915755590U);
    this.radioButton_2.UseVisualStyleBackColor = true;
    this.radioButton_2.Visible = false;
    this.radioButton_3.AutoSize = true;
    this.radioButton_3.Checked = true;
    this.radioButton_3.Location = new Point(200, 324);
    this.radioButton_3.Name = \u003CModule\u003E.smethod_9<string>(3775670097U);
    this.radioButton_3.Size = new Size(54, 19);
    this.radioButton_3.TabIndex = 16;
    this.radioButton_3.TabStop = true;
    this.radioButton_3.Text = \u003CModule\u003E.smethod_9<string>(39613932U);
    this.radioButton_3.UseVisualStyleBackColor = true;
    this.radioButton_3.Visible = false;
    this.pictureBox_0.BackColor = Color.White;
    this.pictureBox_0.Location = new Point(247, 38);
    this.pictureBox_0.Name = \u003CModule\u003E.smethod_6<string>(4176215632U);
    this.pictureBox_0.Size = new Size(139, 118);
    this.pictureBox_0.SizeMode = PictureBoxSizeMode.CenterImage;
    this.pictureBox_0.TabIndex = 17;
    this.pictureBox_0.TabStop = false;
    this.AutoScaleDimensions = new SizeF(7f, 15f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.BackColor = Color.White;
    this.Controls.Add((Control) this.pictureBox_0);
    this.Controls.Add((Control) this.radioButton_3);
    this.Controls.Add((Control) this.radioButton_2);
    this.Controls.Add((Control) this.radioButton_1);
    this.Controls.Add((Control) this.radioButton_0);
    this.Controls.Add((Control) this.groupBox_2);
    this.Controls.Add((Control) this.label_1);
    this.Controls.Add((Control) this.groupBox_1);
    this.Controls.Add((Control) this.label_0);
    this.Controls.Add((Control) this.groupBox_0);
    this.Controls.Add((Control) this.button_0);
    this.DoubleBuffered = true;
    this.Font = new Font(\u003CModule\u003E.smethod_6<string>(2348004861U), 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
    this.ForeColor = Color.Black;
    this.Name = \u003CModule\u003E.smethod_6<string>(2933826358U);
    this.Size = new Size(838, 492);
    this.groupBox_0.ResumeLayout(false);
    this.groupBox_0.PerformLayout();
    this.numericUpDown_0.EndInit();
    this.groupBox_1.ResumeLayout(false);
    this.groupBox_1.PerformLayout();
    this.groupBox_2.ResumeLayout(false);
    this.groupBox_2.PerformLayout();
    ((ISupportInitialize) this.pictureBox_0).EndInit();
    this.ResumeLayout(false);
    this.PerformLayout();
  }

  internal void button_0_Click(object class142_4, [In] EventArgs obj1)
  {
    foreach (Class145 class145 in new List<Class145>((IEnumerable<Class145>) this.class29_0.Control2_0.class29_0.Class26_0.method_4()))
    {
      if (class145.Control3_0 == this)
        this.class29_0.Class26_0.method_43(class145.String_0);
    }
    if (this.class145_0.String_0 == \u003CModule\u003E.smethod_5<string>(3379012078U))
      this.class29_0.Class26_0.control3_0 = (Control3) null;
    else if (this.class145_0.String_0 == \u003CModule\u003E.smethod_5<string>(4041277859U))
    {
      this.class29_0.Class26_0.control3_1 = (Control3) null;
      if (this.class29_0.Class26_0.control3_0 != null)
        this.class29_0.Control2_0.method_9();
    }
    this.Parent.Dispose();
    this.class29_0.method_105(false);
  }
}
