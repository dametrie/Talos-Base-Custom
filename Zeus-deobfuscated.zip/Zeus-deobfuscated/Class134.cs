﻿// Decompiled with JetBrains decompiler
// Type: Class134
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

internal class Class134
{
  private static readonly Dictionary<string, double> dictionary_0 = new Dictionary<string, double>()
  {
    {
      \u003CModule\u003E.smethod_6<string>(1411964U),
      450.0
    },
    {
      \u003CModule\u003E.smethod_5<string>(295268315U),
      450.0
    },
    {
      \u003CModule\u003E.smethod_8<string>(620827399U),
      450.0
    },
    {
      \u003CModule\u003E.smethod_6<string>(3728579786U),
      225.0
    },
    {
      \u003CModule\u003E.smethod_6<string>(2947199660U),
      150.0
    },
    {
      \u003CModule\u003E.smethod_7<string>(1648876412U),
      180.0
    },
    {
      \u003CModule\u003E.smethod_5<string>(848505613U),
      210.0
    },
    {
      \u003CModule\u003E.smethod_5<string>(2237311697U),
      240.0
    },
    {
      \u003CModule\u003E.smethod_9<string>(2860665095U),
      155.0
    },
    {
      \u003CModule\u003E.smethod_8<string>(1207929809U),
      155.0
    },
    {
      \u003CModule\u003E.smethod_7<string>(1291214875U),
      155.0
    },
    {
      \u003CModule\u003E.smethod_5<string>(2044488131U),
      60.0
    },
    {
      \u003CModule\u003E.smethod_5<string>(4159834518U),
      120.0
    },
    {
      \u003CModule\u003E.smethod_6<string>(3053989986U),
      300.0
    },
    {
      \u003CModule\u003E.smethod_8<string>(3608516329U),
      600.0
    },
    {
      \u003CModule\u003E.smethod_5<string>(38170227U),
      20.0
    },
    {
      \u003CModule\u003E.smethod_6<string>(3989039828U),
      20.0
    },
    {
      \u003CModule\u003E.smethod_8<string>(3190460676U),
      20.0
    },
    {
      \u003CModule\u003E.smethod_8<string>(4275199732U),
      10.0
    },
    {
      \u003CModule\u003E.smethod_7<string>(2106758939U),
      10.0
    },
    {
      \u003CModule\u003E.smethod_7<string>(638117704U),
      10.0
    },
    {
      \u003CModule\u003E.smethod_5<string>(2153516614U),
      13.0
    },
    {
      \u003CModule\u003E.smethod_6<string>(176154295U),
      13.0
    },
    {
      \u003CModule\u003E.smethod_5<string>(1177488564U),
      15.0
    }
  };

  internal string String_0 { get; [param: In] set; }

  internal byte Byte_0 { get; [param: In] set; }

  internal byte Byte_1 { get; [param: In] set; }

  internal ushort UInt16_0 { get; }

  internal string String_1 { get; set; }

  internal byte Byte_2 { get; [param: In] set; }

  internal byte Byte_3 { get; set; }

  internal byte Byte_4 { get; [param: In] set; }

  internal DateTime DateTime_0 { get; set; }

  internal DateTime DateTime_1 { get; [param: In] set; }

  internal double Double_0 { get; set; }

  internal bool Boolean_0
  {
    get
    {
      if (this.DateTime_1 == DateTime.MinValue || this.Double_0 == 0.0)
        return true;
      double num = this.Double_0 - (double) this.Byte_2 + 0.5;
      DateTime utcNow = DateTime.UtcNow;
      TimeSpan timeSpan1 = utcNow.Subtract(this.DateTime_0);
      utcNow = DateTime.UtcNow;
      TimeSpan timeSpan2 = utcNow.Subtract(this.DateTime_1);
      return timeSpan1.TotalSeconds > 1.5 && timeSpan2.TotalSeconds > num;
    }
  }

  internal Class134()
  {
    this.String_0 = string.Empty;
    this.String_1 = string.Empty;
  }

  internal Class134(
    [In] byte obj0,
    string uint_1,
    byte byte_0,
    ushort uint_2,
    [In] string obj4,
    [In] byte obj5,
    [In] byte obj6,
    [In] byte obj7)
  {
    this.Byte_0 = obj0;
    this.String_0 = uint_1;
    this.Byte_1 = byte_0;
    this.UInt16_0 = uint_2;
    this.String_1 = obj4;
    this.Byte_2 = obj5;
    this.Byte_3 = obj6;
    this.Byte_4 = obj7;
    this.DateTime_0 = DateTime.MinValue;
  }

  internal static double smethod_0(string string_0) => Class134.dictionary_0.ContainsKey(string_0) ? Class134.dictionary_0[string_0] : 30.0;
}
