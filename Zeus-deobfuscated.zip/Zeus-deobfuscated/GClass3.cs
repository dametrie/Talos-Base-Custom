﻿// Decompiled with JetBrains decompiler
// Type: GClass3
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

public class GClass3
{
  public static Bitmap smethod_0(GClass4 string_0, GClass6 string_1) => string_0.Int32_1 == 1 && string_0.Int32_0 == 1 ? new Bitmap(1, 1) : GClass3.smethod_2(string_0.Byte_0, string_1, new Rectangle(string_0.Int32_3, string_0.Int32_2, string_0.Int32_1, string_0.Int32_0));

  public static Bitmap smethod_1(GClass4 gclass7_0, GClass6 string_0, [In] bool obj2) => gclass7_0.Int32_1 == 1 && gclass7_0.Int32_0 == 1 ? new Bitmap(1, 1) : GClass3.smethod_3(gclass7_0.Byte_0, string_0, new Rectangle(0, 0, gclass7_0.Int32_1, gclass7_0.Int32_0));

  private static unsafe Bitmap smethod_2(byte[] value, [In] GClass6 obj1, [In] Rectangle obj2)
  {
    try
    {
      Bitmap bitmap = new Bitmap(obj2.Width + obj2.X, obj2.Height + obj2.Y);
      BitmapData bitmapdata = bitmap.LockBits(obj2, ImageLockMode.WriteOnly, bitmap.PixelFormat);
      for (int index1 = 0; index1 < obj2.Height; ++index1)
      {
        byte* numPtr1 = (byte*) ((int) (void*) bitmapdata.Scan0 + index1 * bitmapdata.Stride);
        for (int index2 = 0; index2 < obj2.Width; ++index2)
        {
          int num = (int) value[index1 * obj2.Width + index2];
          if (num > 0 && bitmapdata.PixelFormat == PixelFormat.Format32bppArgb)
          {
            byte* numPtr2 = numPtr1 + index2 * 4;
            Color color = obj1[num];
            int b = (int) color.B;
            *numPtr2 = (byte) b;
            byte* numPtr3 = numPtr1 + (index2 * 4 + 1);
            color = obj1[num];
            int g = (int) color.G;
            *numPtr3 = (byte) g;
            byte* numPtr4 = numPtr1 + (index2 * 4 + 2);
            color = obj1[num];
            int r = (int) color.R;
            *numPtr4 = (byte) r;
            byte* numPtr5 = numPtr1 + (index2 * 4 + 3);
            color = obj1[num];
            int a = (int) color.A;
            *numPtr5 = (byte) a;
          }
        }
      }
      bitmap.UnlockBits(bitmapdata);
      return bitmap;
    }
    catch
    {
      return new Bitmap(1, 1);
    }
  }

  private static unsafe Bitmap smethod_3([In] byte[] obj0, GClass6 int_4, Rectangle int_5)
  {
    try
    {
      Bitmap bitmap = new Bitmap(int_5.Width, int_5.Height);
      BitmapData bitmapdata = bitmap.LockBits(int_5, ImageLockMode.WriteOnly, bitmap.PixelFormat);
      for (int index1 = 0; index1 < int_5.Height; ++index1)
      {
        byte* numPtr1 = (byte*) ((int) (void*) bitmapdata.Scan0 + index1 * bitmapdata.Stride);
        for (int index2 = 0; index2 < int_5.Width; ++index2)
        {
          int num = (int) obj0[index1 * int_5.Width + index2];
          if (num > 0 && bitmapdata.PixelFormat == PixelFormat.Format32bppArgb)
          {
            byte* numPtr2 = numPtr1 + index2 * 4;
            Color color = int_4[num];
            int b = (int) color.B;
            *numPtr2 = (byte) b;
            byte* numPtr3 = numPtr1 + (index2 * 4 + 1);
            color = int_4[num];
            int g = (int) color.G;
            *numPtr3 = (byte) g;
            byte* numPtr4 = numPtr1 + (index2 * 4 + 2);
            color = int_4[num];
            int r = (int) color.R;
            *numPtr4 = (byte) r;
            byte* numPtr5 = numPtr1 + (index2 * 4 + 3);
            color = int_4[num];
            int a = (int) color.A;
            *numPtr5 = (byte) a;
          }
        }
      }
      bitmap.UnlockBits(bitmapdata);
      return bitmap;
    }
    catch
    {
      return new Bitmap(1, 1);
    }
  }
}
