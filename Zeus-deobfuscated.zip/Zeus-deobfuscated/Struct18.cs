﻿// Decompiled with JetBrains decompiler
// Type: Struct18
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

internal struct Struct18
{
  internal short Int16_0 { get; set; }

  internal short Int16_1 { get; set; }

  [SpecialName]
  public static bool smethod_0(Struct18 bool_0, [In] Struct18 obj1) => bool_0.Equals((object) obj1);

  [SpecialName]
  public static bool smethod_1(Struct18 ushort_0, [In] Struct18 obj1) => !ushort_0.Equals((object) obj1);

  internal Struct18(short uint_0, [In] short obj1)
  {
    this.Int16_0 = uint_0;
    this.Int16_1 = obj1;
  }

  public virtual bool System\u002EValueType\u002EEquals([In] object obj0) => obj0 is Struct18 struct18 && (int) struct18.Int16_0 == (int) this.Int16_0 && (int) struct18.Int16_1 == (int) this.Int16_1;

  public virtual int System\u002EValueType\u002EGetHashCode() => ((int) this.Int16_1 << 16) + (int) this.Int16_1;

  public virtual string System\u002EValueType\u002EToString() => string.Format(\u003CModule\u003E.smethod_5<string>(3919895280U), (object) this.Int16_1, (object) this.Int16_1);
}
