﻿// Decompiled with JetBrains decompiler
// Type: Class93
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Collections.Generic;
using System.Runtime.InteropServices;

internal class Class93
{
  internal Dictionary<Struct16, Struct15> Dictionary_0 { get; set; }

  internal short Int16_0 { get; }

  internal byte Byte_0 { get; }

  internal byte Byte_1 { get; }

  internal byte Byte_2 { get; }

  internal string String_0 { get; }

  internal sbyte SByte_0 { get; }

  internal Dictionary<Struct16, Class92> Dictionary_1 { get; }

  internal Dictionary<Struct16, Class94> Dictionary_2 { get; }

  internal Class93(
    [In] short obj0,
    byte struct16_0 = default (byte),
    byte bool_1 = true,
    byte short_0 = 1,
    [In] string obj4,
    [In] sbyte obj5)
  {
    this.Int16_0 = obj0;
    this.Byte_0 = struct16_0;
    this.Byte_1 = bool_1;
    this.Byte_2 = short_0;
    this.String_0 = obj4;
    this.SByte_0 = obj5;
    this.Dictionary_0 = new Dictionary<Struct16, Struct15>();
    this.Dictionary_1 = new Dictionary<Struct16, Class92>();
    this.Dictionary_2 = new Dictionary<Struct16, Class94>();
  }

  internal Class93 method_0(string class142_0)
  {
    Class93 class93 = new Class93(this.Int16_0, this.Byte_0, this.Byte_1, this.Byte_2, class142_0, this.SByte_0);
    foreach (KeyValuePair<Struct16, Struct15> keyValuePair in this.Dictionary_0)
      class93.Dictionary_0.Add(keyValuePair.Key, keyValuePair.Value);
    foreach (KeyValuePair<Struct16, Class92> keyValuePair in this.Dictionary_1)
      class93.Dictionary_1.Add(keyValuePair.Key, keyValuePair.Value);
    foreach (KeyValuePair<Struct16, Class94> keyValuePair in this.Dictionary_2)
      class93.Dictionary_2.Add(keyValuePair.Key, keyValuePair.Value);
    return class93;
  }
}
