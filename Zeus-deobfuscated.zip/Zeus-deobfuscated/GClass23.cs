﻿// Decompiled with JetBrains decompiler
// Type: GClass23
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Runtime.InteropServices;

public class GClass23
{
  public long Int64_0 => this.Int64_1 - this.Int64_2;

  public long Int64_1 { get; }

  public long Int64_2 { get; }

  public string String_0 { get; set; }

  public GClass23([In] string obj0, long process_0, long bool_0 = false)
  {
    this.String_0 = obj0;
    this.Int64_2 = process_0;
    this.Int64_1 = bool_0;
  }

  public virtual string System\u002EObject\u002EToString() => \u003CModule\u003E.smethod_9<string>(196757124U) + this.String_0 + \u003CModule\u003E.smethod_5<string>(2645810185U) + this.Int64_0.ToString(\u003CModule\u003E.smethod_9<string>(2304871855U)) + \u003CModule\u003E.smethod_6<string>(2923589087U);
}
