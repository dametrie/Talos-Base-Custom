﻿// Decompiled with JetBrains decompiler
// Type: Struct5
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Drawing;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

internal struct Struct5
{
  internal int int_0;
  internal int int_1;
  internal int int_2;
  internal int int_3;

  internal Struct5(int byte_0, int gclass6_0, int rectangle_0, [In] int obj3)
  {
    this.int_0 = byte_0;
    this.int_1 = gclass6_0;
    this.int_2 = rectangle_0;
    this.int_3 = obj3;
  }

  internal Struct5(Rectangle value)
    : this(value.Left, value.Top, value.Right, value.Bottom)
  {
  }

  internal int Int32_0
  {
    get => this.int_0;
    set
    {
      this.int_2 -= this.int_0 - value;
      this.int_0 = value;
    }
  }

  internal int Int32_1
  {
    get => this.int_1;
    [param: In] set
    {
      this.int_3 -= this.int_1 - value;
      this.int_1 = value;
    }
  }

  internal int Int32_2
  {
    get => this.int_3 - this.int_1;
    [param: In] set => this.int_3 = value + this.int_1;
  }

  internal int Int32_3
  {
    get => this.int_2 - this.int_0;
    [param: In] set => this.int_2 = value + this.int_0;
  }

  internal Point Point_0
  {
    get => new Point(this.int_0, this.int_1);
    [param: In] set
    {
      this.Int32_0 = value.X;
      this.Int32_1 = value.Y;
    }
  }

  internal Size Size_0
  {
    get => new Size(this.Int32_3, this.Int32_2);
    set
    {
      this.Int32_3 = value.Width;
      this.Int32_2 = value.Height;
    }
  }

  [SpecialName]
  public static Rectangle smethod_0(Struct5 int_4) => new Rectangle(int_4.int_0, int_4.int_1, int_4.Int32_3, int_4.Int32_2);

  [SpecialName]
  public static Struct5 smethod_1(Rectangle int_4) => new Struct5(int_4);

  [SpecialName]
  public static bool smethod_2([In] Struct5 obj0, Struct5 value) => obj0.method_1(value);

  [SpecialName]
  public static bool smethod_3(Struct5 value, [In] Struct5 obj1) => !value.method_1(obj1);

  internal bool method_0(int value, [In] int obj1) => value >= this.int_0 && value <= this.int_2 && obj1 >= this.int_1 && obj1 <= this.int_3;

  internal bool method_1(Struct5 value) => value.int_0 == this.int_0 && value.int_1 == this.int_1 && value.int_2 == this.int_2 && value.int_3 == this.int_3;

  public virtual bool System\u002EValueType\u002EEquals(object string_1)
  {
    switch (string_1)
    {
      case Struct5 struct5:
        return this.method_1(struct5);
      case Rectangle rectangle:
        return this.method_1(new Struct5(rectangle));
      default:
        return false;
    }
  }

  public virtual int System\u002EValueType\u002EGetHashCode() => Struct5.smethod_0(this).GetHashCode();

  public virtual string System\u002EValueType\u002EToString() => string.Format((IFormatProvider) CultureInfo.CurrentCulture, \u003CModule\u003E.smethod_9<string>(264395167U), (object) this.int_0, (object) this.int_1, (object) this.int_2, (object) this.int_3);
}
