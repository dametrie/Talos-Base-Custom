﻿// Decompiled with JetBrains decompiler
// Type: Enum6
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;

[Flags]
internal enum Enum6 : byte
{
  None = 1,
  Suomi = 2,
  Loures = Suomi | None, // 0x03
  Mileth = 4,
  Tagor = Mileth | None, // 0x05
  Rucesion = Mileth | Suomi, // 0x06
  Noes = Rucesion | None, // 0x07
}
