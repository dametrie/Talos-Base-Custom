﻿// Decompiled with JetBrains decompiler
// Type: Class100
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;

internal sealed class Class100 : Class98
{
  Enum11 Class98.\u206B​‎‪‫⁫‏‫‌⁭‭⁭⁭‮‫‍‪‏⁬‪‮‪‌‌‌‫‮​⁯‏⁫⁫‮‫⁭‬⁮⁬​‌‮
  {
    get
    {
      byte byte1 = this.byte_1;
      if (byte1 <= (byte) 86)
      {
        if (byte1 <= (byte) 10)
        {
          switch (byte1)
          {
            case 0:
            case 3:
              break;
            case 1:
            case 2:
              goto label_12;
            default:
              if (byte1 == (byte) 10)
                goto label_12;
              else
                goto label_11;
          }
        }
        else if (byte1 != (byte) 64)
        {
          if (byte1 == (byte) 86)
            goto label_12;
          else
            goto label_11;
        }
      }
      else if (byte1 <= (byte) 98)
      {
        if (byte1 == (byte) 96 || byte1 == (byte) 98)
          goto label_12;
        else
          goto label_11;
      }
      else if (byte1 != (byte) 102 && byte1 != (byte) 111)
      {
        if (byte1 != (byte) 126)
          goto label_11;
      }
      else
        goto label_12;
      return Enum11.None;
label_11:
      return Enum11.MD5Key;
label_12:
      return Enum11.Normal;
    }
  }

  internal Class100(byte value)
    : base(value)
  {
  }

  internal Class100(byte[] value)
    : base(value)
  {
  }

  void Class98.\u202A⁭‏⁬‏‎​⁪⁮‎‬‪‪‏⁭‬⁬‪‮‏‍‮⁮⁭‌‌‌⁪‍‍‎‮‌‬⁬‮‏‌‏‎‮(Class72 struct17_1)
  {
    this.int_0 = this.byte_0.Length;
    ushort num1 = (ushort) (Class138.smethod_2(65277) + 256);
    byte num2 = (byte) (Class138.smethod_2(155) + 100);
    byte[] numArray;
    switch (((Class98) this).Class98\u002E⁫​‎‪‫⁫‏‫‌⁭‭⁭⁭‮‫‍‪‏⁬‪‮‪‌‌‌‫‮​⁯‏⁫⁫‮‫⁭‬⁮⁬​‌‮)
    {
      case Enum11.Normal:
        numArray = struct17_1.Byte_1;
        break;
      case Enum11.MD5Key:
        numArray = struct17_1.method_0(num1, num2);
        break;
      default:
        return;
    }
    for (int index1 = 0; index1 < this.byte_0.Length; ++index1)
    {
      int index2 = index1 / struct17_1.Byte_1.Length % 256;
      this.byte_0[index1] ^= (byte) ((uint) struct17_1.Byte_2[index2] ^ (uint) numArray[index1 % numArray.Length]);
      if (index2 != (int) this.byte_3)
        this.byte_0[index1] ^= struct17_1.Byte_2[(int) this.byte_3];
    }
    this.method_14((byte) ((int) num1 % 256 ^ 116));
    this.method_14((byte) ((uint) num2 ^ 36U));
    this.method_14((byte) (((int) num1 >> 8) % 256 ^ 100));
  }

  void Class98.\u200F‫‮​⁪‭‎⁬⁫‍⁪‌‍‏‏⁯⁯‭‫⁫‬‪‬‌‌‪⁯⁮‮⁭⁬‏⁬‮‭⁪‮‭‎⁭‮(Class72 form5_1)
  {
    int newSize = this.byte_0.Length - 3;
    ushort num1 = (ushort) (((int) this.byte_0[newSize + 2] << 8 | (int) this.byte_0[newSize]) ^ 25716);
    byte num2 = (byte) ((uint) this.byte_0[newSize + 1] ^ 36U);
    byte[] numArray;
    switch (((Class98) this).Class98\u002E⁫​‎‪‫⁫‏‫‌⁭‭⁭⁭‮‫‍‪‏⁬‪‮‪‌‌‌‫‮​⁯‏⁫⁫‮‫⁭‬⁮⁬​‌‮)
    {
      case Enum11.Normal:
        numArray = form5_1.Byte_1;
        break;
      case Enum11.MD5Key:
        numArray = form5_1.method_0(num1, num2);
        break;
      default:
        return;
    }
    for (int index1 = 0; index1 < newSize; ++index1)
    {
      int index2 = index1 / form5_1.Byte_1.Length % 256;
      this.byte_0[index1] ^= (byte) ((uint) form5_1.Byte_2[index2] ^ (uint) numArray[index1 % numArray.Length]);
      if (index2 != (int) this.byte_3)
        this.byte_0[index1] ^= form5_1.Byte_2[(int) this.byte_3];
    }
    Array.Resize<byte>(ref this.byte_0, newSize);
  }

  internal Class100 method_29()
  {
    Class100 class100 = new Class100(this.byte_1);
    class100.method_13(this.byte_0);
    class100.dateTime_0 = this.dateTime_0;
    return class100;
  }

  public virtual string System\u002EObject\u002EToString()
  {
    string class0_0 = this.method_27().Substring(0, 2);
    // ISSUE: reference to a compiler-generated method
    switch (Class181.smethod_0(class0_0))
    {
      case 233362851:
        if (class0_0 == \u003CModule\u003E.smethod_7<string>(3765753896U))
          return \u003CModule\u003E.smethod_8<string>(104771331U) + this.method_27();
        break;
      case 334175660:
        if (class0_0 == \u003CModule\u003E.smethod_6<string>(1693975042U))
          return \u003CModule\u003E.smethod_5<string>(1907864537U) + this.method_27();
        break;
      case 350953279:
        if (class0_0 == \u003CModule\u003E.smethod_9<string>(3963562854U))
          return \u003CModule\u003E.smethod_9<string>(2891179053U) + this.method_27();
        break;
      case 367583803:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(2024987903U))
          return \u003CModule\u003E.smethod_5<string>(2184483186U) + this.method_27();
        break;
      case 368025088:
        if (class0_0 == \u003CModule\u003E.smethod_8<string>(259986298U))
          return \u003CModule\u003E.smethod_6<string>(3329677776U) + this.method_27();
        break;
      case 384802707:
        if (class0_0 == \u003CModule\u003E.smethod_6<string>(1316316525U))
          return \u003CModule\u003E.smethod_5<string>(4062252046U) + this.method_27();
        break;
      case 418063755:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(2410635035U))
          return \u003CModule\u003E.smethod_7<string>(596544144U) + this.method_27();
        break;
      case 418357945:
        if (class0_0 == \u003CModule\u003E.smethod_7<string>(369575324U))
          return \u003CModule\u003E.smethod_7<string>(2997474682U) + this.method_27();
        break;
      case 434988469:
        if (class0_0 == \u003CModule\u003E.smethod_8<string>(3701704092U))
          return \u003CModule\u003E.smethod_7<string>(2546565894U) + this.method_27();
        break;
      case 435135564:
        if (class0_0 == \u003CModule\u003E.smethod_7<string>(3050430822U))
          return \u003CModule\u003E.smethod_5<string>(3271437221U) + this.method_27();
        break;
      case 451471898:
        if (class0_0 == \u003CModule\u003E.smethod_9<string>(3262668641U))
          return \u003CModule\u003E.smethod_7<string>(1769016917U) + this.method_27();
        break;
      case 451618993:
        if (class0_0 == \u003CModule\u003E.smethod_8<string>(2481900757U))
          return \u003CModule\u003E.smethod_9<string>(2204738129U) + this.method_27();
        break;
      case 451766088:
        if (class0_0 == \u003CModule\u003E.smethod_7<string>(2011679618U))
          return \u003CModule\u003E.smethod_7<string>(413078494U) + this.method_27();
        break;
      case 468249517:
        if (class0_0 == \u003CModule\u003E.smethod_6<string>(1162646809U))
          return \u003CModule\u003E.smethod_6<string>(4264727618U) + this.method_27();
        break;
      case 468396612:
        if (class0_0 == \u003CModule\u003E.smethod_9<string>(2590681006U))
          return \u003CModule\u003E.smethod_5<string>(2229237147U) + this.method_27();
        break;
      case 485174231:
        if (class0_0 == \u003CModule\u003E.smethod_6<string>(3504163790U))
          return \u003CModule\u003E.smethod_8<string>(1438138137U) + this.method_27();
        break;
      case 485321326:
        if (class0_0 == \u003CModule\u003E.smethod_7<string>(944935918U))
          return \u003CModule\u003E.smethod_9<string>(3967955649U) + this.method_27();
        break;
      case 502098945:
        if (class0_0 == \u003CModule\u003E.smethod_8<string>(4181821396U))
          return \u003CModule\u003E.smethod_9<string>(614488863U) + this.method_27();
        break;
      case 518729469:
        if (class0_0 == \u003CModule\u003E.smethod_7<string>(425560316U))
          return \u003CModule\u003E.smethod_8<string>(2211806646U) + this.method_27();
        break;
      case 518876564:
        if (class0_0 == \u003CModule\u003E.smethod_8<string>(2154367074U))
          return \u003CModule\u003E.smethod_8<string>(240476223U) + this.method_27();
        break;
      case 535654183:
        if (class0_0 == \u003CModule\u003E.smethod_7<string>(2559047716U))
          return \u003CModule\u003E.smethod_6<string>(3931325094U) + this.method_27();
        break;
      case 569209421:
        if (class0_0 == \u003CModule\u003E.smethod_8<string>(2290071966U))
          return \u003CModule\u003E.smethod_8<string>(1307695937U) + this.method_27();
        break;
      case 736691421:
        if (class0_0 == \u003CModule\u003E.smethod_8<string>(1547754589U))
          return \u003CModule\u003E.smethod_9<string>(3656357811U) + this.method_27();
        break;
      case 955388848:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(896610702U))
          return \u003CModule\u003E.smethod_5<string>(1226078195U) + this.method_27();
        break;
      case 972166467:
        if (class0_0 == \u003CModule\u003E.smethod_8<string>(1327206012U))
          return \u003CModule\u003E.smethod_6<string>(2230550069U) + this.method_27();
        break;
      case 1005721705:
        if (class0_0 == \u003CModule\u003E.smethod_9<string>(178714730U))
          return \u003CModule\u003E.smethod_8<string>(1464226577U) + this.method_27();
        break;
      case 1056054562:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(2282085991U))
          return \u003CModule\u003E.smethod_8<string>(2771504943U) + this.method_27();
        break;
      case 1240167086:
        if (class0_0 == \u003CModule\u003E.smethod_6<string>(3126505273U))
          return \u003CModule\u003E.smethod_9<string>(2077208336U) + this.method_27();
        break;
      case 1290499943:
        if (class0_0 == \u003CModule\u003E.smethod_9<string>(1203345869U))
          return \u003CModule\u003E.smethod_8<string>(77367218U) + this.method_27();
        break;
      case 1810753227:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(4059870002U))
          return \u003CModule\u003E.smethod_8<string>(3519085012U) + this.method_27();
        break;
      case 1827530846:
        if (class0_0 == \u003CModule\u003E.smethod_6<string>(451585768U))
          return \u003CModule\u003E.smethod_5<string>(2539184079U) + this.method_27();
        break;
      case 1844308465:
        if (class0_0 == \u003CModule\u003E.smethod_8<string>(2721959409U))
          return \u003CModule\u003E.smethod_5<string>(488112214U) + this.method_27();
        break;
      case 1861086084:
        if (class0_0 == \u003CModule\u003E.smethod_8<string>(694505087U))
          return \u003CModule\u003E.smethod_6<string>(1529897177U) + this.method_27();
        break;
      case 1877863703:
        if (class0_0 == \u003CModule\u003E.smethod_9<string>(610096068U))
          return \u003CModule\u003E.smethod_7<string>(55416957U) + this.method_27();
        break;
      case 1894641322:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(2474909557U))
          return \u003CModule\u003E.smethod_6<string>(4038115420U) + this.method_27();
        break;
      case 2095428297:
        if (class0_0 == \u003CModule\u003E.smethod_8<string>(3575208911U))
          return \u003CModule\u003E.smethod_6<string>(1756509375U) + this.method_27();
        break;
      case 2247118416:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(3670892075U))
          return \u003CModule\u003E.smethod_8<string>(1410734024U) + this.method_27();
        break;
      case 2263896035:
        if (class0_0 == \u003CModule\u003E.smethod_9<string>(261845359U))
          return \u003CModule\u003E.smethod_9<string>(2047262461U) + this.method_27();
        break;
      case 2279835011:
        if (class0_0 == \u003CModule\u003E.smethod_6<string>(902186767U))
          return \u003CModule\u003E.smethod_6<string>(3874037555U) + this.method_27();
        break;
      case 2280673654:
        if (class0_0 == \u003CModule\u003E.smethod_8<string>(740103602U))
          return \u003CModule\u003E.smethod_5<string>(1824069454U) + this.method_27();
        break;
      case 2297451273:
        if (class0_0 == \u003CModule\u003E.smethod_8<string>(3682194017U))
          return \u003CModule\u003E.smethod_6<string>(2905139869U) + this.method_27();
        break;
      case 2313243154:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(636181819U))
          return \u003CModule\u003E.smethod_8<string>(2719328063U) + this.method_27();
        break;
      case 2314228892:
        if (class0_0 == \u003CModule\u003E.smethod_6<string>(2144576041U))
          return \u003CModule\u003E.smethod_8<string>(4187084088U) + this.method_27();
        break;
      case 2331006511:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(2153536947U))
          return \u003CModule\u003E.smethod_6<string>(4051146966U) + this.method_27();
        break;
      case 2346798392:
        if (class0_0 == \u003CModule\u003E.smethod_8<string>(107402677U))
          return \u003CModule\u003E.smethod_7<string>(3411121211U) + this.method_27();
        break;
      case 2347784130:
        if (class0_0 == \u003CModule\u003E.smethod_9<string>(2752549469U))
          return \u003CModule\u003E.smethod_7<string>(1165663827U) + this.method_27();
        break;
      case 2381486463:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(893279907U))
          return \u003CModule\u003E.smethod_7<string>(3389369626U) + this.method_27();
        break;
      case 2414894606:
        if (class0_0 == \u003CModule\u003E.smethod_9<string>(3787241102U))
          return \u003CModule\u003E.smethod_5<string>(3592809831U) + this.method_27();
        break;
      case 2415041701:
        if (class0_0 == \u003CModule\u003E.smethod_6<string>(2298245757U))
          return \u003CModule\u003E.smethod_7<string>(3908745228U) + this.method_27();
        break;
      case 2431672225:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(3674222870U))
          return \u003CModule\u003E.smethod_6<string>(3483347492U) + this.method_27();
        break;
      case 2447611201:
        if (class0_0 == \u003CModule\u003E.smethod_6<string>(3801095073U))
          return \u003CModule\u003E.smethod_6<string>(1649719049U) + this.method_27();
        break;
      case 2498929796:
        if (class0_0 == \u003CModule\u003E.smethod_5<string>(960885224U))
          return \u003CModule\u003E.smethod_7<string>(462822575U) + this.method_27();
        break;
    }
    return \u003CModule\u003E.smethod_5<string>(3849907919U) + this.method_27();
  }
}
