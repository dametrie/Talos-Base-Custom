﻿// Decompiled with JetBrains decompiler
// Type: Class177
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

internal class Class177
{
  private string string_0;

  internal Control4 Control4_0 { get; set; }

  internal ushort UInt16_0
  {
    get
    {
      ushort result;
      return !ushort.TryParse(this.string_0, out result) ? (ushort) 0 : result;
    }
    set => this.string_0 = value.ToString();
  }

  internal bool Boolean_0 => this.string_0 == \u003CModule\u003E.smethod_5<string>(2588197253U);

  internal Class177(ushort bool_1 = false) => this.string_0 = bool_1.ToString();

  internal Class177(string object_0) => this.string_0 = object_0;

  public virtual string System\u002EObject\u002EToString() => this.string_0;
}
