﻿// Decompiled with JetBrains decompiler
// Type: Enum9
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;

[Flags]
internal enum Enum9 : byte
{
  None = 0,
  UnreadMail = 1,
  Unknown = 2,
  Secondary = 4,
  Experience = 8,
  Current = 16, // 0x10
  Primary = 32, // 0x20
  GameMasterA = 64, // 0x40
  GameMasterB = 128, // 0x80
  Swimming = GameMasterB | GameMasterA, // 0xC0
  Full = Primary | Current | Experience | Secondary, // 0x3C
}
