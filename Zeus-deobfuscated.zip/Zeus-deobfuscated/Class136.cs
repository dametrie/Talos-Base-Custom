﻿// Decompiled with JetBrains decompiler
// Type: Class136
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;

internal sealed class Class136 : IEnumerable<Class134>, IEnumerable
{
  private const int int_0 = 90;
  private readonly Class134[] class134_0;

  private Dictionary<string, Class134> Dictionary_0 { get; }

  internal Class134 this[[In] string obj0] => this.Dictionary_0.ContainsKey(obj0) ? this.Dictionary_0[obj0] : (Class134) null;

  internal Class134 this[[In] byte obj0] => this.class134_0[(int) obj0];

  internal int Int32_0 => 90;

  internal Class136()
  {
    this.Dictionary_0 = new Dictionary<string, Class134>();
    this.class134_0 = new Class134[90];
  }

  internal void method_0(Class134 uint_1)
  {
    if (this.Dictionary_0.ContainsKey(uint_1.String_0))
    {
      Class134 class134 = this.Dictionary_0[uint_1.String_0];
      class134.Byte_0 = uint_1.Byte_0;
      class134.Byte_2 = uint_1.Byte_2;
      class134.Byte_3 = uint_1.Byte_3;
      class134.Byte_4 = uint_1.Byte_4;
      if (uint_1.Double_0 > class134.Double_0)
        class134.Double_0 = uint_1.Double_0;
      uint_1 = class134;
    }
    else
      this.Dictionary_0.Add(uint_1.String_0, uint_1);
    this.class134_0[(int) uint_1.Byte_0] = uint_1;
  }

  internal void method_1([In] byte obj0)
  {
    if (this.class134_0[(int) obj0] == null)
      return;
    this.Dictionary_0[this.class134_0[(int) obj0].String_0].Byte_0 = (byte) 0;
    this.class134_0[(int) obj0] = (Class134) null;
  }

  public IEnumerator<Class134> GetEnumerator() => (IEnumerator<Class134>) this.Dictionary_0.Values.GetEnumerator();

  IEnumerator IEnumerable.GetEnumerator() => (IEnumerator) this.GetEnumerator();
}
