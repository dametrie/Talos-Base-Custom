﻿// Decompiled with JetBrains decompiler
// Type: GClass16
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

public class GClass16
{
  public Color this[int value]
  {
    get => this.Color_0[value];
    [param: In] set => this.Color_0[value] = value;
  }

  public Color[] Color_0 { get; } = new Color[256];

  public static GClass16 smethod_0(string string_1) => GClass16.smethod_4((Stream) new FileStream(string_1, FileMode.Open, FileAccess.Read, FileShare.Read));

  public static GClass16 smethod_1(byte[] string_1) => GClass16.smethod_4((Stream) new MemoryStream(string_1));

  public static GClass16 smethod_2([In] string obj0, GClass22 bool_0) => bool_0.method_0(obj0) ? GClass16.smethod_1(bool_0.method_4(obj0)) : (GClass16) null;

  public static GClass16 smethod_3(string string_1, bool bool_0, [In] GClass22 obj2) => obj2.method_1(string_1, bool_0) ? GClass16.smethod_1(obj2.method_5(string_1, bool_0)) : (GClass16) null;

  private static GClass16 smethod_4(Stream string_1)
  {
    string_1.Seek(0L, SeekOrigin.Begin);
    BinaryReader binaryReader = new BinaryReader(string_1);
    GClass16 gclass16 = new GClass16();
    for (int index = 0; index < 256; ++index)
      gclass16.Color_0[index] = Color.FromArgb((int) binaryReader.ReadByte(), (int) binaryReader.ReadByte(), (int) binaryReader.ReadByte());
    return gclass16;
  }

  public static GClass16 smethod_5([In] GClass16 obj0, int bool_0)
  {
    if (bool_0 <= 0)
      return obj0;
    StreamReader streamReader = new StreamReader(Application.StartupPath + \u003CModule\u003E.smethod_9<string>(3433793908U));
    Color[,] colorArray = new Color[Convert.ToInt32(streamReader.ReadLine()), 6];
    while (!streamReader.EndOfStream)
    {
      int int32_1 = Convert.ToInt32(streamReader.ReadLine());
      for (int index = 0; index < 6; ++index)
      {
        string[] strArray = streamReader.ReadLine().Trim().Split(',');
        if (strArray.Length == 3)
        {
          int int32_2 = Convert.ToInt32(strArray[0]);
          int int32_3 = Convert.ToInt32(strArray[1]);
          int int32_4 = Convert.ToInt32(strArray[2]);
          if (int32_2 > (int) byte.MaxValue)
            int32_2 -= (int) byte.MaxValue;
          if (int32_3 > (int) byte.MaxValue)
            int32_3 -= (int) byte.MaxValue;
          if (int32_4 > (int) byte.MaxValue)
            int32_4 -= (int) byte.MaxValue;
          colorArray[int32_1, index] = Color.FromArgb((int) byte.MaxValue, int32_2, int32_3, int32_4);
        }
      }
    }
    streamReader.Close();
    GClass16 gclass16 = new GClass16();
    for (int index = 0; index < 256; ++index)
      gclass16[index] = obj0[index];
    gclass16[98] = colorArray[bool_0, 0];
    gclass16[99] = colorArray[bool_0, 1];
    gclass16[100] = colorArray[bool_0, 2];
    gclass16[101] = colorArray[bool_0, 3];
    gclass16[102] = colorArray[bool_0, 4];
    gclass16[103] = colorArray[bool_0, 5];
    return gclass16;
  }
}
