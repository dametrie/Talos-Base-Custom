﻿// Decompiled with JetBrains decompiler
// Type: Class106
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

internal static class Class106
{
  private static Form5 form5_0;

  internal static Stopwatch Stopwatch_0 { get; [param: In] set; }

  internal static string String_0 { get; set; }

  internal static Version Version_0 { get; [param: In] private set; }

  internal static Form5 Form5_0
  {
    get
    {
      if (Class106.form5_0 == null)
        Class106.form5_0 = (Form5) Application.OpenForms[0];
      return Class106.form5_0;
    }
  }

  [STAThread]
  private static void Main()
  {
    if (!File.Exists(\u003CModule\u003E.smethod_9<string>(4257353905U)))
    {
      File.WriteAllText(\u003CModule\u003E.smethod_5<string>(3363327187U), \u003CModule\u003E.smethod_8<string>(697136433U));
      ThreadPool.QueueUserWorkItem((WaitCallback) delegate
      {
        Process.Start("");
      });
    }
    else
    {
      Class106.Stopwatch_0 = Stopwatch.StartNew();
      Application.EnableVisualStyles();
      Application.SetCompatibleTextRenderingDefault(false);
      Application.ThreadException += new ThreadExceptionEventHandler(Class106.smethod_1);
      AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(Class106.smethod_0);
      Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
      Class106.Version_0 = new Version(0, 0, 1, 12);
      Application.Run((Form) new Form5());
    }
  }

  internal static void smethod_0(object class29_0, UnhandledExceptionEventArgs class99_0)
  {
    string path = AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_9<string>(3506060353U);
    if (!Directory.Exists(path))
      Directory.CreateDirectory(path);
    File.WriteAllText(path + DateTime.Now.ToString(\u003CModule\u003E.smethod_7<string>(1191726713U)) + \u003CModule\u003E.smethod_9<string>(2947149222U), (class99_0.ExceptionObject as Exception).ToString());
  }

  internal static void smethod_1(object class29_0, ThreadExceptionEventArgs class99_0)
  {
    string path = AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_9<string>(3506060353U);
    if (!Directory.Exists(path))
      Directory.CreateDirectory(path);
    File.WriteAllText(path + DateTime.Now.ToString(\u003CModule\u003E.smethod_6<string>(1280272479U)) + \u003CModule\u003E.smethod_8<string>(1926790092U), class99_0.Exception.ToString());
  }

  internal static string smethod_2(
    Environment.SpecialFolder class29_0,
    string class99_0,
    [In] object[] obj2)
  {
    string path = string.Join(\u003CModule\u003E.smethod_7<string>(3689116561U), new string[2]
    {
      Environment.GetFolderPath(class29_0) + \u003CModule\u003E.smethod_9<string>(1218838455U),
      string.Format(class99_0, obj2)
    });
    Directory.CreateDirectory(Path.GetDirectoryName(path));
    return path;
  }

  internal static void smethod_3([In] int obj0, int class99_0) => ThreadPool.QueueUserWorkItem(new WaitCallback(new Class106.Class108()
  {
    int_0 = class99_0,
    int_1 = obj0
  }.method_0));
}
