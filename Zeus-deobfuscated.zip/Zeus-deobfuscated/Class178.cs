﻿// Decompiled with JetBrains decompiler
// Type: Class178
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Threading;

internal class Class178
{
  private DateTime dateTime_0;
  private Form5 form5_0;
  private TcpClient tcpClient_0;
  private Socket socket_0;
  private string string_0;
  internal string string_1;
  internal Thread thread_0;
  private bool bool_0;

  internal Class178([In] Form5 obj0)
  {
    this.form5_0 = obj0;
    this.bool_0 = false;
    if (!this.method_3() || !this.method_5(false))
      return;
    this.dateTime_0 = DateTime.UtcNow;
    this.thread_0 = new Thread(new ThreadStart(this.method_0));
    this.thread_0.Start();
  }

  private void method_0()
  {
    while (this.socket_0.Connected)
    {
      if (this.socket_0.Available > 0)
      {
        byte[] numArray = new byte[this.socket_0.Available];
        this.socket_0.Receive(numArray);
        this.method_1(new Class180(numArray));
      }
      else if (DateTime.UtcNow.Subtract(this.dateTime_0).TotalSeconds > 5.0)
      {
        this.method_2(new Class180(Enum14.KeepAlive));
        this.dateTime_0 = DateTime.UtcNow;
      }
      Thread.Sleep(50);
    }
    Thread.Sleep(10000);
    if (this.socket_0.Connected)
    {
      this.method_0();
    }
    else
    {
      if (this.bool_0)
        return;
      Thread.Sleep(60000);
      this.method_5(true);
    }
  }

  private void method_1([In] Class180 obj0)
  {
    Class180 stream_1_1 = (Class180) null;
    switch ((Enum15) obj0.method_2())
    {
      case Enum15.AdminMessage:
        string str1 = obj0.method_11();
        using (IEnumerator<Class29> enumerator = this.form5_0.Class112_0.IEnumerable_0.GetEnumerator())
        {
          while (enumerator.MoveNext())
          {
            Class29 current = enumerator.Current;
            if (!current.Control2_0.checkBox_21.Checked)
              current.method_75((byte) 1, \u003CModule\u003E.smethod_6<string>(3511435908U) + str1);
          }
          break;
        }
      case Enum15.RangerAlert:
        string key1 = obj0.method_11();
        string str2 = obj0.method_11();
        if (!this.form5_0.dictionary_3.ContainsKey(key1) || this.form5_0.dictionary_3[key1] != str2)
        {
          this.form5_0.dictionary_3[key1] = str2;
          using (IEnumerator<Class29> enumerator = this.form5_0.Class112_0.IEnumerable_0.GetEnumerator())
          {
            while (enumerator.MoveNext())
            {
              Class29 current = enumerator.Current;
              if (!current.Control2_0.checkBox_21.Checked && DateTime.UtcNow.Subtract(current.Class26_0.dateTime_10) < TimeSpan.FromMinutes(1.0) && current.Control2_0.toolStripMenuItem_2.Text == \u003CModule\u003E.smethod_6<string>(2579949292U))
                current.method_75((byte) 1, \u003CModule\u003E.smethod_5<string>(2030639743U) + key1 + \u003CModule\u003E.smethod_9<string>(1133767970U) + str2);
            }
            break;
          }
        }
        else
          break;
      case Enum15.UpTimeRequest:
        Class180 stream_1_2 = new Class180(Enum14.UpTimeResponse);
        stream_1_2.method_16(Class106.Stopwatch_0.Elapsed);
        this.method_2(stream_1_2);
        break;
      case Enum15.CharRequest:
        List<Class29> list = this.form5_0.Class112_0.IEnumerable_0.ToList<Class29>();
        if (list.Count > 0)
        {
          List<string> stringList = new List<string>();
          stream_1_1 = new Class180(Enum14.CharListResponse);
          foreach (Class29 class29 in list)
            stringList.Add(class29.String_0);
          stream_1_1.method_17((byte) stringList.Count);
          foreach (string str3 in stringList)
            stream_1_1.method_27(str3);
        }
        this.method_2(stream_1_1);
        break;
      case Enum15.CharInfoRequest:
        if (obj0.method_3())
        {
          Class29 class29 = this.form5_0.Class112_0.method_75(obj0.method_11());
          if (class29 != null)
          {
            Class180 stream_1_3 = new Class180(Enum14.CharInfoResponse);
            stream_1_3.method_27(class29.String_0);
            stream_1_3.method_27(class29.class88_0.String_0);
            stream_1_3.method_30(class29.Struct16_0);
            stream_1_3.method_25(class29.Control2_0.ulong_0);
            stream_1_3.method_25((ulong) Math.Truncate((double) class29.Control2_0.ulong_0 / class29.Control2_0.stopwatch_0.Elapsed.TotalHours));
            stream_1_3.method_22((int) class29.UInt32_12);
            stream_1_3.method_17((byte) class29.Enum6_0);
            stream_1_3.method_27(class29.String_1);
            stream_1_3.method_17((byte) class29.previousClass_0);
            stream_1_3.method_17((byte) class29.temClass_0);
            stream_1_3.method_17((byte) class29.medClass_0);
            this.method_2(stream_1_3);
            break;
          }
          break;
        }
        using (IEnumerator<Class29> enumerator = this.form5_0.Class112_0.IEnumerable_0.GetEnumerator())
        {
          while (enumerator.MoveNext())
          {
            Class29 current = enumerator.Current;
            Class180 stream_1_4 = new Class180(Enum14.CharInfoResponse);
            stream_1_4.method_27(current.String_0);
            stream_1_4.method_27(current.class88_0.String_0);
            stream_1_4.method_30(current.Struct16_0);
            stream_1_4.method_25(current.Control2_0.ulong_0);
            stream_1_4.method_25((ulong) Math.Truncate((double) current.Control2_0.ulong_0 / current.Control2_0.stopwatch_0.Elapsed.TotalHours));
            stream_1_4.method_22((int) current.UInt32_12);
            stream_1_4.method_17((byte) current.Enum6_0);
            stream_1_4.method_27(current.String_1);
            stream_1_4.method_17((byte) current.previousClass_0);
            stream_1_4.method_17((byte) current.temClass_0);
            stream_1_4.method_17((byte) current.medClass_0);
            this.method_2(stream_1_4);
          }
          break;
        }
      case Enum15.HashResponse:
        if (this.string_1 == obj0.method_11())
        {
          string str4 = obj0.method_11();
          if (!string.IsNullOrEmpty(str4))
          {
            this.string_0 = str4;
            this.form5_0.string_1 = str4;
            while (this.form5_0?.Class112_0 == null)
              Thread.Sleep(10);
            this.form5_0.Class112_0.method_71(2610);
            this.form5_0.toolStripMenuItem_5.Enabled = true;
            break;
          }
          break;
        }
        Process.GetCurrentProcess().Kill();
        break;
      case Enum15.DMUResponse:
        string key2 = obj0.method_11();
        if (obj0.method_3())
        {
          this.form5_0.dictionary_4[key2] = obj0.method_13();
          break;
        }
        if (this.form5_0.dictionary_4.ContainsKey(key2))
        {
          this.form5_0.dictionary_4.Remove(key2);
          break;
        }
        break;
      case Enum15.KillRequest:
        if (obj0.method_3())
        {
          Class29 class29 = this.form5_0.Class112_0.method_75(obj0.method_11());
          if (class29 != null)
          {
            class29.method_6(false);
            break;
          }
          break;
        }
        this.bool_0 = true;
        this.tcpClient_0.Close();
        Process.GetCurrentProcess().Kill();
        break;
    }
    if (obj0.int_0 == obj0.byte_1.Length)
      return;
    byte[] numArray = new byte[obj0.byte_1.Length - obj0.int_0];
    Buffer.BlockCopy((Array) obj0.byte_1, obj0.int_0, (Array) numArray, 0, numArray.Length);
    this.method_1(new Class180(numArray));
  }

  internal void method_2(Class180 stream_1) => ThreadPool.QueueUserWorkItem(new WaitCallback(new Class178.Class179()
  {
    class178_0 = this,
    class180_0 = stream_1
  }.method_0));

  private bool method_3()
  {
    string path = AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_6<string>(2136791289U);
    if (!File.Exists(path))
      this.method_4();
    else
      this.string_1 = File.ReadAllText(path);
    this.form5_0.string_1 = this.string_0;
    return true;
  }

  private void method_4()
  {
    string str1 = AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_9<string>(162321585U);
    List<string> contents = new List<string>();
    string str2 = AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_9<string>(3770847957U);
    contents.Add(\u003CModule\u003E.smethod_9<string>(1535203433U));
    contents.Add(\u003CModule\u003E.smethod_6<string>(4055795687U));
    contents.Add(\u003CModule\u003E.smethod_9<string>(2270436316U) + str2 + \u003CModule\u003E.smethod_8<string>(621502459U));
    contents.Add(\u003CModule\u003E.smethod_9<string>(1152614054U));
    File.WriteAllLines(str1, (IEnumerable<string>) contents);
    Process.Start(new ProcessStartInfo(str1, \u003CModule\u003E.smethod_7<string>(2053900339U))
    {
      WindowStyle = ProcessWindowStyle.Hidden,
      CreateNoWindow = true
    });
    Process.GetCurrentProcess().Kill();
  }

  private bool method_5(bool int_0)
  {
    if (this.bool_0)
      return false;
    try
    {
      this.tcpClient_0 = new TcpClient(\u003CModule\u003E.smethod_9<string>(672440757U), 6379);
    }
    catch
    {
      this.method_5(true);
      return false;
    }
    DateTime utcNow = DateTime.UtcNow;
    while (!this.tcpClient_0.Connected)
    {
      if (DateTime.UtcNow.Subtract(utcNow).TotalSeconds > 10.0)
        return false;
      Thread.Sleep(10);
    }
    this.socket_0 = this.tcpClient_0.Client;
    Class180 stream_1 = new Class180(Enum14.HashRequest);
    stream_1.method_27(this.string_1);
    this.method_2(stream_1);
    if (!int_0)
      return true;
    int_0 = false;
    this.method_0();
    return false;
  }
}
