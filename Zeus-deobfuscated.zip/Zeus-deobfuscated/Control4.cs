﻿// Decompiled with JetBrains decompiler
// Type: Control4
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using Accolade.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

internal class Control4 : UserControl
{
  internal CheckBox checkBox_0;
  internal CheckBox checkBox_1;
  internal ComboBox comboBox_0;
  internal ComboBox comboBox_1;
  internal Class29 class29_0;
  internal IContainer icontainer_0;
  internal Label label_0;
  internal RadioButton radioButton_0;
  internal GroupBox groupBox_0;
  internal PictureBox pictureBox_0;
  internal Button button_0;
  private GroupBox groupBox_1;
  internal GroupBox groupBox_2;
  internal GroupBox groupBox_3;
  private Label label_1;
  internal NumericUpDown numericUpDown_0;
  private Label label_2;
  internal RadioButton radioButton_1;
  internal Label label_3;
  internal Button button_1;
  internal CheckBox checkBox_2;
  internal GroupBox groupBox_4;
  internal ListBox listBox_0;
  internal Button button_2;
  internal TextBox textBox_0;
  internal Class177 class177_0;
  internal CheckBox checkBox_3;
  internal CheckBox checkBox_4;
  internal CheckBox checkBox_5;
  internal CheckBox checkBox_6;
  internal CheckBox checkBox_7;
  internal RadioButton radioButton_2;
  internal Button button_3;
  internal CheckBox checkBox_8;
  internal GroupBox groupBox_5;
  internal ListBox listBox_1;
  internal CheckBox checkBox_9;
  internal Button button_4;
  internal TextBox textBox_1;
  private Panel panel_0;
  private Panel panel_1;
  private Panel panel_2;
  internal RadioButton radioButton_3;
  internal RadioButton radioButton_4;
  internal RadioButton radioButton_5;
  internal CheckBox checkBox_10;
  internal ComboBox comboBox_2;
  internal CheckBox checkBox_11;
  internal ComboBox comboBox_3;
  internal CheckBox checkBox_12;
  internal ComboBox comboBox_4;
  internal CheckBox checkBox_13;
  internal ComboBox comboBox_5;
  internal CheckBox checkBox_14;
  internal CheckBox checkBox_15;
  internal Label label_4;

  internal Control4(Class177 enum15_0, [In] Class29 obj1)
  {
    this.method_0();
    this.class177_0 = enum15_0;
    this.Name = enum15_0.UInt16_0.ToString();
    this.class29_0 = obj1;
    string string_2 = string.Format(\u003CModule\u003E.smethod_8<string>(3365826331U), (object) enum15_0.UInt16_0);
    GClass22 bool_0 = GClass22.smethod_0(Settings.Default.DarkAgesPath.Replace(\u003CModule\u003E.smethod_8<string>(2112040518U), \u003CModule\u003E.smethod_7<string>(1219536002U)));
    if (!bool_0.method_0(string_2))
      return;
    GClass14 gclass14 = GClass14.smethod_2(string_2, bool_0);
    int num = gclass14.byte_5 == (byte) 0 || (int) gclass14.byte_0 == (int) gclass14.byte_4 ? (int) gclass14.byte_0 + (int) gclass14.byte_1 : (int) gclass14.byte_0 - (int) gclass14.byte_5;
    if (num < 0)
      num = 0;
    if (num >= gclass14.Int32_2)
      num = gclass14.Int32_2 - 1;
    GClass16 gclass16 = GClass16.smethod_2(gclass14.string_0, bool_0);
    Bitmap bitmap = GClass9.smethod_2(gclass14[num], gclass16);
    bitmap.RotateFlip(RotateFlipType.RotateNoneFlipX);
    this.pictureBox_0.SizeMode = bitmap.Width > 100 || bitmap.Height > 100 ? PictureBoxSizeMode.Zoom : PictureBoxSizeMode.CenterImage;
    this.pictureBox_0.Image = (Image) bitmap;
    if (enum15_0.Boolean_0)
      return;
    this.comboBox_5.Items.Remove((object) \u003CModule\u003E.smethod_9<string>(3198148489U));
    this.comboBox_5.Items.Remove((object) \u003CModule\u003E.smethod_7<string>(34214993U));
    this.comboBox_5.Items.Remove((object) \u003CModule\u003E.smethod_7<string>(4027688951U));
  }

  void ContainerControl.Dispose(bool byte_2)
  {
    if (byte_2 && this.icontainer_0 != null)
      this.icontainer_0.Dispose();
    // ISSUE: explicit non-virtual call
    __nonvirtual (((ContainerControl) this).Dispose(byte_2));
  }

  private void method_0()
  {
    this.pictureBox_0 = new PictureBox();
    this.button_0 = new Button();
    this.comboBox_3 = new ComboBox();
    this.comboBox_4 = new ComboBox();
    this.groupBox_2 = new GroupBox();
    this.checkBox_10 = new CheckBox();
    this.comboBox_2 = new ComboBox();
    this.checkBox_12 = new CheckBox();
    this.checkBox_11 = new CheckBox();
    this.radioButton_5 = new RadioButton();
    this.radioButton_3 = new RadioButton();
    this.radioButton_1 = new RadioButton();
    this.radioButton_0 = new RadioButton();
    this.radioButton_2 = new RadioButton();
    this.label_0 = new Label();
    this.radioButton_4 = new RadioButton();
    this.label_3 = new Label();
    this.groupBox_3 = new GroupBox();
    this.label_4 = new Label();
    this.checkBox_14 = new CheckBox();
    this.checkBox_15 = new CheckBox();
    this.comboBox_5 = new ComboBox();
    this.checkBox_13 = new CheckBox();
    this.groupBox_0 = new GroupBox();
    this.checkBox_1 = new CheckBox();
    this.comboBox_1 = new ComboBox();
    this.comboBox_0 = new ComboBox();
    this.checkBox_0 = new CheckBox();
    this.groupBox_5 = new GroupBox();
    this.checkBox_9 = new CheckBox();
    this.checkBox_8 = new CheckBox();
    this.button_3 = new Button();
    this.button_4 = new Button();
    this.textBox_1 = new TextBox();
    this.listBox_1 = new ListBox();
    this.groupBox_1 = new GroupBox();
    this.checkBox_7 = new CheckBox();
    this.panel_1 = new Panel();
    this.panel_2 = new Panel();
    this.panel_0 = new Panel();
    this.checkBox_4 = new CheckBox();
    this.checkBox_3 = new CheckBox();
    this.checkBox_5 = new CheckBox();
    this.label_1 = new Label();
    this.numericUpDown_0 = new NumericUpDown();
    this.label_2 = new Label();
    this.groupBox_4 = new GroupBox();
    this.checkBox_2 = new CheckBox();
    this.button_1 = new Button();
    this.button_2 = new Button();
    this.textBox_0 = new TextBox();
    this.listBox_0 = new ListBox();
    this.checkBox_6 = new CheckBox();
    ((ISupportInitialize) this.pictureBox_0).BeginInit();
    this.groupBox_2.SuspendLayout();
    this.groupBox_3.SuspendLayout();
    this.groupBox_0.SuspendLayout();
    this.groupBox_5.SuspendLayout();
    this.groupBox_1.SuspendLayout();
    this.panel_1.SuspendLayout();
    this.panel_2.SuspendLayout();
    this.panel_0.SuspendLayout();
    this.numericUpDown_0.BeginInit();
    this.groupBox_4.SuspendLayout();
    this.SuspendLayout();
    this.pictureBox_0.Location = new Point(114, 111);
    this.pictureBox_0.Name = \u003CModule\u003E.smethod_5<string>(867561965U);
    this.pictureBox_0.Size = new Size(195, 179);
    this.pictureBox_0.SizeMode = PictureBoxSizeMode.CenterImage;
    this.pictureBox_0.TabIndex = 5;
    this.pictureBox_0.TabStop = false;
    this.button_0.FlatStyle = FlatStyle.Flat;
    this.button_0.Location = new Point(389, 74);
    this.button_0.Name = \u003CModule\u003E.smethod_9<string>(2306479235U);
    this.button_0.Size = new Size(75, 23);
    this.button_0.TabIndex = 9;
    this.button_0.Text = \u003CModule\u003E.smethod_7<string>(2102264431U);
    this.button_0.UseVisualStyleBackColor = true;
    this.button_0.Click += new EventHandler(this.button_0_Click);
    this.comboBox_3.ForeColor = Color.Black;
    this.comboBox_3.FormattingEnabled = true;
    this.comboBox_3.Items.AddRange(new object[7]
    {
      (object) \u003CModule\u003E.smethod_5<string>(2108762653U),
      (object) \u003CModule\u003E.smethod_5<string>(719956569U),
      (object) \u003CModule\u003E.smethod_8<string>(1447988461U),
      (object) \u003CModule\u003E.smethod_9<string>(3547106019U),
      (object) \u003CModule\u003E.smethod_7<string>(1375192363U),
      (object) \u003CModule\u003E.smethod_7<string>(1648876412U),
      (object) \u003CModule\u003E.smethod_6<string>(2947199660U)
    });
    this.comboBox_3.Location = new Point(48, 33);
    this.comboBox_3.Name = \u003CModule\u003E.smethod_7<string>(3993455544U);
    this.comboBox_3.Size = new Size(121, 21);
    this.comboBox_3.TabIndex = 10;
    this.comboBox_3.Text = \u003CModule\u003E.smethod_5<string>(2108762653U);
    this.comboBox_4.ForeColor = Color.Black;
    this.comboBox_4.FormattingEnabled = true;
    this.comboBox_4.Items.AddRange(new object[4]
    {
      (object) \u003CModule\u003E.smethod_9<string>(947718200U),
      (object) \u003CModule\u003E.smethod_5<string>(1684074399U),
      (object) \u003CModule\u003E.smethod_5<string>(295268315U),
      (object) \u003CModule\u003E.smethod_9<string>(516336862U)
    });
    this.comboBox_4.Location = new Point(48, 83);
    this.comboBox_4.Name = \u003CModule\u003E.smethod_7<string>(2379343746U);
    this.comboBox_4.Size = new Size(121, 21);
    this.comboBox_4.TabIndex = 11;
    this.comboBox_4.Text = \u003CModule\u003E.smethod_6<string>(3728579786U);
    this.groupBox_2.Controls.Add((Control) this.checkBox_10);
    this.groupBox_2.Controls.Add((Control) this.comboBox_4);
    this.groupBox_2.Controls.Add((Control) this.comboBox_2);
    this.groupBox_2.Controls.Add((Control) this.checkBox_12);
    this.groupBox_2.Controls.Add((Control) this.checkBox_11);
    this.groupBox_2.Controls.Add((Control) this.comboBox_3);
    this.groupBox_2.Location = new Point(321, 111);
    this.groupBox_2.Name = \u003CModule\u003E.smethod_8<string>(4063445273U);
    this.groupBox_2.Size = new Size(186, 180);
    this.groupBox_2.TabIndex = 12;
    this.groupBox_2.TabStop = false;
    this.groupBox_2.Text = \u003CModule\u003E.smethod_5<string>(3275696434U);
    this.checkBox_10.AutoSize = true;
    this.checkBox_10.Location = new Point(20, 136);
    this.checkBox_10.Name = \u003CModule\u003E.smethod_6<string>(71474732U);
    this.checkBox_10.Size = new Size(15, 14);
    this.checkBox_10.TabIndex = 13;
    this.checkBox_10.UseVisualStyleBackColor = true;
    this.comboBox_2.ForeColor = Color.Black;
    this.comboBox_2.FormattingEnabled = true;
    this.comboBox_2.Items.AddRange(new object[4]
    {
      (object) \u003CModule\u003E.smethod_7<string>(2217996095U),
      (object) \u003CModule\u003E.smethod_9<string>(340015110U),
      (object) \u003CModule\u003E.smethod_5<string>(4271245045U),
      (object) \u003CModule\u003E.smethod_9<string>(1026456034U)
    });
    this.comboBox_2.Location = new Point(48, 133);
    this.comboBox_2.Name = \u003CModule\u003E.smethod_5<string>(1091331770U);
    this.comboBox_2.Size = new Size(121, 21);
    this.comboBox_2.TabIndex = 11;
    this.comboBox_2.Text = \u003CModule\u003E.smethod_8<string>(12899241U);
    this.checkBox_12.AutoSize = true;
    this.checkBox_12.Location = new Point(20, 86);
    this.checkBox_12.Name = \u003CModule\u003E.smethod_6<string>(4212772312U);
    this.checkBox_12.Size = new Size(15, 14);
    this.checkBox_12.TabIndex = 13;
    this.checkBox_12.UseVisualStyleBackColor = true;
    this.checkBox_11.AutoSize = true;
    this.checkBox_11.Location = new Point(20, 36);
    this.checkBox_11.Name = \u003CModule\u003E.smethod_5<string>(236242423U);
    this.checkBox_11.Size = new Size(15, 14);
    this.checkBox_11.TabIndex = 12;
    this.checkBox_11.UseVisualStyleBackColor = true;
    this.radioButton_5.AutoSize = true;
    this.radioButton_5.Location = new Point(45, 27);
    this.radioButton_5.Name = \u003CModule\u003E.smethod_5<string>(2351588810U);
    this.radioButton_5.Size = new Size(94, 17);
    this.radioButton_5.TabIndex = 16;
    this.radioButton_5.Text = \u003CModule\u003E.smethod_5<string>(3740394894U);
    this.radioButton_5.UseVisualStyleBackColor = true;
    this.radioButton_3.AutoSize = true;
    this.radioButton_3.Checked = true;
    this.radioButton_3.Location = new Point(45, 7);
    this.radioButton_3.Name = \u003CModule\u003E.smethod_6<string>(48035037U);
    this.radioButton_3.Size = new Size(79, 17);
    this.radioButton_3.TabIndex = 15;
    this.radioButton_3.TabStop = true;
    this.radioButton_3.Text = \u003CModule\u003E.smethod_9<string>(2130157483U);
    this.radioButton_3.UseVisualStyleBackColor = true;
    this.radioButton_1.AutoSize = true;
    this.radioButton_1.Location = new Point(107, 8);
    this.radioButton_1.Name = \u003CModule\u003E.smethod_6<string>(1704554069U);
    this.radioButton_1.Size = new Size(42, 17);
    this.radioButton_1.TabIndex = 15;
    this.radioButton_1.Text = \u003CModule\u003E.smethod_5<string>(1328909297U);
    this.radioButton_1.UseVisualStyleBackColor = true;
    this.radioButton_0.AutoSize = true;
    this.radioButton_0.Checked = true;
    this.radioButton_0.Location = new Point(45, 7);
    this.radioButton_0.Name = \u003CModule\u003E.smethod_6<string>(3775202859U);
    this.radioButton_0.Size = new Size(54, 17);
    this.radioButton_0.TabIndex = 16;
    this.radioButton_0.TabStop = true;
    this.radioButton_0.Text = \u003CModule\u003E.smethod_7<string>(1424570030U);
    this.radioButton_0.UseMnemonic = false;
    this.radioButton_0.UseVisualStyleBackColor = true;
    this.radioButton_2.AutoSize = true;
    this.radioButton_2.Location = new Point(107, 2);
    this.radioButton_2.Name = \u003CModule\u003E.smethod_6<string>(1136754595U);
    this.radioButton_2.Size = new Size(57, 17);
    this.radioButton_2.TabIndex = 19;
    this.radioButton_2.Text = \u003CModule\u003E.smethod_6<string>(2663043606U);
    this.radioButton_2.UseMnemonic = false;
    this.radioButton_2.UseVisualStyleBackColor = true;
    this.label_0.AutoSize = true;
    this.label_0.Location = new Point(3, 4);
    this.label_0.Name = \u003CModule\u003E.smethod_7<string>(3340358373U);
    this.label_0.Size = new Size(32, 13);
    this.label_0.TabIndex = 17;
    this.label_0.Text = \u003CModule\u003E.smethod_6<string>(1965014111U);
    this.radioButton_4.AutoSize = true;
    this.radioButton_4.Checked = true;
    this.radioButton_4.Location = new Point(45, 2);
    this.radioButton_4.Name = \u003CModule\u003E.smethod_5<string>(1798351512U);
    this.radioButton_4.Size = new Size(50, 17);
    this.radioButton_4.TabIndex = 18;
    this.radioButton_4.TabStop = true;
    this.radioButton_4.Text = \u003CModule\u003E.smethod_6<string>(3621533143U);
    this.radioButton_4.UseVisualStyleBackColor = true;
    this.label_3.AutoSize = true;
    this.label_3.Location = new Point(3, 9);
    this.label_3.Name = \u003CModule\u003E.smethod_9<string>(2355271194U);
    this.label_3.Size = new Size(32, 13);
    this.label_3.TabIndex = 15;
    this.label_3.Text = \u003CModule\u003E.smethod_7<string>(112134777U);
    this.groupBox_3.Controls.Add((Control) this.label_4);
    this.groupBox_3.Controls.Add((Control) this.checkBox_14);
    this.groupBox_3.Controls.Add((Control) this.checkBox_15);
    this.groupBox_3.Controls.Add((Control) this.comboBox_5);
    this.groupBox_3.Controls.Add((Control) this.checkBox_13);
    this.groupBox_3.Location = new Point(321, 297);
    this.groupBox_3.Name = \u003CModule\u003E.smethod_5<string>(943262165U);
    this.groupBox_3.Size = new Size(186, 80);
    this.groupBox_3.TabIndex = 17;
    this.groupBox_3.TabStop = false;
    this.groupBox_3.Text = \u003CModule\u003E.smethod_8<string>(3075806552U);
    this.label_4.AutoSize = true;
    this.label_4.Location = new Point(6, 50);
    this.label_4.Name = \u003CModule\u003E.smethod_8<string>(3849475061U);
    this.label_4.Size = new Size(42, 13);
    this.label_4.TabIndex = 21;
    this.label_4.Text = \u003CModule\u003E.smethod_7<string>(1670261583U);
    this.checkBox_14.AutoSize = true;
    this.checkBox_14.Location = new Point(54, 49);
    this.checkBox_14.Name = \u003CModule\u003E.smethod_8<string>(2248645490U);
    this.checkBox_14.Size = new Size(62, 17);
    this.checkBox_14.TabIndex = 20;
    this.checkBox_14.Text = \u003CModule\u003E.smethod_6<string>(2900063953U);
    this.checkBox_14.UseVisualStyleBackColor = true;
    this.checkBox_15.AutoSize = true;
    this.checkBox_15.Location = new Point(119, 49);
    this.checkBox_15.Name = \u003CModule\u003E.smethod_5<string>(2865784986U);
    this.checkBox_15.Size = new Size(61, 17);
    this.checkBox_15.TabIndex = 19;
    this.checkBox_15.Text = \u003CModule\u003E.smethod_6<string>(3087581513U);
    this.checkBox_15.UseVisualStyleBackColor = true;
    this.comboBox_5.ForeColor = Color.Black;
    this.comboBox_5.FormattingEnabled = true;
    this.comboBox_5.Items.AddRange(new object[4]
    {
      (object) \u003CModule\u003E.smethod_6<string>(1754484051U),
      (object) \u003CModule\u003E.smethod_6<string>(3947150915U),
      (object) \u003CModule\u003E.smethod_9<string>(2511707565U),
      (object) \u003CModule\u003E.smethod_9<string>(3540731499U)
    });
    this.comboBox_5.Location = new Point(48, 21);
    this.comboBox_5.Name = \u003CModule\u003E.smethod_5<string>(2840551586U);
    this.comboBox_5.Size = new Size(121, 21);
    this.comboBox_5.TabIndex = 20;
    this.comboBox_5.Text = \u003CModule\u003E.smethod_5<string>(2523922731U);
    this.checkBox_13.AutoSize = true;
    this.checkBox_13.Location = new Point(20, 24);
    this.checkBox_13.Name = \u003CModule\u003E.smethod_9<string>(1552400268U);
    this.checkBox_13.Size = new Size(15, 14);
    this.checkBox_13.TabIndex = 19;
    this.checkBox_13.UseVisualStyleBackColor = true;
    this.groupBox_0.Controls.Add((Control) this.checkBox_1);
    this.groupBox_0.Controls.Add((Control) this.comboBox_1);
    this.groupBox_0.Controls.Add((Control) this.comboBox_0);
    this.groupBox_0.Controls.Add((Control) this.checkBox_0);
    this.groupBox_0.Location = new Point(530, 297);
    this.groupBox_0.Name = \u003CModule\u003E.smethod_8<string>(249910954U);
    this.groupBox_0.Size = new Size(186, 80);
    this.groupBox_0.TabIndex = 18;
    this.groupBox_0.TabStop = false;
    this.groupBox_0.Text = \u003CModule\u003E.smethod_6<string>(2105652281U);
    this.checkBox_1.AutoSize = true;
    this.checkBox_1.Location = new Point(20, 51);
    this.checkBox_1.Name = \u003CModule\u003E.smethod_8<string>(436477053U);
    this.checkBox_1.Size = new Size(15, 14);
    this.checkBox_1.TabIndex = 24;
    this.checkBox_1.UseVisualStyleBackColor = true;
    this.comboBox_1.ForeColor = Color.Black;
    this.comboBox_1.FormattingEnabled = true;
    this.comboBox_1.Items.AddRange(new object[7]
    {
      (object) \u003CModule\u003E.smethod_8<string>(2373824998U),
      (object) \u003CModule\u003E.smethod_7<string>(3324664492U),
      (object) \u003CModule\u003E.smethod_8<string>(4161220668U),
      (object) \u003CModule\u003E.smethod_6<string>(629122374U),
      (object) \u003CModule\u003E.smethod_8<string>(292878123U),
      (object) \u003CModule\u003E.smethod_9<string>(1048988092U),
      (object) \u003CModule\u003E.smethod_9<string>(4222447152U)
    });
    this.comboBox_1.Location = new Point(48, 48);
    this.comboBox_1.Name = \u003CModule\u003E.smethod_9<string>(2670222530U);
    this.comboBox_1.Size = new Size(121, 21);
    this.comboBox_1.TabIndex = 23;
    this.comboBox_1.Text = \u003CModule\u003E.smethod_7<string>(3872032590U);
    this.comboBox_0.ForeColor = Color.Black;
    this.comboBox_0.FormattingEnabled = true;
    this.comboBox_0.Items.AddRange(new object[13]
    {
      (object) \u003CModule\u003E.smethod_9<string>(3229133661U),
      (object) \u003CModule\u003E.smethod_6<string>(1496134772U),
      (object) \u003CModule\u003E.smethod_5<string>(1928798058U),
      (object) \u003CModule\u003E.smethod_6<string>(1626364793U),
      (object) \u003CModule\u003E.smethod_7<string>(3601194186U),
      (object) \u003CModule\u003E.smethod_9<string>(2849565304U),
      (object) \u003CModule\u003E.smethod_9<string>(1251569745U),
      (object) \u003CModule\u003E.smethod_8<string>(4082955348U),
      (object) \u003CModule\u003E.smethod_7<string>(1704311783U),
      (object) \u003CModule\u003E.smethod_6<string>(3064141818U),
      (object) \u003CModule\u003E.smethod_5<string>(1001823848U),
      (object) \u003CModule\u003E.smethod_9<string>(2163124380U),
      (object) \u003CModule\u003E.smethod_9<string>(356879469U)
    });
    this.comboBox_0.Location = new Point(48, 21);
    this.comboBox_0.Name = \u003CModule\u003E.smethod_7<string>(1552050688U);
    this.comboBox_0.Size = new Size(121, 21);
    this.comboBox_0.TabIndex = 22;
    this.comboBox_0.Text = \u003CModule\u003E.smethod_5<string>(3245719279U);
    this.checkBox_0.AutoSize = true;
    this.checkBox_0.Location = new Point(20, 24);
    this.checkBox_0.Name = \u003CModule\u003E.smethod_5<string>(1599815107U);
    this.checkBox_0.Size = new Size(15, 14);
    this.checkBox_0.TabIndex = 21;
    this.checkBox_0.UseVisualStyleBackColor = true;
    this.groupBox_5.Controls.Add((Control) this.checkBox_9);
    this.groupBox_5.Controls.Add((Control) this.checkBox_8);
    this.groupBox_5.Controls.Add((Control) this.button_3);
    this.groupBox_5.Controls.Add((Control) this.button_4);
    this.groupBox_5.Controls.Add((Control) this.textBox_1);
    this.groupBox_5.Controls.Add((Control) this.listBox_1);
    this.groupBox_5.Location = new Point(139, 111);
    this.groupBox_5.Name = \u003CModule\u003E.smethod_9<string>(3196668U);
    this.groupBox_5.Size = new Size(159, 164);
    this.groupBox_5.TabIndex = 19;
    this.groupBox_5.TabStop = false;
    this.groupBox_5.Text = \u003CModule\u003E.smethod_9<string>(1934989647U);
    this.groupBox_5.Visible = false;
    this.checkBox_9.AutoSize = true;
    this.checkBox_9.Location = new Point(81, 44);
    this.checkBox_9.Name = \u003CModule\u003E.smethod_8<string>(2890556126U);
    this.checkBox_9.Size = new Size(50, 17);
    this.checkBox_9.TabIndex = 5;
    this.checkBox_9.Text = \u003CModule\u003E.smethod_6<string>(2626572365U);
    this.checkBox_9.UseVisualStyleBackColor = true;
    this.checkBox_8.AutoSize = true;
    this.checkBox_8.Location = new Point(81, 21);
    this.checkBox_8.Name = \u003CModule\u003E.smethod_7<string>(4155169609U);
    this.checkBox_8.Size = new Size(71, 17);
    this.checkBox_8.TabIndex = 4;
    this.checkBox_8.Text = \u003CModule\u003E.smethod_8<string>(809609251U);
    this.checkBox_8.UseVisualStyleBackColor = true;
    this.button_3.FlatStyle = FlatStyle.Flat;
    this.button_3.Location = new Point(81, 135);
    this.button_3.Name = \u003CModule\u003E.smethod_8<string>(569550599U);
    this.button_3.Size = new Size(71, 22);
    this.button_3.TabIndex = 3;
    this.button_3.Text = \u003CModule\u003E.smethod_5<string>(3013834258U);
    this.button_3.UseVisualStyleBackColor = true;
    this.button_3.Click += new EventHandler(this.button_3_Click);
    this.button_4.FlatStyle = FlatStyle.Flat;
    this.button_4.Location = new Point(81, 83);
    this.button_4.Name = \u003CModule\u003E.smethod_8<string>(1236234002U);
    this.button_4.Size = new Size(71, 46);
    this.button_4.TabIndex = 2;
    this.button_4.Text = \u003CModule\u003E.smethod_5<string>(538074139U);
    this.button_4.UseVisualStyleBackColor = true;
    this.button_4.Click += new EventHandler(this.button_4_Click);
    this.textBox_1.Location = new Point(6, 135);
    this.textBox_1.Name = \u003CModule\u003E.smethod_9<string>(277102338U);
    this.textBox_1.Size = new Size(69, 22);
    this.textBox_1.TabIndex = 1;
    this.textBox_1.KeyPress += new KeyPressEventHandler(this.textBox_1_KeyPress);
    this.listBox_1.FormattingEnabled = true;
    this.listBox_1.Location = new Point(6, 21);
    this.listBox_1.Name = \u003CModule\u003E.smethod_7<string>(1747998160U);
    this.listBox_1.SelectionMode = SelectionMode.MultiSimple;
    this.listBox_1.Size = new Size(69, 108);
    this.listBox_1.TabIndex = 0;
    this.groupBox_1.Controls.Add((Control) this.checkBox_7);
    this.groupBox_1.Controls.Add((Control) this.panel_1);
    this.groupBox_1.Controls.Add((Control) this.panel_2);
    this.groupBox_1.Controls.Add((Control) this.panel_0);
    this.groupBox_1.Location = new Point(530, 111);
    this.groupBox_1.Name = \u003CModule\u003E.smethod_6<string>(3845521944U);
    this.groupBox_1.Size = new Size(186, 180);
    this.groupBox_1.TabIndex = 20;
    this.groupBox_1.TabStop = false;
    this.groupBox_1.Text = \u003CModule\u003E.smethod_5<string>(3532794522U);
    this.checkBox_7.AutoSize = true;
    this.checkBox_7.Location = new Point(51, 90);
    this.checkBox_7.Name = \u003CModule\u003E.smethod_9<string>(3405455413U);
    this.checkBox_7.Size = new Size(90, 17);
    this.checkBox_7.TabIndex = 25;
    this.checkBox_7.Text = \u003CModule\u003E.smethod_7<string>(2211388770U);
    this.checkBox_7.UseVisualStyleBackColor = true;
    this.panel_1.Controls.Add((Control) this.radioButton_1);
    this.panel_1.Controls.Add((Control) this.radioButton_0);
    this.panel_1.Controls.Add((Control) this.label_3);
    this.panel_1.Location = new Point(6, 50);
    this.panel_1.Name = \u003CModule\u003E.smethod_7<string>(1446321615U);
    this.panel_1.Size = new Size(174, 30);
    this.panel_1.TabIndex = 24;
    this.panel_2.Controls.Add((Control) this.radioButton_5);
    this.panel_2.Controls.Add((Control) this.radioButton_3);
    this.panel_2.Location = new Point(6, 120);
    this.panel_2.Name = \u003CModule\u003E.smethod_5<string>(3695640933U);
    this.panel_2.Size = new Size(174, 54);
    this.panel_2.TabIndex = 23;
    this.panel_0.Controls.Add((Control) this.radioButton_2);
    this.panel_0.Controls.Add((Control) this.radioButton_4);
    this.panel_0.Controls.Add((Control) this.label_0);
    this.panel_0.Location = new Point(6, 21);
    this.panel_0.Name = \u003CModule\u003E.smethod_7<string>(3579809015U);
    this.panel_0.Size = new Size(174, 29);
    this.panel_0.TabIndex = 21;
    this.checkBox_4.AutoSize = true;
    this.checkBox_4.Location = new Point(550, 383);
    this.checkBox_4.Name = \u003CModule\u003E.smethod_9<string>(3836836751U);
    this.checkBox_4.Size = new Size(152, 17);
    this.checkBox_4.TabIndex = 25;
    this.checkBox_4.Text = \u003CModule\u003E.smethod_9<string>(3653808003U);
    this.checkBox_4.UseVisualStyleBackColor = true;
    this.checkBox_3.AutoSize = true;
    this.checkBox_3.Location = new Point(550, 429);
    this.checkBox_3.Name = \u003CModule\u003E.smethod_9<string>(2408455948U);
    this.checkBox_3.Size = new Size(146, 17);
    this.checkBox_3.TabIndex = 26;
    this.checkBox_3.Text = \u003CModule\u003E.smethod_6<string>(298086930U);
    this.checkBox_3.UseVisualStyleBackColor = true;
    this.checkBox_3.Visible = false;
    this.checkBox_5.AutoSize = true;
    this.checkBox_5.Location = new Point(550, 452);
    this.checkBox_5.Name = \u003CModule\u003E.smethod_9<string>(2153396362U);
    this.checkBox_5.Size = new Size(173, 17);
    this.checkBox_5.TabIndex = 27;
    this.checkBox_5.Text = \u003CModule\u003E.smethod_8<string>(681798397U);
    this.checkBox_5.UseVisualStyleBackColor = true;
    this.label_1.AutoSize = true;
    this.label_1.Location = new Point(327, 387);
    this.label_1.Name = \u003CModule\u003E.smethod_6<string>(3611124994U);
    this.label_1.Size = new Size(110, 13);
    this.label_1.TabIndex = 28;
    this.label_1.Text = \u003CModule\u003E.smethod_8<string>(1882091657U);
    this.numericUpDown_0.Location = new Point(450, 382);
    this.numericUpDown_0.Maximum = new Decimal(new int[4]
    {
      5,
      0,
      0,
      0
    });
    this.numericUpDown_0.Name = \u003CModule\u003E.smethod_8<string>(2655760166U);
    this.numericUpDown_0.Size = new Size(40, 22);
    this.numericUpDown_0.TabIndex = 29;
    this.label_2.AutoSize = true;
    this.label_2.Location = new Point(414, 410);
    this.label_2.Name = \u003CModule\u003E.smethod_8<string>(1161915701U);
    this.label_2.Size = new Size(76, 13);
    this.label_2.TabIndex = 30;
    this.label_2.Text = \u003CModule\u003E.smethod_8<string>(1828599104U);
    this.groupBox_4.Controls.Add((Control) this.checkBox_2);
    this.groupBox_4.Controls.Add((Control) this.button_1);
    this.groupBox_4.Controls.Add((Control) this.button_2);
    this.groupBox_4.Controls.Add((Control) this.textBox_0);
    this.groupBox_4.Controls.Add((Control) this.listBox_0);
    this.groupBox_4.Location = new Point(139, 297);
    this.groupBox_4.Name = \u003CModule\u003E.smethod_8<string>(334754639U);
    this.groupBox_4.Size = new Size(159, 163);
    this.groupBox_4.TabIndex = 31;
    this.groupBox_4.TabStop = false;
    this.groupBox_4.Text = \u003CModule\u003E.smethod_5<string>(3248101323U);
    this.groupBox_4.Visible = false;
    this.checkBox_2.AutoSize = true;
    this.checkBox_2.Location = new Point(81, 21);
    this.checkBox_2.Name = \u003CModule\u003E.smethod_9<string>(4036397382U);
    this.checkBox_2.Size = new Size(60, 17);
    this.checkBox_2.TabIndex = 10;
    this.checkBox_2.Text = \u003CModule\u003E.smethod_5<string>(3248101323U);
    this.checkBox_2.UseVisualStyleBackColor = true;
    this.button_1.FlatStyle = FlatStyle.Flat;
    this.button_1.Location = new Point(81, 135);
    this.button_1.Name = \u003CModule\u003E.smethod_6<string>(3717915320U);
    this.button_1.Size = new Size(71, 22);
    this.button_1.TabIndex = 9;
    this.button_1.Text = \u003CModule\u003E.smethod_6<string>(3059407658U);
    this.button_1.UseVisualStyleBackColor = true;
    this.button_1.Click += new EventHandler(this.button_1_Click);
    this.button_2.FlatStyle = FlatStyle.Flat;
    this.button_2.Location = new Point(81, 83);
    this.button_2.Name = \u003CModule\u003E.smethod_8<string>(2548775060U);
    this.button_2.Size = new Size(71, 46);
    this.button_2.TabIndex = 8;
    this.button_2.Text = \u003CModule\u003E.smethod_6<string>(1379448931U);
    this.button_2.UseVisualStyleBackColor = true;
    this.button_2.Click += new EventHandler(this.button_2_Click);
    this.textBox_0.Location = new Point(6, 135);
    this.textBox_0.Name = \u003CModule\u003E.smethod_5<string>(3016236635U);
    this.textBox_0.Size = new Size(69, 22);
    this.textBox_0.TabIndex = 7;
    this.textBox_0.KeyPress += new KeyPressEventHandler(this.textBox_0_KeyPress);
    this.listBox_0.FormattingEnabled = true;
    this.listBox_0.Location = new Point(6, 21);
    this.listBox_0.Name = \u003CModule\u003E.smethod_7<string>(1769749745U);
    this.listBox_0.SelectionMode = SelectionMode.MultiSimple;
    this.listBox_0.Size = new Size(69, 108);
    this.listBox_0.TabIndex = 6;
    this.checkBox_6.AutoSize = true;
    this.checkBox_6.Location = new Point(550, 406);
    this.checkBox_6.Name = \u003CModule\u003E.smethod_6<string>(4262275099U);
    this.checkBox_6.Size = new Size(135, 17);
    this.checkBox_6.TabIndex = 32;
    this.checkBox_6.Text = \u003CModule\u003E.smethod_6<string>(3434015583U);
    this.checkBox_6.UseVisualStyleBackColor = true;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.BackColor = Color.White;
    this.Controls.Add((Control) this.checkBox_6);
    this.Controls.Add((Control) this.groupBox_4);
    this.Controls.Add((Control) this.label_2);
    this.Controls.Add((Control) this.numericUpDown_0);
    this.Controls.Add((Control) this.label_1);
    this.Controls.Add((Control) this.checkBox_3);
    this.Controls.Add((Control) this.checkBox_4);
    this.Controls.Add((Control) this.checkBox_5);
    this.Controls.Add((Control) this.groupBox_1);
    this.Controls.Add((Control) this.groupBox_5);
    this.Controls.Add((Control) this.groupBox_0);
    this.Controls.Add((Control) this.groupBox_3);
    this.Controls.Add((Control) this.groupBox_2);
    this.Controls.Add((Control) this.button_0);
    this.Controls.Add((Control) this.pictureBox_0);
    this.DoubleBuffered = true;
    this.Font = new Font(\u003CModule\u003E.smethod_9<string>(868744759U), 8.25f);
    this.ForeColor = Color.Black;
    this.Name = \u003CModule\u003E.smethod_7<string>(183630443U);
    this.Size = new Size(838, 492);
    ((ISupportInitialize) this.pictureBox_0).EndInit();
    this.groupBox_2.ResumeLayout(false);
    this.groupBox_2.PerformLayout();
    this.groupBox_3.ResumeLayout(false);
    this.groupBox_3.PerformLayout();
    this.groupBox_0.ResumeLayout(false);
    this.groupBox_0.PerformLayout();
    this.groupBox_5.ResumeLayout(false);
    this.groupBox_5.PerformLayout();
    this.groupBox_1.ResumeLayout(false);
    this.groupBox_1.PerformLayout();
    this.panel_1.ResumeLayout(false);
    this.panel_1.PerformLayout();
    this.panel_2.ResumeLayout(false);
    this.panel_2.PerformLayout();
    this.panel_0.ResumeLayout(false);
    this.panel_0.PerformLayout();
    this.numericUpDown_0.EndInit();
    this.groupBox_4.ResumeLayout(false);
    this.groupBox_4.PerformLayout();
    this.ResumeLayout(false);
    this.PerformLayout();
  }

  internal void button_0_Click(object int_1, [In] EventArgs obj1)
  {
    foreach (Class177 class177 in new List<Class177>((IEnumerable<Class177>) this.class29_0.Class26_0.method_3()))
    {
      if (class177.Control4_0 == this)
        this.class29_0.Class26_0.method_40(class177.UInt16_0.ToString());
    }
    if (((object) this.class177_0).ToString() == \u003CModule\u003E.smethod_5<string>(2588197253U))
    {
      this.class29_0.Class26_0.control4_0 = (Control4) null;
      this.class29_0.Control2_0.tabControl_0.TabPages.Add(this.class29_0.Control2_0.tabPage_8);
    }
    this.Parent.Dispose();
    this.class29_0.method_105(false);
  }

  private void button_3_Click(object timeSpan_0, [In] EventArgs obj1)
  {
    ushort result;
    if (ushort.TryParse(this.textBox_1.Text, out result) && result >= (ushort) 1 && result <= (ushort) 1000)
    {
      if (this.listBox_1.Items.Contains((object) result.ToString()))
      {
        int num = (int) Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_6<string>(3694475625U), (IWin32Window) null, true);
        this.textBox_1.Clear();
      }
      else
      {
        this.listBox_1.Items.Add((object) result.ToString());
        this.textBox_1.Clear();
      }
    }
    else
    {
      int num = (int) Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_9<string>(2865861580U), (IWin32Window) null, true);
      this.textBox_1.Clear();
    }
  }

  private void button_4_Click(object sbyte_0, [In] EventArgs obj1)
  {
    while (this.listBox_1.SelectedItems.Count > 0)
      this.listBox_1.Items.RemoveAt(this.listBox_1.SelectedIndex);
  }

  private void button_1_Click(object short_0, [In] EventArgs obj1)
  {
    ushort result;
    if (ushort.TryParse(this.textBox_0.Text, out result) && result >= (ushort) 1 && result <= (ushort) 1000)
    {
      if (this.listBox_1.Items.Contains((object) result.ToString()))
      {
        int num = (int) Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_7<string>(1194389151U), (IWin32Window) null, true);
        this.textBox_0.Clear();
      }
      else
      {
        this.listBox_0.Items.Add((object) result.ToString());
        this.textBox_0.Clear();
      }
    }
    else
    {
      int num = (int) Form1.smethod_0(this.class29_0.Class112_0.form5_0, \u003CModule\u003E.smethod_7<string>(1752126254U), (IWin32Window) null, true);
      this.textBox_0.Clear();
    }
  }

  private void button_2_Click(object int_1, [In] EventArgs obj1)
  {
    while (this.listBox_0.SelectedItems.Count > 0)
      this.listBox_0.Items.RemoveAt(this.listBox_0.SelectedIndex);
  }

  private void textBox_1_KeyPress(object long_0, [In] KeyPressEventArgs obj1)
  {
    if (obj1.KeyChar != '\r')
      return;
    this.button_3.PerformClick();
    obj1.Handled = true;
  }

  private void textBox_0_KeyPress(object string_0, KeyPressEventArgs bool_0 = false)
  {
    if (bool_0.KeyChar != '\r')
      return;
    this.button_1.PerformClick();
    bool_0.Handled = true;
  }
}
