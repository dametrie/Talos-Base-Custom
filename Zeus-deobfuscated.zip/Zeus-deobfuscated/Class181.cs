﻿// Decompiled with JetBrains decompiler
// Type: Class181
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[CompilerGenerated]
internal sealed class Class181
{
  internal static uint smethod_0(string class0_0)
  {
    uint num;
    if (class0_0 != null)
    {
      num = 2166136261U;
      for (int index = 0; index < class0_0.Length; ++index)
        num = (uint) (((int) class0_0[index] ^ (int) num) * 16777619);
    }
    return num;
  }

  [StructLayout(LayoutKind.Explicit, Size = 5, Pack = 1)]
  private struct Struct20
  {
  }

  [StructLayout(LayoutKind.Explicit, Size = 14, Pack = 1)]
  private struct Struct21
  {
  }

  [StructLayout(LayoutKind.Explicit, Size = 256, Pack = 1)]
  private struct Struct22
  {
  }

  [StructLayout(LayoutKind.Explicit, Size = 512, Pack = 1)]
  private struct Struct23
  {
  }

  [StructLayout(LayoutKind.Explicit, Size = 1024, Pack = 1)]
  private struct Struct24
  {
  }
}
