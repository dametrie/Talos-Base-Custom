﻿// Decompiled with JetBrains decompiler
// Type: Class61
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using Accolade;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;

internal sealed class Class61
{
  private readonly List<Class19> list_0 = new List<Class19>()
  {
    new Class19(\u003CModule\u003E.smethod_6<string>(2939414908U), TemClass.Peasant, MedClass.NonMed, (byte) 1, (byte) 0, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, string.Empty, string.Empty, string.Empty, 10, \u003CModule\u003E.smethod_5<string>(3219537128U)),
    new Class19(\u003CModule\u003E.smethod_6<string>(131129351U), TemClass.Peasant, MedClass.NonMed, (byte) 1, (byte) 0, (byte) 3, (byte) 5, (byte) 3, (byte) 3, (byte) 3, string.Empty, string.Empty, string.Empty, 1000, \u003CModule\u003E.smethod_9<string>(1010256627U)),
    new Class19(\u003CModule\u003E.smethod_8<string>(3290642397U), TemClass.Warrior, MedClass.NonMed, (byte) 2, (byte) 0, (byte) 5, (byte) 3, (byte) 3, (byte) 9, (byte) 4, \u003CModule\u003E.smethod_8<string>(9402262U), string.Empty, \u003CModule\u003E.smethod_6<string>(4272426931U), 500, \u003CModule\u003E.smethod_7<string>(605630700U)),
    new Class19(\u003CModule\u003E.smethod_8<string>(195968361U), TemClass.Wizard, MedClass.NonMed, (byte) 1, (byte) 0, (byte) 3, (byte) 4, (byte) 7, (byte) 3, (byte) 5, string.Empty, string.Empty, \u003CModule\u003E.smethod_7<string>(1098479462U), 1000, \u003CModule\u003E.smethod_6<string>(3988527194U)),
    new Class19(\u003CModule\u003E.smethod_8<string>(4010818353U), TemClass.Wizard, MedClass.NonMed, (byte) 4, (byte) 0, (byte) 4, (byte) 7, (byte) 18, (byte) 5, (byte) 13, \u003CModule\u003E.smethod_7<string>(1047269725U), string.Empty, \u003CModule\u003E.smethod_7<string>(2114013425U), 5000, \u003CModule\u003E.smethod_5<string>(17236706U)),
    new Class19(\u003CModule\u003E.smethod_5<string>(1939759527U), TemClass.Wizard, MedClass.NonMed, (byte) 20, (byte) 0, (byte) 13, (byte) 14, (byte) 52, (byte) 10, (byte) 24, \u003CModule\u003E.smethod_8<string>(3957325800U), string.Empty, \u003CModule\u003E.smethod_9<string>(4160241201U), 12000, \u003CModule\u003E.smethod_9<string>(3902396200U)),
    new Class19(\u003CModule\u003E.smethod_6<string>(1894438709U), TemClass.Wizard, MedClass.NonMed, (byte) 34, (byte) 0, (byte) 16, (byte) 32, (byte) 72, (byte) 16, (byte) 35, \u003CModule\u003E.smethod_8<string>(1449754174U), string.Empty, \u003CModule\u003E.smethod_7<string>(198225082U), 50000, \u003CModule\u003E.smethod_9<string>(4157455786U))
  };
  private readonly Dictionary<byte, List<string>> dictionary_0 = new Dictionary<byte, List<string>>()
  {
    {
      (byte) 1,
      new List<string>()
      {
        \u003CModule\u003E.smethod_6<string>(628609740U),
        \u003CModule\u003E.smethod_6<string>(3113388288U),
        \u003CModule\u003E.smethod_8<string>(1342769068U),
        \u003CModule\u003E.smethod_8<string>(544327792U),
        \u003CModule\u003E.smethod_5<string>(2917685079U),
        \u003CModule\u003E.smethod_9<string>(3864704032U),
        \u003CModule\u003E.smethod_6<string>(2318976616U),
        \u003CModule\u003E.smethod_8<string>(1264503748U),
        \u003CModule\u003E.smethod_5<string>(3451401816U),
        \u003CModule\u003E.smethod_5<string>(1934046688U),
        \u003CModule\u003E.smethod_6<string>(639017889U)
      }
    },
    {
      (byte) 2,
      new List<string>()
      {
        \u003CModule\u003E.smethod_6<string>(3691595911U),
        \u003CModule\u003E.smethod_7<string>(4185274922U),
        \u003CModule\u003E.smethod_8<string>(3958641473U),
        \u003CModule\u003E.smethod_9<string>(2187970639U),
        \u003CModule\u003E.smethod_8<string>(1104026089U),
        \u003CModule\u003E.smethod_7<string>(2437441555U),
        \u003CModule\u003E.smethod_9<string>(2030494971U),
        \u003CModule\u003E.smethod_8<string>(383850133U)
      }
    },
    {
      (byte) 3,
      new List<string>()
      {
        \u003CModule\u003E.smethod_6<string>(331678457U),
        \u003CModule\u003E.smethod_5<string>(589994565U),
        \u003CModule\u003E.smethod_8<string>(1344084741U),
        \u003CModule\u003E.smethod_8<string>(2010768144U)
      }
    },
    {
      (byte) 4,
      new List<string>()
      {
        \u003CModule\u003E.smethod_7<string>(3995568361U),
        \u003CModule\u003E.smethod_7<string>(493660716U),
        \u003CModule\u003E.smethod_7<string>(219976667U),
        \u003CModule\u003E.smethod_7<string>(1342705359U),
        \u003CModule\u003E.smethod_6<string>(1834527773U),
        \u003CModule\u003E.smethod_8<string>(3504612609U),
        \u003CModule\u003E.smethod_6<string>(1964757794U),
        \u003CModule\u003E.smethod_9<string>(2285554557U),
        \u003CModule\u003E.smethod_5<string>(1347481107U),
        \u003CModule\u003E.smethod_8<string>(1875063252U)
      }
    },
    {
      (byte) 5,
      new List<string>()
      {
        \u003CModule\u003E.smethod_7<string>(213735756U),
        \u003CModule\u003E.smethod_9<string>(2424184141U),
        \u003CModule\u003E.smethod_9<string>(237331576U),
        \u003CModule\u003E.smethod_6<string>(3824449329U),
        \u003CModule\u003E.smethod_5<string>(363842716U),
        \u003CModule\u003E.smethod_8<string>(2781805307U),
        \u003CModule\u003E.smethod_7<string>(705118862U),
        \u003CModule\u003E.smethod_7<string>(4179034011U)
      }
    },
    {
      (byte) 6,
      new List<string>()
      {
        \u003CModule\u003E.smethod_5<string>(3012905840U),
        \u003CModule\u003E.smethod_9<string>(1306361879U)
      }
    },
    {
      (byte) 7,
      new List<string>()
      {
        \u003CModule\u003E.smethod_6<string>(3256649855U),
        \u003CModule\u003E.smethod_5<string>(3610897099U),
        \u003CModule\u003E.smethod_7<string>(1526171009U),
        \u003CModule\u003E.smethod_8<string>(407307227U)
      }
    },
    {
      (byte) 8,
      new List<string>()
      {
        \u003CModule\u003E.smethod_7<string>(3827613385U),
        \u003CModule\u003E.smethod_8<string>(2194702897U),
        \u003CModule\u003E.smethod_9<string>(717504873U),
        \u003CModule\u003E.smethod_6<string>(2404950644U),
        \u003CModule\u003E.smethod_7<string>(3006561238U),
        \u003CModule\u003E.smethod_7<string>(2788862181U),
        \u003CModule\u003E.smethod_8<string>(2381268996U)
      }
    },
    {
      (byte) 9,
      new List<string>()
      {
        \u003CModule\u003E.smethod_6<string>(3647339918U),
        \u003CModule\u003E.smethod_6<string>(1837151170U),
        \u003CModule\u003E.smethod_5<string>(1733128239U),
        \u003CModule\u003E.smethod_9<string>(3590798362U),
        \u003CModule\u003E.smethod_8<string>(3341503604U),
        \u003CModule\u003E.smethod_8<string>(3101444952U),
        \u003CModule\u003E.smethod_7<string>(1336464448U),
        \u003CModule\u003E.smethod_6<string>(2925870728U)
      }
    },
    {
      (byte) 11,
      new List<string>()
      {
        \u003CModule\u003E.smethod_7<string>(3525936840U),
        \u003CModule\u003E.smethod_8<string>(780439425U),
        \u003CModule\u003E.smethod_8<string>(1554107934U),
        \u003CModule\u003E.smethod_9<string>(3474368360U),
        \u003CModule\u003E.smethod_7<string>(537163886U),
        \u003CModule\u003E.smethod_6<string>(1717329298U),
        \u003CModule\u003E.smethod_7<string>(1330223537U)
      }
    },
    {
      (byte) 14,
      new List<string>()
      {
        \u003CModule\u003E.smethod_6<string>(3787978088U),
        \u003CModule\u003E.smethod_5<string>(531432882U)
      }
    },
    {
      (byte) 16,
      new List<string>()
      {
        \u003CModule\u003E.smethod_7<string>(3246011880U),
        \u003CModule\u003E.smethod_5<string>(467158360U),
        \u003CModule\u003E.smethod_9<string>(1415045588U),
        \u003CModule\u003E.smethod_6<string>(3918208109U),
        \u003CModule\u003E.smethod_9<string>(1748843008U),
        \u003CModule\u003E.smethod_8<string>(1608916160U),
        \u003CModule\u003E.smethod_5<string>(3714212743U),
        \u003CModule\u003E.smethod_7<string>(3983086539U),
        \u003CModule\u003E.smethod_8<string>(1315364955U),
        \u003CModule\u003E.smethod_6<string>(13930876U)
      }
    }
  };
  private bool bool_0;
  private readonly Dictionary<string, Delegate1> dictionary_1;
  private readonly List<string> list_1 = new List<string>()
  {
    \u003CModule\u003E.smethod_8<string>(3743355588U),
    \u003CModule\u003E.smethod_6<string>(1149529824U),
    \u003CModule\u003E.smethod_6<string>(4202107846U),
    \u003CModule\u003E.smethod_9<string>(248431367U),
    \u003CModule\u003E.smethod_9<string>(1748843008U),
    \u003CModule\u003E.smethod_7<string>(2123283188U),
    \u003CModule\u003E.smethod_7<string>(3463710937U),
    \u003CModule\u003E.smethod_9<string>(3170516815U),
    \u003CModule\u003E.smethod_8<string>(1315364955U),
    \u003CModule\u003E.smethod_9<string>(2199070430U)
  };

  internal Class61()
  {
    this.dictionary_1 = new Dictionary<string, Delegate1>((IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase)
    {
      {
        \u003CModule\u003E.smethod_9<string>(2326600223U),
        new Delegate1(this.method_18)
      },
      {
        \u003CModule\u003E.smethod_5<string>(2691533230U),
        new Delegate1(this.method_19)
      },
      {
        \u003CModule\u003E.smethod_8<string>(2275599563U),
        new Delegate1(this.method_20)
      },
      {
        \u003CModule\u003E.smethod_9<string>(3748274030U),
        new Delegate1(this.method_21)
      },
      {
        \u003CModule\u003E.smethod_8<string>(1021813750U),
        new Delegate1(this.method_22)
      },
      {
        \u003CModule\u003E.smethod_7<string>(129758268U),
        new Delegate1(this.method_24)
      },
      {
        \u003CModule\u003E.smethod_7<string>(4151041515U),
        new Delegate1(this.method_25)
      },
      {
        \u003CModule\u003E.smethod_5<string>(1772169361U),
        new Delegate1(this.method_26)
      },
      {
        \u003CModule\u003E.smethod_6<string>(2759169466U),
        new Delegate1(this.method_27)
      },
      {
        \u003CModule\u003E.smethod_5<string>(3887515748U),
        new Delegate1(this.method_28)
      },
      {
        \u003CModule\u003E.smethod_9<string>(1591367340U),
        new Delegate1(this.method_11)
      },
      {
        \u003CModule\u003E.smethod_9<string>(1159986002U),
        new Delegate1(this.method_12)
      },
      {
        \u003CModule\u003E.smethod_6<string>(120721202U),
        new Delegate1(this.method_16)
      },
      {
        \u003CModule\u003E.smethod_9<string>(1718897133U),
        new Delegate1(this.method_0)
      },
      {
        \u003CModule\u003E.smethod_7<string>(2235253172U),
        new Delegate1(this.method_29)
      },
      {
        \u003CModule\u003E.smethod_5<string>(126265189U),
        new Delegate1(this.method_30)
      },
      {
        \u003CModule\u003E.smethod_7<string>(621141374U),
        new Delegate1(this.method_14)
      },
      {
        \u003CModule\u003E.smethod_9<string>(3954541657U),
        new Delegate1(this.method_13)
      },
      {
        \u003CModule\u003E.smethod_9<string>(2022748678U),
        new Delegate1(this.method_1)
      },
      {
        \u003CModule\u003E.smethod_5<string>(3163357489U),
        new Delegate1(this.method_6)
      },
      {
        \u003CModule\u003E.smethod_7<string>(2829519706U),
        new Delegate1(this.method_5)
      },
      {
        \u003CModule\u003E.smethod_9<string>(2398631061U),
        new Delegate1(this.method_4)
      },
      {
        \u003CModule\u003E.smethod_7<string>(3348895308U),
        new Delegate1(this.method_8)
      },
      {
        \u003CModule\u003E.smethod_8<string>(520870698U),
        new Delegate1(this.method_9)
      },
      {
        \u003CModule\u003E.smethod_5<string>(3761348748U),
        new Delegate1(this.method_10)
      },
      {
        \u003CModule\u003E.smethod_7<string>(1243400404U),
        new Delegate1(this.method_2)
      },
      {
        \u003CModule\u003E.smethod_8<string>(707436797U),
        new Delegate1(this.method_3)
      },
      {
        \u003CModule\u003E.smethod_7<string>(3924255902U),
        new Delegate1(this.method_31)
      },
      {
        \u003CModule\u003E.smethod_9<string>(1712190137U),
        new Delegate1(this.method_15)
      },
      {
        \u003CModule\u003E.smethod_6<string>(1303114101U),
        new Delegate1(this.method_32)
      }
    };
    this.bool_0 = false;
  }

  private void method_0([In] Class29 obj0, string string_0, string[] string_1)
  {
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_8<string>(1241046654U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_6<string>(321184869U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_5<string>(405265882U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_5<string>(3741828187U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_8<string>(3294589416U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_5<string>(3420455577U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_6<string>(4285373038U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_6<string>(3774861103U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_8<string>(601767364U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(1595760135U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_8<string>(494782258U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_7<string>(1377121973U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(1487076426U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(4184048163U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_8<string>(2655310126U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_5<string>(1813592527U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(3508707030U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_5<string>(1310822029U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_6<string>(263897330U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_5<string>(2442530025U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_6<string>(110227614U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_6<string>(1068717151U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_6<string>(2855466204U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_5<string>(307663077U));
  }

  private void method_1([In] Class29 obj0, string string_0, string[] string_1)
  {
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_8<string>(92930274U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_5<string>(1542686717U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_8<string>(1586774739U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_7<string>(4235202210U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_5<string>(1028490541U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_6<string>(1446375668U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(106448285U));
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(999156836U));
    this.bool_0 = true;
  }

  private void method_2([In] Class29 obj0, string string_0, [In] string[] obj2) => obj0.bool_41 = !obj0.bool_41;

  private void method_3([In] Class29 obj0_1, [In] string obj1, string[] string_1)
  {
    if (!obj0_1.Class21_0.method_0(\u003CModule\u003E.smethod_6<string>(996372742U)) || obj0_1.method_23(\u003CModule\u003E.smethod_6<string>(1387062805U)))
      return;
    byte intptr_0 = 0;
    Dictionary<byte, Class132> dictionary = obj0_1.Class133_0.Dictionary_0.ToDictionary<KeyValuePair<string, Class132>, byte, Class132>((Func<KeyValuePair<string, Class132>, byte>) (obj0_2 => obj0_2.Value.Byte_0), (Func<KeyValuePair<string, Class132>, Class132>) (obj0_3 => obj0_3.Value));
    for (byte key = 1; (int) key < obj0_1.Class133_0.Int32_0; ++key)
    {
      if (!dictionary.ContainsKey(key))
      {
        intptr_0 = key;
        break;
      }
    }
    Class132 string_8 = new Class132(intptr_0, \u003CModule\u003E.smethod_9<string>(2898357263U), (ushort) 49, (byte) 100, (byte) 100)
    {
      Double_0 = 16.0
    };
    obj0_1.Class133_0.method_0(string_8);
    obj0_1.method_99(string_8);
  }

  private void method_4([In] Class29 obj0, [In] string obj1, string[] string_1)
  {
    if (!this.bool_0)
      return;
    try
    {
      Class142 class142 = obj0.method_128(\u003CModule\u003E.smethod_6<string>(99819465U)) ?? obj0.method_128(\u003CModule\u003E.smethod_7<string>(45963987U));
      if (class142 == null || !this.bool_0)
        return;
      if (!(class142.String_0 == \u003CModule\u003E.smethod_7<string>(45963987U)))
      {
        obj0.method_88((byte) 1, class142.Int32_0, (ushort) 2766, Array.Empty<object>());
        obj0.method_90((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 2, (byte) 1);
      }
      else
      {
        obj0.method_88((byte) 1, class142.Int32_0, (ushort) 2547, Array.Empty<object>());
        obj0.method_90((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 2, (byte) 1);
      }
    }
    catch
    {
    }
  }

  private void method_5([In] Class29 obj0, [In] string obj1, string[] string_1)
  {
    if (!this.bool_0)
      return;
    try
    {
      Class142 class142 = obj0.method_128(\u003CModule\u003E.smethod_9<string>(2924242819U)) ?? obj0.method_128(\u003CModule\u003E.smethod_9<string>(2237801895U));
      if (class142 == null || string_1.Length < 2 || !this.bool_0)
        return;
      byte index = (byte) new List<string>()
      {
        "",
        \u003CModule\u003E.smethod_8<string>(3139374449U),
        \u003CModule\u003E.smethod_9<string>(3738213536U),
        \u003CModule\u003E.smethod_9<string>(561068502U),
        \u003CModule\u003E.smethod_5<string>(3981787758U)
      }.IndexOf(string_1[1].ToUpper());
      List<ushort> ushortList = new List<ushort>()
      {
        (ushort) 0,
        (ushort) 87,
        (ushort) 221,
        (ushort) 355,
        (ushort) 489
      };
      obj0.method_88((byte) 1, class142.Int32_0, (ushort) 1933, Array.Empty<object>());
      obj0.method_90((byte) 1, class142.Int32_0, (ushort) 909, (ushort) 81, index);
      obj0.method_91((byte) 1, class142.Int32_0, (ushort) 909, (ushort) ((uint) ushortList[(int) index] + 1U), string_1[0]);
    }
    catch
    {
      obj0.method_75((byte) 0, \u003CModule\u003E.smethod_6<string>(1472438760U));
    }
  }

  private void method_6([In] Class29 obj0, [In] string obj1, string[] string_1)
  {
    Class142 string_1_1;
    if (!this.bool_0 || !this.method_7(obj0, string_1, ref string_1_1))
      return;
    string upper = string_1[0].ToUpper();
    byte num;
    if (!(upper == \u003CModule\u003E.smethod_5<string>(3126698411U)))
    {
      if (!(upper == \u003CModule\u003E.smethod_6<string>(4241117045U)))
      {
        if (!(upper == \u003CModule\u003E.smethod_8<string>(578310270U)))
        {
          if (!(upper == \u003CModule\u003E.smethod_8<string>(3272447995U)))
          {
            if (!(upper == \u003CModule\u003E.smethod_9<string>(384746750U)))
            {
              if (!(upper == \u003CModule\u003E.smethod_9<string>(1198717467U)))
              {
                obj0.method_75((byte) 0, \u003CModule\u003E.smethod_6<string>(1732898802U));
                return;
              }
              num = (byte) 6;
            }
            else
              num = (byte) 5;
          }
          else
            num = (byte) 4;
        }
        else
          num = (byte) 3;
      }
      else
        num = (byte) 2;
    }
    else
      num = (byte) 1;
    obj0.method_90((byte) 1, string_1_1.Int32_0, (ushort) 857, (ushort) 19, num);
  }

  private bool method_7([In] Class29 obj0, [In] string[] obj1, ref Class142 string_1)
  {
    bool flag = false;
label_1:
    string_1 = obj0.method_128(\u003CModule\u003E.smethod_6<string>(1448999065U)) ?? obj0.method_128(\u003CModule\u003E.smethod_5<string>(1416519717U)) ?? obj0.method_128(\u003CModule\u003E.smethod_7<string>(3274187583U)) ?? obj0.method_128(\u003CModule\u003E.smethod_8<string>(1725110977U)) ?? obj0.method_128(\u003CModule\u003E.smethod_7<string>(45963987U)) ?? obj0.method_128(\u003CModule\u003E.smethod_6<string>(2277258581U)) ?? obj0.method_128(\u003CModule\u003E.smethod_6<string>(467069833U)) ?? obj0.method_128(\u003CModule\u003E.smethod_8<string>(4179190050U)) ?? obj0.method_128(\u003CModule\u003E.smethod_9<string>(2335385813U)) ?? obj0.method_128(\u003CModule\u003E.smethod_7<string>(2565105420U));
    if (string_1 != null && obj0.Struct16_1.method_0(string_1.Struct16_0) <= 11 && (int) obj0.class88_0.Int16_0 == (int) string_1.Class88_0.Int16_0)
    {
      if (obj1.Length == 0 || string.IsNullOrEmpty(obj1[0]))
        return false;
      if (flag)
        Thread.Sleep(1000);
      obj0.method_88((byte) 1, string_1.Int32_0, (ushort) 1881, Array.Empty<object>());
      DateTime utcNow = DateTime.UtcNow;
      if (!flag)
      {
        obj0.Class134_0 = new Class134();
        while (obj0.Class75_0 == null)
        {
          if (DateTime.UtcNow.Subtract(utcNow).TotalSeconds > 1.5 || obj0.Class134_0 == null)
          {
            flag = true;
            obj0.Class134_0 = (Class134) null;
            goto label_1;
          }
        }
      }
      return true;
    }
    obj0.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(1217563551U));
    return false;
  }

  private void method_8([In] Class29 obj0, [In] string obj1, string[] string_1)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class61.Class63 class63 = new Class61.Class63();
    // ISSUE: reference to a compiler-generated field
    class63.string_0 = string_1;
    // ISSUE: reference to a compiler-generated field
    class63.class61_0 = this;
    if (!this.bool_0)
      return;
    int num = 0;
    // ISSUE: reference to a compiler-generated field
    class63.int_0 = 0;
    int index1 = 1;
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    for (int index2 = 1; index2 < class63.string_0.Length - 1 && Regex.Match(class63.string_0[index2], \u003CModule\u003E.smethod_5<string>(2079734249U)).Success; ++index2)
    {
      // ISSUE: reference to a compiler-generated field
      ref string local = ref class63.string_0[0];
      // ISSUE: reference to a compiler-generated field
      local = local + \u003CModule\u003E.smethod_9<string>(366607487U) + class63.string_0[index2];
      ++index1;
    }
    if (index1 > 1)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      class63.string_0[1] = class63.string_0[index1];
    }
    if (!obj0.Class21_0.method_0(\u003CModule\u003E.smethod_8<string>(844457362U)) && !obj0.Class21_0.method_0(\u003CModule\u003E.smethod_6<string>(3496208160U)))
    {
      if (!obj0.Class21_0.method_0(\u003CModule\u003E.smethod_7<string>(3358165071U)))
        return;
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (int.TryParse(class63.string_0[0], out class63.int_0) && class63.int_0 >= 1 && class63.int_0 <= 6)
      {
        obj0.method_29(\u003CModule\u003E.smethod_8<string>(1751199417U));
        while (obj0.Class75_0 == null)
          Thread.Sleep(10);
        obj0.method_90(obj0.Class75_0.Byte_1, obj0.Class75_0.Int32_0, (ushort) 0, (ushort) 2, (byte) 12);
        // ISSUE: reference to a compiler-generated field
        obj0.method_90(obj0.Class75_0.Byte_1, obj0.Class75_0.Int32_0, (ushort) 0, (ushort) 2, (byte) class63.int_0);
      }
      else
      {
        foreach (KeyValuePair<byte, List<string>> keyValuePair in this.dictionary_0)
        {
          // ISSUE: object of a compiler-generated type is created
          // ISSUE: variable of a compiler-generated type
          Class61.Class64 class64 = new Class61.Class64();
          // ISSUE: reference to a compiler-generated field
          class64.class63_0 = class63;
          // ISSUE: reference to a compiler-generated field
          class64.keyValuePair_0 = keyValuePair;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          if (class64.class63_0.int_0 == 0)
          {
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated method
            class64.class63_0.int_0 = class64.keyValuePair_0.Value.FindIndex(class64.class63_0.predicate_0 ?? (class64.class63_0.predicate_0 = new Predicate<string>(class64.class63_0.method_2))) + 1;
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            if (class64.class63_0.int_0 != 0)
            {
              // ISSUE: reference to a compiler-generated field
              num = (int) class64.keyValuePair_0.Key;
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated method
              if (class64.keyValuePair_0.Value.FindIndex(new Predicate<string>(class64.method_0)) != -1)
              {
                obj0.method_75((byte) 0, \u003CModule\u003E.smethod_7<string>(3933525665U));
                return;
              }
            }
          }
          else
          {
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated method
            if (class64.keyValuePair_0.Value.FindIndex(class64.class63_0.predicate_1 ?? (class64.class63_0.predicate_1 = new Predicate<string>(class64.class63_0.method_3))) != -1)
            {
              obj0.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(962503965U));
              return;
            }
          }
        }
        byte result;
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (class63.int_0 == 0 || !byte.TryParse(class63.string_0[1], out result))
          return;
        result = result > (byte) 15 ? (byte) 15 : result;
        for (int index3 = 0; index3 < (int) result; ++index3)
        {
          obj0.method_29(\u003CModule\u003E.smethod_7<string>(3358165071U));
          while (obj0.Class75_0 == null)
            Thread.Sleep(10);
          obj0.method_90(obj0.Class75_0.Byte_1, obj0.Class75_0.Int32_0, (ushort) 0, (ushort) 2, (byte) num);
          // ISSUE: reference to a compiler-generated field
          obj0.method_90(obj0.Class75_0.Byte_1, obj0.Class75_0.Int32_0, (ushort) 0, (ushort) 2, (byte) class63.int_0);
        }
      }
    }
    else
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (int.TryParse(class63.string_0[0], out class63.int_0) && class63.int_0 >= 1 && class63.int_0 <= 6)
      {
        if (!obj0.method_29(\u003CModule\u003E.smethod_9<string>(1521415096U)))
          obj0.method_29(\u003CModule\u003E.smethod_5<string>(265291160U));
        while (obj0.Class75_0 == null)
          Thread.Sleep(10);
        obj0.method_90(obj0.Class75_0.Byte_1, obj0.Class75_0.Int32_0, (ushort) 0, (ushort) 2, (byte) 1);
        // ISSUE: reference to a compiler-generated field
        obj0.method_90(obj0.Class75_0.Byte_1, obj0.Class75_0.Int32_0, (ushort) 0, (ushort) 2, (byte) class63.int_0);
      }
      else
      {
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated method
        class63.int_0 = this.list_1.FindIndex(new Predicate<string>(class63.method_0)) + 1;
        // ISSUE: reference to a compiler-generated method
        if (this.list_1.FindIndex(new Predicate<string>(class63.method_1)) != -1)
        {
          obj0.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(962503965U));
        }
        else
        {
          byte result;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          if (class63.int_0 == 0 || !byte.TryParse(class63.string_0[1], out result))
            return;
          result = result > (byte) 15 ? (byte) 15 : result;
          for (int index4 = 0; index4 < (int) result; ++index4)
          {
            if (!obj0.method_29(\u003CModule\u003E.smethod_8<string>(844457362U)))
              obj0.method_29(\u003CModule\u003E.smethod_6<string>(3496208160U));
            while (obj0.Class75_0 == null)
              Thread.Sleep(10);
            obj0.method_90(obj0.Class75_0.Byte_1, obj0.Class75_0.Int32_0, (ushort) 0, (ushort) 2, (byte) 5);
            // ISSUE: reference to a compiler-generated field
            obj0.method_90(obj0.Class75_0.Byte_1, obj0.Class75_0.Int32_0, (ushort) 0, (ushort) 2, (byte) class63.int_0);
          }
        }
      }
    }
  }

  private void method_9([In] Class29 obj0, [In] string obj1, string[] string_1)
  {
    if (!this.bool_0)
      return;
    if (!obj0.Class21_0.method_0(\u003CModule\u003E.smethod_6<string>(1425559370U)) && !obj0.Class21_0.method_0(\u003CModule\u003E.smethod_9<string>(403592834U)))
    {
      if (!obj0.Class21_0.method_0(\u003CModule\u003E.smethod_7<string>(3358165071U)))
        return;
      obj0.method_29(\u003CModule\u003E.smethod_7<string>(3358165071U));
      while (obj0.Class75_0 == null)
        Thread.Sleep(10);
      obj0.method_90(obj0.Class75_0.Byte_1, obj0.Class75_0.Int32_0, (ushort) 0, (ushort) 2, (byte) 15);
    }
    else
    {
      if (!obj0.method_29(\u003CModule\u003E.smethod_5<string>(329565682U)))
        obj0.method_29(\u003CModule\u003E.smethod_9<string>(403592834U));
      while (obj0.Class75_0 == null)
        Thread.Sleep(10);
      obj0.method_90(obj0.Class75_0.Byte_1, obj0.Class75_0.Int32_0, (ushort) 0, (ushort) 2, (byte) 4);
    }
  }

  private void method_10([In] Class29 obj0, [In] string obj1, string[] string_1)
  {
    if (!this.bool_0)
      return;
    if (!obj0.bool_40)
    {
      obj0.bool_40 = true;
    }
    else
    {
      foreach (Class20 class20 in obj0.dictionary_11.Values)
      {
        Class29 class29 = obj0;
        string[] strArray = new string[7];
        strArray[0] = class20.String_0;
        strArray[1] = \u003CModule\u003E.smethod_5<string>(289555476U);
        int num = class20.Int32_2;
        strArray[2] = num.ToString();
        strArray[3] = \u003CModule\u003E.smethod_9<string>(354800875U);
        num = class20.Int32_0;
        strArray[4] = num.ToString();
        strArray[5] = \u003CModule\u003E.smethod_6<string>(3058638707U);
        num = class20.Int32_1;
        strArray[6] = num.ToString();
        string ushort_2 = string.Concat(strArray);
        class29.method_75((byte) 0, ushort_2);
      }
    }
  }

  private void method_11([In] Class29 obj0, [In] string obj1, string[] string_1)
  {
    if (string_1.Length == 0)
    {
      obj0.Control2_0.checkBox_68.Checked = false;
    }
    else
    {
      obj0.Control2_0.checkBox_68.Checked = true;
      obj0.Control2_0.textBox_17.Text = string_1[0];
      try
      {
        obj0.Control2_0.numericUpDown_20.Value = Decimal.Parse(string_1[1]);
      }
      catch
      {
      }
    }
  }

  private void method_12(Class29 keyValuePair_0, [In] string obj1, [In] string[] obj2)
  {
    if (obj2.Length == 0)
    {
      foreach (Class29 class29 in keyValuePair_0.Class112_0.IEnumerable_0)
      {
        if (class29 != keyValuePair_0)
          class29.Control2_0.checkBox_68.Checked = false;
      }
    }
    else
    {
      int num = 2;
      foreach (Class29 class29 in keyValuePair_0.Class112_0.IEnumerable_0)
      {
        if (class29 != keyValuePair_0)
        {
          class29.Control2_0.checkBox_68.Checked = true;
          class29.Control2_0.textBox_17.Text = obj2[0];
          class29.Control2_0.numericUpDown_20.Value = (Decimal) num++;
        }
      }
    }
  }

  private void method_13(Class29 string_1, [In] string obj1, [In] string[] obj2)
  {
    bool flag = false;
    string str1 = "";
    foreach (string str2 in obj2)
      str1 = str1 + str2 + \u003CModule\u003E.smethod_6<string>(899990565U);
    string str3 = str1.Trim();
    string searchPattern = \u003CModule\u003E.smethod_9<string>(3963327247U);
    string str4 = AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_8<string>(4000292969U);
    string[] files = Directory.GetFiles(str4, searchPattern, SearchOption.AllDirectories);
    if (string.IsNullOrEmpty(str3))
      return;
    foreach (string path in files)
    {
      foreach (string readAllLine in File.ReadAllLines(path))
      {
        if (readAllLine.ToUpper().Contains(str3.ToUpper()))
        {
          string[] strArray = path.Replace(str4, "").Split('\\');
          string_1.method_75((byte) 0, Class138.smethod_6(strArray[0] + \u003CModule\u003E.smethod_5<string>(2721530718U) + strArray[1].Replace(\u003CModule\u003E.smethod_9<string>(365900666U), "") + \u003CModule\u003E.smethod_5<string>(1307491234U) + readAllLine + \u003CModule\u003E.smethod_9<string>(837288373U)));
          flag = true;
        }
      }
    }
    if (flag)
      return;
    string_1.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(2170163852U) + str3 + \u003CModule\u003E.smethod_9<string>(837288373U));
  }

  private void method_14(Class29 string_1, [In] string obj1, [In] string[] obj2)
  {
    Dictionary<string, int> source = new Dictionary<string, int>((IDictionary<string, int>) string_1.Class112_0.form5_0.dictionary_1.OrderByDescending<KeyValuePair<string, int>, int>((Func<KeyValuePair<string, int>, int>) (obj0 => obj0.Value)).ToDictionary<KeyValuePair<string, int>, string, int>((Func<KeyValuePair<string, int>, string>) (obj0 => obj0.Key), (Func<KeyValuePair<string, int>, int>) (obj0 => obj0.Value)));
    string_1.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(669752211U));
    for (int index = 0; index < 5; ++index)
    {
      try
      {
        string_1.method_75((byte) 0, source.ElementAt<KeyValuePair<string, int>>(index).Key + \u003CModule\u003E.smethod_5<string>(289555476U) + source.ElementAt<KeyValuePair<string, int>>(index).Value.ToString());
      }
      catch
      {
        break;
      }
    }
  }

  private void method_15(Class29 class142_0, [In] string obj1, [In] string[] obj2)
  {
    if (obj2.Length != 0)
    {
      if (obj2[0].Equals(\u003CModule\u003E.smethod_5<string>(1050393146U), StringComparison.CurrentCultureIgnoreCase))
      {
        foreach (Class29 class29 in class142_0.Class112_0.IEnumerable_0)
        {
          if (class29.class88_0.String_0.Contains(\u003CModule\u003E.smethod_7<string>(3111093529U)))
            class29.method_60((byte) 1, \u003CModule\u003E.smethod_5<string>(3892279836U));
        }
      }
      else
      {
        if (!obj2[0].Equals(\u003CModule\u003E.smethod_7<string>(3787322274U), StringComparison.CurrentCultureIgnoreCase))
          return;
        foreach (Class29 class29 in class142_0.Class112_0.IEnumerable_0)
        {
          if (class29.class88_0.String_0.Contains(\u003CModule\u003E.smethod_7<string>(3111093529U)))
            class29.method_60((byte) 1, \u003CModule\u003E.smethod_5<string>(857569580U));
        }
      }
    }
    else
    {
      if (!class142_0.class88_0.String_0.Contains(\u003CModule\u003E.smethod_7<string>(3111093529U)))
        return;
      class142_0.method_60((byte) 1, \u003CModule\u003E.smethod_7<string>(3323931664U));
    }
  }

  private void method_16(Class29 class142_0, [In] string obj1, [In] string[] obj2) => class142_0.bool_14 = !class142_0.bool_14;

  internal void method_17(Class29 byte_0, [In] string obj1)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class61.Class65 class65 = new Class61.Class65();
    // ISSUE: reference to a compiler-generated field
    class65.class61_0 = this;
    // ISSUE: reference to a compiler-generated field
    class65.class29_0 = byte_0;
    // ISSUE: reference to a compiler-generated field
    class65.string_1 = obj1;
    // ISSUE: reference to a compiler-generated field
    if (class65.class29_0.Control2_0.checkBox_21.Checked)
      return;
    // ISSUE: reference to a compiler-generated field
    string[] strArray = class65.string_1.Split(' ');
    // ISSUE: reference to a compiler-generated field
    class65.string_0 = strArray[0];
    // ISSUE: reference to a compiler-generated field
    if (!this.dictionary_1.ContainsKey(class65.string_0))
      return;
    // ISSUE: reference to a compiler-generated field
    class65.string_2 = new string[strArray.Length - 1];
    // ISSUE: reference to a compiler-generated field
    if (class65.string_2.Length != 0)
    {
      for (int index = 1; index < strArray.Length; ++index)
      {
        // ISSUE: reference to a compiler-generated field
        class65.string_2[index - 1] = strArray[index];
      }
    }
    // ISSUE: reference to a compiler-generated method
    ThreadPool.QueueUserWorkItem(new WaitCallback(class65.method_0));
  }

  private void method_18(Class29 string_0, string string_1, [In] string[] obj2)
  {
    if (obj2.Length == 0)
      string_0.Control2_0.method_42(!string_0.Boolean_9, string_0.UInt16_0);
    ushort result;
    if (obj2.Length != 1 || !ushort.TryParse(obj2[0], out result))
      return;
    if (result >= (ushort) 1 && result <= (ushort) 1000)
      string_0.Control2_0.method_42(true, result);
    else
      string_0.method_75((byte) 3, \u003CModule\u003E.smethod_6<string>(430598592U));
  }

  private void method_19([In] Class29 obj0, string string_1, [In] string[] obj2)
  {
    ushort result;
    if (obj2.Length != 1 || !ushort.TryParse(obj2[0], out result))
      return;
    obj0.method_76(result, (short) 100);
  }

  private void method_20(Class29 byte_3, string string_1, [In] string[] obj2)
  {
    Class142 class142 = byte_3.method_128(\u003CModule\u003E.smethod_5<string>(3569938142U));
    if (class142 == null || obj2.Length != 1)
      return;
    string lower = obj2[0].ToLower();
    byte num;
    if (!(lower == \u003CModule\u003E.smethod_7<string>(4228961299U)))
    {
      if (!(lower == \u003CModule\u003E.smethod_5<string>(1223696151U)))
      {
        if (!(lower == \u003CModule\u003E.smethod_9<string>(2395277563U)))
        {
          if (!(lower == \u003CModule\u003E.smethod_5<string>(2612502235U)))
          {
            if (!(lower == \u003CModule\u003E.smethod_9<string>(1708836639U)))
              return;
            num = (byte) 5;
          }
          else
            num = (byte) 2;
        }
        else
          num = (byte) 4;
      }
      else
        num = (byte) 3;
    }
    else
      num = (byte) 1;
    byte_3.method_88((byte) 1, class142.Int32_0, (ushort) 1693, Array.Empty<object>());
    byte_3.method_89((byte) 1, class142.Int32_0, (ushort) 669, (ushort) 38);
    byte_3.method_89((byte) 1, class142.Int32_0, (ushort) 669, (ushort) 39);
    byte_3.method_89((byte) 1, class142.Int32_0, (ushort) 669, (ushort) 40);
    byte_3.method_90((byte) 1, class142.Int32_0, (ushort) 669, (ushort) 41, (byte) 1);
    byte_3.method_90((byte) 1, class142.Int32_0, (ushort) 669, (ushort) 237, num);
  }

  private void method_21([In] Class29 obj0, string string_1, string[] string_2)
  {
label_0:
    Class142 class142 = obj0.method_128(\u003CModule\u003E.smethod_7<string>(3681593201U));
    int result1;
    if (class142 == null || string_2.Length != 1 || !int.TryParse(string_2[0], out result1) && string_2[0] != null && string_2[0].ToUpper() != \u003CModule\u003E.smethod_8<string>(4020028064U))
      return;
    obj0.method_78(class142.Int32_0);
    obj0.method_90((byte) 1, class142.Int32_0, (ushort) 626, (ushort) 2, (byte) 1);
    obj0.method_89((byte) 1, class142.Int32_0, (ushort) 626, (ushort) 28);
    DateTime utcNow = DateTime.UtcNow;
    while (obj0.string_2 == null || !obj0.string_2.Contains(\u003CModule\u003E.smethod_8<string>(1752515090U)))
    {
      if (DateTime.UtcNow.Subtract(utcNow).TotalSeconds <= 2.0)
        Thread.Sleep(25);
      else
        goto label_0;
    }
    Match match;
    if ((match = Regex.Match(obj0.string_2, \u003CModule\u003E.smethod_7<string>(755046150U))).Success)
    {
      uint result2;
      if (!uint.TryParse(match.Groups[1].Value, out result2) || result2 == 0U)
        return;
      obj0.UInt32_3 = result2;
      obj0.method_89((byte) 1, class142.Int32_0, (ushort) 626, (ushort) 30);
      obj0.method_90((byte) 1, class142.Int32_0, (ushort) 626, (ushort) 51, (byte) 2);
      if (result1 == 0 && string_2[0] != null && string_2[0].ToUpper() == \u003CModule\u003E.smethod_6<string>(1105188392U))
        result1 = this.method_23(obj0, \u003CModule\u003E.smethod_8<string>(3153396812U));
      for (int index = 1; index < result1; ++index)
      {
        obj0.method_90((byte) 1, class142.Int32_0, (ushort) 626, (ushort) 80, (byte) 2);
        obj0.method_90((byte) 1, class142.Int32_0, (ushort) 626, (ushort) 51, (byte) 2);
        Thread.Sleep(5);
      }
      Thread.Sleep(1000);
      obj0.method_90((byte) 1, class142.Int32_0, (ushort) 626, (ushort) 80, (byte) 1);
      obj0.method_90((byte) 1, class142.Int32_0, (ushort) 626, (ushort) 85, (byte) 3);
    }
    else
      obj0.method_75((byte) 0, \u003CModule\u003E.smethod_8<string>(2472691046U));
  }

  private void method_22([In] Class29 obj0, string byte_3, [In] string[] obj2)
  {
label_0:
    Class142 class142 = obj0.method_128(\u003CModule\u003E.smethod_5<string>(2226855103U));
    int result1;
    if (class142 == null || obj2.Length != 1 || !int.TryParse(obj2[0], out result1) && obj2[0] != null && obj2[0].ToUpper() != \u003CModule\u003E.smethod_7<string>(235670548U))
      return;
    obj0.method_78(class142.Int32_0);
    obj0.method_90((byte) 1, class142.Int32_0, (ushort) 627, (ushort) 2, (byte) 1);
    obj0.method_89((byte) 1, class142.Int32_0, (ushort) 627, (ushort) 28);
    DateTime utcNow = DateTime.UtcNow;
    while (obj0.string_2 == null || !obj0.string_2.Contains(\u003CModule\u003E.smethod_6<string>(3436297224U)))
    {
      if (DateTime.UtcNow.Subtract(utcNow).TotalSeconds <= 2.0)
        Thread.Sleep(25);
      else
        goto label_0;
    }
    Match match;
    if ((match = Regex.Match(obj0.string_2, \u003CModule\u003E.smethod_8<string>(3192867002U))).Success)
    {
      uint result2;
      if (!uint.TryParse(match.Groups[1].Value, out result2) || result2 == 0U)
        return;
      obj0.UInt32_4 = result2;
      obj0.method_89((byte) 1, class142.Int32_0, (ushort) 627, (ushort) 30);
      obj0.method_90((byte) 1, class142.Int32_0, (ushort) 627, (ushort) 47, (byte) 2);
      if (result1 == 0 && obj2[0] != null && obj2[0].ToUpper() == \u003CModule\u003E.smethod_6<string>(1105188392U))
        result1 = this.method_23(obj0, \u003CModule\u003E.smethod_7<string>(1226326534U));
      for (int index = 1; index < result1; ++index)
      {
        obj0.method_90((byte) 1, class142.Int32_0, (ushort) 627, (ushort) 73, (byte) 2);
        obj0.method_90((byte) 1, class142.Int32_0, (ushort) 627, (ushort) 47, (byte) 2);
        Thread.Sleep(5);
      }
      Thread.Sleep(1000);
      obj0.method_90((byte) 1, class142.Int32_0, (ushort) 627, (ushort) 73, (byte) 1);
      obj0.method_90((byte) 1, class142.Int32_0, (ushort) 627, (ushort) 78, (byte) 3);
    }
    else
      obj0.method_75((byte) 0, \u003CModule\u003E.smethod_8<string>(2472691046U));
  }

  private int method_23(Class29 byte_0, [In] string obj1)
  {
    int num1 = 0;
    int num2 = obj1 == \u003CModule\u003E.smethod_5<string>(1273658076U) ? 50 : 25;
    uint num3 = obj1 == \u003CModule\u003E.smethod_8<string>(3153396812U) ? byte_0.UInt32_3 : byte_0.UInt32_4;
    float uint327 = (float) byte_0.UInt32_7;
    while ((double) (uint327 -= (float) (((long) num3 + (long) (num2 * num1)) * 500L)) >= 0.0)
      ++num1;
    return num1;
  }

  private void method_24(Class29 byte_0, string int_0, string[] int_1)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class61.Class66 class66 = new Class61.Class66();
    // ISSUE: reference to a compiler-generated field
    class66.class29_0 = byte_0;
    string str = string.Join(\u003CModule\u003E.smethod_9<string>(366607487U), int_1);
    if (str.Equals(\u003CModule\u003E.smethod_6<string>(1980327298U), StringComparison.CurrentCultureIgnoreCase))
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated method
      Class142 class142 = class66.class29_0.method_129().OrderBy<Class142, int>(new Func<Class142, int>(class66.method_0)).FirstOrDefault<Class142>();
      // ISSUE: reference to a compiler-generated field
      if (class142 != null && class142.Struct16_0.method_0(class66.class29_0.Struct16_1) <= 12)
      {
        // ISSUE: reference to a compiler-generated field
        class66.class29_0.method_88((byte) 1, class142.Int32_0, (ushort) 92, Array.Empty<object>());
      }
      else
      {
        // ISSUE: reference to a compiler-generated field
        class66.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_8<string>(2817103458U));
      }
    }
    else
    {
      // ISSUE: reference to a compiler-generated field
      foreach (Class76 class76 in new List<Class76>((IEnumerable<Class76>) class66.class29_0.Class21_0))
      {
        if (class76 != null && class76.String_0.Equals(str, StringComparison.CurrentCultureIgnoreCase))
        {
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated method
          Class142 class142 = class66.class29_0.method_129().OrderBy<Class142, int>(class66.func_0 ?? (class66.func_0 = new Func<Class142, int>(class66.method_1))).FirstOrDefault<Class142>();
          // ISSUE: reference to a compiler-generated field
          if (class142 != null && class142.Struct16_0.method_0(class66.class29_0.Struct16_1) <= 12)
          {
            // ISSUE: reference to a compiler-generated field
            class66.class29_0.method_88((byte) 1, class142.Int32_0, (ushort) 90, new object[2]
            {
              (object) 1,
              (object) class76.Byte_0
            });
            return;
          }
          // ISSUE: reference to a compiler-generated field
          class66.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_6<string>(3509239706U));
          return;
        }
      }
      // ISSUE: reference to a compiler-generated field
      class66.class29_0.method_75((byte) 3, \u003CModule\u003E.smethod_8<string>(2763610905U) + str + \u003CModule\u003E.smethod_9<string>(2965288485U));
    }
  }

  private void method_25(Class29 value, [In] string obj1, [In] string[] obj2)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class61.Class67 class67 = new Class61.Class67();
    // ISSUE: reference to a compiler-generated field
    class67.class29_0 = value;
    if (obj2.Length == 0)
      return;
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated method
    Class142 class142 = class67.class29_0.method_129().OrderBy<Class142, int>(new Func<Class142, int>(class67.method_0)).FirstOrDefault<Class142>();
    // ISSUE: reference to a compiler-generated field
    if (class142 != null && class142.Struct16_0.method_0(class67.class29_0.Struct16_1) <= 12)
    {
      if (obj2[0] == \u003CModule\u003E.smethod_5<string>(2984341645U))
      {
        // ISSUE: reference to a compiler-generated field
        class67.class29_0.method_88((byte) 1, class142.Int32_0, (ushort) 68, Array.Empty<object>());
      }
      else if (obj2[0] == \u003CModule\u003E.smethod_9<string>(1288555092U))
      {
        // ISSUE: reference to a compiler-generated field
        class67.class29_0.method_88((byte) 1, class142.Int32_0, (ushort) 69, Array.Empty<object>());
      }
      else
      {
        string str = string.Join(\u003CModule\u003E.smethod_9<string>(366607487U), obj2).Trim();
        int result;
        if (int.TryParse(str, out result))
        {
          // ISSUE: reference to a compiler-generated field
          class67.class29_0.method_86(class142.Int32_0, result);
        }
        else if (int.TryParse(obj2[obj2.Length - 1], out result))
        {
          // ISSUE: reference to a compiler-generated field
          class67.class29_0.method_84(class142.Int32_0, str.Replace(\u003CModule\u003E.smethod_9<string>(366607487U) + obj2[obj2.Length - 1], ""), result);
        }
        else
        {
          // ISSUE: reference to a compiler-generated field
          class67.class29_0.method_84(class142.Int32_0, str, 0);
        }
      }
    }
    else
    {
      // ISSUE: reference to a compiler-generated field
      class67.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_8<string>(2817103458U));
    }
  }

  private void method_26(Class29 value, [In] string obj1, [In] string[] obj2)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class61.Class68 class68 = new Class61.Class68();
    // ISSUE: reference to a compiler-generated field
    class68.class29_0 = value;
    if (obj2.Length == 0)
      return;
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated method
    Class142 class142 = class68.class29_0.method_129().OrderBy<Class142, int>(new Func<Class142, int>(class68.method_0)).FirstOrDefault<Class142>();
    // ISSUE: reference to a compiler-generated field
    if (class142 != null && class142.Struct16_0.method_0(class68.class29_0.Struct16_1) <= 12)
    {
      if (obj2[0] == \u003CModule\u003E.smethod_5<string>(2984341645U))
      {
        // ISSUE: reference to a compiler-generated field
        class68.class29_0.method_88((byte) 1, class142.Int32_0, (ushort) 66, Array.Empty<object>());
      }
      else if (obj2[0] == \u003CModule\u003E.smethod_8<string>(3057162110U))
      {
        // ISSUE: reference to a compiler-generated field
        class68.class29_0.method_88((byte) 1, class142.Int32_0, (ushort) 67, Array.Empty<object>());
      }
      else
      {
        string str = string.Join(\u003CModule\u003E.smethod_9<string>(366607487U), obj2).Trim();
        int result;
        if (int.TryParse(str, out result))
        {
          // ISSUE: reference to a compiler-generated field
          class68.class29_0.method_87(class142.Int32_0, result);
        }
        else if (int.TryParse(obj2[obj2.Length - 1], out result))
        {
          // ISSUE: reference to a compiler-generated field
          class68.class29_0.method_85(class142.Int32_0, str.Replace(\u003CModule\u003E.smethod_5<string>(2854823517U) + obj2[obj2.Length - 1], ""), result);
        }
        else
        {
          // ISSUE: reference to a compiler-generated field
          class68.class29_0.method_85(class142.Int32_0, str, 1);
        }
      }
    }
    else
    {
      // ISSUE: reference to a compiler-generated field
      class68.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_7<string>(1485879898U));
    }
  }

  private void method_27(Class29 value, [In] string obj1, [In] string[] obj2)
  {
    if (obj2.Length == 0)
      return;
    obj2[0] = obj2[0].Trim();
    if (obj2[0] == \u003CModule\u003E.smethod_6<string>(97965019U))
    {
      foreach (Class29 class29 in value.Class112_0.IEnumerable_0)
      {
        if (class29.Control2_0 != null && !string.IsNullOrEmpty(class29.String_0) && value != class29)
          value.method_113(class29.String_0);
      }
    }
    else
      value.method_113(obj2[0]);
  }

  private void method_28(Class29 value, [In] string obj1, [In] string[] obj2)
  {
    if (obj2.Length != 1)
      return;
    value.method_114(obj2[0]);
  }

  private void method_29(Class29 value, [In] string obj1, [In] string[] obj2)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class61.Class69 class69 = new Class61.Class69();
    // ISSUE: reference to a compiler-generated field
    class69.class29_0 = value;
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated method
    Class142 class142 = class69.class29_0.method_129().OrderBy<Class142, int>(new Func<Class142, int>(class69.method_0)).FirstOrDefault<Class142>();
    // ISSUE: reference to a compiler-generated field
    if (class142 != null && class142.Struct16_0.method_0(class69.class29_0.Struct16_1) <= 12)
    {
      // ISSUE: reference to a compiler-generated field
      class69.class29_0.method_88((byte) 1, class142.Int32_0, (ushort) 96, Array.Empty<object>());
    }
    else
    {
      // ISSUE: reference to a compiler-generated field
      class69.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_8<string>(2817103458U));
    }
  }

  private void method_30(Class29 value, [In] string obj1, [In] string[] obj2)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class61.Class70 class70 = new Class61.Class70();
    // ISSUE: reference to a compiler-generated field
    class70.class29_0 = value;
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated method
    Class142 class142 = class70.class29_0.method_129().OrderBy<Class142, int>(new Func<Class142, int>(class70.method_0)).FirstOrDefault<Class142>();
    // ISSUE: reference to a compiler-generated field
    if (class142 != null && class142.Struct16_0.method_0(class70.class29_0.Struct16_1) <= 12)
    {
      // ISSUE: reference to a compiler-generated field
      class70.class29_0.method_88((byte) 1, class142.Int32_0, (ushort) 100, Array.Empty<object>());
    }
    else
    {
      // ISSUE: reference to a compiler-generated field
      class70.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(3347877864U));
    }
  }

  private void method_31(Class29 value, [In] string obj1, [In] string[] obj2) => value.Class26_0.bool_18 = !value.Class26_0.bool_18;

  private void method_32([In] Class29 obj0, string byte_9, string[] int_1)
  {
  }
}
