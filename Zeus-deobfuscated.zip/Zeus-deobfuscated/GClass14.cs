﻿// Decompiled with JetBrains decompiler
// Type: GClass14
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.IO;
using System.Runtime.InteropServices;

public class GClass14
{
  public byte byte_0;
  public byte byte_1;
  public byte byte_2;
  public byte byte_3;
  public byte byte_4;
  public byte byte_5;
  public ushort ushort_0;
  public byte byte_6;
  public byte byte_7;
  public byte byte_8;
  public byte byte_9;
  public string string_0;

  public GClass15 this[[In] int obj0]
  {
    get => this.GClass15_0[obj0];
    [param: In] set => this.GClass15_0[obj0] = value;
  }

  public bool Boolean_0 { get; private set; }

  public bool Boolean_1 { get; private set; }

  public uint UInt32_0 { get; [param: In] private set; }

  public uint UInt32_1 { get; private set; }

  public GClass15[] GClass15_0 { get; private set; }

  public int Int32_0 { get; private set; }

  public int Int32_1 { get; private set; }

  public int Int32_2 { get; private set; }

  public virtual string System\u002EObject\u002EToString() => string.Format(\u003CModule\u003E.smethod_5<string>(2657235863U), (object) this.Int32_2, (object) this.Int32_1, (object) this.Int32_0, (object) this.byte_0, (object) this.byte_1, (object) this.byte_2, (object) this.byte_3, (object) this.byte_4, (object) this.byte_5);

  public static GClass14 smethod_0(string string_2) => GClass14.smethod_4((Stream) new FileStream(string_2, FileMode.Open, FileAccess.Read, FileShare.Read));

  public static GClass14 smethod_1([In] byte[] obj0) => GClass14.smethod_4((Stream) new MemoryStream(obj0));

  public static GClass14 smethod_2(string string_2, GClass22 bool_0) => bool_0.method_0(string_2) ? GClass14.smethod_1(bool_0.method_4(string_2)) : (GClass14) null;

  public static GClass14 smethod_3([In] string obj0, [In] bool obj1, GClass22 gclass22_0) => gclass22_0.method_1(obj0, obj1) ? GClass14.smethod_1(gclass22_0.method_5(obj0, obj1)) : (GClass14) null;

  private static GClass14 smethod_4(Stream value)
  {
    value.Seek(0L, SeekOrigin.Begin);
    BinaryReader binaryReader = new BinaryReader(value);
    GClass14 gclass14 = new GClass14();
    if (binaryReader.ReadUInt32() == uint.MaxValue)
    {
      gclass14.Boolean_0 = true;
      gclass14.UInt32_0 = binaryReader.ReadUInt32();
    }
    else
      binaryReader.BaseStream.Seek(-4L, SeekOrigin.Current);
    gclass14.Int32_2 = (int) binaryReader.ReadByte();
    gclass14.GClass15_0 = new GClass15[gclass14.Int32_2];
    gclass14.Int32_1 = (int) binaryReader.ReadUInt16();
    gclass14.Int32_0 = (int) binaryReader.ReadUInt16();
    gclass14.UInt32_1 = binaryReader.ReadUInt32();
    gclass14.byte_0 = binaryReader.ReadByte();
    gclass14.byte_1 = binaryReader.ReadByte();
    gclass14.Boolean_1 = binaryReader.ReadUInt16() == ushort.MaxValue;
    if (gclass14.Boolean_1)
    {
      gclass14.byte_4 = binaryReader.ReadByte();
      gclass14.byte_5 = binaryReader.ReadByte();
      gclass14.ushort_0 = binaryReader.ReadUInt16();
      gclass14.byte_2 = binaryReader.ReadByte();
      gclass14.byte_3 = binaryReader.ReadByte();
      gclass14.byte_6 = binaryReader.ReadByte();
      gclass14.byte_7 = binaryReader.ReadByte();
      gclass14.byte_8 = binaryReader.ReadByte();
      gclass14.byte_9 = binaryReader.ReadByte();
    }
    else
    {
      binaryReader.BaseStream.Seek(-2L, SeekOrigin.Current);
      gclass14.byte_2 = binaryReader.ReadByte();
      gclass14.byte_3 = binaryReader.ReadByte();
      gclass14.byte_4 = binaryReader.ReadByte();
      gclass14.byte_5 = binaryReader.ReadByte();
      gclass14.ushort_0 = binaryReader.ReadUInt16();
    }
    long num1 = binaryReader.BaseStream.Length - (long) gclass14.UInt32_1;
    for (int index = 0; index < gclass14.Int32_2; ++index)
    {
      int num2 = (int) binaryReader.ReadUInt16();
      int bool_0 = (int) binaryReader.ReadUInt16();
      int num3 = (int) binaryReader.ReadUInt16();
      int num4 = (int) binaryReader.ReadUInt16();
      int num5 = num3 - num2;
      int num6 = bool_0;
      int num7 = num4 - num6;
      int num8 = (int) binaryReader.ReadUInt16();
      int num9 = (int) binaryReader.ReadUInt16();
      int num10 = (num8 % 256 << 8) + num8 / 256;
      int num11 = (num9 % 256 << 8) + num9 / 256;
      long num12 = (long) binaryReader.ReadUInt32();
      if (num2 == (int) ushort.MaxValue && num3 == (int) ushort.MaxValue)
      {
        gclass14.string_0 = string.Format(\u003CModule\u003E.smethod_9<string>(639238253U), (object) num12);
        --gclass14.Int32_2;
      }
      else
        gclass14.string_0 = \u003CModule\u003E.smethod_8<string>(3625395058U);
      byte[] numArray = (byte[]) null;
      if (num7 > 0 && num5 > 0)
      {
        long position = binaryReader.BaseStream.Position;
        binaryReader.BaseStream.Seek(num1 + num12, SeekOrigin.Begin);
        numArray = binaryReader.ReadBytes(num7 * num5);
        binaryReader.BaseStream.Seek(position, SeekOrigin.Begin);
      }
      gclass14.GClass15_0[index] = new GClass15(num2, bool_0, num5, num7, num10, num11, numArray);
    }
    binaryReader.Close();
    return gclass14;
  }
}
