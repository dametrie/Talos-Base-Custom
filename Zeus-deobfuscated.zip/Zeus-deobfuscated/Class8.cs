﻿// Decompiled with JetBrains decompiler
// Type: Class8
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Runtime.InteropServices;

internal sealed class Class8 : SafeHandle
{
  internal Class8()
    : base(IntPtr.Zero, true)
  {
  }

  public virtual bool System\u002ERuntime\u002EInteropServices\u002ESafeHandle\u002EIsInvalid => this.handle == IntPtr.Zero;

  bool SafeHandle.ReleaseHandle() => Class7.CloseHandle(this.handle);
}
