﻿// Decompiled with JetBrains decompiler
// Type: Class142
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using Accolade;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

internal class Class142 : Class140
{
  internal int int_1;
  internal bool bool_0;
  private byte byte_0;
  internal int int_2;
  internal ushort ushort_1;
  internal DateTime dateTime_1 = DateTime.MinValue;

  internal Direction Direction_0 { get; set; }

  internal DateTime DateTime_1 { get; set; }

  internal DateTime DateTime_2 { get; set; }

  internal DateTime DateTime_3 { get; set; }

  internal DateTime DateTime_4 { get; set; }

  internal double Double_0 { get; set; }

  internal double Double_1 { get; set; }

  internal double Double_2 { get; set; }

  internal Dictionary<ushort, DateTime> Dictionary_0 { get; [param: In] set; }

  internal Dictionary<ushort, DateTime> Dictionary_1 { get; [param: In] set; }

  internal byte Byte_0 { get; [param: In] set; }

  internal string String_1 { get; [param: In] set; }

  internal DateTime DateTime_5 { get; [param: In] set; }

  internal double Double_3 { get; [param: In] set; }

  internal string String_2
  {
    get => this.String_3;
    [param: In] set
    {
      if (value != \u003CModule\u003E.smethod_7<string>(1397493569U))
        this.bool_0 = true;
      this.String_3 = value;
    }
  }

  internal byte Byte_1
  {
    get => this.byte_0 > (byte) 100 ? (byte) 100 : this.byte_0;
    [param: In] set => this.byte_0 = value;
  }

  private string String_3 { get; [param: In] set; }

  internal bool Boolean_0 => DateTime.UtcNow.Subtract(this.DateTime_5).TotalSeconds < this.Double_3;

  internal bool Boolean_1 => DateTime.UtcNow.Subtract(this.DateTime_1).TotalSeconds < this.Double_0;

  internal bool Boolean_2 => DateTime.UtcNow.Subtract(this.DateTime_2).TotalSeconds < this.Double_1;

  internal bool Boolean_3 => DateTime.UtcNow.Subtract(this.DateTime_3).TotalSeconds < this.Double_2;

  internal bool Boolean_4 => this.Dictionary_0.ContainsKey((ushort) 40) && DateTime.UtcNow.Subtract(this.Dictionary_0[(ushort) 40]).TotalSeconds < 1.5;

  internal bool Boolean_5 => this.Dictionary_0.ContainsKey((ushort) 235) && DateTime.UtcNow.Subtract(this.Dictionary_0[(ushort) 235]).TotalSeconds < 2.0 || this.Dictionary_0.ContainsKey((ushort) 377) && DateTime.UtcNow.Subtract(this.Dictionary_0[(ushort) 377]).TotalSeconds < 1.0;

  internal bool Boolean_6 => this.Dictionary_0.ContainsKey((ushort) 117) && DateTime.UtcNow.Subtract(this.Dictionary_0[(ushort) 117]).TotalSeconds < 1.5 || this.Dictionary_0.ContainsKey((ushort) 32) && DateTime.UtcNow.Subtract(this.Dictionary_0[(ushort) 32]).TotalSeconds < 3.0;

  internal bool Boolean_7 => this.Dictionary_0.ContainsKey((ushort) 25) && DateTime.UtcNow.Subtract(this.Dictionary_0[(ushort) 25]).TotalSeconds < 1.5 || this.Dictionary_0.ContainsKey((ushort) 247) && DateTime.UtcNow.Subtract(this.Dictionary_0[(ushort) 247]).TotalSeconds < 3.0 || this.Dictionary_0.ContainsKey((ushort) 295) && DateTime.UtcNow.Subtract(this.Dictionary_0[(ushort) 295]).TotalSeconds < 3.0;

  internal Class142(
    [In] int obj0,
    [In] string obj1,
    [In] ushort obj2,
    [In] byte obj3,
    [In] Struct16 obj4,
    [In] Class88 obj5,
    [In] Direction obj6)
    : base(obj0, obj1, obj2, obj4, obj5)
  {
    this.Direction_0 = obj6;
    this.Dictionary_0 = new Dictionary<ushort, DateTime>();
    this.Dictionary_1 = new Dictionary<ushort, DateTime>();
    this.byte_0 = (byte) 100;
    this.Byte_0 = obj3;
    this.DateTime_4 = DateTime.UtcNow;
    this.DateTime_1 = DateTime.MinValue;
    this.DateTime_2 = DateTime.MinValue;
    this.DateTime_3 = DateTime.MinValue;
    this.DateTime_5 = DateTime.MinValue;
    this.Dictionary_0 = new Dictionary<ushort, DateTime>();
    this.Dictionary_1 = new Dictionary<ushort, DateTime>();
    this.String_1 = "";
    this.String_3 = "";
  }
}
