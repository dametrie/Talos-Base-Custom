﻿// Decompiled with JetBrains decompiler
// Type: Class182
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;

[CompilerGenerated]
internal static class Class182
{
  private static object object_0 = new object();
  private static Dictionary<string, bool> dictionary_0 = new Dictionary<string, bool>();
  private static Dictionary<string, string> dictionary_1 = new Dictionary<string, string>();
  private static Dictionary<string, string> dictionary_2 = new Dictionary<string, string>();
  private static int int_0;

  private static string smethod_0([In] CultureInfo obj0) => obj0 == null ? "" : obj0.Name;

  private static Assembly smethod_1([In] AssemblyName obj0)
  {
    foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
    {
      AssemblyName name = assembly.GetName();
      // ISSUE: reference to a compiler-generated method
      // ISSUE: reference to a compiler-generated method
      if (string.Equals(name.Name, obj0.Name, StringComparison.InvariantCultureIgnoreCase) && string.Equals(Class182.smethod_0(name.CultureInfo), Class182.smethod_0(obj0.CultureInfo), StringComparison.InvariantCultureIgnoreCase))
        return assembly;
    }
    return (Assembly) null;
  }

  private static void smethod_2([In] Stream obj0, [In] Stream obj1)
  {
    byte[] buffer = new byte[81920];
    int count;
    while ((count = obj0.Read(buffer, 0, buffer.Length)) != 0)
      obj1.Write(buffer, 0, count);
  }

  private static Stream smethod_3(string class0_0)
  {
    Assembly executingAssembly = Assembly.GetExecutingAssembly();
    if (!class0_0.EndsWith(\u003CModule\u003E.smethod_6<string>(565648212U)))
      return executingAssembly.GetManifestResourceStream(class0_0);
    using (Stream manifestResourceStream = executingAssembly.GetManifestResourceStream(class0_0))
    {
      using (DeflateStream deflateStream = new DeflateStream(manifestResourceStream, CompressionMode.Decompress))
      {
        MemoryStream memoryStream = new MemoryStream();
        // ISSUE: reference to a compiler-generated method
        Class182.smethod_2((Stream) deflateStream, (Stream) memoryStream);
        memoryStream.Position = 0L;
        return (Stream) memoryStream;
      }
    }
  }

  private static Stream smethod_4([In] Dictionary<string, string> obj0, string byte_0)
  {
    string class0_0;
    // ISSUE: reference to a compiler-generated method
    return obj0.TryGetValue(byte_0, out class0_0) ? Class182.smethod_3(class0_0) : (Stream) null;
  }

  private static byte[] smethod_5(Stream stream_1)
  {
    byte[] buffer = new byte[stream_1.Length];
    stream_1.Read(buffer, 0, buffer.Length);
    return buffer;
  }

  private static Assembly smethod_6(
    [In] Dictionary<string, string> obj0,
    Dictionary<string, string> bool_0,
    [In] AssemblyName obj2)
  {
    string byte_0 = obj2.Name.ToLowerInvariant();
    if (obj2.CultureInfo != null && !string.IsNullOrEmpty(obj2.CultureInfo.Name))
      byte_0 = obj2.CultureInfo.Name + \u003CModule\u003E.smethod_5<string>(1526496951U) + byte_0;
    byte[] rawAssembly;
    // ISSUE: reference to a compiler-generated method
    using (Stream stream_1 = Class182.smethod_4(obj0, byte_0))
    {
      if (stream_1 == null)
        return (Assembly) null;
      // ISSUE: reference to a compiler-generated method
      rawAssembly = Class182.smethod_5(stream_1);
    }
    // ISSUE: reference to a compiler-generated method
    using (Stream stream_1 = Class182.smethod_4(bool_0, byte_0))
    {
      if (stream_1 != null)
      {
        // ISSUE: reference to a compiler-generated method
        byte[] rawSymbolStore = Class182.smethod_5(stream_1);
        return Assembly.Load(rawAssembly, rawSymbolStore);
      }
    }
    return Assembly.Load(rawAssembly);
  }

  public static Assembly smethod_7(object byte_1, [In] ResolveEventArgs obj1)
  {
    // ISSUE: reference to a compiler-generated field
    lock (Class182.object_0)
    {
      // ISSUE: reference to a compiler-generated field
      if (Class182.dictionary_0.ContainsKey(obj1.Name))
        return (Assembly) null;
    }
    AssemblyName assemblyRef = new AssemblyName(obj1.Name);
    // ISSUE: reference to a compiler-generated method
    Assembly assembly1 = Class182.smethod_1(assemblyRef);
    if (assembly1 != (Assembly) null)
      return assembly1;
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated method
    Assembly assembly2 = Class182.smethod_6(Class182.dictionary_1, Class182.dictionary_2, assemblyRef);
    if (assembly2 == (Assembly) null)
    {
      // ISSUE: reference to a compiler-generated field
      lock (Class182.object_0)
      {
        // ISSUE: reference to a compiler-generated field
        Class182.dictionary_0[obj1.Name] = true;
      }
      if ((assemblyRef.Flags & AssemblyNameFlags.Retargetable) != AssemblyNameFlags.None)
        assembly2 = Assembly.Load(assemblyRef);
    }
    return assembly2;
  }

  static Class182()
  {
    // ISSUE: reference to a compiler-generated field
    Class182.dictionary_1.Add(\u003CModule\u003E.smethod_8<string>(177289472U), \u003CModule\u003E.smethod_5<string>(1220304357U));
    // ISSUE: reference to a compiler-generated field
    Class182.dictionary_1.Add(\u003CModule\u003E.smethod_6<string>(3878686276U), \u003CModule\u003E.smethod_8<string>(686126562U));
    // ISSUE: reference to a compiler-generated field
    Class182.dictionary_1.Add(\u003CModule\u003E.smethod_9<string>(683540548U), \u003CModule\u003E.smethod_5<string>(937972869U));
    // ISSUE: reference to a compiler-generated field
    Class182.dictionary_1.Add(\u003CModule\u003E.smethod_5<string>(2989044734U), \u003CModule\u003E.smethod_5<string>(82883522U));
    // ISSUE: reference to a compiler-generated field
    Class182.dictionary_1.Add(\u003CModule\u003E.smethod_5<string>(1407415084U), \u003CModule\u003E.smethod_9<string>(252159210U));
    // ISSUE: reference to a compiler-generated field
    Class182.dictionary_1.Add(\u003CModule\u003E.smethod_8<string>(3086713082U), \u003CModule\u003E.smethod_8<string>(3860381591U));
  }

  public static void smethod_8()
  {
    // ISSUE: reference to a compiler-generated field
    if (Interlocked.Exchange(ref Class182.int_0, 1) == 1)
      return;
    AppDomain.CurrentDomain.AssemblyResolve += (ResolveEventHandler) ((byte_1, obj1) =>
    {
      // ISSUE: reference to a compiler-generated field
      lock (Class182.object_0)
      {
        // ISSUE: reference to a compiler-generated field
        if (Class182.dictionary_0.ContainsKey(obj1.Name))
          return (Assembly) null;
      }
      AssemblyName assemblyRef = new AssemblyName(obj1.Name);
      // ISSUE: reference to a compiler-generated method
      Assembly assembly1 = Class182.smethod_1(assemblyRef);
      if (assembly1 != (Assembly) null)
        return assembly1;
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated method
      Assembly assembly2 = Class182.smethod_6(Class182.dictionary_1, Class182.dictionary_2, assemblyRef);
      if (assembly2 == (Assembly) null)
      {
        // ISSUE: reference to a compiler-generated field
        lock (Class182.object_0)
        {
          // ISSUE: reference to a compiler-generated field
          Class182.dictionary_0[obj1.Name] = true;
        }
        if ((assemblyRef.Flags & AssemblyNameFlags.Retargetable) != AssemblyNameFlags.None)
          assembly2 = Assembly.Load(assemblyRef);
      }
      return assembly2;
    });
  }
}
