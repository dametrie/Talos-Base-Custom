﻿// Decompiled with JetBrains decompiler
// Type: Class88
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using Accolade.Properties;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;

internal sealed class Class88
{
  internal short Int16_0 { get; }

  internal byte Byte_0 { get; }

  internal byte Byte_1 { get; }

  internal byte Byte_2 { get; set; }

  internal string String_0 { get; set; }

  internal bool Boolean_0 { get; set; }

  internal bool Boolean_1 { get; set; }

  private bool Boolean_2 { get; set; }

  internal Struct15 this[short struct19_0, short struct19_1] => this.Dictionary_0[new Struct16(struct19_0, struct19_1)];

  internal Struct15 this[Struct16 struct19_0] => this.Dictionary_0[struct19_0];

  internal ushort UInt16_0 { get; }

  internal Dictionary<Struct16, Struct15> Dictionary_0 { get; }

  internal Class88(
    [In] short obj0,
    byte struct19_1,
    byte short_6,
    byte short_7,
    [In] ushort obj4,
    [In] string obj5)
  {
    this.Int16_0 = obj0;
    this.Byte_0 = struct19_1;
    this.Byte_1 = short_6;
    this.Byte_2 = short_7;
    this.UInt16_0 = obj4;
    this.String_0 = obj5;
    this.Dictionary_0 = new Dictionary<Struct16, Struct15>();
    this.Boolean_0 = true;
    this.Boolean_1 = true;
    for (short index = 0; (int) index < (int) struct19_1; ++index)
    {
      for (short byte_5 = 0; (int) byte_5 < (int) short_6; ++byte_5)
        this.Dictionary_0[new Struct16(index, byte_5)] = new Struct15((short) 0, (short) 0, (short) 0);
    }
  }

  internal void method_0([In] byte[] obj0)
  {
    this.Dictionary_0.Clear();
    int num1 = 0;
    for (short byte_5 = 0; (int) byte_5 < (int) this.Byte_1; ++byte_5)
    {
      for (short index1 = 0; (int) index1 < (int) this.Byte_0; ++index1)
      {
        Struct16 key = new Struct16(index1, byte_5);
        byte[] numArray1 = obj0;
        int index2 = num1;
        int num2 = index2 + 1;
        int num3 = (int) numArray1[index2];
        byte[] numArray2 = obj0;
        int index3 = num2;
        int num4 = index3 + 1;
        int num5 = (int) numArray2[index3] << 8;
        short num6 = (short) (num3 | num5);
        byte[] numArray3 = obj0;
        int index4 = num4;
        int num7 = index4 + 1;
        int num8 = (int) numArray3[index4];
        byte[] numArray4 = obj0;
        int index5 = num7;
        int num9 = index5 + 1;
        int num10 = (int) numArray4[index5] << 8;
        short byte_3 = (short) (num8 | num10);
        byte[] numArray5 = obj0;
        int index6 = num9;
        int num11 = index6 + 1;
        int num12 = (int) numArray5[index6];
        byte[] numArray6 = obj0;
        int index7 = num11;
        num1 = index7 + 1;
        int num13 = (int) numArray6[index7] << 8;
        short byte_4 = (short) (num12 | num13);
        this.Dictionary_0[key] = new Struct15(num6, byte_3, byte_4);
      }
    }
    this.Boolean_2 = true;
  }

  internal void method_1(string struct16_0)
  {
    if (!File.Exists(struct16_0))
      return;
    this.method_0(File.ReadAllBytes(struct16_0));
  }

  internal void method_2()
  {
    string path = string.Format(\u003CModule\u003E.smethod_7<string>(2453318643U), (object) Settings.Default.DataPath, (object) this.Int16_0);
    if (!Directory.Exists(Settings.Default.DataPath))
      Directory.CreateDirectory(Settings.Default.DataPath);
    if (!File.Exists(path))
      return;
    FileStream fileStream = File.Open(path, FileMode.Open, FileAccess.Read, FileShare.Read);
    for (short byte_5 = 0; (int) byte_5 < (int) this.Byte_1; ++byte_5)
    {
      for (short index = 0; (int) index < (int) this.Byte_0; ++index)
        this.Dictionary_0[new Struct16(index, byte_5)] = new Struct15((short) (fileStream.ReadByte() | fileStream.ReadByte() << 8), (short) (fileStream.ReadByte() | fileStream.ReadByte() << 8), (short) (fileStream.ReadByte() | fileStream.ReadByte() << 8));
    }
    fileStream.Close();
  }

  internal bool method_3(Struct16 short_4) => this.method_4(short_4.short_0, short_4.short_1);

  internal bool method_4([In] short obj0, short short_5) => obj0 < (short) 0 || short_5 < (short) 0 || (int) obj0 >= (int) this.Byte_0 || (int) short_5 >= (int) this.Byte_1 || this.Dictionary_0[new Struct16(obj0, short_5)].Boolean_0;

  internal bool method_5(Class29 obj, [In] Struct16 obj1)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class88.Class89 class89 = new Class88.Class89();
    // ISSUE: reference to a compiler-generated field
    class89.struct16_0 = obj1;
    // ISSUE: reference to a compiler-generated field
    class89.class29_0 = obj;
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated method
    return !this.method_3(class89.struct16_0) && !class89.class29_0.method_116().Any<Class139>(new Func<Class139, bool>(class89.method_0));
  }
}
