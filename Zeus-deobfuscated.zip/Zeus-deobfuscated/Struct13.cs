﻿// Decompiled with JetBrains decompiler
// Type: Struct13
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Runtime.InteropServices;

internal struct Struct13
{
  internal int Int32_0 { get; [param: In] set; }

  internal string String_0 { get; set; }

  internal string String_1 { get; set; }

  internal string String_2 { get; [param: In] set; }

  internal int Int32_1 { get; set; }

  internal int Int32_2 { get; set; }

  internal int Int32_3 { get; set; }

  internal int Int32_4 { get; set; }

  internal int Int32_5 { get; [param: In] set; }

  internal int Int32_6 { get; set; }

  internal int Int32_7 { get; [param: In] set; }

  internal int Int32_8 { get; set; }

  internal short Int16_0 { get; [param: In] set; }

  internal short Int16_1 { get; set; }

  internal IntPtr IntPtr_0 { get; set; }

  internal IntPtr IntPtr_1 { get; set; }

  internal IntPtr IntPtr_2 { get; set; }

  internal IntPtr IntPtr_3 { get; set; }
}
