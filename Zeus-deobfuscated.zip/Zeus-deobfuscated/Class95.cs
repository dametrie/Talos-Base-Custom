﻿// Decompiled with JetBrains decompiler
// Type: Class95
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Runtime.InteropServices;

internal class Class95
{
  internal Struct16 Struct16_0 { get; [param: In] set; }

  internal string String_0 { get; set; }

  internal short Int16_0 { get; set; }

  internal Struct16 Struct16_1 { get; set; }

  internal Struct17 Struct17_0 => new Struct17(this.Int16_0, this.Struct16_1.short_0, this.Struct16_1.short_1);

  internal Class95([In] Struct16 obj0, string enum7_1, short count, [In] Struct16 obj3)
  {
    this.Struct16_0 = obj0;
    this.String_0 = enum7_1;
    this.Int16_0 = count;
    this.Struct16_1 = obj3;
  }
}
