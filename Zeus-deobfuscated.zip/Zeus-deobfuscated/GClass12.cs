﻿// Decompiled with JetBrains decompiler
// Type: GClass12
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.IO;
using System.Runtime.InteropServices;

public class GClass12
{
  public GClass13 this[int stream_0, [In] int obj1]
  {
    get => this.GClass13_0[obj1 * this.Int32_2 + stream_0];
    [param: In] set => this.GClass13_0[int_0 * this.Int32_2 + obj0] = value;
  }

  public string String_0 { get; set; }

  public int Int32_0 { get; set; }

  public GClass13[] GClass13_0 { get; [param: In] private set; }

  public int Int32_1 { get; [param: In] set; }

  public int Int32_2 { get; set; }

  public static GClass12 smethod_0(string string_0)
  {
    GClass12 gclass12 = GClass12.smethod_4((Stream) new FileStream(string_0, FileMode.Open, FileAccess.Read, FileShare.Read));
    gclass12.Int32_0 = Convert.ToInt32(Path.GetFileNameWithoutExtension(string_0).Remove(0, 3));
    return gclass12;
  }

  public static GClass12 smethod_1(string stream_0, int gclass22_0, [In] int obj2)
  {
    GClass12 gclass12 = GClass12.smethod_4((Stream) new FileStream(stream_0, FileMode.Open, FileAccess.Read, FileShare.Read));
    gclass12.Int32_2 = gclass22_0;
    gclass12.Int32_1 = obj2;
    gclass12.Int32_0 = Convert.ToInt32(Path.GetFileNameWithoutExtension(stream_0).Remove(0, 3));
    return gclass12;
  }

  public static GClass12 smethod_2(byte[] string_0) => GClass12.smethod_4((Stream) new MemoryStream(string_0));

  public static GClass12 smethod_3([In] byte[] obj0, int gclass22_0, [In] int obj2)
  {
    GClass12 gclass12 = GClass12.smethod_4((Stream) new MemoryStream(obj0));
    gclass12.Int32_2 = gclass22_0;
    gclass12.Int32_1 = obj2;
    return gclass12;
  }

  private static GClass12 smethod_4(Stream value)
  {
    value.Seek(0L, SeekOrigin.Begin);
    BinaryReader binaryReader = new BinaryReader(value);
    int length = (int) (binaryReader.BaseStream.Length / 6L);
    GClass12 gclass12 = new GClass12()
    {
      GClass13_0 = new GClass13[length]
    };
    for (int index = 0; index < length; ++index)
    {
      ushort string_0 = binaryReader.ReadUInt16();
      ushort gclass22_0 = binaryReader.ReadUInt16();
      ushort num = binaryReader.ReadUInt16();
      gclass12.GClass13_0[index] = new GClass13(string_0, gclass22_0, num);
    }
    binaryReader.Close();
    return gclass12;
  }

  public virtual string System\u002EObject\u002EToString() => \u003CModule\u003E.smethod_9<string>(196757124U) + this.String_0 + \u003CModule\u003E.smethod_9<string>(1963328142U) + this.Int32_0.ToString() + \u003CModule\u003E.smethod_5<string>(807082447U) + this.Int32_2.ToString() + \u003CModule\u003E.smethod_6<string>(2275062379U) + this.Int32_1.ToString() + \u003CModule\u003E.smethod_8<string>(907800239U);
}
