﻿// Decompiled with JetBrains decompiler
// Type: Class71
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.IO;
using System.Runtime.InteropServices;
using zlib;

internal static class Class71
{
  internal static MemoryStream smethod_0([In] byte[] obj0)
  {
    MemoryStream memoryStream1 = new MemoryStream();
    using (MemoryStream memoryStream2 = new MemoryStream(obj0))
    {
      using (ZOutputStream zoutputStream = new ZOutputStream((Stream) memoryStream1, -1))
      {
        memoryStream2.Seek(0L, SeekOrigin.Begin);
        byte[] buffer = new byte[2000];
        int count;
        while ((count = memoryStream2.Read(buffer, 0, 2000)) > 0)
          ((Stream) zoutputStream).Write(buffer, 0, count);
        ((Stream) zoutputStream).Flush();
      }
    }
    return memoryStream1;
  }

  internal static MemoryStream smethod_1([In] byte[] obj0)
  {
    MemoryStream memoryStream = new MemoryStream();
    ZOutputStream zoutputStream = new ZOutputStream((Stream) memoryStream);
    int count;
    for (int offset = 0; offset < obj0.Length; offset += count)
    {
      int num = obj0.Length - offset;
      count = num > 2000 ? 2000 : num;
      ((Stream) zoutputStream).Write(obj0, offset, count);
    }
    ((Stream) zoutputStream).Flush();
    memoryStream.Seek(0L, SeekOrigin.Begin);
    return memoryStream;
  }

  internal static void smethod_2([In] string obj0, [In] string obj1)
  {
    FileStream fileStream1 = new FileStream(obj1, FileMode.Create);
    ZOutputStream zoutputStream = new ZOutputStream((Stream) fileStream1, -1);
    FileStream fileStream2 = new FileStream(obj0, FileMode.Open);
    try
    {
      Class71.smethod_4((Stream) fileStream2, (Stream) zoutputStream);
    }
    finally
    {
      ((Stream) zoutputStream).Close();
      fileStream1.Close();
      fileStream2.Close();
    }
  }

  internal static void smethod_3([In] string obj0, [In] string obj1)
  {
    FileStream fileStream1 = new FileStream(obj1, FileMode.Create);
    ZOutputStream zoutputStream = new ZOutputStream((Stream) fileStream1);
    FileStream fileStream2 = new FileStream(obj0, FileMode.Open);
    try
    {
      Class71.smethod_4((Stream) fileStream2, (Stream) zoutputStream);
    }
    finally
    {
      ((Stream) zoutputStream).Close();
      fileStream1.Close();
      fileStream2.Close();
    }
  }

  internal static void smethod_4([In] Stream obj0, [In] Stream obj1)
  {
    byte[] buffer = new byte[2000];
    int count;
    while ((count = obj0.Read(buffer, 0, 2000)) > 0)
      obj1.Write(buffer, 0, count);
    obj1.Flush();
  }
}
