﻿// Decompiled with JetBrains decompiler
// Type: Class16
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.Runtime.InteropServices;

internal static class Class16
{
  internal struct Struct7
  {
    internal uint uint_0;
    internal uint uint_1;
    internal uint uint_2;
    internal IntPtr intptr_0;
    internal uint uint_3;
  }

  internal struct Struct8
  {
    internal int int_0;
    internal bool bool_0;
    internal bool bool_1;
    internal byte byte_0;
    internal Class16.Struct9 struct9_0;
    internal Class16.Struct9 struct9_1;
  }

  internal struct Struct9
  {
    internal int int_0;
    internal int int_1;
    internal int int_2;
    internal int int_3;

    internal Struct9([In] int obj0, [In] int obj1, [In] int obj2, int byte_7)
    {
      this.int_1 = obj0;
      this.int_3 = obj1;
      this.int_2 = obj2;
      this.int_0 = byte_7;
    }

    internal bool method_0([In] int obj0, [In] int obj1) => obj0 >= this.int_1 && obj0 <= this.int_2 && obj1 >= this.int_3 && obj1 <= this.int_0;
  }

  internal struct Struct10
  {
    internal int int_0;
    internal int int_1;
  }
}
