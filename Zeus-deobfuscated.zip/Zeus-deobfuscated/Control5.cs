﻿// Decompiled with JetBrains decompiler
// Type: Control5
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using Accolade.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;

internal class Control5 : UserControl, Interface0
{
  private readonly IContainer icontainer_0;
  private RadioButton radioButton_0;
  private ListBox listBox_0;
  private RadioButton radioButton_1;
  private Label label_0;
  private Label label_1;
  private readonly Form5 form5_0;
  private RadioButton radioButton_2;
  private Button button_0;
  private NumericUpDown numericUpDown_0;
  private NumericUpDown numericUpDown_1;
  private Button button_1;

  internal Control5(Form5 string_0)
  {
    this.form5_0 = string_0;
    this.method_0();
    foreach (KeyValuePair<int, int> keyValuePair in this.form5_0.dictionary_5)
    {
      ListBox.ObjectCollection items = this.listBox_0.Items;
      int key = keyValuePair.Key;
      string str1 = key.ToString();
      string str2 = \u003CModule\u003E.smethod_9<string>(1211895852U);
      key = keyValuePair.Value;
      string str3 = key.ToString();
      string str4 = str1 + str2 + str3;
      items.Add((object) str4);
    }
    this.radioButton_1.Checked = Settings.Default.OverrideSprites;
    this.radioButton_0.Checked = Settings.Default.DisableSprites;
    this.radioButton_2.Checked = Settings.Default.NormalSprites;
  }

  private void method_0()
  {
    this.listBox_0 = new ListBox();
    this.numericUpDown_1 = new NumericUpDown();
    this.numericUpDown_0 = new NumericUpDown();
    this.label_0 = new Label();
    this.label_1 = new Label();
    this.button_1 = new Button();
    this.radioButton_1 = new RadioButton();
    this.radioButton_0 = new RadioButton();
    this.radioButton_2 = new RadioButton();
    this.button_0 = new Button();
    this.numericUpDown_1.BeginInit();
    this.numericUpDown_0.BeginInit();
    this.SuspendLayout();
    this.listBox_0.BackColor = Color.White;
    this.listBox_0.ForeColor = Color.Black;
    this.listBox_0.FormattingEnabled = true;
    this.listBox_0.ItemHeight = 15;
    this.listBox_0.Location = new Point(373, 16);
    this.listBox_0.Name = \u003CModule\u003E.smethod_9<string>(2025866569U);
    this.listBox_0.SelectionMode = SelectionMode.MultiSimple;
    this.listBox_0.Size = new Size(97, 229);
    this.listBox_0.TabIndex = 0;
    this.numericUpDown_1.BackColor = Color.White;
    this.numericUpDown_1.ForeColor = Color.Black;
    this.numericUpDown_1.Location = new Point(306, 14);
    this.numericUpDown_1.Maximum = new Decimal(new int[4]
    {
      387,
      0,
      0,
      0
    });
    this.numericUpDown_1.Minimum = new Decimal(new int[4]
    {
      1,
      0,
      0,
      0
    });
    this.numericUpDown_1.Name = \u003CModule\u003E.smethod_6<string>(4108605383U);
    this.numericUpDown_1.Size = new Size(51, 23);
    this.numericUpDown_1.TabIndex = 1;
    this.numericUpDown_1.Value = new Decimal(new int[4]
    {
      1,
      0,
      0,
      0
    });
    this.numericUpDown_0.BackColor = Color.White;
    this.numericUpDown_0.ForeColor = Color.Black;
    this.numericUpDown_0.Location = new Point(306, 44);
    this.numericUpDown_0.Maximum = new Decimal(new int[4]
    {
      387,
      0,
      0,
      0
    });
    this.numericUpDown_0.Name = \u003CModule\u003E.smethod_5<string>(4019395587U);
    this.numericUpDown_0.Size = new Size(51, 23);
    this.numericUpDown_0.TabIndex = 2;
    this.numericUpDown_0.Value = new Decimal(new int[4]
    {
      1,
      0,
      0,
      0
    });
    this.label_0.AutoSize = true;
    this.label_0.Location = new Point(168, 46);
    this.label_0.Name = \u003CModule\u003E.smethod_9<string>(410771044U);
    this.label_0.Size = new Size(112, 15);
    this.label_0.TabIndex = 3;
    this.label_0.Text = \u003CModule\u003E.smethod_5<string>(1113234375U);
    this.label_1.AutoSize = true;
    this.label_1.Location = new Point(179, 16);
    this.label_1.Name = \u003CModule\u003E.smethod_5<string>(4048423991U);
    this.label_1.Size = new Size(100, 15);
    this.label_1.TabIndex = 4;
    this.label_1.Text = \u003CModule\u003E.smethod_9<string>(397925135U);
    this.button_1.BackColor = Color.White;
    this.button_1.FlatStyle = FlatStyle.Flat;
    this.button_1.Font = new Font(\u003CModule\u003E.smethod_8<string>(2699142928U), 11.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.button_1.Location = new Point(249, 86);
    this.button_1.Name = \u003CModule\u003E.smethod_8<string>(2897134491U);
    this.button_1.Size = new Size(118, 41);
    this.button_1.TabIndex = 5;
    this.button_1.Text = \u003CModule\u003E.smethod_8<string>(1643348678U);
    this.button_1.UseVisualStyleBackColor = false;
    this.button_1.Click += new EventHandler(this.button_1_Click);
    this.radioButton_1.AutoSize = true;
    this.radioButton_1.BackColor = SystemColors.Control;
    this.radioButton_1.Location = new Point(57, 120);
    this.radioButton_1.Name = \u003CModule\u003E.smethod_8<string>(1403290026U);
    this.radioButton_1.Size = new Size(108, 19);
    this.radioButton_1.TabIndex = 6;
    this.radioButton_1.Text = \u003CModule\u003E.smethod_8<string>(816187616U);
    this.radioButton_1.UseVisualStyleBackColor = false;
    this.radioButton_0.AutoSize = true;
    this.radioButton_0.BackColor = SystemColors.Control;
    this.radioButton_0.Location = new Point(57, 147);
    this.radioButton_0.Name = \u003CModule\u003E.smethod_5<string>(830902887U);
    this.radioButton_0.Size = new Size(118, 19);
    this.radioButton_0.TabIndex = 7;
    this.radioButton_0.Text = \u003CModule\u003E.smethod_5<string>(2946249274U);
    this.radioButton_0.UseVisualStyleBackColor = false;
    this.radioButton_2.AutoSize = true;
    this.radioButton_2.BackColor = SystemColors.Control;
    this.radioButton_2.Checked = true;
    this.radioButton_2.Location = new Point(57, 173);
    this.radioButton_2.Name = \u003CModule\u003E.smethod_5<string>(2881974752U);
    this.radioButton_2.Size = new Size(114, 19);
    this.radioButton_2.TabIndex = 8;
    this.radioButton_2.TabStop = true;
    this.radioButton_2.Text = \u003CModule\u003E.smethod_9<string>(4096289132U);
    this.radioButton_2.UseVisualStyleBackColor = false;
    this.button_0.BackColor = Color.White;
    this.button_0.FlatStyle = FlatStyle.Flat;
    this.button_0.Font = new Font(\u003CModule\u003E.smethod_7<string>(1598949124U), 11.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.button_0.Location = new Point(249, 164);
    this.button_0.Name = \u003CModule\u003E.smethod_5<string>(602348661U);
    this.button_0.Size = new Size(118, 65);
    this.button_0.TabIndex = 9;
    this.button_0.Text = \u003CModule\u003E.smethod_6<string>(1379448931U);
    this.button_0.UseVisualStyleBackColor = false;
    this.button_0.Click += new EventHandler(this.button_0_Click);
    this.AutoScaleDimensions = new SizeF(7f, 15f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.BackColor = Color.White;
    this.Controls.Add((Control) this.button_0);
    this.Controls.Add((Control) this.radioButton_2);
    this.Controls.Add((Control) this.radioButton_0);
    this.Controls.Add((Control) this.radioButton_1);
    this.Controls.Add((Control) this.button_1);
    this.Controls.Add((Control) this.label_1);
    this.Controls.Add((Control) this.label_0);
    this.Controls.Add((Control) this.numericUpDown_0);
    this.Controls.Add((Control) this.numericUpDown_1);
    this.Controls.Add((Control) this.listBox_0);
    this.Font = new Font(\u003CModule\u003E.smethod_5<string>(2184462853U), 9f);
    this.ForeColor = Color.Black;
    this.Name = \u003CModule\u003E.smethod_8<string>(2069973429U);
    this.Size = new Size(490, 258);
    this.numericUpDown_1.EndInit();
    this.numericUpDown_0.EndInit();
    this.ResumeLayout(false);
    this.PerformLayout();
  }

  public void imethod_0()
  {
    string str1 = AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_6<string>(1170431561U);
    List<string> contents = new List<string>();
    foreach (string str2 in new List<string>((IEnumerable<string>) this.listBox_0.Items.OfType<string>().ToList<string>()))
    {
      string[] separator = new string[1]
      {
        \u003CModule\u003E.smethod_7<string>(920705102U)
      };
      string[] strArray = str2.Split(separator, StringSplitOptions.None);
      contents.Add(strArray[0] + \u003CModule\u003E.smethod_7<string>(2075004763U) + strArray[1]);
    }
    File.WriteAllLines(str1 + \u003CModule\u003E.smethod_9<string>(3841229546U), (IEnumerable<string>) contents);
    Settings.Default.OverrideSprites = this.radioButton_1.Checked;
    Settings.Default.DisableSprites = this.radioButton_0.Checked;
    Settings.Default.NormalSprites = this.radioButton_2.Checked;
    Settings.Default.Save();
  }

  void ContainerControl.Dispose(bool string_0)
  {
    if (string_0 && this.icontainer_0 != null)
      this.icontainer_0.Dispose();
    // ISSUE: explicit non-virtual call
    __nonvirtual (((ContainerControl) this).Dispose(string_0));
  }

  private void button_1_Click(object class144_0, [In] EventArgs obj1)
  {
    if (this.form5_0.dictionary_5.ContainsKey((int) this.numericUpDown_1.Value))
      return;
    this.form5_0.dictionary_5.Add((int) this.numericUpDown_1.Value, (int) this.numericUpDown_0.Value);
    this.listBox_0.Items.Add((object) (this.numericUpDown_1.Value.ToString() + \u003CModule\u003E.smethod_7<string>(920705102U) + this.numericUpDown_0.Value.ToString()));
  }

  private void button_0_Click(object string_0, [In] EventArgs obj1)
  {
    foreach (string str in new List<string>((IEnumerable<string>) this.listBox_0.SelectedItems.OfType<string>().ToList<string>()))
    {
      int result;
      int.TryParse(str.Split(new string[1]
      {
        \u003CModule\u003E.smethod_5<string>(1236070580U)
      }, StringSplitOptions.None)[0], out result);
      this.form5_0.dictionary_5.Remove(result);
      this.listBox_0.Items.Remove((object) str);
    }
  }
}
