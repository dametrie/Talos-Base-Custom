﻿// Decompiled with JetBrains decompiler
// Type: Class29
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using Accolade;
using Accolade.Properties;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

internal sealed class Class29
{
  internal static HashSet<string> hashSet_0 = new HashSet<string>((IEnumerable<string>) new string[3]
  {
    \u003CModule\u003E.smethod_8<string>(1159699948U),
    \u003CModule\u003E.smethod_7<string>(346077336U),
    \u003CModule\u003E.smethod_5<string>(2136378097U)
  }, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase);
  internal byte[] byte_0;
  internal int int_0;
  internal byte[] byte_1;
  internal readonly object object_0;
  internal bool bool_0;
  internal bool bool_1;
  internal System.Windows.Forms.Timer timer_0;
  internal int int_1;
  internal List<string> list_0;
  internal bool bool_2;
  internal bool bool_3;
  internal bool bool_4;
  internal bool bool_5;
  internal bool bool_6;
  internal bool bool_7;
  internal bool bool_8;
  internal bool bool_9;
  internal bool bool_10;
  internal bool bool_11;
  internal bool bool_12;
  internal bool bool_13;
  internal string string_0;
  internal string string_1;
  internal Struct16 struct16_0;
  internal Dictionary<int, Class12> dictionary_0;
  internal int int_2;
  internal bool bool_14;
  internal Dictionary<int, Class139> dictionary_1;
  internal string string_2;
  internal readonly object object_1;
  internal byte[] byte_2;
  internal byte[] byte_3;
  internal List<byte> list_1;
  internal List<byte> list_2;
  internal int int_3;
  internal string string_3;
  internal int int_4;
  internal Control2 control2_0;
  internal Class112 class112_0;
  internal Enum6 enum6_0;
  internal Class72 class72_0;
  internal bool bool_15;
  internal Socket socket_0;
  internal Socket socket_1;
  internal byte byte_4;
  internal byte byte_5;
  internal Queue<Class98> queue_0;
  internal Queue<Class98> queue_1;
  internal Thread thread_0;
  internal Class143 class143_0;
  internal DateTime dateTime_0;
  internal uint uint_0;
  internal byte byte_6;
  internal string string_4;
  internal Class133 class133_0;
  internal Class136 class136_0;
  internal Class21 class21_0;
  internal Class76[] class76_0;
  internal Enum10 enum10_0;
  internal HashSet<ushort> hashSet_1;
  internal Class75 class75_0;
  internal bool bool_16;
  internal bool bool_17;
  internal bool bool_18;
  internal int int_5;
  internal HashSet<int> hashSet_2;
  internal HashSet<int> hashSet_3;
  internal Dictionary<string, Class143> dictionary_2;
  internal Dictionary<string, Class143> dictionary_3;
  internal Dictionary<int, Class143> dictionary_4;
  internal Dictionary<string, Class142> dictionary_5;
  internal HashSet<string> hashSet_4;
  internal Dictionary<int, Struct17> dictionary_6;
  internal Class88 class88_0;
  internal Class94 class94_0;
  internal Struct16 struct16_1;
  internal Struct16 struct16_2;
  internal Direction direction_0;
  internal Direction direction_1;
  internal bool bool_19;
  internal bool bool_20;
  internal bool bool_21;
  internal Struct17 struct17_0;
  internal Class25 class25_0;
  internal Class26 class26_0;
  internal Class103 class103_0;
  internal Stack<Struct16> stack_0;
  internal int int_6;
  internal Class109 class109_0;
  internal Struct17 struct17_1;
  internal Stack<Struct17> stack_1;
  internal DateTime dateTime_1;
  internal byte byte_7;
  internal DateTime dateTime_2;
  internal bool bool_22;
  internal Enum5 enum5_0;
  internal TemClass temClass_0;
  internal MedClass medClass_0;
  internal PreviousClass previousClass_0;
  internal Enum0 enum0_0;
  internal Enum1 enum1_0;
  internal ushort ushort_0;
  internal bool bool_23;
  internal bool bool_24;
  internal List<string> list_3;
  internal Dictionary<string, int> dictionary_7;
  internal bool bool_25;
  internal bool bool_26;
  internal Struct12 struct12_0;
  internal Class134 class134_0;
  internal Class142 class142_0;
  internal Struct11 struct11_0;
  internal Class142 class142_1;
  internal bool bool_27;
  internal Dictionary<string, byte> dictionary_8;
  internal List<Class24> list_4;
  internal List<Class17> list_5;
  internal List<Class10> list_6;
  internal Dictionary<string, Class143> dictionary_9;
  internal double double_0;
  internal bool bool_28;
  internal bool bool_29;
  internal Dictionary<string, string> dictionary_10;
  internal List<Class15> list_7;
  internal bool bool_30;
  internal bool bool_31;
  internal bool bool_32;
  internal bool bool_33;
  internal string string_5;
  internal bool bool_34;
  internal bool bool_35;
  internal bool bool_36;
  internal DateTime dateTime_3;
  internal bool bool_37;
  internal bool bool_38;
  internal uint uint_1;
  internal IntPtr intptr_0;
  internal Class134 class134_1;
  internal bool bool_39;
  internal int int_7;
  internal string string_6;
  internal int int_8;
  internal ushort[] ushort_1;
  internal byte byte_8;
  internal DateTime dateTime_4;
  internal bool bool_40;
  internal Dictionary<string, Class20> dictionary_11;
  internal Dictionary<Struct17, Class91> dictionary_12;
  internal bool bool_41;
  internal bool bool_42;
  internal bool bool_43;
  internal Struct5 struct5_0;
  internal Struct5 struct5_1;
  internal int int_9;
  internal int int_10;
  internal bool bool_44;
  internal Enum3 enum3_0;
  internal bool bool_45;
  internal IntPtr intptr_1;
  internal Class16.Struct8 struct8_0;
  internal bool bool_46;
  internal string string_7;
  internal DateTime dateTime_5;
  internal DateTime dateTime_6;
  internal bool bool_47;
  private readonly List<string> list_8;
  internal bool bool_48;
  internal List<string> list_9;
  private Dictionary<string, (int ab, int lv)> dictionary_13;
  private Dictionary<string, int> dictionary_14;
  internal Dictionary<short, Struct16> dictionary_15;

  internal bool Boolean_0
  {
    get
    {
      if (!(this.class88_0?.String_0 != \u003CModule\u003E.smethod_8<string>(3530251009U)) || !(this.class88_0?.String_0 != \u003CModule\u003E.smethod_9<string>(3652436230U)))
        return false;
      Class88 class880_1 = this.class88_0;
      bool? nullable;
      int num1;
      if (class880_1 == null)
      {
        num1 = 0;
      }
      else
      {
        nullable = class880_1.String_0?.Contains(\u003CModule\u003E.smethod_9<string>(55009649U));
        num1 = nullable.GetValueOrDefault() & nullable.HasValue ? 1 : 0;
      }
      if (num1 == 0)
      {
        Class88 class880_2 = this.class88_0;
        int num2;
        if (class880_2 == null)
        {
          num2 = 0;
        }
        else
        {
          nullable = class880_2.String_0?.Contains(\u003CModule\u003E.smethod_6<string>(368662332U));
          num2 = nullable.GetValueOrDefault() & nullable.HasValue ? 1 : 0;
        }
        if (num2 == 0)
        {
          Class88 class880_3 = this.class88_0;
          if (class880_3 == null)
            return false;
          nullable = class880_3.String_0?.Contains(\u003CModule\u003E.smethod_8<string>(3688097322U));
          return nullable.GetValueOrDefault() & nullable.HasValue;
        }
      }
      return true;
    }
  }

  internal bool Boolean_1 => this.Class143_0 != null && (this.method_25((ushort) 89) || this.method_25((ushort) 2)) && this.Class143_0.Boolean_10;

  internal Dictionary<int, Class139> Dictionary_0
  {
    get
    {
      Dictionary<int, Class139> dictionary0 = new Dictionary<int, Class139>();
      if (Monitor.TryEnter(Class112.object_0, 1000))
      {
        try
        {
          dictionary0 = new Dictionary<int, Class139>((IDictionary<int, Class139>) this.dictionary_1);
        }
        finally
        {
          Monitor.Exit(Class112.object_0);
        }
      }
      return dictionary0;
    }
  }

  internal string String_0
  {
    get => this.string_3;
    set => this.string_3 = value;
  }

  internal Control2 Control2_0
  {
    get => this.control2_0;
    set => this.control2_0 = value;
  }

  internal Class112 Class112_0 => this.class112_0;

  internal Class72 Class72_0
  {
    get => this.class72_0;
    set => this.class72_0 = value;
  }

  internal Class143 Class143_0
  {
    get => this.class143_0;
    set => this.class143_0 = value;
  }

  internal uint UInt32_0
  {
    get => this.uint_0;
    set => this.uint_0 = value;
  }

  internal byte Byte_0
  {
    get => this.byte_6;
    set => this.byte_6 = value;
  }

  internal string String_1
  {
    get => this.string_4;
    set => this.string_4 = value;
  }

  internal Enum6 Enum6_0
  {
    get => this.enum6_0;
    set => this.enum6_0 = value;
  }

  internal Class133 Class133_0 => this.class133_0;

  internal Class136 Class136_0 => this.class136_0;

  internal Class21 Class21_0 => this.class21_0;

  internal Class76[] Class76_0 => this.class76_0;

  internal HashSet<ushort> HashSet_0 => this.hashSet_1;

  internal Class75 Class75_0
  {
    get => this.class75_0;
    [param: In] set => this.class75_0 = value;
  }

  internal bool Boolean_2
  {
    get => this.bool_17;
    set => this.bool_17 = value;
  }

  internal bool Boolean_3
  {
    get => this.bool_16;
    set => this.bool_16 = value;
  }

  internal bool Boolean_4
  {
    get => this.bool_18;
    set => this.bool_18 = value;
  }

  internal int Int32_0
  {
    get => this.int_5;
    set => this.int_5 = value;
  }

  internal HashSet<int> HashSet_1 => this.hashSet_2;

  internal HashSet<int> HashSet_2 => this.hashSet_3;

  internal Dictionary<string, Class143> Dictionary_1 => this.dictionary_2;

  internal Dictionary<string, Class143> Dictionary_2 => this.dictionary_3;

  internal Dictionary<string, Class142> Dictionary_3 => this.dictionary_5;

  internal HashSet<string> HashSet_3 => new HashSet<string>((IEnumerable<string>) this.hashSet_4);

  internal Dictionary<int, Struct17> Dictionary_4 => this.dictionary_6;

  internal Dictionary<string, byte> Dictionary_5
  {
    get => this.dictionary_8;
    set => this.dictionary_8 = value;
  }

  internal Class94 Class94_0
  {
    get => this.class94_0;
    set => this.class94_0 = value;
  }

  internal Struct16 Struct16_0
  {
    get => this.struct16_1;
    set => this.struct16_1 = value;
  }

  internal Struct16 Struct16_1
  {
    get => this.struct16_2;
    set => this.struct16_2 = value;
  }

  internal Direction Direction_0
  {
    get => this.direction_0;
    set => this.direction_0 = value;
  }

  internal Direction Direction_1
  {
    get => this.direction_1;
    set => this.direction_1 = value;
  }

  internal Struct17 Struct17_0 => new Struct17(this.class88_0.Int16_0, this.Struct16_0.short_0, this.Struct16_0.short_1);

  internal Struct17 Struct17_1 => new Struct17(this.class88_0.Int16_0, this.Struct16_1.short_0, this.Struct16_1.short_1);

  internal bool Boolean_5
  {
    get => this.bool_19;
    set => this.bool_19 = value;
  }

  internal bool Boolean_6
  {
    get => this.bool_20;
    set => this.bool_20 = value;
  }

  internal bool Boolean_7
  {
    get => this.bool_21;
    set => this.bool_21 = value;
  }

  internal Struct17 Struct17_2
  {
    get => this.struct17_0;
    set => this.struct17_0 = value;
  }

  internal Class25 Class25_0
  {
    get => this.class25_0;
    set => this.class25_0 = value;
  }

  internal Class26 Class26_0 => this.class26_0;

  internal Class103 Class103_0
  {
    get => this.class103_0;
    set => this.class103_0 = value;
  }

  internal int Int32_1
  {
    get => this.int_6;
    set => this.int_6 = value;
  }

  internal byte Byte_1
  {
    get => this.byte_7;
    set => this.byte_7 = value;
  }

  internal DateTime DateTime_0
  {
    get => this.dateTime_2;
    set => this.dateTime_2 = value;
  }

  internal bool Boolean_8
  {
    get => this.bool_22;
    set => this.bool_22 = value;
  }

  internal Enum5 Enum5_0 => this.enum5_0;

  internal Enum0 Enum0_0 => this.enum0_0;

  internal ushort UInt16_0
  {
    get => this.ushort_0;
    set => this.ushort_0 = value;
  }

  internal bool Boolean_9
  {
    get => this.bool_23;
    [param: In] set => this.bool_23 = value;
  }

  internal bool Boolean_10
  {
    get => this.bool_24;
    set => this.bool_24 = value;
  }

  internal List<string> List_0 => this.list_3;

  internal Dictionary<string, int> Dictionary_6 => this.dictionary_7;

  internal bool Boolean_11
  {
    get => this.bool_25;
    set => this.bool_25 = value;
  }

  internal bool Boolean_12
  {
    get => this.bool_26;
    set => this.bool_26 = value;
  }

  internal byte Byte_2
  {
    get => this.struct12_0.byte_7;
    set => this.struct12_0.byte_7 = value;
  }

  internal byte Byte_3
  {
    get => this.struct12_0.byte_0;
    set => this.struct12_0.byte_0 = value;
  }

  internal uint UInt32_1
  {
    get => this.struct12_0.uint_7;
    set => this.struct12_0.uint_7 = value;
  }

  internal uint UInt32_2
  {
    get => this.struct12_0.uint_8;
    set => this.struct12_0.uint_8 = value;
  }

  internal uint UInt32_3
  {
    get => this.struct12_0.uint_1;
    set => this.struct12_0.uint_1 = value;
  }

  internal uint UInt32_4
  {
    get => this.struct12_0.uint_2;
    set => this.struct12_0.uint_2 = value;
  }

  internal byte Byte_4
  {
    get => this.struct12_0.byte_9;
    set => this.struct12_0.byte_9 = value;
  }

  internal byte Byte_5
  {
    get => this.struct12_0.byte_6;
    [param: In] set => this.struct12_0.byte_6 = value;
  }

  internal byte Byte_6
  {
    get => this.struct12_0.byte_11;
    [param: In] set => this.struct12_0.byte_11 = value;
  }

  internal byte Byte_7
  {
    get => this.struct12_0.byte_2;
    [param: In] set => this.struct12_0.byte_2 = value;
  }

  internal byte Byte_8
  {
    get => this.struct12_0.byte_3;
    set => this.struct12_0.byte_3 = value;
  }

  internal bool Boolean_13
  {
    get => this.struct12_0.bool_0;
    set => this.struct12_0.bool_0 = value;
  }

  internal byte Byte_9
  {
    get => this.struct12_0.byte_10;
    [param: In] set => this.struct12_0.byte_10 = value;
  }

  internal short Int16_0
  {
    get => this.struct12_0.short_1;
    [param: In] set => this.struct12_0.short_1 = value;
  }

  internal short Int16_1
  {
    get => this.struct12_0.short_0;
    set => this.struct12_0.short_0 = value;
  }

  internal uint UInt32_5
  {
    get => this.struct12_0.uint_6;
    [param: In] set => this.struct12_0.uint_6 = value;
  }

  internal uint UInt32_6
  {
    get => this.struct12_0.uint_9;
    set => this.struct12_0.uint_9 = value;
  }

  internal uint UInt32_7
  {
    get => this.struct12_0.uint_3;
    [param: In] set => this.struct12_0.uint_3 = value;
  }

  internal uint UInt32_8
  {
    get => this.struct12_0.uint_11;
    set => this.struct12_0.uint_11 = value;
  }

  internal uint UInt32_9
  {
    get => this.struct12_0.uint_0;
    set => this.struct12_0.uint_0 = value;
  }

  internal uint UInt32_10
  {
    get => this.struct12_0.uint_10;
    set => this.struct12_0.uint_10 = value;
  }

  internal uint UInt32_11
  {
    get => this.struct12_0.uint_4;
    set => this.struct12_0.uint_4 = value;
  }

  internal uint UInt32_12
  {
    get => this.struct12_0.uint_5;
    set => this.struct12_0.uint_5 = value;
  }

  internal byte Byte_10
  {
    get => this.struct12_0.byte_1;
    [param: In] set => this.struct12_0.byte_1 = value;
  }

  internal bool Boolean_14 => this.struct12_0.enum4_0.HasFlag((Enum) Enum4.HasLetter);

  internal bool Boolean_15 => this.struct12_0.enum4_0.HasFlag((Enum) Enum4.HasParcel);

  internal Enum3 Enum3_0
  {
    get => this.struct12_0.enum3_1;
    set => this.struct12_0.enum3_1 = value;
  }

  internal Enum3 Enum3_1
  {
    get => this.struct12_0.enum3_0;
    set => this.struct12_0.enum3_0 = value;
  }

  internal byte Byte_11
  {
    get => this.struct12_0.byte_8;
    set => this.struct12_0.byte_8 = value;
  }

  internal sbyte SByte_0
  {
    get => this.struct12_0.sbyte_0;
    [param: In] set => this.struct12_0.sbyte_0 = value;
  }

  internal byte Byte_12
  {
    get => this.struct12_0.byte_4;
    [param: In] set => this.struct12_0.byte_4 = value;
  }

  internal byte Byte_13
  {
    get => this.struct12_0.byte_5;
    [param: In] set => this.struct12_0.byte_5 = value;
  }

  internal Struct12 Struct12_0
  {
    get => this.struct12_0;
    set => this.struct12_0 = value;
  }

  internal Class134 Class134_0
  {
    get => this.class134_0;
    [param: In] set => this.class134_0 = value;
  }

  internal Class142 Class142_0
  {
    get => this.class142_0;
    [param: In] set => this.class142_0 = value;
  }

  internal Struct11 Struct11_0
  {
    get => this.struct11_0;
    [param: In] set => this.struct11_0 = value;
  }

  internal Class142 Class142_1
  {
    get => this.class142_1;
    [param: In] set => this.class142_1 = value;
  }

  internal Dictionary<string, Class143> Dictionary_7
  {
    get => this.dictionary_9;
    set => this.dictionary_9 = value;
  }

  internal Class29(Class112 short_0, [In] Socket obj1)
  {
    Dictionary<string, (int, int)> dictionary = new Dictionary<string, (int, int)>();
    dictionary.Add(\u003CModule\u003E.smethod_6<string>(2699771164U), (0, 14));
    dictionary.Add(\u003CModule\u003E.smethod_5<string>(2796261834U), (0, 11));
    dictionary.Add(\u003CModule\u003E.smethod_5<string>(2005447009U), (60, 99));
    dictionary.Add(\u003CModule\u003E.smethod_8<string>(2513892502U), (95, 99));
    dictionary.Add(\u003CModule\u003E.smethod_9<string>(3487214269U), (0, 11));
    this.dictionary_13 = dictionary;
    this.dictionary_14 = new Dictionary<string, int>()
    {
      {
        \u003CModule\u003E.smethod_9<string>(25063774U),
        11
      },
      {
        \u003CModule\u003E.smethod_8<string>(4247795619U),
        25
      }
    };
    this.dictionary_15 = new Dictionary<short, Struct16>()
    {
      {
        (short) 167,
        new Struct16(6, 6)
      },
      {
        (short) 135,
        new Struct16(6, 6)
      },
      {
        (short) 422,
        new Struct16(6, 6)
      }
    };
    // ISSUE: explicit constructor call
    base.\u002Ector();
    this.byte_0 = new byte[5]
    {
      (byte) 185,
      (byte) 0,
      (byte) 0,
      (byte) 0,
      (byte) 144
    };
    this.dictionary_1 = new Dictionary<int, Class139>();
    this.int_3 = Class138.smethod_2(int.MaxValue);
    this.class112_0 = short_0;
    this.class72_0 = new Class72((byte) 0, \u003CModule\u003E.smethod_7<string>(3297221617U));
    this.socket_0 = obj1;
    this.socket_1 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
    this.queue_0 = new Queue<Class98>();
    this.queue_1 = new Queue<Class98>();
    this.class133_0 = new Class133();
    this.class136_0 = new Class136();
    this.class21_0 = new Class21(60);
    this.class76_0 = new Class76[20];
    this.hashSet_1 = new HashSet<ushort>();
    this.hashSet_2 = new HashSet<int>();
    this.hashSet_3 = new HashSet<int>();
    this.dictionary_2 = new Dictionary<string, Class143>((IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase);
    this.dictionary_3 = new Dictionary<string, Class143>((IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase);
    this.dictionary_5 = new Dictionary<string, Class142>((IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase);
    this.hashSet_4 = new HashSet<string>((IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase);
    this.dictionary_6 = new Dictionary<int, Struct17>();
    this.class26_0 = new Class26(this);
    this.stack_0 = new Stack<Struct16>();
    this.stack_1 = new Stack<Struct17>();
    this.class109_0 = new Class109(this.class112_0, this);
    this.ushort_0 = (ushort) 1;
    this.list_3 = new List<string>();
    this.dictionary_7 = new Dictionary<string, int>((IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase);
    this.dictionary_9 = new Dictionary<string, Class143>();
    this.dictionary_10 = new Dictionary<string, string>();
    this.enum0_0 |= Enum0.NoBlind;
    this.enum0_0 |= Enum0.SeeHidden;
    this.string_0 = "";
    this.string_1 = "";
    this.timer_0 = new System.Windows.Forms.Timer() { Interval = 1000 };
    this.timer_0.Tick += new EventHandler(this.timer_0_Tick);
    this.dictionary_11 = new Dictionary<string, Class20>();
    this.bool_40 = false;
    this.dictionary_4 = new Dictionary<int, Class143>();
    this.dictionary_12 = new Dictionary<Struct17, Class91>();
    this.struct16_0 = new Struct16();
  }

  private void method_0()
  {
    Thread.GetDomain().UnhandledException += new UnhandledExceptionEventHandler(Class106.smethod_0);
    while (this.bool_15)
    {
      lock (this.queue_0)
      {
        while (this.queue_0.Count > 0)
        {
          Class98 class98 = this.queue_0.Dequeue();
          Socket state;
          if (class98 is Class99 class99)
          {
            if (this.control2_0 != null && !this.control2_0.IsDisposed)
              this.control2_0.method_30(class99);
            if (class99.Boolean_1)
              class99.method_30();
            if (class99.Byte_2 == (byte) 98)
              this.byte_4 = class99.Byte_0;
            if (class99.Boolean_0)
            {
              class99.Byte_0 = this.byte_4++;
              ((Class98) class99).Class98\u002E‪⁭‏⁬‏‎​⁪⁮‎‬‪‪‏⁭‬⁬‪‮‏‍‮⁮⁭‌‌‌⁪‍‍‎‮‌‬⁬‮‏‌‏‎‮(this.class72_0);
            }
            state = this.socket_1;
          }
          else
          {
            Class100 sender = (Class100) class98;
            if (this.control2_0 != null && !this.control2_0.IsDisposed)
              this.control2_0.method_31(sender);
            if (sender.Boolean_0)
            {
              sender.Byte_0 = this.byte_5++;
              ((Class98) sender).Class98\u002E‪⁭‏⁬‏‎​⁪⁮‎‬‪‪‏⁭‬⁬‪‮‏‍‮⁮⁭‌‌‌⁪‍‍‎‮‌‬⁬‮‏‌‏‎‮(this.class72_0);
            }
            state = this.socket_0;
          }
          byte[] buffer = class98.method_26();
          try
          {
            state.BeginSend(buffer, 0, buffer.Length, SocketFlags.None, new AsyncCallback(this.method_3), (object) state);
          }
          catch (Exception ex)
          {
            string path = AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_9<string>(3506060353U);
            if (!Directory.Exists(path))
              Directory.CreateDirectory(path);
            System.IO.File.WriteAllText(path + DateTime.Now.ToString(\u003CModule\u003E.smethod_8<string>(1153121583U)) + \u003CModule\u003E.smethod_6<string>(1410502500U), ex.ToString());
          }
        }
      }
      lock (this.queue_1)
      {
        while (this.queue_1.Count > 0)
        {
          Class98 string_0 = this.queue_1.Dequeue();
          if (string_0.Boolean_0)
            string_0.Class98\u002E‏‫‮​⁪‭‎⁬⁫‍⁪‌‍‏‏⁯⁯‭‫⁫‬‪‬‌‌‪⁯⁮‮⁭⁬‏⁬‮‭⁪‮‭‎⁭‮(this.class72_0);
          bool flag = true;
          if (string_0 is Class99 class99)
          {
            if (class99.Boolean_1)
              class99.method_31();
            Delegate2 delegate2 = this.class112_0.Delegate2_0[(int) class99.Byte_2];
            if (delegate2 != null)
            {
              lock (Class112.object_0)
              {
                try
                {
                  flag = delegate2(this, class99);
                }
                catch
                {
                  flag = false;
                }
              }
            }
          }
          else if (string_0 is Class100)
          {
            Delegate3 delegate3 = this.class112_0.Delegate3_0[(int) string_0.Byte_2];
            if (delegate3 != null)
            {
              lock (Class112.object_0)
              {
                try
                {
                  flag = delegate3(this, (Class100) string_0);
                }
                catch
                {
                  flag = false;
                }
              }
            }
          }
          if (flag)
            this.method_4(new Class98[1]{ string_0 });
        }
      }
      Thread.Sleep(5);
    }
    if (this.class25_0 != null)
      this.class25_0.method_1();
    foreach (Class29 class29 in this.Class112_0.IEnumerable_0)
    {
      if (class29.String_0 != this.String_0 && class29.Class26_0?.control3_1 != null)
        class29.Class26_0.method_43(this.String_0);
    }
    try
    {
      this.socket_0.Disconnect(false);
      this.socket_1.Disconnect(false);
    }
    catch
    {
    }
    if (this.bool_45)
      this.Class112_0.form5_0.form2_0.method_1();
    try
    {
      if (!Class137.IsWindowVisible(Process.GetProcessById(this.int_4).MainWindowHandle))
      {
        if (this.int_4 != 0)
          Process.GetProcessById(this.int_4).Kill();
      }
    }
    catch
    {
    }
    try
    {
      Class137.SetForegroundWindow((int) this.intptr_0);
      Class137.ShowWindow(this.intptr_0, 1U);
      this.method_45(Process.GetProcessById(this.int_4).MainWindowHandle);
    }
    catch
    {
    }
    List<Class145> class145List = this.Class26_0.method_4();
    List<Class177> class177List = this.Class26_0.method_3();
    this.Class26_0.control4_0?.Dispose();
    this.Class26_0.control3_1?.Dispose();
    Thread.Sleep(500);
    foreach (Class145 class145 in class145List)
    {
      Control3 control30_1 = class145.Control3_0;
      if ((control30_1 != null ? (!control30_1.IsDisposed ? 1 : 0) : 0) != 0)
      {
        Control3 control30_2 = class145.Control3_0;
        if ((control30_2 != null ? (!control30_2.Disposing ? 1 : 0) : 0) != 0)
          class145.Control3_0.Dispose();
      }
    }
    foreach (Class177 class177 in class177List)
    {
      Control4 control40_1 = class177.Control4_0;
      if ((control40_1 != null ? (!control40_1.IsDisposed ? 1 : 0) : 0) != 0)
      {
        Control4 control40_2 = class177.Control4_0;
        if ((control40_2 != null ? (!control40_2.Disposing ? 1 : 0) : 0) != 0)
          class177.Control4_0.Dispose();
      }
    }
    this.Control2_0?.form3_0?.Dispose();
    this.Class112_0.list_2.Remove(this);
    Thread.Sleep(100);
    this.class25_0 = (Class25) null;
    this.class26_0 = (Class26) null;
    this.Class112_0.form5_0.method_3(this);
  }

  private void method_1([In] IAsyncResult obj0)
  {
    try
    {
      int length = this.socket_0.EndReceive(obj0);
      if (length == 0)
      {
        this.method_6(false);
      }
      else
      {
        byte[] numArray = new byte[length];
        Array.Copy((Array) this.byte_2, (Array) numArray, length);
        this.list_1.AddRange((IEnumerable<byte>) numArray);
        while (this.list_1.Count > 3)
        {
          int count = ((int) this.list_1[1] << 8) + (int) this.list_1[2] + 3;
          if (count <= this.list_1.Count)
          {
            List<byte> range = this.list_1.GetRange(0, count);
            this.list_1.RemoveRange(0, count);
            Class99 class99 = new Class99(range.ToArray());
            lock (this.queue_1)
              this.queue_1.Enqueue((Class98) class99);
          }
          else
            break;
        }
        this.socket_0.BeginReceive(this.byte_2, 0, this.byte_2.Length, SocketFlags.None, new AsyncCallback(this.method_1), (object) null);
      }
    }
    catch
    {
      this.method_6(false);
    }
  }

  private void method_2(IAsyncResult class142_2)
  {
    try
    {
      int length = this.socket_1.EndReceive(class142_2);
      if (length == 0)
      {
        this.method_6(false);
      }
      else
      {
        byte[] numArray = new byte[length];
        Array.Copy((Array) this.byte_3, (Array) numArray, length);
        this.list_2.AddRange((IEnumerable<byte>) numArray);
        while (this.list_2.Count > 3)
        {
          int count = ((int) this.list_2[1] << 8) + (int) this.list_2[2] + 3;
          if (count <= this.list_2.Count)
          {
            List<byte> range = this.list_2.GetRange(0, count);
            this.list_2.RemoveRange(0, count);
            Class100 class100 = new Class100(range.ToArray());
            lock (this.queue_1)
              this.queue_1.Enqueue((Class98) class100);
          }
          else
            break;
        }
        this.socket_1.BeginReceive(this.byte_3, 0, this.byte_3.Length, SocketFlags.None, new AsyncCallback(this.method_2), (object) null);
      }
    }
    catch (Exception ex)
    {
      this.method_6(false);
    }
  }

  private void method_3(IAsyncResult class142_2) => ((Socket) class142_2.AsyncState).EndSend(class142_2);

  internal void method_4(Class98[] string_8)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class29.Class30 class30 = new Class29.Class30();
    // ISSUE: reference to a compiler-generated field
    class30.class29_0 = this;
    // ISSUE: reference to a compiler-generated field
    class30.class98_0 = string_8;
    if (Thread.CurrentThread.ManagedThreadId == Class106.Form5_0.Int32_0)
    {
      // ISSUE: reference to a compiler-generated method
      ThreadPool.QueueUserWorkItem(new WaitCallback(class30.method_0));
    }
    else
    {
      lock (this.queue_0)
      {
        // ISSUE: reference to a compiler-generated field
        foreach (Class98 class98 in class30.class98_0)
          this.queue_0.Enqueue(class98);
      }
    }
  }

  internal void method_5(EndPoint string_8)
  {
    this.socket_1.Connect(string_8);
    this.bool_15 = true;
    this.socket_0.BeginReceive(this.byte_2, 0, this.byte_2.Length, SocketFlags.None, new AsyncCallback(this.method_1), (object) null);
    this.socket_1.BeginReceive(this.byte_3, 0, this.byte_3.Length, SocketFlags.None, new AsyncCallback(this.method_2), (object) null);
    this.thread_0 = new Thread(new ThreadStart(this.method_0));
    this.thread_0.Start();
  }

  internal void method_6([In] bool obj0)
  {
    this.bool_15 = false;
    if (!obj0)
      return;
    this.thread_0.Join(1000);
    if (!this.thread_0.IsAlive)
      return;
    this.thread_0.Abort();
  }

  internal bool method_7(Enum10 byte_9) => this.enum10_0.HasFlag((Enum) byte_9);

  internal void method_8([In] Enum10 obj0)
  {
    if (this.method_7(obj0))
      return;
    this.enum10_0 |= obj0;
  }

  internal void method_9(Enum10 byte_9) => this.enum10_0 &= ~byte_9;

  internal bool method_10([In] Enum5 obj0) => this.enum5_0.HasFlag((Enum) obj0);

  internal void method_11([In] TemClass obj0) => this.temClass_0 |= obj0;

  internal void method_12(MedClass byte_9) => this.medClass_0 |= byte_9;

  internal void method_13([In] PreviousClass obj0) => this.previousClass_0 |= obj0;

  internal void method_14([In] Enum1 obj0) => this.enum1_0 |= obj0;

  internal void method_15(Enum5 int_11) => this.enum5_0 |= int_11;

  internal void method_16(Enum5 byte_9) => this.enum5_0 &= ~byte_9;

  internal bool method_17([In] Enum0 obj0) => this.enum0_0.HasFlag((Enum) obj0);

  internal void method_18([In] Enum0 obj0) => this.enum0_0 |= obj0;

  internal void method_19([In] Enum0 obj0) => this.enum0_0 &= ~obj0;

  internal void method_20([In] Enum9 obj0) => this.method_21(obj0, this.struct12_0);

  internal void method_21([In] Enum9 obj0, [In] Struct12 obj1)
  {
    Class100 class100 = new Class100((byte) 8);
    if (this.method_17(Enum0.GmMode))
      obj0 |= Enum9.GameMasterA;
    if (obj1.enum4_0 != (Enum4) 0)
      obj0 |= Enum9.UnreadMail | Enum9.Secondary;
    class100.method_14((byte) obj0);
    if (obj0.HasFlag((Enum) Enum9.Primary))
    {
      class100.method_13(new byte[3]);
      class100.method_14(obj1.byte_7);
      class100.method_14(obj1.byte_0);
      class100.method_20(obj1.uint_7);
      class100.method_20(obj1.uint_8);
      class100.method_14(obj1.byte_9);
      class100.method_14(obj1.byte_6);
      class100.method_14(obj1.byte_11);
      class100.method_14(obj1.byte_2);
      class100.method_14(obj1.byte_3);
      class100.method_16(obj1.bool_0);
      class100.method_14(obj1.byte_10);
      class100.method_17(obj1.short_1);
      class100.method_17(obj1.short_0);
      class100.method_13(new byte[4]);
    }
    if (obj0.HasFlag((Enum) Enum9.Current))
    {
      class100.method_20(obj1.uint_6);
      class100.method_20(obj1.uint_9);
    }
    if (obj0.HasFlag((Enum) Enum9.Experience))
    {
      class100.method_20(obj1.uint_3);
      class100.method_20(obj1.uint_11);
      class100.method_20(obj1.uint_0);
      class100.method_20(obj1.uint_10);
      class100.method_20(obj1.uint_4);
      class100.method_20(obj1.uint_5);
    }
    if (obj0.HasFlag((Enum) Enum9.Secondary))
    {
      class100.method_13(new byte[1]);
      if (this.method_17(Enum0.NoBlind) && !this.Boolean_0)
        class100.method_14((byte) 0);
      else
        class100.method_14(obj1.byte_1);
      class100.method_13(new byte[4]);
      class100.method_14((byte) obj1.enum3_1);
      class100.method_14((byte) obj1.enum3_0);
      class100.method_14(obj1.byte_8);
      class100.method_13(new byte[1]);
      class100.method_15(obj1.sbyte_0);
      class100.method_14(obj1.byte_4);
      class100.method_14(obj1.byte_5);
    }
    this.method_4(new Class98[1]{ (Class98) class100 });
  }

  internal bool method_22([In] string obj0) => this.class21_0.method_0(obj0);

  internal bool method_23([In] string obj0) => this.class133_0[obj0] != null;

  internal bool method_24([In] string obj0) => this.class136_0[obj0] != null;

  internal bool method_25([In] ushort obj0) => this.hashSet_1.Contains(obj0);

  internal int method_26([In] string obj0)
  {
    int num = 0;
    foreach (Class76 class76 in this.class21_0)
    {
      if (class76 != null && class76.String_0.Equals(obj0, StringComparison.CurrentCultureIgnoreCase))
        num += class76.Int32_0;
    }
    return num;
  }

  internal bool method_27([In] Class76 obj0) => !this.method_7(Enum10.Pramh) && !this.method_7(Enum10.Suain);

  internal bool method_28([In] Class132 obj0) => obj0.Boolean_0 && this.class88_0.Boolean_0 && !this.method_7(Enum10.Pramh) && !this.method_7(Enum10.Suain);

  internal bool method_29([In] string obj0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class29.Class31 class31 = new Class29.Class31();
    // ISSUE: reference to a compiler-generated field
    class31.string_0 = obj0;
    // ISSUE: reference to a compiler-generated field
    class31.class29_0 = this;
    // ISSUE: reference to a compiler-generated method
    Class76 class76 = this.Class21_0.FirstOrDefault<Class76>(new Func<Class76, bool>(class31.method_0));
    if (class76 == null || this.method_7(Enum10.Pramh) || this.method_7(Enum10.Suain) || this.Class112_0.bool_1)
      return false;
    Class99 class99 = new Class99((byte) 28);
    class99.method_14(class76.Byte_0);
    class76.DateTime_0 = DateTime.UtcNow;
    // ISSUE: reference to a compiler-generated field
    this.string_1 = class31.string_0;
    // ISSUE: reference to a compiler-generated field
    if (class31.string_0 == \u003CModule\u003E.smethod_9<string>(1142886036U))
    {
      // ISSUE: reference to a compiler-generated method
      ThreadPool.QueueUserWorkItem(new WaitCallback(class31.method_1));
    }
    // ISSUE: reference to a compiler-generated field
    this.Control2_0.label_5.Text = this.string_7 + \u003CModule\u003E.smethod_6<string>(712473005U) + class31.string_0;
    this.method_4(new Class98[1]{ (Class98) class99 });
    // ISSUE: reference to a compiler-generated field
    string string0 = class31.string_0;
    if (!(string0 == \u003CModule\u003E.smethod_8<string>(1099629030U)))
    {
      if (string0 == \u003CModule\u003E.smethod_9<string>(3839857773U))
      {
        foreach (Class143 class143 in this.method_127())
        {
          if (class143 != this.Class143_0)
          {
            class143.Dictionary_0[(ushort) 117] = DateTime.UtcNow.Subtract(new TimeSpan(0, 0, 5));
            class143.Dictionary_0[(ushort) 32] = DateTime.UtcNow.Subtract(new TimeSpan(0, 0, 5));
          }
        }
      }
    }
    else
    {
      foreach (Class143 class143 in this.method_127())
      {
        Dictionary<ushort, DateTime> dictionary0_1 = class143.Dictionary_0;
        DateTime utcNow = DateTime.UtcNow;
        DateTime dateTime1 = utcNow.Subtract(new TimeSpan(0, 0, 5));
        dictionary0_1[(ushort) 25] = dateTime1;
        Dictionary<ushort, DateTime> dictionary0_2 = class143.Dictionary_0;
        utcNow = DateTime.UtcNow;
        DateTime dateTime2 = utcNow.Subtract(new TimeSpan(0, 0, 5));
        dictionary0_2[(ushort) 247] = dateTime2;
        Dictionary<ushort, DateTime> dictionary0_3 = class143.Dictionary_0;
        utcNow = DateTime.UtcNow;
        DateTime dateTime3 = utcNow.Subtract(new TimeSpan(0, 0, 5));
        dictionary0_3[(ushort) 295] = dateTime3;
      }
    }
    // ISSUE: reference to a compiler-generated field
    if (class31.string_0 == \u003CModule\u003E.smethod_5<string>(4101272835U))
    {
      if (this.byte_8 <= (byte) 1)
      {
        ++this.byte_8;
        this.dateTime_4 = DateTime.UtcNow;
      }
    }
    else
    {
      // ISSUE: reference to a compiler-generated field
      if (class31.string_0 == \u003CModule\u003E.smethod_8<string>(2059863638U) && this.byte_8 <= (byte) 2)
      {
        ++this.byte_8;
        this.dateTime_4 = DateTime.UtcNow;
      }
    }
    // ISSUE: reference to a compiler-generated field
    this.method_32(class31.string_0);
    return true;
  }

  internal bool method_30([In] string obj0)
  {
    Class132 class132 = this.class133_0[obj0];
    if (class132 == null || !this.method_28(class132))
      return false;
    Class99 class99 = new Class99((byte) 62);
    class99.method_14(class132.Byte_0);
    class132.DateTime_0 = DateTime.UtcNow;
    if (this.string_0 != obj0)
    {
      this.string_0 = obj0;
      if (obj0 == \u003CModule\u003E.smethod_9<string>(2898357263U))
        ThreadPool.QueueUserWorkItem((WaitCallback) delegate
        {
          this.Control2_0.method_24();
        });
      this.Control2_0.label_5.Text = this.string_7 + \u003CModule\u003E.smethod_5<string>(1387935189U) + obj0;
    }
    this.method_4(new Class98[1]{ (Class98) class99 });
    return true;
  }

  internal bool method_31(string class143_1, [In] Class142 obj1, [In] bool obj2, [In] bool obj3)
  {
    lock (this.object_0)
    {
      Class134 class134 = this.class136_0[class143_1];
      if (class134 == null || !this.method_41(class134, obj1) || class143_1 != \u003CModule\u003E.smethod_8<string>(1579746334U) && class143_1 != \u003CModule\u003E.smethod_7<string>(3782363812U) && this.Class112_0.bool_1)
        return false;
      byte byte2 = class134.Byte_2;
      if (obj2 && this.method_40(class134, ref byte2) && !this.method_41(class134, obj1))
        return false;
      if (this.class134_1 != class134)
        this.Control2_0.label_5.Text = this.string_7 + \u003CModule\u003E.smethod_5<string>(3947490391U) + class143_1;
      Class99 class99_1 = new Class99((byte) 15);
      class99_1.method_14(class134.Byte_0);
      if (obj1 != null && this.hashSet_2.Contains(obj1.Int32_0))
      {
        class99_1.method_19(obj1.Int32_0);
        class99_1.method_24(obj1.Struct16_0);
      }
      if (byte2 > (byte) 0)
      {
        if (this.Boolean_4)
        {
          this.Boolean_3 = false;
          return false;
        }
        string[] strArray = this.method_136(class143_1);
        lock (this.object_1)
        {
          this.Boolean_3 = true;
          Class99 class99_2 = new Class99((byte) 77);
          class99_2.method_14(byte2);
          this.method_4(new Class98[1]
          {
            (Class98) class99_2
          });
          for (int index = 0; index < (int) byte2; ++index)
          {
            if (this.Control2_0.checkBox_72.Checked)
              this.method_58(\u003CModule\u003E.smethod_5<string>(2854823517U));
            else if (!string.IsNullOrWhiteSpace(this.Control2_0.textBox_12.Text) && !this.class26_0.bool_17)
              this.method_58(this.method_134());
            else if (!string.IsNullOrWhiteSpace(strArray[index]))
              this.method_58(strArray[index]);
            DateTime utcNow = DateTime.UtcNow;
            Class29 int_11 = obj1 != null ? this.Class112_0.method_75(obj1.String_0) : this;
            while (DateTime.UtcNow.Subtract(utcNow).TotalMilliseconds < 1000.0)
            {
              if (this.method_33(int_11, class134.String_0, obj1))
              {
                Thread.Sleep(10);
              }
              else
              {
                this.Boolean_3 = false;
                return false;
              }
            }
            if (!this.Boolean_3 || !this.method_41(class134, obj1))
            {
              this.Boolean_3 = false;
              return false;
            }
          }
          if (this.Control2_0.checkBox_72.Checked)
          {
            this.method_58(\u003CModule\u003E.smethod_6<string>(899990565U));
          }
          else
          {
            if (class134.String_0 == \u003CModule\u003E.smethod_7<string>(1620883916U) && !this.Class26_0.bool_4 && !this.Class26_0.bool_12)
            {
              this.Boolean_3 = false;
              return false;
            }
            this.method_58(class134.String_0);
          }
        }
      }
      int result;
      if (class134.String_0 == \u003CModule\u003E.smethod_6<string>(2118940144U) && this.Control2_0.checkBox_89.Checked && (int.TryParse(this.Control2_0.textBox_21.Text, out result) ? ((long) this.UInt32_5 < (long) result ? 1 : 0) : ((double) this.UInt32_5 < (double) this.UInt32_2 * 0.5 ? 1 : 0)) != 0)
      {
        this.Boolean_3 = false;
        return false;
      }
      this.class142_0 = obj1 ?? (Class142) this.Class143_0;
      if (this.method_32(class134.String_0))
        this.list_7.Add(new Class15(class134, this.Class142_0));
      this.method_4(new Class98[1]{ (Class98) class99_1 });
      ++this.int_1;
      this.Class26_0.dateTime_4 = DateTime.UtcNow;
      class134.DateTime_0 = DateTime.UtcNow;
      this.Boolean_3 = false;
      this.class134_0 = obj3 ? class134 : (Class134) null;
      if (class134.String_0 != \u003CModule\u003E.smethod_9<string>(4282338902U) || class134.String_0.Contains(\u003CModule\u003E.smethod_9<string>(2095486337U)))
        this.class134_1 = class134;
      return !obj3 || this.method_34();
    }
  }

  private bool method_32(string class142_2)
  {
    try
    {
      // ISSUE: reference to a compiler-generated method
      switch (Class181.smethod_0(class142_2))
      {
        case 72064257:
          if (class142_2 == \u003CModule\u003E.smethod_5<string>(38170227U))
            goto label_86;
          else
            goto default;
        case 107956092:
          if (class142_2 == \u003CModule\u003E.smethod_7<string>(1241470794U))
            goto label_39;
          else
            goto default;
        case 195270534:
          if (class142_2 == \u003CModule\u003E.smethod_5<string>(2712466751U))
          {
            foreach (Class143 class143 in this.method_127())
            {
              class143.Dictionary_0[(ushort) 117] = DateTime.MinValue;
              class143.Dictionary_0[(ushort) 32] = DateTime.MinValue;
            }
            return false;
          }
          goto default;
        case 219207967:
          if (class142_2 == \u003CModule\u003E.smethod_5<string>(719956569U))
            goto label_65;
          else
            goto default;
        case 249286892:
          if (class142_2 == \u003CModule\u003E.smethod_9<string>(3085778806U))
            goto label_86;
          else
            goto default;
        case 291448073:
          if (class142_2 == \u003CModule\u003E.smethod_6<string>(569211438U))
            goto label_51;
          else
            goto default;
        case 420187390:
          if (class142_2 == \u003CModule\u003E.smethod_7<string>(666110200U))
            goto label_39;
          else
            goto default;
        case 443271170:
          if (class142_2 == \u003CModule\u003E.smethod_5<string>(3265704049U))
            goto label_51;
          else
            goto default;
        case 674409180:
          if (class142_2 == \u003CModule\u003E.smethod_6<string>(832294877U))
            goto label_49;
          else
            goto default;
        case 810175405:
          if (!(class142_2 == \u003CModule\u003E.smethod_5<string>(2966234044U)))
            goto default;
          else
            break;
        case 894297607:
          if (class142_2 == \u003CModule\u003E.smethod_7<string>(2329966079U))
            break;
          goto default;
        case 928817768:
          if (class142_2 == \u003CModule\u003E.smethod_8<string>(967871157U))
            goto label_65;
          else
            goto default;
        case 1046347411:
          if (class142_2 == \u003CModule\u003E.smethod_5<string>(4271245045U))
          {
            if (!this.Class142_0.Boolean_4)
              this.Class142_0.Dictionary_0[(ushort) 40] = DateTime.UtcNow.Subtract(new TimeSpan(0, 0, 0, 3, 500));
            return true;
          }
          goto default;
        case 1149628551:
          if (class142_2 == \u003CModule\u003E.smethod_7<string>(1648876412U))
            goto label_65;
          else
            goto default;
        case 1154413499:
          if (class142_2 == \u003CModule\u003E.smethod_8<string>(620827399U))
            goto label_39;
          else
            goto default;
        case 1281358573:
          if (class142_2 == \u003CModule\u003E.smethod_6<string>(2249170165U))
            goto label_65;
          else
            goto default;
        case 1484963323:
          if (class142_2 == \u003CModule\u003E.smethod_7<string>(420418647U))
            goto label_86;
          else
            goto default;
        case 1645955527:
          if (class142_2 == \u003CModule\u003E.smethod_8<string>(4275199732U))
            goto label_86;
          else
            goto default;
        case 1928539694:
          if (class142_2 == \u003CModule\u003E.smethod_9<string>(2860665095U))
            goto label_65;
          else
            goto default;
        case 2030226177:
          if (class142_2 == \u003CModule\u003E.smethod_9<string>(3674635812U))
          {
            if (this.Class142_0.Dictionary_0.ContainsKey((ushort) 20))
            {
              DateTime utcNow = DateTime.UtcNow;
              if (utcNow.Subtract(this.Class142_0.Dictionary_0[(ushort) 20]).TotalMinutes < 2.5)
              {
                Dictionary<ushort, DateTime> dictionary0 = this.Class142_0.Dictionary_0;
                utcNow = DateTime.UtcNow;
                DateTime dateTime = utcNow.Subtract(new TimeSpan(0, 2, 25));
                dictionary0[(ushort) 20] = dateTime;
              }
            }
            return true;
          }
          goto default;
        case 2112563240:
          if (class142_2 == \u003CModule\u003E.smethod_9<string>(3292046433U))
            goto label_51;
          else
            goto default;
        case 2118188214:
          if (class142_2 == \u003CModule\u003E.smethod_8<string>(1688047113U))
            goto label_65;
          else
            goto default;
        case 2454795333:
          if (!(class142_2 == \u003CModule\u003E.smethod_7<string>(2006537949U)))
            goto default;
          else
            goto label_39;
        case 2476745328:
          if (class142_2 == \u003CModule\u003E.smethod_5<string>(3478048176U))
            goto label_86;
          else
            goto default;
        case 2579487986:
          if (class142_2 == \u003CModule\u003E.smethod_6<string>(311374793U))
          {
            if (!this.Class142_0.Boolean_6)
              this.Class142_0.Dictionary_0[(ushort) 117] = DateTime.UtcNow.Subtract(new TimeSpan(0, 0, 0, 3, 500));
            return true;
          }
          goto default;
        case 2592944103:
          if (class142_2 == \u003CModule\u003E.smethod_8<string>(2007686758U))
            goto label_86;
          else
            goto default;
        case 2647647615:
          if (class142_2 == \u003CModule\u003E.smethod_7<string>(2771605104U))
            goto label_80;
          else
            goto default;
        case 2756163491:
          if (class142_2 == \u003CModule\u003E.smethod_8<string>(1099629030U))
          {
            foreach (Class143 class143 in this.method_127())
            {
              class143.Dictionary_0[(ushort) 25] = DateTime.MinValue;
              class143.Dictionary_0[(ushort) 247] = DateTime.MinValue;
              class143.Dictionary_0[(ushort) 295] = DateTime.MinValue;
            }
            return false;
          }
          goto default;
        case 2761324515:
          if (!(class142_2 == \u003CModule\u003E.smethod_6<string>(3053989986U)))
            goto default;
          else
            goto label_51;
        case 2793184655:
          if (!(class142_2 == \u003CModule\u003E.smethod_7<string>(28523703U)))
            goto default;
          else
            goto label_49;
        case 2848971440:
          if (!(class142_2 == \u003CModule\u003E.smethod_5<string>(3092401044U)))
            goto default;
          else
            goto label_65;
        case 2983429004:
          if (class142_2 == \u003CModule\u003E.smethod_7<string>(1614643005U))
            goto label_76;
          else
            goto default;
        case 2996522388:
          if (class142_2 == \u003CModule\u003E.smethod_7<string>(442170232U))
          {
            this.Class142_0.Dictionary_0[(ushort) 25] = DateTime.MinValue;
            this.Class142_0.Dictionary_0[(ushort) 247] = DateTime.MinValue;
            this.Class142_0.Dictionary_0[(ushort) 295] = DateTime.MinValue;
            return false;
          }
          goto default;
        case 3000206623:
          if (class142_2 == \u003CModule\u003E.smethod_8<string>(2226919662U))
            goto label_76;
          else
            goto default;
        case 3050539480:
          if (class142_2 == \u003CModule\u003E.smethod_8<string>(2760529519U))
            goto label_76;
          else
            goto default;
        case 3067317099:
          if (class142_2 == \u003CModule\u003E.smethod_8<string>(1506743706U))
            goto label_76;
          else
            goto default;
        case 3084094718:
          if (class142_2 == \u003CModule\u003E.smethod_6<string>(2642483625U))
            goto label_76;
          else
            goto default;
        case 3100872337:
          if (class142_2 == \u003CModule\u003E.smethod_9<string>(667105534U))
            goto label_76;
          else
            goto default;
        case 3134427575:
          if (!(class142_2 == \u003CModule\u003E.smethod_5<string>(3544704742U)))
            goto default;
          else
            goto label_76;
        case 3151205194:
          if (class142_2 == \u003CModule\u003E.smethod_7<string>(1123259899U))
            goto label_76;
          else
            goto default;
        case 3167982813:
          if (class142_2 == \u003CModule\u003E.smethod_8<string>(4254373984U))
            goto label_76;
          else
            goto default;
        case 3219892635:
          if (class142_2 == \u003CModule\u003E.smethod_7<string>(638117704U))
            goto label_86;
          else
            goto default;
        case 3740145550:
          if (class142_2 == \u003CModule\u003E.smethod_5<string>(828985052U))
            goto label_86;
          else
            goto default;
        case 3777649476:
          if (!(class142_2 == \u003CModule\u003E.smethod_5<string>(1960693048U)))
            goto default;
          else
            goto label_80;
        default:
          return false;
      }
      this.Class142_0.Dictionary_0[(ushort) 40] = DateTime.MinValue;
      return false;
label_39:
      if (!this.Class142_0.Boolean_2)
      {
        this.Class142_0.DateTime_2 = DateTime.UtcNow;
        this.Class142_0.Double_1 = 2.0;
      }
      return true;
label_49:
      this.Class26_0.bool_4 = true;
      return false;
label_51:
      if (!this.Class142_0.Boolean_3)
      {
        this.Class142_0.DateTime_3 = DateTime.UtcNow;
        this.Class142_0.Double_2 = 2.0;
      }
      return true;
label_65:
      if (!this.Class142_0.Boolean_1)
      {
        this.Class142_0.DateTime_1 = DateTime.UtcNow;
        this.Class142_0.Double_0 = 0.3;
        this.Class142_0.String_1 = class142_2;
      }
      return true;
label_76:
      if (!this.Class142_0.Boolean_5)
        this.Class142_0.Dictionary_0[(ushort) 235] = DateTime.UtcNow.Subtract(new TimeSpan(0, 0, 0, 1));
      return true;
label_80:
      if (!this.Class142_0.Boolean_6)
        this.Class142_0.Dictionary_0[(ushort) 32] = DateTime.UtcNow.Subtract(new TimeSpan(0, 0, 0, 3, 500));
      return true;
label_86:
      return true;
    }
    catch
    {
      return false;
    }
  }

  private bool method_33(Class29 int_11, [In] string obj1, [In] Class142 obj2)
  {
    if (this.method_7(Enum10.Suain) && (int_11 == null || obj1 != \u003CModule\u003E.smethod_6<string>(548395140U) && obj1 != \u003CModule\u003E.smethod_9<string>(813481411U)))
      return false;
    if (!this.class88_0.String_0.Contains(\u003CModule\u003E.smethod_5<string>(1345563272U)))
    {
      // ISSUE: reference to a compiler-generated method
      switch (Class181.smethod_0(obj1))
      {
        case 107956092:
          if (obj1 == \u003CModule\u003E.smethod_8<string>(1287510802U))
            break;
          goto label_62;
        case 219207967:
          if (obj1 == \u003CModule\u003E.smethod_6<string>(2095500449U))
            goto label_40;
          else
            goto label_62;
        case 291448073:
          if (obj1 == \u003CModule\u003E.smethod_5<string>(4159834518U))
            goto label_31;
          else
            goto label_62;
        case 420187390:
          if (obj1 == \u003CModule\u003E.smethod_9<string>(516336862U))
            break;
          goto label_62;
        case 443271170:
          if (obj1 == \u003CModule\u003E.smethod_9<string>(4252393027U))
            goto label_31;
          else
            goto label_62;
        case 810175405:
          if (obj1 == \u003CModule\u003E.smethod_9<string>(3589190982U))
          {
            if (int_11 != null)
            {
              if (!int_11.method_7(Enum10.Suain))
                return false;
              goto label_62;
            }
            else
            {
              if (obj2 != null && !obj2.Boolean_4)
                return false;
              goto label_62;
            }
          }
          else
            goto label_62;
        case 928817768:
          if (obj1 == \u003CModule\u003E.smethod_9<string>(4233546943U))
            goto label_40;
          else
            goto label_62;
        case 1046347411:
          if (obj1 == \u003CModule\u003E.smethod_9<string>(2520160679U) && obj2 != null && obj2.Boolean_4)
            return false;
          goto label_62;
        case 1149628551:
          if (obj1 == \u003CModule\u003E.smethod_5<string>(186239832U))
            goto label_40;
          else
            goto label_62;
        case 1154413499:
          if (obj1 == \u003CModule\u003E.smethod_6<string>(3184220007U))
            break;
          goto label_62;
        case 1281358573:
          if (obj1 == \u003CModule\u003E.smethod_5<string>(848505613U))
            goto label_40;
          else
            goto label_62;
        case 1928539694:
          if (obj1 == \u003CModule\u003E.smethod_5<string>(3626117781U))
            goto label_40;
          else
            goto label_62;
        case 2112563240:
          if (obj1 == \u003CModule\u003E.smethod_7<string>(4028055365U))
            goto label_31;
          else
            goto label_62;
        case 2118188214:
          if (obj1 == \u003CModule\u003E.smethod_5<string>(2237311697U))
            goto label_40;
          else
            goto label_62;
        case 2454795333:
          if (!(obj1 == \u003CModule\u003E.smethod_9<string>(3821011689U)))
            goto label_62;
          else
            break;
        case 2579487986:
          if (obj1 == \u003CModule\u003E.smethod_7<string>(2217996095U))
            goto label_53;
          else
            goto label_62;
        case 2647647615:
          if (obj1 == \u003CModule\u003E.smethod_5<string>(3349499132U))
            goto label_53;
          else
            goto label_62;
        case 2761324515:
          if (!(obj1 == \u003CModule\u003E.smethod_6<string>(3053989986U)))
            goto label_62;
          else
            goto label_31;
        case 2848971440:
          if (!(obj1 == \u003CModule\u003E.smethod_6<string>(2947199660U)))
            goto label_62;
          else
            goto label_40;
        case 2983429004:
          if (obj1 == \u003CModule\u003E.smethod_9<string>(3971780361U))
            goto label_50;
          else
            goto label_62;
        case 3000206623:
          if (obj1 == \u003CModule\u003E.smethod_7<string>(4021814454U))
            goto label_50;
          else
            goto label_62;
        case 3050539480:
          if (obj1 == \u003CModule\u003E.smethod_8<string>(2760529519U))
            goto label_50;
          else
            goto label_62;
        case 3067317099:
          if (obj1 == \u003CModule\u003E.smethod_5<string>(1898800570U))
            goto label_50;
          else
            goto label_62;
        case 3084094718:
          if (obj1 == \u003CModule\u003E.smethod_9<string>(108194403U))
            goto label_50;
          else
            goto label_62;
        case 3100872337:
          if (obj1 == \u003CModule\u003E.smethod_6<string>(4168772636U))
            goto label_50;
          else
            goto label_62;
        case 3134427575:
          if (obj1 == \u003CModule\u003E.smethod_9<string>(1961249548U))
            goto label_50;
          else
            goto label_62;
        case 3151205194:
          if (!(obj1 == \u003CModule\u003E.smethod_5<string>(2753889917U)))
            goto label_62;
          else
            goto label_50;
        case 3167982813:
          if (obj1 == \u003CModule\u003E.smethod_7<string>(3586416340U))
            goto label_50;
          else
            goto label_62;
        case 3635920463:
          if (obj1 == \u003CModule\u003E.smethod_8<string>(2568700728U) && !this.Class26_0.bool_4 && !this.Class26_0.bool_12)
            return false;
          goto label_62;
        case 3777649476:
          if (!(obj1 == \u003CModule\u003E.smethod_5<string>(1960693048U)))
            goto label_62;
          else
            goto label_53;
        default:
          goto label_62;
      }
      if (int_11 != null)
      {
        if (int_11.method_7(Enum10.FasNadur))
          return false;
        goto label_62;
      }
      else
      {
        if (obj2 != null && obj2.Boolean_2)
          return false;
        goto label_62;
      }
label_31:
      if (int_11 != null)
      {
        if (int_11.method_7(Enum10.NaomhAite))
          return false;
        goto label_62;
      }
      else
      {
        if (obj2 != null && obj2.Boolean_3)
          return false;
        goto label_62;
      }
label_40:
      if (obj2 != null && obj2.Boolean_1)
        return false;
      goto label_62;
label_50:
      if (obj2 != null && obj2.Boolean_5)
        return false;
      goto label_62;
label_53:
      if (int_11 != null)
      {
        if (int_11.method_7(Enum10.Pramh))
          return false;
      }
      else if (obj2 != null && obj2.Boolean_6)
        return false;
    }
    else if (obj1 == \u003CModule\u003E.smethod_7<string>(1620883916U) && !this.Class26_0.bool_4 && !this.Class26_0.bool_12)
      return false;
label_62:
    return true;
  }

  internal bool method_34()
  {
    DateTime utcNow = DateTime.UtcNow;
    while (this.class134_0 != null)
    {
      if (DateTime.UtcNow.Subtract(utcNow).TotalSeconds <= 1.5)
      {
        Thread.Sleep(5);
      }
      else
      {
        this.class134_0 = (Class134) null;
        this.class134_1 = (Class134) null;
        return false;
      }
    }
    return true;
  }

  internal bool method_35()
  {
    lock (this.object_0)
    {
      if (this.dictionary_13.ContainsKey(this.Class76_0[6].String_0))
      {
        this.string_5 = \u003CModule\u003E.smethod_5<string>(554748447U);
        return true;
      }
      List<string> stringList = new List<string>();
      foreach (Class76 class76 in new List<Class76>((IEnumerable<Class76>) this.Class21_0))
      {
        if (((IEnumerable<string>) this.dictionary_13.Keys).Contains<string>(class76.String_0) && !stringList.Contains(class76.String_0))
          stringList.Add(class76.String_0);
      }
      KeyValuePair<string, (int, int)> keyValuePair = new KeyValuePair<string, (int, int)>("", (0, 0));
      foreach (string key in stringList)
      {
        if (this.dictionary_13[key].ab <= (int) this.Byte_3 && this.dictionary_13[key].lv <= (int) this.Byte_2 && (this.dictionary_13[key].lv > keyValuePair.Value.Item2 || this.dictionary_13[key].ab > keyValuePair.Value.Item1))
          keyValuePair = new KeyValuePair<string, (int, int)>(key, this.dictionary_13[key]);
      }
      this.method_29(keyValuePair.Key);
      DateTime utcNow = DateTime.UtcNow;
      while (DateTime.UtcNow.Subtract(utcNow).TotalSeconds <= 1.5)
      {
        if (this.Class76_0[6].String_0 == keyValuePair.Key)
          return true;
        Thread.Sleep(50);
      }
      return false;
    }
  }

  internal bool method_36()
  {
    lock (this.object_0)
    {
      if (this.dictionary_14.ContainsKey(this.Class76_0[6].String_0))
      {
        this.string_5 = \u003CModule\u003E.smethod_6<string>(3991663225U);
        return true;
      }
      List<string> stringList = new List<string>();
      foreach (Class76 class76 in new List<Class76>((IEnumerable<Class76>) this.Class21_0))
      {
        if (this.dictionary_14.Keys.Contains<string>(class76.String_0) && !stringList.Contains(class76.String_0))
          stringList.Add(class76.String_0);
      }
      KeyValuePair<string, int> keyValuePair = new KeyValuePair<string, int>("", 0);
      foreach (string str in stringList)
      {
        // ISSUE: object of a compiler-generated type is created
        // ISSUE: variable of a compiler-generated type
        Class29.Class32 class32 = new Class29.Class32();
        // ISSUE: reference to a compiler-generated field
        class32.string_0 = str;
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (this.dictionary_14[class32.string_0] <= (int) this.Byte_2 && this.dictionary_14[class32.string_0] > keyValuePair.Value)
        {
          // ISSUE: reference to a compiler-generated method
          keyValuePair = this.dictionary_14.First<KeyValuePair<string, int>>(new Func<KeyValuePair<string, int>, bool>(class32.method_0));
        }
      }
      this.method_29(keyValuePair.Key);
      DateTime utcNow = DateTime.UtcNow;
      while (DateTime.UtcNow.Subtract(utcNow).TotalSeconds <= 1.5)
      {
        if (this.Class76_0[6].String_0 == keyValuePair.Key)
          return true;
        Thread.Sleep(50);
      }
      return false;
    }
  }

  internal string method_37()
  {
    lock (this.object_0)
    {
      Dictionary<string, (int, int)> dictionary1 = new Dictionary<string, (int, int)>();
      dictionary1.Add(\u003CModule\u003E.smethod_5<string>(2670094834U), (0, 50));
      dictionary1.Add(\u003CModule\u003E.smethod_5<string>(4058900918U), (0, 50));
      dictionary1.Add(\u003CModule\u003E.smethod_6<string>(3293633730U), (0, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_5<string>(1815005487U), (0, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_8<string>(1239280941U), (0, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_5<string>(1686456443U), (0, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_9<string>(3941834486U), (0, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_5<string>(2348722224U), (0, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_7<string>(687861785U), (0, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_7<string>(1754605485U), (0, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_5<string>(2220173180U), (65, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_9<string>(1893611505U), (65, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_7<string>(1720372078U), (80, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_6<string>(405133573U), (80, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_5<string>(2066390736U), (90, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_6<string>(121233836U), (95, 99));
      Dictionary<string, (int, int)> dictionary2 = dictionary1;
      List<string> stringList = new List<string>();
      foreach (Class76 class76 in new List<Class76>((IEnumerable<Class76>) this.Class21_0))
      {
        if (((IEnumerable<string>) dictionary2.Keys).Contains<string>(class76.String_0) && !stringList.Contains(class76.String_0))
          stringList.Add(class76.String_0);
      }
      KeyValuePair<string, (int, int)> keyValuePair = new KeyValuePair<string, (int, int)>("", (0, 0));
      foreach (string key in stringList)
      {
        if (dictionary2[key].Item1 <= (int) this.Byte_3 && (dictionary2[key].Item2 > keyValuePair.Value.Item2 || dictionary2[key].Item1 > keyValuePair.Value.Item1))
          keyValuePair = new KeyValuePair<string, (int, int)>(key, dictionary2[key]);
      }
      if (this.Class76_0[1].String_0 == keyValuePair.Key)
        return this.Class76_0[1].String_0;
      this.method_29(keyValuePair.Key);
      return keyValuePair.Key;
    }
  }

  internal string method_38()
  {
    lock (this.object_0)
    {
      Dictionary<string, (int, int)> dictionary1 = new Dictionary<string, (int, int)>();
      dictionary1.Add(\u003CModule\u003E.smethod_9<string>(1766081712U), (0, 1));
      dictionary1.Add(\u003CModule\u003E.smethod_9<string>(4129256029U), (0, 2));
      dictionary1.Add(\u003CModule\u003E.smethod_5<string>(2600107473U), (0, 7));
      dictionary1.Add(\u003CModule\u003E.smethod_5<string>(3988913557U), (0, 13));
      dictionary1.Add(\u003CModule\u003E.smethod_9<string>(3649082732U), (0, 14));
      dictionary1.Add(\u003CModule\u003E.smethod_9<string>(1413438208U), (0, 17));
      dictionary1.Add(\u003CModule\u003E.smethod_9<string>(726997284U), (0, 20));
      dictionary1.Add(\u003CModule\u003E.smethod_5<string>(1680743604U), (0, 50));
      dictionary1.Add(\u003CModule\u003E.smethod_5<string>(3069549688U), (0, 71));
      dictionary1.Add(\u003CModule\u003E.smethod_5<string>(3628499825U), (0, 77));
      dictionary1.Add(\u003CModule\u003E.smethod_6<string>(1056283678U), (0, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_8<string>(1000537962U), (0, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_8<string>(1427162713U), (0, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_8<string>(173376900U), (0, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_5<string>(4097942040U), (0, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_7<string>(2653394209U), (0, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_9<string>(1942403464U), (0, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_5<string>(2516312390U), (0, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_9<string>(3315285312U), (0, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_5<string>(272416959U), (0, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_7<string>(3144777315U), (15, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_8<string>(600001651U), (30, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_6<string>(1707433783U), (45, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_9<string>(3630236648U), (55, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_9<string>(708151200U), (90, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_5<string>(1884992848U), (65, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_8<string>(944414063U), (65, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_5<string>(3209524410U), (80, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_7<string>(1714131167U), (80, 99));
      dictionary1.Add(\u003CModule\u003E.smethod_9<string>(1649651710U), (95, 99));
      Dictionary<string, (int, int)> dictionary2 = dictionary1;
      List<string> stringList = new List<string>();
      foreach (Class76 class76 in new List<Class76>((IEnumerable<Class76>) this.Class21_0))
      {
        if (((IEnumerable<string>) dictionary2.Keys).Contains<string>(class76.String_0) && !stringList.Contains(class76.String_0))
          stringList.Add(class76.String_0);
      }
      KeyValuePair<string, (int, int)> keyValuePair = new KeyValuePair<string, (int, int)>("", (0, 0));
      foreach (string key in stringList)
      {
        if (dictionary2[key].Item1 <= (int) this.Byte_3 && (dictionary2[key].Item2 > keyValuePair.Value.Item2 || dictionary2[key].Item1 > keyValuePair.Value.Item1))
          keyValuePair = new KeyValuePair<string, (int, int)>(key, dictionary2[key]);
      }
      if (this.Class76_0[1].String_0 == keyValuePair.Key)
        return this.Class76_0[1].String_0;
      this.method_29(keyValuePair.Key);
      return keyValuePair.Key;
    }
  }

  internal string method_39()
  {
    Dictionary<string, int> source = new Dictionary<string, int>()
    {
      {
        \u003CModule\u003E.smethod_5<string>(174814154U),
        1
      },
      {
        \u003CModule\u003E.smethod_5<string>(1563620238U),
        8
      },
      {
        \u003CModule\u003E.smethod_5<string>(2952426322U),
        15
      },
      {
        \u003CModule\u003E.smethod_5<string>(46265110U),
        22
      },
      {
        \u003CModule\u003E.smethod_5<string>(708530891U),
        30
      },
      {
        \u003CModule\u003E.smethod_7<string>(2261499265U),
        45
      },
      {
        \u003CModule\u003E.smethod_9<string>(3041379642U),
        55
      },
      {
        \u003CModule\u003E.smethod_7<string>(1608402094U),
        95
      }
    };
    List<string> stringList = new List<string>();
    foreach (Class76 class76 in new List<Class76>((IEnumerable<Class76>) this.Class21_0))
    {
      if (source.Keys.Contains<string>(class76.String_0) && !stringList.Contains(class76.String_0))
        stringList.Add(class76.String_0);
    }
    KeyValuePair<string, int> keyValuePair = new KeyValuePair<string, int>("", 0);
    foreach (string str in stringList)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      Class29.Class33 class33 = new Class29.Class33();
      // ISSUE: reference to a compiler-generated field
      class33.string_0 = str;
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (source[class33.string_0] <= (int) this.Byte_3 && source[class33.string_0] > keyValuePair.Value)
      {
        // ISSUE: reference to a compiler-generated method
        keyValuePair = source.First<KeyValuePair<string, int>>(new Func<KeyValuePair<string, int>, bool>(class33.method_0));
      }
    }
    this.method_29(keyValuePair.Key);
    return keyValuePair.Key;
  }

  private bool method_40([In] Class134 obj0, ref byte string_8)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class29.Class34 class34 = new Class29.Class34();
    // ISSUE: reference to a compiler-generated field
    class34.class134_0 = obj0;
    // ISSUE: reference to a compiler-generated field
    string_8 = class34.class134_0.Byte_2;
    Class24 class24 = new Class24();
    Class76 class76_1 = this.Class76_0[1];
    Class10 class10 = (class76_1 != null ? (class76_1.Boolean_1 ? 1 : 0) : 0) != 0 ? this.Class76_0[1].Class10_0 : new Class10();
    // ISSUE: reference to a compiler-generated method
    int num1 = this.list_8.Any<string>(new Func<string, bool>(class34.method_0)) ? 1 : 0;
    DateTime utcNow = DateTime.UtcNow;
    int result;
    if (num1 != 0 && int.TryParse(this.Class133_0.Dictionary_0.Keys.FirstOrDefault<string>((Func<string, bool>) (sender => sender.Contains(\u003CModule\u003E.smethod_5<string>(1203206506U)))).Replace(\u003CModule\u003E.smethod_8<string>(2571332074U), ""), out result))
    {
      foreach (Class76 class76_2 in new List<Class76>((IEnumerable<Class76>) this.class21_0))
      {
        if (class76_2.Boolean_1 && class76_2.Class10_0.method_0((int) this.Byte_3, result) && class76_2.Class10_0.Int32_0 > class10.Int32_0)
          class10 = class76_2.Class10_0;
      }
      string string0_1 = class10.String_0;
      Class76 class76_3 = this.Class76_0[1];
      string string0_2 = ((class76_3 != null ? (class76_3.Boolean_1 ? 1 : 0) : 0) != 0 ? this.Class76_0[1].Class10_0 : new Class10()).String_0;
      if (string0_1.Equals(string0_2, StringComparison.CurrentCultureIgnoreCase))
        return true;
      this.method_110();
      this.method_29(class10.String_0);
      while (true)
      {
        Class76 class76_4 = this.Class76_0[1];
        if ((class76_4 != null ? (!class76_4.String_0.Equals(class10.String_0, StringComparison.CurrentCultureIgnoreCase) ? 1 : 0) : 1) != 0)
        {
          if (DateTime.UtcNow.Subtract(utcNow).TotalSeconds <= 2.0)
          {
            this.Control2_0.label_5.Text = this.string_7 + \u003CModule\u003E.smethod_6<string>(2561756391U) + class10.String_0;
            Thread.Sleep(5);
          }
          else
            break;
        }
        else
          goto label_32;
      }
      return false;
    }
    foreach (Class76 class76_5 in new List<Class76>((IEnumerable<Class76>) this.class21_0))
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (class76_5.Boolean_0 && class76_5.Class24_0.method_0(this.Byte_3, this.Byte_2, this.UInt32_8, this.temClass_0) && (int) class76_5.Class24_0.Dictionary_0[class34.class134_0.String_0] < (int) class34.class134_0.Byte_2 && (class76_5.Class24_0.Int32_0 > class24.Int32_0 || class76_5.Class24_0.Int32_1 > class24.Int32_1 || !class24.Boolean_0 && class76_5.Class24_0.Boolean_0))
        class24 = class76_5.Class24_0;
    }
    if (class24.String_0 == new Class24().String_0)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if ((int) this.Class136_0[class34.class134_0.String_0].Byte_2 <= (int) this.list_4[0].Dictionary_0[class34.class134_0.String_0])
        return true;
      class24 = this.list_4[0];
    }
    this.method_110();
    if (class24.String_0 == \u003CModule\u003E.smethod_6<string>(751567643U))
      this.method_107();
    else
      this.method_29(class24.String_0);
    while (true)
    {
      // ISSUE: reference to a compiler-generated field
      byte? byte2 = this.Class136_0[class34.class134_0.String_0]?.Byte_2;
      int? nullable = byte2.HasValue ? new int?((int) byte2.GetValueOrDefault()) : new int?();
      // ISSUE: reference to a compiler-generated field
      int num2 = (int) class24.Dictionary_0[class34.class134_0.String_0];
      if (!(nullable.GetValueOrDefault() == num2 & nullable.HasValue))
      {
        if (DateTime.UtcNow.Subtract(utcNow).TotalSeconds <= 2.0)
        {
          this.Control2_0.label_5.Text = this.string_7 + \u003CModule\u003E.smethod_6<string>(2561756391U) + class24.String_0;
          Thread.Sleep(5);
        }
        else
          break;
      }
      else
        goto label_31;
    }
    return false;
label_31:
    Thread.Sleep(100);
label_32:
    // ISSUE: reference to a compiler-generated field
    string_8 = this.Class136_0[class34.class134_0.String_0].Byte_2;
    return true;
  }

  internal bool method_41([In] Class134 obj0, Class142 string_8)
  {
    if (!obj0.Boolean_0 || !this.class88_0.Boolean_1 || string_8 != null && !this.hashSet_2.Contains(string_8.Int32_0))
      return false;
    if (Class29.hashSet_0.Contains(obj0.String_0))
      return true;
    return !this.method_7(Enum10.Pramh) && !this.method_7(Enum10.Suain);
  }

  internal bool method_42([In] string obj0)
  {
    for (int index = 20; index > 0; --index)
    {
      if (this.method_30(obj0))
        return true;
    }
    return false;
  }

  internal bool method_43() => this.method_44(this.Struct16_1);

  internal bool method_44(Struct16 ushort_2)
  {
    if (this.Class143_0.Struct16_0.method_0(ushort_2) <= 1)
      return false;
    IEnumerable<Struct16> source = this.method_116().OfType<Class142>().Where<Class142>((Func<Class142, bool>) (sender => (sender.Byte_0 == (byte) 4 || sender.Byte_0 == (byte) 2 || sender.Byte_0 == (byte) 0) && sender != this.Class143_0)).Select<Class142, Struct16>((Func<Class142, Struct16>) (obj0 => obj0.Struct16_0));
    List<Struct16> struct16List = this.method_121(ushort_2);
    int num = 0;
    Struct16[] struct16Array = new Struct16[4]
    {
      ushort_2.method_3(Direction.North),
      ushort_2.method_3(Direction.West),
      ushort_2.method_3(Direction.South),
      ushort_2.method_3(Direction.East)
    };
    foreach (Struct16 short_4 in struct16Array)
    {
      if (source.Contains<Struct16>(short_4))
        ++num;
      else if (struct16List.Contains(short_4))
        ++num;
      else if (this.class88_0.method_3(short_4))
        ++num;
    }
    return num >= 4;
  }

  internal bool method_45([In] IntPtr obj0)
  {
    if (!this.Boolean_16)
      return false;
    Class16.Struct7 struct7 = Class137.smethod_0(obj0, 15U, uint.MaxValue, 0U);
    return Class137.FlashWindowEx(ref struct7);
  }

  internal void method_46([In] Struct17 obj0)
  {
    if (!this.Class112_0.Dictionary_3.ContainsKey(obj0.Int16_0))
      return;
    if (this.Class112_0.Dictionary_3[obj0.Int16_0].Dictionary_1.ContainsKey(obj0.Struct16_0))
      this.Class112_0.Dictionary_3[obj0.Int16_0].Dictionary_1.Remove(obj0.Struct16_0);
    if (this.Class112_0.Dictionary_3[obj0.Int16_0].Dictionary_2.ContainsKey(obj0.Struct16_0))
      this.Class112_0.Dictionary_3[obj0.Int16_0].Dictionary_2.Remove(obj0.Struct16_0);
    this.Class112_0.method_80(\u003CModule\u003E.smethod_8<string>(1744171012U));
  }

  internal void method_47(Struct17 int_11, [In] Struct17 obj1)
  {
    if (this.Class112_0.Dictionary_3.ContainsKey(int_11.Int16_0))
    {
      Class92 class92 = new Class92((byte) int_11.Struct16_0.short_0, (byte) int_11.Struct16_0.short_1, (byte) obj1.Struct16_0.short_0, (byte) obj1.Struct16_0.short_1, int_11.Int16_0, obj1.Int16_0);
      this.Class112_0.Dictionary_3[int_11.Int16_0].Dictionary_1[int_11.Struct16_0] = class92;
      this.Class112_0.method_80(\u003CModule\u003E.smethod_6<string>(2691986412U));
    }
    else
      this.method_75((byte) 0, \u003CModule\u003E.smethod_7<string>(2429454241U));
  }

  internal void method_48(Direction int_11)
  {
    this.Class26_0.dateTime_18 = DateTime.UtcNow;
    Class99 class99 = new Class99((byte) 17);
    class99.method_14((byte) int_11);
    this.method_4(new Class98[1]{ (Class98) class99 });
    this.direction_0 = int_11;
  }

  internal void method_49([In] Direction obj0)
  {
    if (this.Class75_0 == null && !this.Class112_0.bool_2 && obj0 != Direction.Invalid && !this.bool_48)
    {
      this.dateTime_2 = DateTime.UtcNow;
      if (this.direction_0 != obj0)
        this.method_48(obj0);
      this.bool_32 = true;
      Class99 class99 = new Class99((byte) 6);
      class99.method_14((byte) obj0);
      class99.method_14(this.byte_7++);
      this.method_4(new Class98[1]{ (Class98) class99 });
      Class100 class100 = new Class100((byte) 12);
      class100.method_20(this.uint_0);
      class100.method_24(this.struct16_1);
      class100.method_14((byte) obj0);
      this.method_4(new Class98[1]{ (Class98) class100 });
      this.struct16_1.method_2(obj0);
      this.dateTime_3 = DateTime.UtcNow;
      this.Control2_0.label_5.Text = this.string_7 + \u003CModule\u003E.smethod_8<string>(2704405620U) + obj0.ToString();
    }
    else
    {
      this.Boolean_4 = false;
      Thread.Sleep(100);
    }
  }

  internal bool method_50(Struct16 int_11, short string_8, [In] bool obj2, [In] bool obj3)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class29.Class36 class36 = new Class29.Class36();
    // ISSUE: reference to a compiler-generated field
    class36.class29_0 = this;
    // ISSUE: reference to a compiler-generated field
    class36.struct16_0 = int_11;
    if (this.dictionary_4.Count > 0 || this.Boolean_3)
    {
      if (!this.Boolean_4)
        return false;
      this.Boolean_3 = false;
    }
    // ISSUE: reference to a compiler-generated method
    if (!this.class88_0.method_3(this.struct16_1) && (this.int_7 != 0 || !this.method_116().OfType<Class142>().Any<Class142>(new Func<Class142, bool>(class36.method_0))) || !this.bool_32 && (this.struct16_1.short_0 != (short) 0 || this.struct16_1.short_1 != (short) 0) && (this.Struct16_1.short_0 != (short) 0 || this.Struct16_1.short_1 != (short) 0))
    {
      // ISSUE: reference to a compiler-generated field
      if (string_8 != (short) 0 && this.struct16_1.method_0(class36.struct16_0) <= (int) string_8)
      {
        Thread.Sleep(25);
        return false;
      }
      // ISSUE: reference to a compiler-generated field
      if (Struct16.smethod_0(this.Struct16_0, class36.struct16_0))
      {
        if (this.bool_32 || DateTime.UtcNow.Subtract(this.DateTime_0).TotalSeconds > 2.0)
        {
          if (this.int_7 == 0)
            this.method_105(true);
          this.bool_32 = false;
        }
        return true;
      }
      while (DateTime.UtcNow.Subtract(this.dateTime_3).TotalMilliseconds < (this.Class26_0.method_38() || this.Class26_0.bool_17 ? 420.0 : this.double_0))
        Thread.Sleep(10);
      // ISSUE: reference to a compiler-generated field
      if (Struct16.smethod_1(class36.struct16_0, this.struct16_0) || this.stack_0.Count == 0)
      {
        // ISSUE: reference to a compiler-generated field
        this.struct16_0 = class36.struct16_0;
        // ISSUE: reference to a compiler-generated field
        this.stack_0 = this.class103_0.method_2(this.struct16_1, class36.struct16_0, obj3, string_8);
      }
      if (this.stack_0.Count == 0 && Struct16.smethod_1(this.struct16_1, this.Struct16_1) && this.bool_32)
      {
        // ISSUE: reference to a compiler-generated field
        this.stack_0 = this.class103_0.method_2(this.Struct16_1, class36.struct16_0, obj3, string_8);
        if (this.stack_0.Count == 0)
          return false;
        this.method_105(true);
        this.bool_32 = false;
        return false;
      }
      if (this.stack_0.Count == 0)
        return false;
      // ISSUE: reference to a compiler-generated method
      List<Class142> list = this.method_116().OfType<Class142>().Where<Class142>(new Func<Class142, bool>(class36.method_1)).ToList<Class142>();
      foreach (Struct16 struct16 in this.stack_0)
      {
        // ISSUE: object of a compiler-generated type is created
        // ISSUE: variable of a compiler-generated type
        Class29.Class37 class37 = new Class29.Class37();
        // ISSUE: reference to a compiler-generated field
        class37.class36_0 = class36;
        // ISSUE: reference to a compiler-generated field
        class37.struct16_0 = struct16;
        // ISSUE: reference to a compiler-generated method
        if (this.dictionary_12.Count > 0 && this.dictionary_12.Values.Any<Class91>(new Func<Class91, bool>(class37.method_0)))
        {
          // ISSUE: reference to a compiler-generated field
          this.method_79(class37.struct16_0);
        }
        // ISSUE: reference to a compiler-generated method
        if (list.Count > 0 && list.Any<Class142>(new Func<Class142, bool>(class37.method_1)))
        {
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          this.stack_0 = this.class103_0.method_2(this.struct16_1, class37.class36_0.struct16_0, obj3, string_8);
          return false;
        }
      }
      Struct16 struct16_1 = this.stack_0.Pop();
      if (struct16_1.method_0(this.struct16_1) != 1)
      {
        if (struct16_1.method_0(this.struct16_1) > 2 && this.bool_32)
        {
          if (this.int_7 == 0)
            this.method_105(true);
          this.bool_32 = false;
        }
        // ISSUE: reference to a compiler-generated field
        this.stack_0 = this.class103_0.method_2(this.struct16_1, class36.struct16_0, obj3, string_8);
        return false;
      }
      Direction direction = struct16_1.method_4(this.struct16_1);
      if (obj2)
      {
        lock (this.object_1)
        {
          if (!this.method_7(Enum10.Pramh))
          {
            if (!this.method_7(Enum10.Suain))
            {
              if (this.method_25((ushort) 89))
              {
                if (!(this.Control2_0.button_69.Text == \u003CModule\u003E.smethod_7<string>(3959588551U)))
                  goto label_48;
              }
              this.method_49(direction);
            }
          }
        }
      }
      else if (!this.method_7(Enum10.Pramh) && !this.method_7(Enum10.Suain) && (!this.method_25((ushort) 89) || this.Control2_0.button_69.Text == \u003CModule\u003E.smethod_6<string>(1840287201U)))
        this.method_49(direction);
label_48:
      return true;
    }
    this.method_105(true);
    this.bool_32 = false;
    return false;
  }

  internal bool method_51(Struct17 int_11, short string_8, bool int_12, [In] bool obj3, [In] bool obj4)
  {
    try
    {
      if (this.Class112_0.bool_2)
        return false;
      Struct17 string_1_1 = new Struct17(this.class88_0.Int16_0, this.struct16_1.short_0, this.struct16_1.short_1);
      if (Struct17.smethod_0(string_1_1, int_11))
      {
        if (Struct17.smethod_0(int_11, new Struct17((short) 395, (short) 6, (short) 6)))
          this.Class26_0.bool_29 = true;
        else if (Struct17.smethod_0(int_11, new Struct17((short) 344, (short) 6, (short) 6)))
          this.Class26_0.bool_30 = true;
        this.stack_1.Clear();
        return false;
      }
      if (((this.stack_1.Count != 1 ? 0 : ((int) int_11.Int16_0 == (int) this.class88_0.Int16_0 ? 1 : 0)) & (int_12 ? 1 : 0)) != 0)
      {
        this.stack_1.Clear();
        return false;
      }
      if (Struct17.smethod_1(this.struct17_1, int_11) || this.stack_1.Count == 0)
      {
        this.struct17_1 = int_11;
        this.stack_1 = this.class109_0.method_0(string_1_1, int_11);
      }
      if (this.class88_0.String_0.Contains(\u003CModule\u003E.smethod_9<string>(3679028607U)))
        this.stack_1 = this.class109_0.method_0(string_1_1, int_11);
      if (this.stack_1.Count == 0)
      {
        this.class109_0 = new Class109(this.class112_0, this);
        this.struct17_1 = int_11;
        this.dateTime_1 = DateTime.MinValue;
        this.stack_1 = this.class109_0.method_0(string_1_1, int_11);
        return false;
      }
      Struct17 string_1_2 = this.stack_1.Peek();
      if (this.stack_1.Count != 1)
        string_8 = (short) 0;
      if (this.stack_1.Count > 1 && Struct17.smethod_0(string_1_2, this.Struct17_1))
      {
        this.stack_1.Pop();
        string_1_2 = this.stack_1.Peek();
      }
      if (this.class94_0 != null)
      {
        List<Struct17> list = this.class109_0.method_0(string_1_1, int_11).Reverse<Struct17>().ToList<Struct17>();
        if (DateTime.UtcNow.Subtract(this.dateTime_1).TotalSeconds < 1.0)
          return false;
        foreach (Struct17 struct17 in list)
        {
          foreach (Class95 class95 in this.class94_0.List_0)
          {
            if ((int) class95.Int16_0 == (int) struct17.Int16_0)
            {
              this.dateTime_1 = DateTime.UtcNow;
              this.method_112(class95.Int16_0, class95.Struct16_1);
              return true;
            }
          }
        }
        foreach (Class95 class95 in this.class94_0.List_0)
        {
          if ((int) class95.Int16_0 == (int) string_1_2.Int16_0)
          {
            this.dateTime_1 = DateTime.UtcNow;
            this.method_112(class95.Int16_0, class95.Struct16_1);
            return true;
          }
        }
        return false;
      }
      if ((int) string_1_2.Int16_0 != (int) this.class88_0.Int16_0)
      {
        Class93 class93;
        if (!this.class112_0.Dictionary_3.TryGetValue(this.class88_0.Int16_0, out class93))
        {
          this.stack_1.Clear();
          return false;
        }
        Class94 class94;
        if (class93.Dictionary_2.TryGetValue(this.struct16_1, out class94))
        {
          if (!class93.Dictionary_2.TryGetValue(this.struct16_2, out class94))
          {
            this.method_105(true);
            return false;
          }
          foreach (Class95 class95 in class94.List_0)
          {
            if ((int) class95.Int16_0 == (int) string_1_2.Int16_0)
              return false;
          }
        }
        Class92 class92;
        if (class93.Dictionary_1.TryGetValue(this.struct16_1, out class92) && (int) class92.Int16_0 == (int) string_1_2.Int16_0)
        {
          this.method_53(string_1_2);
          this.method_105(true);
          return true;
        }
        this.stack_1.Clear();
        return false;
      }
      if (!this.method_50(new Struct16(string_1_2.Int16_1, string_1_2.Int16_2), string_8, obj3, obj4))
      {
        if (!this.class88_0.String_0.Contains(\u003CModule\u003E.smethod_7<string>(3685904502U)))
          return false;
        this.method_49(Direction.South);
        Thread.Sleep(1000);
        return true;
      }
    }
    catch
    {
      this.method_105(true);
      return false;
    }
    return this.stack_1.Count > 0;
  }

  internal void method_52()
  {
    if (this.Control2_0 == null)
      return;
    try
    {
      if (this.bool_0)
        return;
      Struct17 int_11 = new Struct17((short) 5252, (short) 7, (short) 7);
      if (Struct17.smethod_1(this.Struct17_0, int_11))
      {
        this.method_51(int_11, (short) 0, false, true, true);
      }
      else
      {
        if (!Struct17.smethod_0(this.Struct17_0, int_11))
          return;
        Class142 class142 = this.method_128(\u003CModule\u003E.smethod_8<string>(1637185906U));
        this.method_78(class142.Int32_0);
        this.method_89((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 2);
        this.method_89((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 2);
        this.method_90((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 2, (byte) 1);
        this.method_89((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 2);
        this.method_90((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 2, (byte) 3);
        this.method_89((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 2);
        this.method_89((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 1);
        this.bool_0 = true;
      }
    }
    catch
    {
    }
  }

  private void method_53([In] Struct17 obj0)
  {
    if (this.Control2_0 == null)
      return;
    try
    {
      if (Struct17.smethod_0(this.Struct17_0, new Struct17((short) 5220, (short) 0, (short) 6)) && obj0.Int16_0 == (short) 5210 && this.Class75_0 != null)
        this.Class75_0.method_2((byte) 2);
      if (Struct17.smethod_0(this.Struct17_0, new Struct17((short) 6926, (short) 8, (short) 9)) && obj0.Int16_0 == (short) 10028)
      {
        Class142 sender = this.method_128(\u003CModule\u003E.smethod_6<string>(2254416959U));
        this.method_141(sender, \u003CModule\u003E.smethod_7<string>(1033041500U), true);
        this.method_90((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2, (byte) 1);
        this.method_89((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2);
        if (!string.IsNullOrEmpty(this.Control2_0.comboBox_4.Text) && this.Control2_0.button_45.Text == \u003CModule\u003E.smethod_9<string>(591721198U) && this.Control2_0.toolStripMenuItem_2.Text == \u003CModule\u003E.smethod_7<string>(1365922600U))
          this.Class112_0.dictionary_5[this.String_0] = this.Control2_0.comboBox_4.Text;
        if (!string.IsNullOrEmpty(this.Control2_0.textBox_17.Text) && this.Control2_0.checkBox_68.Checked && this.Control2_0.toolStripMenuItem_2.Text == \u003CModule\u003E.smethod_8<string>(4223022852U))
          this.Class112_0.dictionary_6[this.String_0] = this.Control2_0.textBox_17.Text;
        if ((!string.IsNullOrEmpty(this.Control2_0.comboBox_4.Text) && this.Control2_0.button_45.Text == \u003CModule\u003E.smethod_9<string>(591721198U) || !string.IsNullOrEmpty(this.Control2_0.textBox_17.Text) && this.Control2_0.checkBox_68.Checked) && this.Control2_0.toolStripMenuItem_2.Text == \u003CModule\u003E.smethod_9<string>(591721198U))
          this.Class112_0.dictionary_7[this.String_0] = this.Control2_0.trackBar_0.Value;
        if (!(this.Control2_0.button_17.Text == \u003CModule\u003E.smethod_8<string>(3184522924U)) || !(this.Control2_0.toolStripMenuItem_2.Text == \u003CModule\u003E.smethod_8<string>(4223022852U)))
          return;
        this.Class112_0.dictionary_6[this.String_0] = \u003CModule\u003E.smethod_8<string>(3399808809U);
        this.Class112_0.dictionary_7[this.String_0] = this.Control2_0.trackBar_0.Value;
      }
      else if (Struct17.smethod_0(this.Struct17_0, new Struct17((short) 706, (short) 11, (short) 13)) && obj0.Int16_0 == (short) 6591)
        this.method_60((byte) 3, \u003CModule\u003E.smethod_5<string>(663776930U));
      else if (Struct17.smethod_0(this.Struct17_0, new Struct17((short) 10000, (short) 29, (short) 31)) && obj0.Int16_0 == (short) 10999)
      {
        Class142 sender = this.method_128(\u003CModule\u003E.smethod_9<string>(1758335419U));
        this.method_141(sender, \u003CModule\u003E.smethod_6<string>(347846034U), true);
        this.method_89((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2);
        this.method_90((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2, (byte) 1);
        this.method_89((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2);
      }
      else if (Struct17.smethod_0(this.Struct17_0, new Struct17((short) 10055, (short) 46, (short) 23)) && obj0.Int16_0 == (short) 10999)
      {
        Class142 sender = this.method_128(\u003CModule\u003E.smethod_9<string>(1934657171U));
        this.method_141(sender, \u003CModule\u003E.smethod_7<string>(233740938U), true);
        this.method_89((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2);
        this.method_90((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2, (byte) 1);
        this.method_89((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2);
      }
      else if (Struct17.smethod_0(this.Struct17_0, new Struct17((short) 10265, (short) 87, (short) 47)) && obj0.Int16_0 == (short) 10998)
      {
        Class142 sender = this.method_128(\u003CModule\u003E.smethod_5<string>(406678842U));
        this.method_141(sender, \u003CModule\u003E.smethod_8<string>(3933418666U), true);
        this.method_89((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2);
        this.method_90((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2, (byte) 1);
        this.method_89((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2);
      }
      else if (Struct17.smethod_0(this.Struct17_0, new Struct17((short) 10055, (short) 46, (short) 24)) && obj0.Int16_0 == (short) 1960)
      {
        Class142 sender = this.method_128(\u003CModule\u003E.smethod_9<string>(1934657171U));
        this.method_141(sender, \u003CModule\u003E.smethod_7<string>(1819860240U), true);
        this.method_89((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2);
        this.method_90((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2, (byte) 1);
        this.method_90((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2, (byte) 1);
        this.method_89((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2);
        if (!string.IsNullOrEmpty(this.Control2_0.comboBox_4.Text) && this.Control2_0.button_45.Text == \u003CModule\u003E.smethod_8<string>(4223022852U) && this.Control2_0.toolStripMenuItem_2.Text == \u003CModule\u003E.smethod_8<string>(4223022852U))
          this.Class112_0.dictionary_5[this.String_0] = this.Control2_0.comboBox_4.Text;
        if (!string.IsNullOrEmpty(this.Control2_0.textBox_17.Text) && this.Control2_0.checkBox_68.Checked && this.Control2_0.toolStripMenuItem_2.Text == \u003CModule\u003E.smethod_8<string>(4223022852U))
          this.Class112_0.dictionary_6[this.String_0] = this.Control2_0.textBox_17.Text;
        if ((!string.IsNullOrEmpty(this.Control2_0.comboBox_4.Text) && this.Control2_0.button_45.Text == \u003CModule\u003E.smethod_6<string>(2579949292U) || !string.IsNullOrEmpty(this.Control2_0.textBox_17.Text) && this.Control2_0.checkBox_68.Checked) && this.Control2_0.toolStripMenuItem_2.Text == \u003CModule\u003E.smethod_6<string>(2579949292U))
          this.Class112_0.dictionary_7[this.String_0] = this.Control2_0.trackBar_0.Value;
        if (!(this.Control2_0.button_17.Text == \u003CModule\u003E.smethod_8<string>(3184522924U)) || !(this.Control2_0.toolStripMenuItem_2.Text == \u003CModule\u003E.smethod_6<string>(2579949292U)))
          return;
        this.Class112_0.dictionary_6[this.String_0] = \u003CModule\u003E.smethod_7<string>(1546176191U);
        this.Class112_0.dictionary_7[this.String_0] = this.Control2_0.trackBar_0.Value;
      }
      else if (Struct17.smethod_0(this.Struct17_0, new Struct17((short) 3634, (short) 16, (short) 6)) && obj0.Int16_0 == (short) 8420)
      {
        Class142 sender = this.method_128(\u003CModule\u003E.smethod_6<string>(2962854603U));
        this.method_141(sender, \u003CModule\u003E.smethod_5<string>(278129798U), true);
        this.method_90((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2, (byte) 1);
      }
      else if (Struct17.smethod_0(this.Struct17_0, new Struct17((short) 8318, (short) 50, (short) 95)) && obj0.Int16_0 == (short) 8345)
      {
        Class142 class142 = this.method_128(\u003CModule\u003E.smethod_6<string>(2678954866U));
        this.method_78(class142.Int32_0);
        this.method_89((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 2);
      }
      else if (Struct17.smethod_0(this.Struct17_0, new Struct17((short) 8355, (short) 32, (short) 5)) && obj0.Int16_0 == (short) 8356)
      {
        Class142 class142 = this.method_128(\u003CModule\u003E.smethod_8<string>(2332589095U));
        this.method_60((byte) 0, \u003CModule\u003E.smethod_7<string>(2858611444U));
        while (this.Class75_0 == null)
          Thread.Sleep(25);
        if (!this.Class75_0.String_1.Contains(\u003CModule\u003E.smethod_8<string>(3772941007U)))
        {
          this.method_90((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 2, (byte) 1);
          this.method_90((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 2, (byte) 1);
          Thread.Sleep(1000);
          this.method_60((byte) 0, \u003CModule\u003E.smethod_7<string>(2858611444U));
        }
        this.method_89((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 2);
        this.method_89((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 2);
        this.method_89((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 2);
        Thread.Sleep(1000);
      }
      else if (Struct17.smethod_0(this.Struct17_0, new Struct17((short) 8361, (short) 32, (short) 7)) && obj0.Int16_0 == (short) 8362)
      {
        Class142 class142 = this.method_128(\u003CModule\u003E.smethod_6<string>(3223314645U));
        if (class142 != null && this.Class21_0.method_0(\u003CModule\u003E.smethod_8<string>(2945779945U)))
        {
          this.method_30(\u003CModule\u003E.smethod_8<string>(1691994132U));
          this.method_29(\u003CModule\u003E.smethod_8<string>(2945779945U));
          this.method_29(\u003CModule\u003E.smethod_5<string>(3421868537U));
          Thread.Sleep(1000);
        }
        this.method_60((byte) 0, \u003CModule\u003E.smethod_6<string>(300966644U));
        DateTime utcNow = DateTime.UtcNow;
        while (this.Class75_0 == null)
        {
          if (DateTime.UtcNow.Subtract(utcNow).TotalSeconds > 2.0)
            return;
          Thread.Sleep(25);
        }
        if (this.Class75_0.String_1 == \u003CModule\u003E.smethod_5<string>(2631053712U))
        {
          Thread.Sleep(1000);
        }
        else
        {
          this.method_89((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 2);
          this.method_89((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 2);
          this.method_89((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 2);
          this.method_89((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 2);
          this.method_89((byte) 1, class142.Int32_0, (ushort) 0, (ushort) 2);
          Thread.Sleep(1000);
        }
      }
      else if (this.class88_0.Int16_0 == (short) 3052 && this.struct16_1.short_0 == (short) 44 && this.struct16_1.short_1 >= (short) 18 && this.struct16_1.short_1 <= (short) 25)
      {
        Class142 sender = this.method_128(\u003CModule\u003E.smethod_8<string>(3372404696U));
        this.method_141(sender, \u003CModule\u003E.smethod_9<string>(4170301695U), true);
        this.method_89((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2);
        while (this.Class75_0 == null)
          Thread.Sleep(10);
        Thread.Sleep(1000);
        if (this.Class75_0 == null || !this.Class75_0.String_1.Contains(\u003CModule\u003E.smethod_6<string>(452012963U)))
          return;
        this.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(3228801185U));
        this.Class26_0.method_1();
      }
      else if (this.class88_0.Int16_0 == (short) 393 && this.Struct16_0.method_0(new Struct16(7, 6)) <= 1)
      {
        this.method_88((byte) 1, this.method_128(\u003CModule\u003E.smethod_9<string>(865626868U)).Int32_0, (ushort) 1171, Array.Empty<object>());
        if (!this.method_142())
          return;
        this.method_89(this.Class75_0.Byte_1, this.Class75_0.Int32_0, this.Class75_0.UInt16_2, (ushort) 1);
        this.method_89(this.Class75_0.Byte_1, this.Class75_0.Int32_0, this.Class75_0.UInt16_2, this.Class143_0.Byte_2 == (byte) 16 ? (ushort) 6 : (ushort) 3);
        this.method_90(this.Class75_0.Byte_1, this.Class75_0.Int32_0, this.Class75_0.UInt16_2, (ushort) 8, (byte) 1);
        this.method_90(this.Class75_0.Byte_1, this.Class75_0.Int32_0, this.Class75_0.UInt16_2, (ushort) 15, (byte) 1);
        Thread.Sleep(1000);
      }
      else
      {
        if (!Struct17.smethod_0(this.Struct17_0, new Struct17((short) 503, (short) 41, (short) 59)) || obj0.Int16_0 != (short) 3014)
          return;
        Class142 sender = this.method_128(\u003CModule\u003E.smethod_8<string>(1377617179U));
        this.method_141(sender, \u003CModule\u003E.smethod_7<string>(3017479864U), true);
        this.method_90((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2, (byte) 1);
        this.method_89((byte) 1, sender.Int32_0, (ushort) 0, (ushort) 2);
      }
    }
    catch
    {
    }
  }

  internal bool method_54(short int_11) => this.method_51(new Struct17(int_11, (short) 0, (short) 0), (short) 0, true, true, true);

  internal bool method_55([In] short obj0, bool string_8)
  {
    if (this.class25_0 == null)
      return false;
    Struct16 int_11 = this.class25_0.List_1[this.int_6];
    if (int_11.method_0(this.struct16_1) <= (int) obj0)
    {
      ++this.int_6;
      if (this.int_6 >= this.class25_0.List_1.Count)
        this.int_6 = 0;
      int_11 = this.class25_0.List_1[this.int_6];
    }
    return this.method_50(int_11, (short) 0, true, true);
  }

  internal List<Struct16> method_56(Class142 int_11)
  {
    if (this.method_7(Enum10.Hide))
      return new List<Struct16>();
    return new List<Struct16>()
    {
      new Struct16((short) ((int) int_11.Struct16_0.short_0 - 2), int_11.Struct16_0.short_1),
      new Struct16((short) ((int) int_11.Struct16_0.short_0 - 1), (short) ((int) int_11.Struct16_0.short_1 + 1)),
      new Struct16((short) ((int) int_11.Struct16_0.short_0 - 1), int_11.Struct16_0.short_1),
      new Struct16((short) ((int) int_11.Struct16_0.short_0 - 1), (short) ((int) int_11.Struct16_0.short_1 - 1)),
      new Struct16(int_11.Struct16_0.short_0, (short) ((int) int_11.Struct16_0.short_1 + 2)),
      new Struct16(int_11.Struct16_0.short_0, (short) ((int) int_11.Struct16_0.short_1 + 1)),
      new Struct16(int_11.Struct16_0.short_0, (short) ((int) int_11.Struct16_0.short_1 - 1)),
      new Struct16(int_11.Struct16_0.short_0, (short) ((int) int_11.Struct16_0.short_1 - 2)),
      new Struct16((short) ((int) int_11.Struct16_0.short_0 + 1), (short) ((int) int_11.Struct16_0.short_1 + 1)),
      new Struct16((short) ((int) int_11.Struct16_0.short_0 + 1), int_11.Struct16_0.short_1),
      new Struct16((short) ((int) int_11.Struct16_0.short_0 + 1), (short) ((int) int_11.Struct16_0.short_1 - 1)),
      new Struct16((short) ((int) int_11.Struct16_0.short_0 + 2), int_11.Struct16_0.short_1)
    };
  }

  internal List<Struct16> method_57([In] Class142 obj0) => new List<Struct16>()
  {
    new Struct16((short) ((int) obj0.Struct16_0.short_0 - 1), obj0.Struct16_0.short_1),
    new Struct16(obj0.Struct16_0.short_0, (short) ((int) obj0.Struct16_0.short_1 + 1)),
    new Struct16(obj0.Struct16_0.short_0, (short) ((int) obj0.Struct16_0.short_1 - 1)),
    new Struct16((short) ((int) obj0.Struct16_0.short_0 + 1), obj0.Struct16_0.short_1)
  };

  internal void method_58(string int_11)
  {
    Class99 class99 = new Class99((byte) 78);
    class99.method_22(int_11);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_59([In] string obj0, string int_12)
  {
    Class99 class99 = new Class99((byte) 25);
    class99.method_22(obj0);
    class99.method_22(int_12);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_60([In] byte obj0, string int_11)
  {
    Class99 class99 = new Class99((byte) 14);
    class99.method_14(obj0);
    class99.method_22(int_11);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_61([In] byte obj0, [In] int obj1, [In] string obj2)
  {
    if (!this.Class26_0.bool_19)
      return;
    Class100 class100 = new Class100((byte) 13);
    class100.method_14(obj0);
    class100.method_19(obj1);
    class100.method_22(obj2);
    this.method_4(new Class98[1]{ (Class98) class100 });
  }

  internal void method_62([In] byte obj0, [In] int obj1, string ushort_2)
  {
    Class100 class100 = new Class100((byte) 13);
    class100.method_14(obj0);
    class100.method_19(obj1);
    class100.method_22(ushort_2);
    this.method_4(new Class98[1]{ (Class98) class100 });
  }

  internal void method_63([In] int obj0)
  {
    Class100 class100 = new Class100((byte) 41);
    class100.method_19(obj0);
    class100.method_19(obj0);
    class100.method_18((ushort) 374);
    class100.method_18((ushort) 374);
    class100.method_17((short) 100);
    this.method_4(new Class98[1]{ (Class98) class100 });
  }

  internal void method_64(
    [In] byte obj0,
    [In] byte obj1,
    int ushort_2,
    byte ushort_3,
    ushort byte_10,
    [In] byte obj5,
    [In] byte obj6,
    [In] ushort obj7,
    [In] byte obj8,
    [In] ushort obj9,
    [In] ushort obj10,
    [In] bool obj11,
    [In] bool obj12,
    [In] byte obj13,
    [In] string obj14,
    [In] string obj15)
  {
    Class100 class100 = new Class100((byte) 48);
    class100.method_14(obj0);
    class100.method_14(obj1);
    class100.method_19(ushort_2);
    class100.method_14(ushort_3);
    class100.method_18(byte_10);
    class100.method_14(obj5);
    class100.method_14(obj6);
    class100.method_18(obj7);
    class100.method_14(obj8);
    class100.method_18(obj9);
    class100.method_18(obj10);
    class100.method_16(obj11);
    class100.method_16(obj12);
    class100.method_14(obj13);
    class100.method_22(obj14);
    class100.method_23(obj15);
    this.method_4(new Class98[1]{ (Class98) class100 });
  }

  internal void method_65()
  {
    Class100 class100 = new Class100((byte) 5);
    class100.method_20(this.uint_0);
    class100.method_18((ushort) 0);
    class100.method_14(this.method_17(Enum0.ZoomableMap) ? (byte) 2 : this.byte_6);
    class100.method_18((ushort) 0);
    this.method_4(new Class98[1]{ (Class98) class100 });
  }

  internal void method_66([In] Class143 obj0)
  {
    Struct16 struct160 = obj0.Struct16_0;
    ushort num1 = obj0.UInt16_0;
    if (obj0 == this.class143_0 && this.bool_23)
      num1 = this.ushort_0;
    if (obj0 == this.class143_0 && this.Control2_0.checkBox_20.Checked && obj0.Byte_2 != (byte) 48)
    {
      obj0.Byte_2 = !this.Control2_0.checkBox_19.Checked ? (byte) 32 : (byte) 16;
      obj0.UInt16_1 = (ushort) this.Control2_0.numericUpDown_16.Value;
      obj0.Byte_3 = (byte) this.Control2_0.numericUpDown_13.Value;
      if (this.Control2_0.numericUpDown_10.Value > 0M && this.class76_0[3] != null)
        obj0.Byte_4 = (byte) this.Control2_0.numericUpDown_10.Value;
      if (this.Control2_0.numericUpDown_12.Value > 0M && this.class76_0[1] != null)
        obj0.UInt16_4 = (ushort) this.Control2_0.numericUpDown_12.Value;
      obj0.Byte_5 = (byte) this.Control2_0.numericUpDown_11.Value;
      obj0.Byte_7 = (byte) this.Control2_0.numericUpDown_8.Value;
      obj0.UInt16_5 = (ushort) this.Control2_0.numericUpDown_9.Value;
      obj0.Byte_8 = (byte) this.Control2_0.numericUpDown_6.Value;
      obj0.UInt16_6 = (ushort) this.Control2_0.numericUpDown_7.Value;
      obj0.Byte_9 = (byte) this.Control2_0.numericUpDown_4.Value;
      obj0.UInt16_7 = (ushort) this.Control2_0.numericUpDown_5.Value;
      if (this.Control2_0.numericUpDown_14.Value > 0M && this.class76_0[2] != null)
        obj0.UInt16_8 = (ushort) this.Control2_0.numericUpDown_14.Value;
      obj0.Byte_13 = (byte) this.Control2_0.numericUpDown_15.Value;
      obj0.Byte_14 = (byte) this.Control2_0.numericUpDown_17.Value;
      obj0.Direction_0 = this.Direction_1;
      if (this.Control2_0.checkBox_18.Checked && !string.IsNullOrEmpty(obj0.String_5) && obj0.Equals((object) this.Class143_0))
      {
        Class144 class144 = new Class144(obj0);
        if (!this.Class112_0.form5_0.dictionary_4.ContainsKey(obj0.String_5) || !this.Class112_0.form5_0.dictionary_4[obj0.String_5].Equals((object) class144))
        {
          Class180 stream_1 = new Class180(Enum14.DMUResponse);
          stream_1.method_27(obj0.String_5);
          stream_1.method_19(true);
          stream_1.method_29(class144);
          this.Class112_0.form5_0.class178_0.method_2(stream_1);
        }
      }
    }
    Class100 class100 = new Class100((byte) 51);
    class100.method_24(obj0.Struct16_0);
    class100.method_14((byte) obj0.Direction_0);
    class100.method_19(obj0.Int32_0);
    if (num1 == (ushort) 0)
    {
      class100.method_18(obj0.UInt16_1);
      if (obj0.Byte_2 == (byte) 0 && this.method_17(Enum0.SeeHidden) && !this.Boolean_0)
        class100.method_14((byte) 80);
      else
        class100.method_14(obj0.Byte_2);
      class100.method_18(obj0.UInt16_2);
      class100.method_14(obj0.Byte_3);
      class100.method_18(obj0.UInt16_3);
      class100.method_14(obj0.Byte_4);
      class100.method_18(obj0.UInt16_4);
      class100.method_14(obj0.Byte_5);
      class100.method_14(obj0.Byte_6);
      class100.method_14(obj0.Byte_7);
      class100.method_18(obj0.UInt16_5);
      class100.method_14(obj0.Byte_8);
      class100.method_18(obj0.UInt16_6);
      class100.method_14(obj0.Byte_9);
      class100.method_18(obj0.UInt16_7);
      class100.method_14(obj0.Byte_10);
      class100.method_14(obj0.Byte_11);
      class100.method_18(obj0.UInt16_8);
      class100.method_14(obj0.Byte_12);
      class100.method_14(obj0.Byte_13);
      class100.method_16(obj0.bool_1);
      class100.method_14(obj0.Byte_14);
    }
    else
    {
      class100.method_18(ushort.MaxValue);
      class100.method_18((ushort) ((uint) num1 + 16384U));
      class100.method_14(obj0.Byte_5);
      class100.method_14(obj0.Byte_6);
      class100.method_18((ushort) 0);
      class100.method_20(0U);
    }
    class100.method_14(obj0.Byte_15);
    if (obj0.Byte_2 == (byte) 0 && !this.method_17(Enum0.SeeHidden))
    {
      Class88 class880 = this.class88_0;
      int num2;
      if (class880 == null)
      {
        num2 = 0;
      }
      else
      {
        bool? nullable = class880.String_0?.Contains(\u003CModule\u003E.smethod_7<string>(4279987829U));
        num2 = !nullable.GetValueOrDefault() & nullable.HasValue ? 1 : 0;
      }
      if (num2 != 0 && !this.Boolean_0)
      {
        class100.method_22(string.Empty);
        goto label_25;
      }
    }
    class100.method_22(obj0.String_5);
label_25:
    class100.method_22(obj0.String_4);
    this.method_4(new Class98[1]{ (Class98) class100 });
  }

  internal void method_67(Class143 byte_9)
  {
    byte_9.method_2();
    byte_9.Byte_5 = (byte) 1;
    byte_9.Byte_2 = (byte) 48;
    this.method_66(byte_9);
    this.method_73(byte_9.Int32_0);
  }

  internal void method_68([In] Class141 obj0)
  {
    Class100 class100 = new Class100((byte) 7);
    class100.method_18((ushort) 1);
    class100.method_24(obj0.Struct16_0);
    class100.method_19(obj0.Int32_0);
    class100.method_18((ushort) ((uint) obj0.UInt16_0 + 32768U));
    this.method_4(new Class98[1]{ (Class98) class100 });
  }

  internal void method_69([In] Class142 obj0)
  {
    Class100 class100 = new Class100((byte) 7);
    class100.method_18((ushort) 1);
    class100.method_24(obj0.Struct16_0);
    class100.method_19(obj0.Int32_0);
    class100.method_18((ushort) ((uint) obj0.UInt16_0 + 16384U));
    class100.method_14((byte) 0);
    class100.method_13(new byte[2]);
    class100.method_14((byte) 0);
    class100.method_14((byte) obj0.Direction_0);
    class100.method_14((byte) 0);
    class100.method_14(obj0.Byte_0);
    this.method_4(new Class98[1]{ (Class98) class100 });
  }

  internal void method_70(Class142 int_11)
  {
    Class100 class100 = new Class100((byte) 7);
    class100.method_18((ushort) 1);
    class100.method_24(int_11.Struct16_0);
    class100.method_19(int_11.Int32_0);
    class100.method_18((ushort) ((uint) int_11.UInt16_0 + 16384U));
    class100.method_14((byte) 0);
    class100.method_13(new byte[2]);
    class100.method_14((byte) 0);
    class100.method_14((byte) int_11.Direction_0);
    class100.method_14((byte) 0);
    class100.method_14(int_11.Byte_0);
    class100.method_22(int_11.String_0);
    this.method_4(new Class98[1]{ (Class98) class100 });
  }

  internal void method_71([In] int obj0)
  {
    Class100 class100 = new Class100((byte) 14);
    class100.method_20((uint) obj0);
    this.method_4(new Class98[1]{ (Class98) class100 });
  }

  internal void method_72() => this.method_4(new Class98[1]
  {
    (Class98) new Class99((byte) 45)
  });

  internal void method_73(int class135_0)
  {
    Class99 class99 = new Class99((byte) 12);
    class99.method_19(class135_0);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_74([In] byte obj0, string enum12_0)
  {
    Class100 class100 = new Class100((byte) 2);
    class100.method_14(obj0);
    class100.method_22(enum12_0);
    this.method_4(new Class98[1]{ (Class98) class100 });
  }

  internal void method_75(byte class135_0, string ushort_2)
  {
    if (this.bool_47)
      return;
    Class100 class100 = new Class100((byte) 10);
    class100.method_14(class135_0);
    class100.method_23(ushort_2);
    this.method_4(new Class98[1]{ (Class98) class100 });
  }

  internal void method_76([In] ushort obj0, [In] short obj1)
  {
    Class100 class100 = new Class100((byte) 41);
    class100.method_20(this.uint_0);
    class100.method_20(this.uint_0);
    class100.method_18(obj0);
    class100.method_18(obj0);
    class100.method_17(obj1);
    this.method_4(new Class98[1]{ (Class98) class100 });
  }

  internal void method_77(ushort class132_0, short byte_9, [In] Struct16 obj2)
  {
    Class100 class100 = new Class100((byte) 41);
    class100.method_20(0U);
    class100.method_18(class132_0);
    class100.method_17(byte_9);
    class100.method_24(obj2);
    this.method_4(new Class98[1]{ (Class98) class100 });
  }

  internal void method_78([In] int obj0)
  {
    Class99 class99 = new Class99((byte) 67);
    class99.method_14((byte) 1);
    class99.method_19(obj0);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_79(Struct16 class134_2)
  {
    Class99 class99 = new Class99((byte) 67);
    class99.method_14((byte) 3);
    class99.method_24(class134_2);
    class99.method_14((byte) 0);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_80(int byte_9, string ushort_2)
  {
    this.method_88((byte) 1, byte_9, (ushort) 64, Array.Empty<object>());
    Class99 class99 = new Class99((byte) 57);
    class99.method_14((byte) 1);
    class99.method_19(byte_9);
    class99.method_17((short) 74);
    class99.method_22(ushort_2);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_81([In] int obj0, [In] string obj1)
  {
    Class99 class99_1 = new Class99((byte) 57);
    class99_1.method_14((byte) 1);
    class99_1.method_19(obj0);
    class99_1.method_17((short) 23);
    class99_1.method_22(obj1);
    this.method_4(new Class98[1]{ (Class98) class99_1 });
    Class99 class99_2 = new Class99((byte) 57);
    class99_2.method_14((byte) 1);
    class99_2.method_19(obj0);
    class99_2.method_17((short) 44);
    class99_2.method_22(obj1);
    this.method_4(new Class98[1]{ (Class98) class99_2 });
    Class99 class99_3 = new Class99((byte) 57);
    class99_3.method_14((byte) 1);
    class99_3.method_19(obj0);
    class99_3.method_17((short) 46);
    class99_3.method_22(obj1);
    this.method_4(new Class98[1]{ (Class98) class99_3 });
  }

  internal void method_82([In] int obj0, [In] string obj1)
  {
    Class99 class99_1 = new Class99((byte) 57);
    class99_1.method_14((byte) 1);
    class99_1.method_19(obj0);
    class99_1.method_17((short) 17);
    class99_1.method_22(obj1);
    this.method_4(new Class98[1]{ (Class98) class99_1 });
    Class99 class99_2 = new Class99((byte) 57);
    class99_2.method_14((byte) 1);
    class99_2.method_19(obj0);
    class99_2.method_17((short) 36);
    class99_2.method_22(obj1);
    this.method_4(new Class98[1]{ (Class98) class99_2 });
    Class99 class99_3 = new Class99((byte) 57);
    class99_3.method_14((byte) 1);
    class99_3.method_19(obj0);
    class99_3.method_17((short) 38);
    class99_3.method_22(obj1);
    this.method_4(new Class98[1]{ (Class98) class99_3 });
  }

  internal void method_83(int bool_49 = true, string byte_10, [In] int obj2)
  {
    Class99 class99_1 = new Class99((byte) 57);
    class99_1.method_14((byte) 1);
    class99_1.method_19(bool_49);
    class99_1.method_17((short) 74);
    class99_1.method_22(byte_10);
    this.method_4(new Class98[1]{ (Class98) class99_1 });
    Class99 class99_2 = new Class99((byte) 57);
    class99_2.method_14((byte) 1);
    class99_2.method_19(bool_49);
    class99_2.method_17((short) 76);
    class99_2.method_22(byte_10);
    class99_2.method_22(obj2.ToString());
    this.method_4(new Class98[1]{ (Class98) class99_2 });
  }

  internal void method_84(int short_0, string struct16_3, [In] int obj2)
  {
    Class99 class99 = new Class99((byte) 57);
    class99.method_14((byte) 1);
    class99.method_19(short_0);
    class99.method_17(obj2 > 0 ? (short) 87 : (short) 86);
    class99.method_22(struct16_3);
    if (obj2 > 0)
      class99.method_22(obj2.ToString());
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_85(int string_8, string string_9 = "", [In] int obj2)
  {
    byte num = 0;
    if (!this.Class21_0.method_0(string_9))
      this.method_75((byte) 0, \u003CModule\u003E.smethod_8<string>(2151285688U));
    else
      num = this.Class21_0[string_9].Byte_0;
    Class99 class99 = new Class99((byte) 57);
    class99.method_14((byte) 1);
    class99.method_19(string_8);
    class99.method_17(obj2 > 1 ? (short) 84 : (short) 83);
    if (obj2 > 1)
      class99.method_14((byte) 1);
    class99.method_14(num);
    if (obj2 > 1)
      class99.method_22(obj2.ToString());
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_86([In] int obj0, [In] int obj1)
  {
    Class99 class99 = new Class99((byte) 57);
    class99.method_14((byte) 1);
    class99.method_19(obj0);
    class99.method_17((short) 85);
    class99.method_22(obj1.ToString());
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_87([In] int obj0, [In] int obj1)
  {
    Class99 class99 = new Class99((byte) 57);
    class99.method_14((byte) 1);
    class99.method_19(obj0);
    class99.method_17((short) 82);
    class99.method_22(obj1.ToString());
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_88([In] byte obj0, [In] int obj1, [In] ushort obj2, [In] object[] obj3)
  {
    Class99 class99 = new Class99((byte) 57);
    class99.method_14(obj0);
    class99.method_19(obj1);
    class99.method_18(obj2);
    class99.method_25((Array) obj3);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_89(byte int_11 = 12, params int ushort_2, [In] ushort obj2, [In] ushort obj3)
  {
    Class99 class99 = new Class99((byte) 58);
    class99.method_14(int_11);
    class99.method_19(ushort_2);
    class99.method_18(obj2);
    class99.method_18(obj3);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_90([In] byte obj0, params int ushort_2, [In] ushort obj2, [In] ushort obj3, [In] byte obj4)
  {
    Class99 class99 = new Class99((byte) 58);
    class99.method_14(obj0);
    class99.method_19(ushort_2);
    class99.method_18(obj2);
    class99.method_18(obj3);
    class99.method_14((byte) 1);
    class99.method_14(obj4);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_91(byte string_8, [In] int obj1, [In] ushort obj2, [In] ushort obj3, [In] string obj4)
  {
    Class99 class99 = new Class99((byte) 58);
    class99.method_14(string_8);
    class99.method_19(obj1);
    class99.method_18(obj2);
    class99.method_18(obj3);
    class99.method_14((byte) 2);
    class99.method_22(obj4);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_92([In] byte obj0, short int_11 = 12, [In] short obj2) => this.method_93(obj0, new Struct16(int_11, obj2));

  internal void method_93(byte string_8, [In] Struct16 obj1)
  {
    Class99 class99 = new Class99((byte) 7);
    class99.method_14(string_8);
    class99.method_24(obj1);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_94(byte string_8_1, short string_8_2, [In] short obj2, [In] int obj3) => this.method_95(string_8_1, new Struct16(string_8_2, obj2), obj3);

  internal void method_95([In] byte obj0, [In] Struct16 obj1, int bool_49)
  {
    Class99 class99 = new Class99((byte) 8);
    class99.method_14(obj0);
    class99.method_24(obj1);
    class99.method_19(bool_49);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_96(int byte_9, Struct16 string_8)
  {
    Class99 class99 = new Class99((byte) 36);
    class99.method_19(byte_9);
    class99.method_24(string_8);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_97(Class135 string_8, [In] Enum12 obj1, [In] ushort obj2)
  {
    int num = (int) obj1 * 36;
    this.method_98(string_8, obj2, (byte) 0, (byte) (num + 1));
  }

  internal void method_98([In] Class135 obj0, ushort string_9, [In] byte obj2, [In] byte obj3)
  {
    if ((int) obj2 >= this.class136_0.Int32_0 || this.class136_0[obj2] != null || this.class136_0[obj0.String_0] != null)
      return;
    if ((int) obj2 < (int) obj3)
      obj2 = obj3;
    while ((int) obj2 < this.class136_0.Int32_0 && this.class136_0[obj2] != null)
      ++obj2;
    if (this.class136_0[obj2] != null)
      return;
    obj0.Byte_0 = obj2;
    this.class136_0.method_0((Class134) obj0);
    Class100 class100_1 = new Class100((byte) 23);
    class100_1.method_14(obj0.Byte_0 = obj2);
    class100_1.method_18(string_9);
    class100_1.method_14(obj0.Byte_1);
    class100_1.method_22(obj0.String_0);
    class100_1.method_22(obj0.String_1);
    Class100 class100_2 = class100_1;
    obj0.Byte_2 = (byte) 0;
    class100_2.method_14((byte) 0);
    this.method_4(new Class98[1]{ (Class98) class100_1 });
  }

  internal void method_99(Class132 string_8)
  {
    Class100 class100 = new Class100((byte) 44);
    class100.method_14(string_8.Byte_0);
    class100.method_18(string_8.UInt16_0);
    class100.method_22(string_8.String_0);
    this.method_4(new Class98[1]{ (Class98) class100 });
  }

  internal void method_100(bool int_11, byte int_12, [In] uint obj2)
  {
    Class100 class100 = new Class100((byte) 63);
    class100.method_16(int_11);
    class100.method_14(int_12);
    class100.method_20(obj2);
    this.method_4(new Class98[1]{ (Class98) class100 });
  }

  internal void method_101(Class134 class142_2)
  {
    Class100 class100 = new Class100((byte) 23);
    class100.method_14(class142_2.Byte_0);
    class100.method_18(class142_2.UInt16_0);
    class100.method_14(class142_2.Byte_1);
    class100.method_22(class142_2.String_0);
    class100.method_22(class142_2.String_1);
    class100.method_14(class142_2.Byte_2);
    this.method_4(new Class98[1]{ (Class98) class100 });
  }

  internal void method_102(
    byte keyValuePair_0,
    [In] ushort obj1,
    [In] byte obj2,
    [In] string obj3,
    [In] string obj4,
    [In] byte obj5)
  {
    Class100 class100 = new Class100((byte) 23);
    class100.method_14(keyValuePair_0);
    class100.method_18(obj1);
    class100.method_14(obj2);
    class100.method_22(obj3);
    class100.method_22(obj4);
    class100.method_14(obj5);
    this.method_4(new Class98[1]{ (Class98) class100 });
  }

  internal void method_103()
  {
    Class100 class100_1 = new Class100((byte) 21);
    class100_1.method_17(this.class88_0.Int16_0);
    class100_1.method_14(this.class88_0.Byte_0);
    class100_1.method_14(this.class88_0.Byte_1);
    if (this.bool_22)
      class100_1.method_14((byte) this.enum5_0);
    else
      class100_1.method_14(this.class88_0.Byte_2);
    class100_1.method_18((ushort) 0);
    class100_1.method_14((byte) ((uint) this.class88_0.UInt16_0 % 256U));
    class100_1.method_14((byte) ((uint) this.class88_0.UInt16_0 / 256U));
    class100_1.method_22(this.class88_0.String_0);
    this.method_4(new Class98[1]{ (Class98) class100_1 });
    Class100 class100_2 = new Class100((byte) 22);
    class100_2.method_14((byte) 0);
    this.method_4(new Class98[1]{ (Class98) class100_2 });
  }

  internal void method_104()
  {
    this.struct16_1 = this.struct16_2;
    Class100 class100 = new Class100((byte) 4);
    class100.method_24(this.struct16_2);
    class100.method_18((ushort) 11);
    class100.method_18((ushort) 11);
    this.method_4(new Class98[1]{ (Class98) class100 });
  }

  internal void method_105(bool object_0)
  {
    if (this.bool_48)
      return;
    this.bool_48 = true;
    this.method_4(new Class98[1]
    {
      (Class98) new Class99((byte) 56)
    });
    if (object_0)
    {
      DateTime utcNow = DateTime.UtcNow;
      while (DateTime.UtcNow.Subtract(utcNow).TotalMilliseconds < 1500.0)
      {
        if (!this.bool_46)
        {
          Thread.Sleep(10);
        }
        else
        {
          this.bool_46 = false;
          break;
        }
      }
    }
    this.bool_48 = false;
  }

  internal void method_106(byte keyValuePair_0, [In] byte obj1)
  {
    Class99 class99 = new Class99((byte) 48);
    class99.method_14(keyValuePair_0);
    class99.method_14(obj1);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_107()
  {
    Class99 class99 = new Class99((byte) 68);
    class99.method_14((byte) 1);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal bool method_108() => this.Class76_0[1] != null && this.list_5.Select<Class17, string>((Func<Class17, string>) (sender => sender.String_0)).Contains<string>(this.Class76_0[1].String_0) && !this.Class76_0[1].Class17_0.Boolean_1;

  internal void method_109()
  {
    if (this.Class76_0[1] == null || !this.list_4.Select<Class24, string>((Func<Class24, string>) (obj0 => obj0.String_0)).Contains<string>(this.Class76_0[1].String_0))
      return;
    Class99 class99 = new Class99((byte) 68);
    class99.method_14((byte) 1);
    this.method_4(new Class98[1]{ (Class98) class99 });
    Dictionary<string, byte> dictionary0 = this.list_4[0].Dictionary_0;
    foreach (Class134 class134 in this.Class136_0.Where<Class134>((Func<Class134, bool>) (sender => sender != null)))
    {
      if (dictionary0.ContainsKey(class134.String_0))
        class134.Byte_2 = dictionary0[class134.String_0];
    }
  }

  internal void method_110()
  {
    Class99 class99 = new Class99((byte) 68);
    class99.method_14((byte) 3);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_111()
  {
    Class99 class99 = new Class99((byte) 71);
    class99.method_14((byte) 1);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_112(short string_0, [In] Struct16 obj1)
  {
    Class99 class99 = new Class99((byte) 63);
    class99.method_19((int) string_0);
    class99.method_24(obj1);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_113(string class142_0)
  {
    Class99 class99 = new Class99((byte) 46);
    class99.method_14((byte) 2);
    class99.method_22(class142_0);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_114(string class17_0)
  {
    Class99 class99 = new Class99((byte) 46);
    class99.method_14((byte) 3);
    class99.method_22(class17_0);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_115(
    string class24_0,
    [In] string obj1,
    [In] byte obj2,
    [In] byte obj3,
    [In] byte obj4,
    [In] byte obj5,
    [In] byte obj6,
    [In] byte obj7,
    [In] byte obj8)
  {
    Class99 class99 = new Class99((byte) 46);
    class99.method_14((byte) 4);
    class99.method_22(this.string_3);
    class99.method_22(class24_0);
    class99.method_22(obj1);
    class99.method_14(obj2);
    class99.method_14(obj3);
    class99.method_14(obj4);
    class99.method_14(obj5);
    class99.method_14(obj6);
    class99.method_14(obj7);
    class99.method_14(obj8);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal List<Class139> method_116()
  {
    List<Class139> class139List = new List<Class139>();
    if (Monitor.TryEnter(Class112.object_0, 1000))
    {
      try
      {
        foreach (int key in this.hashSet_2)
        {
          if (this.dictionary_1.ContainsKey(key))
            class139List.Add(this.dictionary_1[key]);
        }
      }
      finally
      {
        Monitor.Exit(Class112.object_0);
      }
    }
    return class139List;
  }

  internal List<Class142> method_117(int class142_0)
  {
    List<Class142> class142List = new List<Class142>();
    if (Monitor.TryEnter(Class112.object_0, 1000))
    {
      try
      {
        foreach (Class142 class142_1 in this.method_116().OfType<Class142>())
        {
          if (class142_1.Byte_0 < (byte) 2 && class142_1.UInt16_0 > (ushort) 0 && class142_1.UInt16_0 <= (ushort) 1000 && this.method_131((Class140) class142_1, class142_0) && !this.Class112_0.list_4.Contains(class142_1.UInt16_0))
            class142List.Add(class142_1);
        }
      }
      finally
      {
        Monitor.Exit(Class112.object_0);
      }
    }
    return class142List;
  }

  internal List<Class142> method_118(int class91_0, [In] ushort[] obj1)
  {
    List<Class142> class142List = new List<Class142>();
    HashSet<ushort> ushortSet = new HashSet<ushort>((IEnumerable<ushort>) obj1);
    if (Monitor.TryEnter(Class112.object_0, 1000))
    {
      try
      {
        foreach (Class142 class142_1 in this.method_116().OfType<Class142>())
        {
          if ((class142_1.Byte_0 == (byte) 0 || class142_1.Byte_0 == (byte) 1) && this.method_131((Class140) class142_1, class91_0) && class142_1.UInt16_0 > (ushort) 0 && class142_1.UInt16_0 <= (ushort) 1000 && !this.Class112_0.list_4.Contains(class142_1.UInt16_0) && ushortSet.Contains(class142_1.UInt16_0))
            class142List.Add(class142_1);
        }
      }
      finally
      {
        Monitor.Exit(Class112.object_0);
      }
    }
    return class142List;
  }

  internal List<Class142> method_119(int class142_0)
  {
    List<Class142> class142List = new List<Class142>();
    if (Monitor.TryEnter(Class112.object_0, 1000))
    {
      try
      {
        // ISSUE: object of a compiler-generated type is created
        // ISSUE: variable of a compiler-generated type
        Class29.Class38 class38 = new Class29.Class38();
        // ISSUE: reference to a compiler-generated field
        class38.class29_0 = this;
        foreach (Class142 class142_1 in this.method_116().OfType<Class142>())
        {
          if (class142_1.Byte_0 < (byte) 2 && class142_1.UInt16_0 > (ushort) 0 && class142_1.UInt16_0 <= (ushort) 1000 && this.method_131((Class140) class142_1, class142_0))
            class142List.Add(class142_1);
        }
        // ISSUE: reference to a compiler-generated field
        class38.list_0 = new List<ushort>();
        List<ushort> collection;
        if (this.Class112_0.dictionary_2.TryGetValue((int) this.class88_0.Int16_0, out collection))
        {
          // ISSUE: reference to a compiler-generated field
          class38.list_0.AddRange((IEnumerable<ushort>) collection);
        }
        KeyValuePair<string, List<ushort>> keyValuePair = this.Class112_0.dictionary_3.FirstOrDefault<KeyValuePair<string, List<ushort>>>((Func<KeyValuePair<string, List<ushort>>, bool>) (obj0 => this.class88_0.String_0.StartsWith(obj0.Key)));
        List<ushort> ushortList = keyValuePair.Value;
        // ISSUE: explicit non-virtual call
        if ((ushortList != null ? (__nonvirtual (ushortList.Count) > 0 ? 1 : 0) : 0) != 0)
        {
          // ISSUE: reference to a compiler-generated field
          class38.list_0.AddRange((IEnumerable<ushort>) keyValuePair.Value);
        }
        if (class142List.Count > 0)
        {
          // ISSUE: reference to a compiler-generated method
          class142List.RemoveAll(new Predicate<Class142>(class38.method_0));
        }
      }
      finally
      {
        Monitor.Exit(Class112.object_0);
      }
    }
    return class142List;
  }

  internal List<Class142> method_120(int class142_0, [In] ushort[] obj1)
  {
    List<Class142> class142List = new List<Class142>();
    HashSet<ushort> ushortSet = new HashSet<ushort>((IEnumerable<ushort>) obj1);
    if (Monitor.TryEnter(Class112.object_0, 1000))
    {
      try
      {
        // ISSUE: object of a compiler-generated type is created
        // ISSUE: variable of a compiler-generated type
        Class29.Class39 class39 = new Class29.Class39();
        // ISSUE: reference to a compiler-generated field
        class39.class29_0 = this;
        foreach (Class142 class142_1 in this.method_116().OfType<Class142>())
        {
          if (class142_1.Byte_0 < (byte) 2 && class142_1.UInt16_0 > (ushort) 0 && class142_1.UInt16_0 < (ushort) 1000 && this.method_131((Class140) class142_1, class142_0) && ushortSet.Contains(class142_1.UInt16_0))
            class142List.Add(class142_1);
        }
        // ISSUE: reference to a compiler-generated field
        class39.list_0 = new List<ushort>();
        List<ushort> collection;
        if (this.Class112_0.dictionary_2.TryGetValue((int) this.class88_0.Int16_0, out collection))
        {
          // ISSUE: reference to a compiler-generated field
          class39.list_0.AddRange((IEnumerable<ushort>) collection);
        }
        KeyValuePair<string, List<ushort>> keyValuePair = this.Class112_0.dictionary_3.FirstOrDefault<KeyValuePair<string, List<ushort>>>((Func<KeyValuePair<string, List<ushort>>, bool>) (obj0 => this.class88_0.String_0.StartsWith(obj0.Key)));
        List<ushort> ushortList = keyValuePair.Value;
        // ISSUE: explicit non-virtual call
        if ((ushortList != null ? (__nonvirtual (ushortList.Count) > 0 ? 1 : 0) : 0) != 0)
        {
          // ISSUE: reference to a compiler-generated field
          class39.list_0.AddRange((IEnumerable<ushort>) keyValuePair.Value);
        }
        if (class142List.Count > 0)
        {
          // ISSUE: reference to a compiler-generated method
          class142List.RemoveAll(new Predicate<Class142>(class39.method_0));
        }
      }
      finally
      {
        Monitor.Exit(Class112.object_0);
      }
    }
    return class142List;
  }

  internal List<Struct16> method_121(Struct16 sender)
  {
    List<Struct16> struct16List = new List<Struct16>();
    Class93 class93;
    if (this.Class112_0.Dictionary_3.TryGetValue(this.class88_0.Int16_0, out class93))
    {
      foreach (KeyValuePair<Struct16, Class92> keyValuePair in class93.Dictionary_1)
      {
        if (Struct16.smethod_1(keyValuePair.Key, sender))
          struct16List.Add(keyValuePair.Key);
      }
      foreach (KeyValuePair<Struct16, Class94> keyValuePair in class93.Dictionary_2)
      {
        if (Struct16.smethod_1(keyValuePair.Key, sender))
          struct16List.Add(keyValuePair.Key);
      }
    }
    return struct16List;
  }

  internal List<Class141> method_122([In] int obj0)
  {
    List<Class141> class141List = new List<Class141>();
    if (Monitor.TryEnter(Class112.object_0, 1000))
    {
      try
      {
        foreach (int key in this.hashSet_3)
        {
          if (this.dictionary_1[key] is Class141)
          {
            Class141 class142_1 = this.dictionary_1[key] as Class141;
            if (this.method_131((Class140) class142_1, obj0))
              class141List.Add(class142_1);
          }
        }
      }
      finally
      {
        Monitor.Exit(Class112.object_0);
      }
    }
    return class141List;
  }

  internal List<Class141> method_123(int class17_0, [In] ushort[] obj1)
  {
    HashSet<ushort> ushortSet = new HashSet<ushort>((IEnumerable<ushort>) obj1);
    List<Class141> class141List = new List<Class141>();
    if (Monitor.TryEnter(Class112.object_0, 1000))
    {
      try
      {
        foreach (int key in this.hashSet_3)
        {
          if (this.dictionary_1[key] is Class141)
          {
            Class141 class142_1 = this.dictionary_1[key] as Class141;
            if (this.method_131((Class140) class142_1, class17_0) && ushortSet.Contains(class142_1.UInt16_0))
              class141List.Add(class142_1);
          }
        }
      }
      finally
      {
        Monitor.Exit(Class112.object_0);
      }
    }
    return class141List;
  }

  internal Class143 method_124(string class24_0)
  {
    if (!Monitor.TryEnter(Class112.object_0, 300))
      return (Class143) null;
    try
    {
      return !this.dictionary_2.ContainsKey(class24_0) ? (Class143) null : this.dictionary_2[class24_0];
    }
    finally
    {
      Monitor.Exit(Class112.object_0);
    }
  }

  internal List<Class143> method_125()
  {
    List<Class143> class143List = new List<Class143>();
    if (Monitor.TryEnter(Class112.object_0, 1000))
    {
      try
      {
        foreach (Class143 class143 in this.dictionary_2.Values.Where<Class143>((Func<Class143, bool>) (obj0 => !string.IsNullOrEmpty(obj0.String_5))))
          class143List.Add(class143);
      }
      finally
      {
        Monitor.Exit(Class112.object_0);
      }
    }
    return class143List;
  }

  internal List<Class143> method_126(string[] class24_0)
  {
    HashSet<string> stringSet = new HashSet<string>((IEnumerable<string>) class24_0, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase);
    List<Class143> class143List = new List<Class143>();
    if (Monitor.TryEnter(Class112.object_0, 1000))
    {
      try
      {
        foreach (Class143 class143 in this.dictionary_2.Values)
        {
          if (stringSet.Contains(class143.String_5))
            class143List.Add(class143);
        }
      }
      finally
      {
        Monitor.Exit(Class112.object_0);
      }
    }
    return class143List;
  }

  internal List<Class143> method_127()
  {
    List<Class143> class143List = new List<Class143>();
    if (Monitor.TryEnter(Class112.object_0, 1000))
    {
      try
      {
        foreach (Class143 class143 in this.dictionary_2.Values)
        {
          if (this.hashSet_4.Contains(class143.String_5))
            class143List.Add(class143);
        }
      }
      finally
      {
        Monitor.Exit(Class112.object_0);
      }
    }
    return class143List;
  }

  internal Class142 method_128(string class10_0)
  {
    if (!Monitor.TryEnter(Class112.object_0, 300))
      return (Class142) null;
    try
    {
      return !this.dictionary_5.ContainsKey(class10_0) ? (Class142) null : this.dictionary_5[class10_0];
    }
    finally
    {
      Monitor.Exit(Class112.object_0);
    }
  }

  internal List<Class142> method_129()
  {
    List<Class142> class142List = new List<Class142>();
    if (Monitor.TryEnter(Class112.object_0, 1000))
    {
      try
      {
        foreach (Class142 class142 in this.dictionary_5.Values)
          class142List.Add(class142);
      }
      finally
      {
        Monitor.Exit(Class112.object_0);
      }
    }
    return class142List;
  }

  internal List<Class142> method_130(string[] class10_0)
  {
    HashSet<string> stringSet = new HashSet<string>((IEnumerable<string>) class10_0, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase);
    List<Class142> class142List = new List<Class142>();
    if (Monitor.TryEnter(Class112.object_0, 1000))
    {
      try
      {
        foreach (Class142 class142 in this.dictionary_5.Values)
        {
          if (stringSet.Contains(class142.String_0))
            class142List.Add(class142);
        }
      }
      finally
      {
        Monitor.Exit(Class112.object_0);
      }
    }
    return class142List;
  }

  internal bool method_131(Class140 class142_1, int class29_1) => this.hashSet_2.Contains(class142_1.Int32_0) && this.Struct16_1.method_0(class142_1.Struct16_0) <= class29_1;

  internal void timer_0_Tick(object sender, EventArgs e) => this.int_1 = 0;

  internal int method_132(string sender)
  {
    int num = this.Byte_6 >= (byte) 99 ? (int) this.Byte_6 : 99;
    // ISSUE: reference to a compiler-generated method
    switch (Class181.smethod_0(sender))
    {
      case 301833330:
        if (sender == \u003CModule\u003E.smethod_9<string>(937657706U))
          return 2000000;
        goto default;
      case 1544215329:
        if (sender == \u003CModule\u003E.smethod_9<string>(2104271927U))
          goto label_15;
        else
          goto default;
      case 1586538930:
        if (sender == \u003CModule\u003E.smethod_5<string>(4170311445U))
          goto label_9;
        else
          goto default;
      case 1812078524:
        if (!(sender == \u003CModule\u003E.smethod_9<string>(3683421402U)))
          goto default;
        else
          break;
      case 2358017708:
        if (sender == \u003CModule\u003E.smethod_6<string>(4228598133U))
          break;
        goto default;
      case 2360874113:
        if (sender == \u003CModule\u003E.smethod_5<string>(4106036923U))
          return 1056 - ((int) byte.MaxValue - num) * 6;
        goto default;
      case 2431366422:
        if (!(sender == \u003CModule\u003E.smethod_9<string>(3810951195U)))
          goto default;
        else
          goto label_9;
      case 3783935686:
        if (sender == \u003CModule\u003E.smethod_9<string>(2790712851U))
          return 88000 - ((int) byte.MaxValue - num) * 500;
        goto default;
      case 4118165127:
        if (!(sender == \u003CModule\u003E.smethod_6<string>(3116438880U)))
          goto default;
        else
          goto label_15;
      case 4167026527:
        if (sender == \u003CModule\u003E.smethod_5<string>(3379496620U))
          return 500 * (int) this.Byte_3;
        goto default;
      default:
        return 0;
    }
    return 26400 - ((int) byte.MaxValue - num) * 150;
label_9:
    return 8800 - ((int) byte.MaxValue - num) * 50;
label_15:
    return 52800 - ((int) byte.MaxValue - num) * 300;
  }

  internal void method_133([In] byte obj0)
  {
    this.Class26_0.bool_6 = true;
    if (!this.method_29(\u003CModule\u003E.smethod_5<string>(3977487879U)))
    {
      this.method_75((byte) 1, \u003CModule\u003E.smethod_5<string>(1797866970U));
      this.Control2_0.checkBox_86.Checked = false;
    }
    else
    {
      while (this.Class75_0 == null)
        Thread.Sleep(25);
      byte byte1_1 = this.Class75_0.Byte_1;
      int int320_1 = this.Class75_0.Int32_0;
      ushort uint162_1 = this.Class75_0.UInt16_2;
      ushort uint163_1 = this.Class75_0.UInt16_3;
      this.method_89(byte1_1, int320_1, uint162_1, (ushort) ((uint) uint163_1 + 1U));
      this.method_90(byte1_1, int320_1, uint162_1, (ushort) ((uint) uint163_1 + 1U), obj0);
      this.method_89(byte1_1, int320_1, uint162_1, (ushort) ((uint) uint163_1 + 1U));
      this.method_89(byte1_1, int320_1, uint162_1, (ushort) ((uint) uint163_1 + 1U));
      this.method_89(byte1_1, int320_1, uint162_1, (ushort) ((uint) uint163_1 + 1U));
      Thread.Sleep(1000);
      while (this.Class75_0 == null)
        Thread.Sleep(25);
      byte byte1_2 = this.Class75_0.Byte_1;
      int int320_2 = this.Class75_0.Int32_0;
      ushort uint162_2 = this.Class75_0.UInt16_2;
      ushort uint163_2 = this.Class75_0.UInt16_3;
      this.method_89(byte1_2, int320_2, uint162_2, (ushort) ((uint) uint163_2 + 1U));
      this.method_90(byte1_2, int320_2, uint162_2, (ushort) ((uint) uint163_2 + 1U), (byte) 2);
      this.method_89(byte1_2, int320_2, uint162_2, uint163_2);
      this.Class26_0.dateTime_5 = DateTime.UtcNow;
      this.Class26_0.bool_6 = false;
    }
  }

  private string method_134()
  {
    string[] source = Regex.Split(this.Control2_0.textBox_12.Text, \u003CModule\u003E.smethod_5<string>(1630276804U));
    ++this.int_8;
    if (this.int_8 > ((IEnumerable<string>) source).Count<string>() - 1)
      this.int_8 = 0;
    return source[this.int_8];
  }

  internal void method_135()
  {
    foreach (Class143 class143 in this.method_125())
    {
      if (!this.Class112_0.form5_0.bindingList_0.Contains(class143.String_5))
        new SoundPlayer((Stream) Class9.UnmanagedMemoryStream_1).PlaySync();
    }
  }

  private string[] method_136(string class29_1)
  {
    string[] strArray = new string[10];
    string path = string.Format(\u003CModule\u003E.smethod_5<string>(177196198U), (object) Settings.Default.DarkAgesPath.Replace(\u003CModule\u003E.smethod_7<string>(152792302U), ""), (object) this.string_3);
    if (!System.IO.File.Exists(path))
      return strArray;
    using (StreamReader streamReader = new StreamReader((Stream) System.IO.File.Open(path, FileMode.Open, FileAccess.Read, FileShare.Read)))
    {
      string str1;
      while ((str1 = streamReader.ReadLine()) != null)
      {
        if (str1.Equals(class29_1, StringComparison.CurrentCultureIgnoreCase))
        {
          for (int index = 0; index < strArray.Length; ++index)
          {
            string str2;
            if ((str2 = streamReader.ReadLine()) != null)
            {
              string str3 = string.Format(\u003CModule\u003E.smethod_7<string>(967969952U), (object) index);
              if (str2.StartsWith(str3))
                strArray[index] = str2.Substring(str3.Length);
              else
                break;
            }
            else
              break;
          }
          break;
        }
      }
    }
    return strArray;
  }

  internal Enum3 method_137(Enum3 disposing)
  {
    switch (disposing)
    {
      case Enum3.Fire:
        return Enum3.Water;
      case Enum3.Water:
        return Enum3.Earth;
      case Enum3.Wind:
        return Enum3.Fire;
      case Enum3.Earth:
        return Enum3.Wind;
      case Enum3.Holy:
        return Enum3.Darkness;
      case Enum3.Darkness:
        return Enum3.Holy;
      case Enum3.Wood:
        return Enum3.Wind;
      case Enum3.Metal:
        return Enum3.Water;
      case Enum3.Nature:
        return Enum3.Fire;
      default:
        return Enum3.Any;
    }
  }

  internal void method_138()
  {
    short x = 15;
    short y = 20;
    foreach (Class132 class132 in this.Class133_0.Dictionary_0.Values)
    {
      if (class132 != null && !this.Class112_0.list_0.Contains(class132.String_0) && !class132.String_0.Contains(\u003CModule\u003E.smethod_8<string>(3137608736U)) && !class132.String_0.Contains(\u003CModule\u003E.smethod_5<string>(48647154U)) && !class132.String_0.Contains(\u003CModule\u003E.smethod_6<string>(584780942U)) && !class132.String_0.Contains(\u003CModule\u003E.smethod_8<string>(2657491432U)) && !class132.String_0.Contains(\u003CModule\u003E.smethod_8<string>(3431159941U)) && (int) class132.Byte_1 < (int) class132.Byte_2)
      {
        this.Control2_0.method_45(class132.String_0, class132.UInt16_0, new Point((int) x, (int) y));
        x += (short) 40;
        if (x >= (short) 480)
        {
          x = (short) 15;
          y += (short) 40;
        }
      }
    }
    this.bool_5 = true;
  }

  internal void method_139()
  {
    short x = 15;
    short y = 20;
    foreach (Class132 class132 in this.Class133_0.Dictionary_0.Values)
    {
      if (class132 != null && !this.Class112_0.list_1.Contains(class132.String_0) && !class132.String_0.Contains(\u003CModule\u003E.smethod_5<string>(1501727760U)) && !class132.String_0.Contains(\u003CModule\u003E.smethod_7<string>(3704810442U)) && !class132.String_0.Contains(\u003CModule\u003E.smethod_5<string>(1437453238U)) && !class132.String_0.Contains(\u003CModule\u003E.smethod_6<string>(3483689248U)) && !class132.String_0.Contains(\u003CModule\u003E.smethod_8<string>(3431159941U)) && !class132.String_0.Contains(\u003CModule\u003E.smethod_7<string>(2006721156U)) && class132 != null)
      {
        this.Control2_0.method_46(class132.String_0, class132.UInt16_0, new Point((int) x, (int) y));
        x += (short) 40;
        if (x >= (short) 650)
        {
          x = (short) 15;
          y += (short) 40;
        }
      }
    }
    this.bool_7 = true;
  }

  internal void method_140()
  {
    short x = 15;
    short y = 20;
    foreach (Class134 class134 in this.Class136_0.Where<Class134>((Func<Class134, bool>) (sender => sender != null)))
    {
      if (!this.Class112_0.list_0.Contains(class134.String_0) && !class134.String_0.Contains(\u003CModule\u003E.smethod_7<string>(2090698644U)) && !class134.String_0.Contains(\u003CModule\u003E.smethod_7<string>(3704810442U)) && !class134.String_0.Contains(\u003CModule\u003E.smethod_8<string>(630037110U)) && !class134.String_0.Contains(\u003CModule\u003E.smethod_9<string>(3015826562U)) && !class134.String_0.Contains(\u003CModule\u003E.smethod_7<string>(3950501995U)) && (int) class134.Byte_3 < (int) class134.Byte_4)
      {
        this.Control2_0.method_47(class134.String_0, class134.UInt16_0, new Point((int) x, (int) y));
        x += (short) 40;
        if (x >= (short) 480)
        {
          x = (short) 15;
          y += (short) 40;
        }
      }
    }
    this.bool_6 = true;
  }

  internal bool method_141(Class142 sender, string e, [In] bool obj2)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class29.Class40 class40 = new Class29.Class40();
    // ISSUE: reference to a compiler-generated field
    class40.string_0 = e;
    DateTime utcNow1 = DateTime.UtcNow;
    if (sender == null)
      return false;
    TimeSpan timeSpan;
    // ISSUE: reference to a compiler-generated field
    if (!this.Class112_0.SortedDictionary_0.Values.Contains<string>(class40.string_0))
    {
      bool flag = false;
      this.method_78(sender.Int32_0);
      while (this.Class75_0 == null)
      {
        timeSpan = DateTime.UtcNow.Subtract(utcNow1);
        if (timeSpan.TotalSeconds > 2.0)
        {
          if (flag)
            return false;
          this.method_78(sender.Int32_0);
          flag = true;
        }
        Thread.Sleep(10);
      }
      this.Class75_0.method_4();
    }
    DateTime utcNow2 = DateTime.UtcNow;
    this.Class75_0 = (Class75) null;
    // ISSUE: reference to a compiler-generated method
    this.method_88((byte) 1, sender.Int32_0, this.Class112_0.SortedDictionary_0.FirstOrDefault<KeyValuePair<ushort, string>>(new Func<KeyValuePair<ushort, string>, bool>(class40.method_0)).Key, Array.Empty<object>());
    if (obj2)
    {
      while (this.Class75_0 == null)
      {
        timeSpan = DateTime.UtcNow.Subtract(utcNow2);
        if (timeSpan.TotalSeconds > 2.0)
          return false;
        Thread.Sleep(10);
      }
    }
    return true;
  }

  internal bool method_142()
  {
    DateTime utcNow = DateTime.UtcNow;
    while (this.Class75_0 == null)
    {
      if (DateTime.UtcNow.Subtract(utcNow).TotalSeconds > 3.0)
        return false;
      Thread.Sleep(10);
    }
    return true;
  }

  internal void method_143([In] string obj0, bool e)
  {
    int num1 = int.MaxValue;
    short num2 = 0;
    if (this.dictionary_15.Keys.Contains<short>(this.class88_0.Int16_0) && this.Struct16_0.method_0(new Struct16(6, 6)) <= 2)
    {
      Class142 class142 = (this.method_128(\u003CModule\u003E.smethod_5<string>(1842620931U)) ?? this.method_128(\u003CModule\u003E.smethod_5<string>(1116080628U))) ?? this.method_128(\u003CModule\u003E.smethod_9<string>(2967034603U));
      if (class142 != null)
      {
        this.method_88((byte) 1, class142.Int32_0, (ushort) 1335, Array.Empty<object>());
        DateTime utcNow = DateTime.UtcNow;
        while (this.Class75_0 == null)
        {
          if (DateTime.UtcNow.Subtract(utcNow).TotalSeconds > 1.5)
            return;
          Thread.Sleep(10);
        }
        if (this.Class75_0.String_1 == \u003CModule\u003E.smethod_8<string>(2310447674U))
        {
          this.Control2_0.button_35.Text = \u003CModule\u003E.smethod_7<string>(3073464856U);
        }
        else
        {
          if (!e)
            Thread.Sleep(1500);
          this.method_90((byte) 1, class142.Int32_0, (ushort) 311, (ushort) 17, (byte) 2);
          this.method_91((byte) 1, class142.Int32_0, (ushort) 311, (ushort) 25, obj0);
        }
      }
      Thread.Sleep(1500);
    }
    else
    {
      foreach (KeyValuePair<short, Struct16> keyValuePair in this.dictionary_15)
      {
        int count = this.class109_0.method_0(this.Struct17_0, new Struct17(keyValuePair.Key, keyValuePair.Value)).Count;
        if (count < num1 && count > 0)
        {
          num1 = count;
          num2 = keyValuePair.Key;
        }
      }
      if (num2 != (short) 0)
      {
        this.method_51(new Struct17(num2, this.dictionary_15[num2]), (short) 1, false, true, true);
      }
      else
      {
        this.Control2_0.button_35.Text = \u003CModule\u003E.smethod_5<string>(4150790884U);
        int num3 = (int) Form1.smethod_0(this.Class112_0.form5_0, \u003CModule\u003E.smethod_5<string>(518089369U), (IWin32Window) null, true);
      }
    }
  }

  internal void method_144()
  {
    if (this.class134_1 == null || this.class134_1.String_0 != \u003CModule\u003E.smethod_7<string>(2687627616U) || DateTime.UtcNow.Subtract(this.class134_1.DateTime_0).TotalSeconds > 30.0)
      this.method_31(\u003CModule\u003E.smethod_8<string>(2328642076U), (Class142) null, true, true);
    bool flag;
    string str = (flag = this.Control2_0.checkBox_16.Checked) ? this.Control2_0.textBox_11.Text : (string) null;
    byte num = flag ? (byte) 1 : (byte) 2;
    this.method_96(1, this.Struct16_0);
    while (this.Class75_0 == null)
      Thread.Sleep(25);
    if (!(this.Class75_0.String_1 == \u003CModule\u003E.smethod_7<string>(4133967645U)) && !(this.Class75_0.String_1 == \u003CModule\u003E.smethod_9<string>(1605252546U)))
    {
      byte byte0 = this.Class75_0.Byte_0;
      int int320 = this.Class75_0.Int32_0;
      ushort uint162 = this.Class75_0.UInt16_2;
      if (this.Class26_0.method_38())
        Thread.Sleep(1000);
      this.method_90(byte0, int320, uint162, (ushort) 39, num);
      if (flag)
        this.method_91(byte0, int320, uint162, (ushort) 44, str);
      this.class134_0 = new Class134();
      this.method_34();
      if (!this.bool_43 && this.Control2_0.checkBox_15.Checked)
      {
        this.method_149();
        this.method_95((byte) 1, this.Struct16_1, 1);
      }
      else
        this.bool_43 = false;
      Thread.Sleep(1000);
    }
    else
      this.Control2_0.button_36.Text = \u003CModule\u003E.smethod_9<string>(3743313152U);
  }

  internal void method_145([In] byte obj0, string e)
  {
    if (this.dictionary_10 == null || !this.dictionary_10.Any<KeyValuePair<string, string>>() || obj0 <= (byte) 0 || !(this.dictionary_10.Values.ToList<string>()[(int) obj0 - 1] != e.ToUpper()))
      return;
    Class99 class99 = new Class99((byte) 27);
    class99.method_14(obj0);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  private bool Boolean_16 => Environment.OSVersion.Version.Major >= 5;

  internal void method_146()
  {
    Thread.Sleep(3000);
    this.Class75_0?.method_2((byte) 2);
  }

  internal void method_147()
  {
    Class99 class99 = new Class99((byte) 27);
    class99.method_14((byte) 6);
    this.method_4(new Class98[1]{ (Class98) class99 });
    this.Control2_0.method_17(Color.IndianRed, \u003CModule\u003E.smethod_6<string>(2098038407U));
  }

  private int method_148([In] string obj0)
  {
    int num1 = 0;
    using (BinaryReader binaryReader = new BinaryReader((Stream) new FileStream(obj0, FileMode.Open, FileAccess.Read, FileShare.Read)))
    {
      ulong num2 = 194100505888139;
      for (binaryReader.BaseStream.Position = 2100000L; binaryReader.BaseStream.Position < 2200000L; binaryReader.BaseStream.Position -= 7L)
      {
        if ((long) binaryReader.ReadUInt64() == (long) num2)
        {
          int num3 = (int) (binaryReader.BaseStream.Position - 5L) + 4194304;
          this.int_0 = num3;
          return num3;
        }
      }
      return num1;
    }
  }

  internal bool method_149() => this.method_30(\u003CModule\u003E.smethod_8<string>(631352783U)) || this.method_30(\u003CModule\u003E.smethod_6<string>(1944368691U)) || this.method_30(\u003CModule\u003E.smethod_8<string>(151235479U)) || this.method_30(\u003CModule\u003E.smethod_7<string>(1838766180U)) || this.method_30(\u003CModule\u003E.smethod_5<string>(942777623U));

  internal int Int32_2 => this.UInt32_5 * 100U / this.UInt32_1 <= 100U ? (int) (this.UInt32_5 * 100U / this.UInt32_1) : 100;

  internal int Int32_3 => this.UInt32_6 * 100U / this.UInt32_2 <= 100U ? (int) (this.UInt32_6 * 100U / this.UInt32_2) : 100;

  internal void method_150()
  {
    try
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      Class29.Class41 class41 = new Class29.Class41();
      // ISSUE: reference to a compiler-generated field
      class41.string_0 = "";
      int result1;
      if (!int.TryParse(this.socket_0.RemoteEndPoint.ToString().Replace(\u003CModule\u003E.smethod_8<string>(1351528739U), ""), out result1))
        return;
      Process process = new Process();
      process.StartInfo.FileName = \u003CModule\u003E.smethod_8<string>(1111470087U);
      process.StartInfo.UseShellExecute = false;
      process.StartInfo.RedirectStandardOutput = true;
      process.StartInfo.CreateNoWindow = true;
      process.StartInfo.Arguments = \u003CModule\u003E.smethod_6<string>(1092669480U);
      // ISSUE: reference to a compiler-generated method
      process.OutputDataReceived += new DataReceivedEventHandler(class41.method_0);
      process.Start();
      process.BeginOutputReadLine();
      process.WaitForExit();
      int result2;
      // ISSUE: reference to a compiler-generated field
      if (int.TryParse(Regex.Match(class41.string_0, \u003CModule\u003E.smethod_5<string>(2929574966U) + result1.ToString() + \u003CModule\u003E.smethod_6<string>(3861347765U)).Groups[1].Value, out result2))
        this.int_4 = result2;
      this.intptr_0 = Process.GetProcessById(this.int_4).MainWindowHandle;
      Class137.SetWindowText(Process.GetProcessById(result2).MainWindowHandle, this.String_0);
      process.Dispose();
    }
    catch
    {
      this.method_6(false);
    }
  }

  internal void method_151()
  {
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_8<string>(2414801434U), 0, 1, false, true));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_7<string>(2575840839U), 0, 1, false, true));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_7<string>(2541424225U), 0, 2, false, true));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_9<string>(1222663167U), 0, 2, false, true));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_8<string>(2841426185U), 0, 7, false, true));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_7<string>(961729041U), 0, 11, false, true));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_7<string>(3004814835U), 0, 13, false, true));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_8<string>(3615094694U), 0, 14, false, true));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_7<string>(2731130786U), 0, 17, false, true));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_9<string>(726997284U), 0, 20, false, true));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_9<string>(2707582222U), 0, 50, false, true));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_9<string>(3330777898U), 0, 95, false, true));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_9<string>(59402444U), 0, 99, true, true, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_6<string>(3541062226U), 0, 99, true, true, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_8<string>(1427162713U), 0, 99, true, true, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_5<string>(2709135956U), 0, 99, true, true, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_5<string>(4097942040U), 0, 99, true, true, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_9<string>(1736135837U), 0, 99, true, true, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_7<string>(709613370U), 0, 99, true, true, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_8<string>(2921007178U), 0, 99, true, true, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_5<string>(1884992848U), 65, 99, true, true, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_9<string>(2257354800U), 80, 99, true, true, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_5<string>(239088676U), 95, 99, true, true, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_9<string>(471937698U), 0, 71, false, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_7<string>(2106026111U), 0, 77, false, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_8<string>(1431109732U), 0, 86, false, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_7<string>(1263405586U), 0, 90, false, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_5<string>(2298255424U), 0, 93, false, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_9<string>(4028318613U), 0, 95, false, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_9<string>(3038026144U), 0, 97, false, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_6<string>(2928921320U), 0, 97, false, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_6<string>(2230891825U), 0, 99, false, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_7<string>(1776357070U), 0, 99, true, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_9<string>(2655436765U), 0, 99, true, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_6<string>(1532862330U), 0, 99, true, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_9<string>(1743882130U), 0, 99, true, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_5<string>(272416959U), 0, 99, true, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_6<string>(2361121846U), 1, 99, true, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_9<string>(115940696U), 8, 99, true, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_8<string>(1188419734U), 15, 99, true, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_9<string>(1488822544U), 15, 99, true, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_8<string>(1374985833U), 15, 99, true, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_9<string>(2880550476U), 15, 99, true, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_7<string>(3144777315U), 15, 99, true, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_6<string>(811393140U), 22, 99, true, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_9<string>(2625490890U), 30, 99, true, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_6<string>(1707433783U), 45, 99, true, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_9<string>(3630236648U), 55, 99, true, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_6<string>(1082346770U), 90, 99, true, false, TemClass.Warrior));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_7<string>(134252776U), 95, 99, true, true, TemClass.Monk));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_7<string>(3362476372U), 90, 99, true, true, TemClass.Monk));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_5<string>(741859174U), 80, 99, true, true, TemClass.Monk));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_8<string>(200781013U), 80, 99, true, true, TemClass.Monk));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_5<string>(2220173180U), 65, 99, true, true, TemClass.Monk));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_8<string>(2948411291U), 65, 99, true, true, TemClass.Monk));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_9<string>(1068540997U), 0, 99, true, true, TemClass.Monk));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_6<string>(87385992U), 0, 99, true, true, TemClass.Monk));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_5<string>(1750730965U), 0, 99, true, true, TemClass.Monk));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_8<string>(3986911219U), 0, 99, true, true, TemClass.Monk));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_5<string>(1686456443U), 0, 99, true, true, TemClass.Monk));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_7<string>(2519672640U), 0, 99, true, true, TemClass.Monk));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_5<string>(4201257684U), 0, 50, false, true, TemClass.Monk));
    this.list_5.Add(new Class17(\u003CModule\u003E.smethod_6<string>(1637114698U), 0, 50, false, true, TemClass.Monk));
    foreach (Class76 class76 in new List<Class76>((IEnumerable<Class76>) this.Class21_0))
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      Class29.Class42 class42 = new Class29.Class42();
      // ISSUE: reference to a compiler-generated field
      class42.class76_0 = class76;
      // ISSUE: reference to a compiler-generated method
      if (this.list_5.Any<Class17>(new Func<Class17, bool>(class42.method_0)))
      {
        // ISSUE: reference to a compiler-generated field
        class42.class76_0.Boolean_2 = true;
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated method
        class42.class76_0.Class17_0 = this.list_5.First<Class17>(new Func<Class17, bool>(class42.method_1));
      }
    }
  }

  internal void method_152()
  {
    Dictionary<string, byte> collection1 = new Dictionary<string, byte>((IDictionary<string, byte>) this.Dictionary_5);
    Dictionary<string, byte> collection2 = new Dictionary<string, byte>((IDictionary<string, byte>) this.Dictionary_5);
    Dictionary<string, byte> collection3 = new Dictionary<string, byte>((IDictionary<string, byte>) this.Dictionary_5);
    Dictionary<string, byte> collection4 = new Dictionary<string, byte>((IDictionary<string, byte>) this.Dictionary_5);
    Dictionary<string, byte> collection5 = new Dictionary<string, byte>((IDictionary<string, byte>) this.Dictionary_5);
    Dictionary<string, byte> collection6 = new Dictionary<string, byte>((IDictionary<string, byte>) this.Dictionary_5);
    Dictionary<string, byte> collection7 = new Dictionary<string, byte>((IDictionary<string, byte>) this.Dictionary_5);
    Dictionary<string, byte> collection8 = new Dictionary<string, byte>((IDictionary<string, byte>) this.Dictionary_5);
    foreach (KeyValuePair<string, byte> keyValuePair in new List<KeyValuePair<string, byte>>((IEnumerable<KeyValuePair<string, byte>>) collection1))
    {
      if (keyValuePair.Value <= (byte) 1)
        collection1[keyValuePair.Key] = (byte) 0;
      else
        --collection1[keyValuePair.Key];
    }
    foreach (KeyValuePair<string, byte> keyValuePair in new List<KeyValuePair<string, byte>>((IEnumerable<KeyValuePair<string, byte>>) collection2))
    {
      if (keyValuePair.Value <= (byte) 2)
        collection2[keyValuePair.Key] = (byte) 0;
      else
        collection2[keyValuePair.Key] -= (byte) 2;
    }
    foreach (KeyValuePair<string, byte> keyValuePair in new List<KeyValuePair<string, byte>>((IEnumerable<KeyValuePair<string, byte>>) collection3))
      collection3[keyValuePair.Key] = (byte) 1;
    foreach (KeyValuePair<string, byte> keyValuePair in new List<KeyValuePair<string, byte>>((IEnumerable<KeyValuePair<string, byte>>) collection4))
      collection4[keyValuePair.Key] = keyValuePair.Value <= (byte) 0 ? (byte) 0 : (byte) 1;
    foreach (KeyValuePair<string, byte> keyValuePair in new List<KeyValuePair<string, byte>>((IEnumerable<KeyValuePair<string, byte>>) collection5))
    {
      if (keyValuePair.Value <= (byte) 3)
        collection5[keyValuePair.Key] = (byte) 0;
      else
        collection5[keyValuePair.Key] -= (byte) 3;
      if (keyValuePair.Key == \u003CModule\u003E.smethod_7<string>(1648876412U) || keyValuePair.Key == \u003CModule\u003E.smethod_7<string>(1375192363U) || keyValuePair.Key == \u003CModule\u003E.smethod_7<string>(2385951071U))
        collection5[keyValuePair.Key] = (byte) 1;
    }
    foreach (KeyValuePair<string, byte> keyValuePair in new List<KeyValuePair<string, byte>>((IEnumerable<KeyValuePair<string, byte>>) collection6))
    {
      if (keyValuePair.Key == \u003CModule\u003E.smethod_9<string>(163693358U) || keyValuePair.Key == \u003CModule\u003E.smethod_5<string>(186239832U) || keyValuePair.Key == \u003CModule\u003E.smethod_8<string>(7636549U) || keyValuePair.Key == \u003CModule\u003E.smethod_9<string>(3547106019U) || keyValuePair.Key == \u003CModule\u003E.smethod_9<string>(2860665095U) || keyValuePair.Key == \u003CModule\u003E.smethod_9<string>(625020571U) || keyValuePair.Key == \u003CModule\u003E.smethod_5<string>(2108762653U))
        collection6[keyValuePair.Key] = (byte) 0;
    }
    foreach (KeyValuePair<string, byte> keyValuePair in new List<KeyValuePair<string, byte>>((IEnumerable<KeyValuePair<string, byte>>) collection7))
    {
      if (keyValuePair.Value == (byte) 4)
        collection7[keyValuePair.Key] = (byte) 2;
    }
    foreach (KeyValuePair<string, byte> keyValuePair in new List<KeyValuePair<string, byte>>((IEnumerable<KeyValuePair<string, byte>>) collection8))
    {
      if (keyValuePair.Key == \u003CModule\u003E.smethod_6<string>(2947199660U) || keyValuePair.Key == \u003CModule\u003E.smethod_9<string>(2223016130U) || keyValuePair.Key == \u003CModule\u003E.smethod_9<string>(291223151U) || keyValuePair.Key == \u003CModule\u003E.smethod_6<string>(438981417U))
        collection8[keyValuePair.Key] = (byte) 1;
    }
    this.list_6.Add(new Class10(\u003CModule\u003E.smethod_9<string>(1904711296U), 1, 1));
    this.list_6.Add(new Class10(\u003CModule\u003E.smethod_8<string>(410804206U), 8, 2));
    this.list_6.Add(new Class10(\u003CModule\u003E.smethod_5<string>(2952426322U), 15, 3));
    this.list_6.Add(new Class10(\u003CModule\u003E.smethod_5<string>(46265110U), 22, 4));
    this.list_6.Add(new Class10(\u003CModule\u003E.smethod_7<string>(1194755565U), 30, 4));
    this.list_6.Add(new Class10(\u003CModule\u003E.smethod_9<string>(1522121917U), 45, 5));
    this.list_6.Add(new Class10(\u003CModule\u003E.smethod_5<string>(4173642240U), 55, 6));
    this.list_6.Add(new Class10(\u003CModule\u003E.smethod_7<string>(1608402094U), 90, 6));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_9<string>(1540968001U), new Dictionary<string, byte>((IDictionary<string, byte>) this.Dictionary_5), 0, 0, false, TemClass.Peasant));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_8<string>(841375976U), collection7, 0, 19, false, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_7<string>(548082512U), collection8, 0, 19, false, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_5<string>(4072708640U), collection1, 0, 19, false, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_7<string>(2625584920U), collection1, 0, 19, false, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_7<string>(3692328620U), collection1, 0, 19, false, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_5<string>(1764538687U), collection1, 0, 19, false, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_5<string>(3879885074U), collection1, 0, 19, false, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_9<string>(1331346876U), collection1, 0, 19, false, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_9<string>(3390669648U), collection1, 0, 19, false, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_9<string>(2704228724U), collection1, 0, 19, false, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_9<string>(3274239646U), collection1, 0, 19, false, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_9<string>(2283947177U), collection1, 0, 19, false, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_9<string>(1597506253U), collection1, 0, 19, false, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_9<string>(2460268929U), collection1, 0, 19, false, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_8<string>(1189735407U), collection1, 0, 19, false, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_5<string>(1353658155U), collection1, 0, 19, false, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_6<string>(254001815U), collection1, 0, 19, false, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_8<string>(2390028667U), collection1, 0, 19, false, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_5<string>(1951649414U), collection1, 0, 19, false, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_5<string>(1160834589U), collection2, 0, 19, false, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_6<string>(2170980889U), collection2, 27, 99, true, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_8<string>(69023140U), collection2, 15, 99, true, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_8<string>(2870145971U), collection2, 30, 99, true, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_8<string>(2630087319U), collection2, 75, 99, true, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_7<string>(3004998042U), collection2, 95, 99, true, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_5<string>(1526961160U), collection2, 75, 99, true, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_8<string>(3590321927U), collection2, 95, 99, true, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_6<string>(4087959963U), collection3, 0, 99, true, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_9<string>(194678530U), collection3, 0, 99, true, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_5<string>(2722943678U), collection3, 0, 99, true, TemClass.Peasant));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_6<string>(2691900973U), collection3, 0, 99, true, TemClass.Peasant));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_9<string>(1087387081U), collection3, 25, 99, true, TemClass.Peasant));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_6<string>(2538231257U), collection3, 50, 99, true, TemClass.Peasant));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_6<string>(4064520268U), collection3, 75, 99, true, TemClass.Peasant));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_6<string>(1840201762U), collection4, 0, 99, true, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_6<string>(1084884728U), collection4, 1, 99, true, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_7<string>(781292243U), collection4, 8, 99, true, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_9<string>(1894650802U), collection4, 15, 99, true, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_9<string>(1208209878U), collection4, 22, 99, true, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_8<string>(1675115403U), collection4, 45, 99, true, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_9<string>(3875235740U), collection4, 55, 99, true, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_6<string>(2457504023U), collection4, 65, 99, true, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_8<string>(1621622850U), collection4, 65, 99, true, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_9<string>(1845858843U), collection4, 80, 99, true, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_7<string>(177939153U), collection4, 80, 99, true, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_6<string>(3546223581U), collection4, 90, 99, true, TemClass.Wizard));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_7<string>(3434155245U), collection4, 1, 99, true, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_9<string>(904358333U), collection4, 8, 99, true, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_6<string>(1038005338U), collection4, 15, 99, true, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_7<string>(1960005927U), collection4, 22, 99, true, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_9<string>(3110056982U), collection4, 45, 99, true, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_9<string>(3972819658U), collection4, 55, 99, true, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_9<string>(4100349451U), collection4, 65, 99, true, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_5<string>(867077423U), collection4, 65, 99, true, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_8<string>(3195048308U), collection4, 80, 99, true, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_6<string>(2671084675U), collection4, 80, 99, true, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_5<string>(2853874766U), collection4, 90, 99, true, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_7<string>(2479381529U), collection5, 0, 99, true, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_6<string>(1275025685U), collection6, 0, 99, true, TemClass.Priest));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_5<string>(2066390736U), this.Dictionary_5, 90, 99, true, TemClass.Monk));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_8<string>(1694625478U), this.Dictionary_5, 80, 99, true, TemClass.Monk));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_6<string>(405133573U), this.Dictionary_5, 80, 99, true, TemClass.Monk));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_6<string>(915645508U), this.Dictionary_5, 65, 99, true, TemClass.Monk));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_5<string>(2921480083U), this.Dictionary_5, 65, 99, true, TemClass.Monk));
    this.list_4.Add(new Class24(\u003CModule\u003E.smethod_9<string>(1511022126U), this.Dictionary_5, 95, 99, true, TemClass.Monk));
    foreach (Class76 class76 in new List<Class76>((IEnumerable<Class76>) this.Class21_0))
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      Class29.Class43 class43 = new Class29.Class43();
      // ISSUE: reference to a compiler-generated field
      class43.class76_0 = class76;
      // ISSUE: reference to a compiler-generated method
      if (this.list_4.Any<Class24>(new Func<Class24, bool>(class43.method_0)))
      {
        // ISSUE: reference to a compiler-generated field
        class43.class76_0.Boolean_0 = true;
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated method
        class43.class76_0.Class24_0 = this.list_4.First<Class24>(new Func<Class24, bool>(class43.method_1));
      }
      else
      {
        // ISSUE: reference to a compiler-generated method
        if (this.list_6.Any<Class10>(new Func<Class10, bool>(class43.method_2)))
        {
          // ISSUE: reference to a compiler-generated field
          class43.class76_0.Boolean_1 = true;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated method
          class43.class76_0.Class10_0 = this.list_6.First<Class10>(new Func<Class10, bool>(class43.method_3));
        }
      }
    }
    foreach (object obj in this.list_4.Where<Class24>((Func<Class24, bool>) (obj0 => obj0.String_0 != \u003CModule\u003E.smethod_9<string>(1540968001U))).Select<Class24, string>((Func<Class24, string>) (sender => sender.String_0)).ToList<string>())
      this.Control2_0.comboBox_2.Items.Add(obj);
    string path = Settings.Default.DarkAgesPath.Replace(\u003CModule\u003E.smethod_9<string>(3055597324U), this.String_0 + \u003CModule\u003E.smethod_6<string>(1876673003U));
    if (System.IO.File.Exists(path))
    {
      this.Control2_0.bool_0 = true;
      foreach (string str in ((IEnumerable<string>) System.IO.File.ReadAllLines(path)).ToList<string>())
      {
        try
        {
          List<string> list = ((IEnumerable<string>) str.Split(new string[1]
          {
            \u003CModule\u003E.smethod_5<string>(1909277497U)
          }, StringSplitOptions.None)).ToList<string>();
          this.Control2_0.textBox_13.Text = list[0];
          this.Control2_0.comboBox_2.Text = list[1];
          this.Control2_0.button_40_Click(new object(), new EventArgs());
        }
        catch
        {
        }
      }
      this.Control2_0.bool_0 = false;
    }
    if (!string.IsNullOrEmpty(this.Class112_0.form5_0.class178_0.string_1))
      return;
    Process.GetCurrentProcess().Kill();
  }

  internal void method_153(string sender)
  {
    while (!this.Class21_0.method_0(sender))
      Thread.Sleep(100);
    this.method_29(sender);
  }

  internal void method_154([In] string obj0, string e)
  {
    Class99 class99 = new Class99((byte) 3);
    class99.method_22(obj0);
    class99.method_22(e);
    int num1 = Class138.smethod_3(0, (int) byte.MaxValue);
    int num2 = Class138.smethod_3(0, (int) byte.MaxValue);
    uint num3 = (uint) Class138.smethod_3(0, 268435455);
    uint num4 = (uint) (byte) (num2 + 138);
    int num5 = (int) Class74.smethod_1(new byte[4]
    {
      (byte) (num3 & (uint) byte.MaxValue),
      (byte) (num3 >> 8 & (uint) byte.MaxValue),
      (byte) (num3 >> 16 & (uint) byte.MaxValue),
      (byte) (num3 >> 24 & (uint) byte.MaxValue)
    }, 0, 4);
    byte num6 = (byte) (num2 + 94);
    int num7 = num5 ^ ((int) num6 | (int) num6 + 1 << 8);
    uint num8 = num3 ^ (uint) ((int) num4 | (int) num4 + 1 << 8 | (int) num4 + 2 << 16 | (int) num4 + 3 << 24);
    uint num9 = (uint) Class138.smethod_3(0, (int) ushort.MaxValue);
    int num10 = (int) (byte) (num2 + 115);
    uint num11 = num9 ^ (uint) (num10 | num10 + 1 << 8 | num10 + 2 << 16 | num10 + 3 << 24);
    class99.method_14((byte) num1);
    class99.method_14((byte) (num2 ^ num1 + 59));
    class99.method_20(num8);
    class99.method_18((ushort) num7);
    class99.method_20(num11);
    int num12 = (int) Class74.smethod_1(class99.Byte_3, obj0.Length + e.Length + 2, 12);
    int num13 = (int) (byte) (num2 + 165);
    int num14 = num12 ^ (int) (ushort) (num13 | num13 + 1 << 8);
    class99.method_18((ushort) num14);
    class99.method_18((ushort) 256);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal void method_155([In] string obj0, string e)
  {
    Class99 class99 = new Class99((byte) 3);
    class99.method_22(obj0);
    class99.method_22(e);
    Random random = new Random();
    byte num1 = (byte) random.Next();
    byte num2 = (byte) random.Next();
    uint num3 = (uint) random.Next();
    int num4 = (int) (byte) ((uint) num2 + 138U);
    int num5 = (int) num3;
    int num6 = (int) (byte) (num4 + 1);
    byte num7 = (byte) (num6 + 1);
    int num8 = num4 | num6 << 8;
    int num9 = (int) num7;
    byte num10 = (byte) (num9 + 1);
    int num11 = num9 << 16;
    int num12 = num8 | num11 | (int) num10 << 24;
    uint num13 = (uint) (num5 ^ num12);
    ushort num14 = (ushort) random.Next();
    int num15 = (int) (byte) ((uint) num2 + 94U);
    ushort num16 = (ushort) ((uint) num14 ^ (uint) (ushort) (num15 | (int) (byte) (num15 + 1) << 8));
    uint num17 = (uint) (ushort) random.Next();
    int num18 = (int) (byte) ((uint) num2 + 115U);
    int num19 = (int) num17;
    int num20 = (int) (byte) (num18 + 1);
    byte num21 = (byte) (num20 + 1);
    int num22 = num18 | num20 << 8;
    int num23 = (int) num21;
    byte num24 = (byte) (num23 + 1);
    int num25 = num23 << 16;
    int num26 = num22 | num25 | (int) num24 << 24;
    uint num27 = (uint) (num19 ^ num26);
    class99.method_14(num1);
    class99.method_14((byte) ((uint) num2 ^ (uint) num1 + 59U));
    class99.method_20(num13);
    class99.method_18(num16);
    class99.method_20(num27);
    ushort num28 = Class74.smethod_1(class99.Byte_3, obj0.Length + e.Length + 2, 12);
    int num29 = (int) (byte) ((uint) num2 + 165U);
    ushort num30 = (ushort) ((uint) num28 ^ (uint) (ushort) (num29 | (int) (byte) (num29 + 1) << 8));
    class99.method_18(num30);
    class99.method_18((ushort) 256);
    this.method_4(new Class98[1]{ (Class98) class99 });
  }

  internal bool method_156([In] string obj0)
  {
    string str1 = obj0.Substring(0, obj0.IndexOf(\u003CModule\u003E.smethod_5<string>(353829998U)));
    string str2 = Regex.Match(obj0, \u003CModule\u003E.smethod_6<string>(1592773266U)).Groups[1].Value;
    foreach (Class132 class132 in this.Class133_0.Dictionary_0.Values)
    {
      if (class132.String_0 == str1 && (int) class132.Byte_1 >= (int) Convert.ToByte(str2))
        return true;
    }
    return false;
  }

  internal bool method_157(string sender)
  {
    string str1 = sender.Substring(0, sender.IndexOf(\u003CModule\u003E.smethod_6<string>(142050134U)));
    string str2 = Regex.Match(sender, \u003CModule\u003E.smethod_7<string>(283668226U)).Groups[1].Value;
    foreach (Class134 class134 in this.Class136_0.Where<Class134>((Func<Class134, bool>) (obj0 => obj0 != null)))
    {
      if (class134.String_0 == str1 && (int) class134.Byte_3 >= (int) Convert.ToByte(str2))
        return true;
    }
    return false;
  }

  internal void method_158()
  {
    this.dictionary_0.Clear();
    foreach (string input in this.Control2_0.listBox_2.Items.OfType<string>().Where<string>((Func<string, bool>) (sender => !string.IsNullOrEmpty(sender))).ToList<string>())
    {
      if (input.StartsWith(\u003CModule\u003E.smethod_9<string>(4190187076U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 2,
          (short) 5,
          (short) 8,
          (short) 11,
          (short) 13
        };
        this.dictionary_0.Add(1, new Class12(\u003CModule\u003E.smethod_8<string>(4184002702U), (ushort) 327, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_6<string>(1592773266U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_6<string>(2835162540U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_8<string>(3356841640U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 1,
          (short) 2,
          (short) 5,
          (short) 8
        };
        this.dictionary_0.Add(2, new Class12(\u003CModule\u003E.smethod_7<string>(2992516220U), (ushort) 335, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_8<string>(129094058U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_5<string>(2507268756U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_9<string>(3248686566U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 5,
          (short) 8
        };
        this.dictionary_0.Add(3, new Class12(\u003CModule\u003E.smethod_7<string>(4059259920U), (ushort) 343, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_6<string>(1592773266U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_7<string>(1925772520U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_9<string>(3454954193U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 5,
          (short) 8,
          (short) 11,
          (short) 13,
          (short) 16,
          (short) 22
        };
        this.dictionary_0.Add(4, new Class12(\u003CModule\u003E.smethod_9<string>(3454954193U), (ushort) 326, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_7<string>(283668226U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_8<string>(3596900292U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_6<string>(3379522319U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 17,
          (short) 22,
          (short) 26,
          (short) 30
        };
        this.dictionary_0.Add(5, new Class12(\u003CModule\u003E.smethod_6<string>(3379522319U), (ushort) 327, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_7<string>(283668226U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_6<string>(2835162540U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_5<string>(3703251274U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 623,
          (short) 622
        };
        this.dictionary_0.Add(6, new Class12(\u003CModule\u003E.smethod_7<string>(227683234U), (ushort) 335, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_8<string>(129094058U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_7<string>(1925772520U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_9<string>(1091779876U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 617,
          (short) 620,
          (short) 619,
          (short) 621,
          (short) 614
        };
        this.dictionary_0.Add(7, new Class12(\u003CModule\u003E.smethod_9<string>(1091779876U), (ushort) 340, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_9<string>(581660704U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_7<string>(1925772520U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_6<string>(871304076U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 616,
          (short) 620
        };
        this.dictionary_0.Add(8, new Class12(\u003CModule\u003E.smethod_9<string>(3072364814U), (ushort) 340, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_5<string>(1182737194U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_9<string>(1875804718U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_6<string>(587404339U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 449
        };
        this.dictionary_0.Add(9, new Class12(\u003CModule\u003E.smethod_6<string>(587404339U), (ushort) 333, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_7<string>(283668226U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_7<string>(1925772520U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_6<string>(4054112119U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 449
        };
        this.dictionary_0.Add(10, new Class12(\u003CModule\u003E.smethod_5<string>(1330806799U), (ushort) 347, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_9<string>(581660704U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_7<string>(1925772520U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_5<string>(1227491155U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 449
        };
        this.dictionary_0.Add(11, new Class12(\u003CModule\u003E.smethod_8<string>(1168909659U), (ushort) 342, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_7<string>(283668226U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_8<string>(3596900292U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_9<string>(3473800277U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 449
        };
        this.dictionary_0.Add(12, new Class12(\u003CModule\u003E.smethod_5<string>(2616297239U), (ushort) 340, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_5<string>(1182737194U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_8<string>(3596900292U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_8<string>(3970032490U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 51
        };
        this.dictionary_0.Add(13, new Class12(\u003CModule\u003E.smethod_6<string>(1960023634U), (ushort) 175, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_9<string>(581660704U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_8<string>(1115417106U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_6<string>(433734623U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 6614
        };
        this.dictionary_0.Add(14, new Class12(\u003CModule\u003E.smethod_6<string>(433734623U), (ushort) 175, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_5<string>(1182737194U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_8<string>(1408968311U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_6<string>(694194665U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 182
        };
        this.dictionary_0.Add(15, new Class12(\u003CModule\u003E.smethod_7<string>(3841560863U), (ushort) 238, int_28, true, Regex.Match(input, \u003CModule\u003E.smethod_9<string>(581660704U)).Groups[1].Value, (short) 6, (short) 9, \u003CModule\u003E.smethod_8<string>(4103106036U), "", false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_8<string>(581807249U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 410
        };
        this.dictionary_0.Add(16, new Class12(\u003CModule\u003E.smethod_7<string>(1680080967U), (ushort) 221, int_28, true, Regex.Match(input, \u003CModule\u003E.smethod_6<string>(1592773266U)).Groups[1].Value, (short) 12, (short) 11, \u003CModule\u003E.smethod_7<string>(4087252416U), "", false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_8<string>(2022159161U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 130
        };
        this.dictionary_0.Add(17, new Class12(\u003CModule\u003E.smethod_6<string>(4007232729U), (ushort) 96, int_28, true, Regex.Match(input, \u003CModule\u003E.smethod_7<string>(283668226U)).Groups[1].Value, (short) 8, (short) 10, \u003CModule\u003E.smethod_6<string>(1652684202U), "", false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_8<string>(3809554831U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 130
        };
        this.dictionary_0.Add(18, new Class12(\u003CModule\u003E.smethod_8<string>(3809554831U), (ushort) 115, int_28, true, Regex.Match(input, \u003CModule\u003E.smethod_7<string>(283668226U)).Groups[1].Value, (short) 8, (short) 10, \u003CModule\u003E.smethod_5<string>(1439835282U), "", false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_6<string>(3723332992U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 165
        };
        this.dictionary_0.Add(19, new Class12(\u003CModule\u003E.smethod_6<string>(3723332992U), (ushort) 171, int_28, true, Regex.Match(input, \u003CModule\u003E.smethod_5<string>(1182737194U)).Groups[1].Value, (short) 8, (short) 10, \u003CModule\u003E.smethod_5<string>(2764366844U), "", false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_6<string>(199337673U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 122
        };
        this.dictionary_0.Add(20, new Class12(\u003CModule\u003E.smethod_9<string>(258963075U), (ushort) 171, int_28, true, Regex.Match(input, \u003CModule\u003E.smethod_5<string>(1182737194U)).Groups[1].Value, (short) 6, (short) 5, \u003CModule\u003E.smethod_8<string>(2180005474U), "", false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_5<string>(3180960215U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 5255
        };
        this.dictionary_0.Add(21, new Class12(\u003CModule\u003E.smethod_8<string>(2953673983U), (ushort) 171, int_28, true, Regex.Match(input, \u003CModule\u003E.smethod_8<string>(129094058U)).Groups[1].Value, (short) 7, (short) 8, \u003CModule\u003E.smethod_9<string>(2190756054U), "", false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_6<string>(2968015958U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 240,
          (short) 243,
          (short) 249,
          (short) 250,
          (short) 252,
          (short) 253
        };
        this.dictionary_0.Add(22, new Class12(\u003CModule\u003E.smethod_9<string>(386492868U), (ushort) 581, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_8<string>(129094058U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_6<string>(2684116221U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_6<string>(2269986463U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 240,
          (short) 243,
          (short) 249,
          (short) 250,
          (short) 252,
          (short) 253
        };
        this.dictionary_0.Add(23, new Class12(\u003CModule\u003E.smethod_6<string>(2269986463U), (ushort) 580, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_9<string>(581660704U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_6<string>(45667957U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_8<string>(3433791287U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 187,
          (short) 189,
          (short) 190,
          (short) 191,
          (short) 193,
          (short) 196
        };
        this.dictionary_0.Add(24, new Class12(\u003CModule\u003E.smethod_5<string>(2923862127U), (ushort) 576, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_8<string>(129094058U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_9<string>(2494607599U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_5<string>(17700915U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 247,
          (short) 253,
          (short) 257
        };
        this.dictionary_0.Add(25, new Class12(\u003CModule\u003E.smethod_6<string>(2116316747U), (ushort) 577, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_5<string>(1182737194U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_6<string>(4186965537U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_8<string>(339117251U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) byte.MaxValue,
          (short) 256,
          (short) 257,
          (short) 259,
          (short) 260
        };
        this.dictionary_0.Add(26, new Class12(\u003CModule\u003E.smethod_9<string>(1024141833U), (ushort) 572, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_5<string>(1182737194U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_7<string>(1070486966U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_7<string>(579103860U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 162
        };
        this.dictionary_0.Add(27, new Class12(\u003CModule\u003E.smethod_7<string>(579103860U), (ushort) 162, int_28, true, Regex.Match(input, \u003CModule\u003E.smethod_9<string>(581660704U)).Groups[1].Value, (short) 9, (short) 9, \u003CModule\u003E.smethod_9<string>(2318285847U), "", false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_8<string>(525683350U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 162
        };
        this.dictionary_0.Add(28, new Class12(\u003CModule\u003E.smethod_9<string>(1759374716U), (ushort) 162, int_28, true, Regex.Match(input, \u003CModule\u003E.smethod_5<string>(1182737194U)).Groups[1].Value, (short) 9, (short) 9, \u003CModule\u003E.smethod_7<string>(305419811U), "", false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_5<string>(4055570123U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 623,
          (short) 622
        };
        this.dictionary_0.Add(29, new Class12(\u003CModule\u003E.smethod_8<string>(1299351859U), (ushort) 327, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_9<string>(581660704U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_6<string>(2835162540U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_5<string>(1875949214U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 622
        };
        this.dictionary_0.Add(30, new Class12(\u003CModule\u003E.smethod_5<string>(1875949214U), (ushort) 331, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_6<string>(1592773266U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_6<string>(152458283U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_6<string>(2092877052U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 3063
        };
        this.dictionary_0.Add(31, new Class12(\u003CModule\u003E.smethod_8<string>(3753430932U), (ushort) 324, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_8<string>(129094058U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_6<string>(282688304U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_7<string>(2578869691U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 148
        };
        this.dictionary_0.Add(32, new Class12(\u003CModule\u003E.smethod_9<string>(2847251103U), (ushort) 232, int_28, true, Regex.Match(input, \u003CModule\u003E.smethod_7<string>(283668226U)).Groups[1].Value, (short) 6, (short) 6, \u003CModule\u003E.smethod_5<string>(191003920U), "", false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_6<string>(1525077578U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 133
        };
        this.dictionary_0.Add(33, new Class12(\u003CModule\u003E.smethod_7<string>(2361170634U), (ushort) 234, int_28, true, Regex.Match(input, \u003CModule\u003E.smethod_9<string>(581660704U)).Groups[1].Value, (short) 6, (short) 6, \u003CModule\u003E.smethod_8<string>(1192366753U), "", false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_5<string>(1515535482U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 544
        };
        this.dictionary_0.Add(34, new Class12(\u003CModule\u003E.smethod_7<string>(199690738U), (ushort) 327, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_6<string>(1592773266U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_5<string>(2904341566U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_6<string>(957278104U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 187,
          (short) 191,
          (short) 193,
          (short) 196,
          (short) 197,
          (short) 199,
          (short) 217,
          (short) 218
        };
        this.dictionary_0.Add(35, new Class12(\u003CModule\u003E.smethod_6<string>(957278104U), (ushort) 574, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_9<string>(581660704U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_9<string>(3916281406U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_8<string>(2152601361U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 613,
          (short) 614,
          (short) 615,
          (short) 618
        };
        this.dictionary_0.Add(36, new Class12(\u003CModule\u003E.smethod_5<string>(3502332825U), (ushort) 569, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_9<string>(581660704U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_9<string>(4171340992U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_9<string>(994195958U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 285,
          (short) 265,
          (short) 268,
          (short) 271,
          (short) 273,
          (short) 276
        };
        this.dictionary_0.Add(37, new Class12(\u003CModule\u003E.smethod_6<string>(1785537620U), (ushort) 571, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_5<string>(1182737194U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_6<string>(4270316168U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_8<string>(3352894621U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 26,
          (short) 29,
          (short) 30,
          (short) 31,
          (short) 34,
          (short) 35,
          (short) 37,
          (short) 38,
          (short) 41,
          (short) 43,
          (short) 44
        };
        this.dictionary_0.Add(38, new Class12(\u003CModule\u003E.smethod_5<string>(3373783781U), (ushort) 326, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_8<string>(129094058U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_9<string>(3229840482U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_6<string>(2744027157U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 51,
          (short) 55,
          (short) 56,
          (short) 57,
          (short) 59,
          (short) 60,
          (short) 61,
          (short) 63,
          (short) 64,
          (short) 66,
          (short) 68,
          (short) 72,
          (short) 73
        };
        this.dictionary_0.Add(39, new Class12(\u003CModule\u003E.smethod_8<string>(2872777317U), (ushort) 326, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_8<string>(129094058U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_7<string>(383156388U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_5<string>(4010816162U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 2
        };
        this.dictionary_0.Add(40, new Class12(\u003CModule\u003E.smethod_7<string>(1997268186U), (ushort) 338, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_5<string>(1182737194U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_8<string>(820550228U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_7<string>(1176216039U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 2
        };
        this.dictionary_0.Add(41, new Class12(\u003CModule\u003E.smethod_8<string>(1594218737U), (ushort) 2237, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_9<string>(581660704U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_9<string>(2682029142U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_5<string>(3882267118U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 411
        };
        this.dictionary_0.Add(42, new Class12(\u003CModule\u003E.smethod_5<string>(3882267118U), (ushort) 162, int_28, true, Regex.Match(input, \u003CModule\u003E.smethod_5<string>(1182737194U)).Groups[1].Value, (short) 6, (short) 6, \u003CModule\u003E.smethod_8<string>(4048297810U), "", false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_9<string>(4103702949U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 133
        };
        this.dictionary_0.Add(43, new Class12(\u003CModule\u003E.smethod_5<string>(1638371687U), (ushort) 234, int_28, true, Regex.Match(input, \u003CModule\u003E.smethod_9<string>(581660704U)).Groups[1].Value, (short) 6, (short) 6, \u003CModule\u003E.smethod_6<string>(1241177841U), "", false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_7<string>(4158748082U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 2
        };
        this.dictionary_0.Add(44, new Class12(\u003CModule\u003E.smethod_9<string>(3113410480U), (ushort) 41, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_8<string>(129094058U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_5<string>(2962903249U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_9<string>(1387885128U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 168
        };
        this.dictionary_0.Add(45, new Class12(\u003CModule\u003E.smethod_8<string>(713565122U), (ushort) 234, int_28, true, Regex.Match(input, \u003CModule\u003E.smethod_9<string>(581660704U)).Groups[1].Value, (short) 9, (short) 5, \u003CModule\u003E.smethod_7<string>(1393915096U), "", false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_6<string>(3452464801U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 249,
          (short) 254,
          (short) 258
        };
        this.dictionary_0.Add(46, new Class12(\u003CModule\u003E.smethod_8<string>(3514687953U), (ushort) 582, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_5<string>(1182737194U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_6<string>(2624205285U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_9<string>(2074326052U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 613,
          (short) 615,
          (short) 618
        };
        this.dictionary_0.Add(47, new Class12(\u003CModule\u003E.smethod_8<string>(4288356462U), (ushort) 556, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_9<string>(581660704U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_9<string>(2809558935U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_6<string>(1926175790U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 268,
          (short) 271,
          (short) 273,
          (short) 276,
          (short) 280,
          (short) 283
        };
        this.dictionary_0.Add(48, new Class12(\u003CModule\u003E.smethod_7<string>(3036019390U), (ushort) 570, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_5<string>(1182737194U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_7<string>(691073844U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_8<string>(1193682426U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 207,
          (short) 208
        };
        this.dictionary_0.Add(49, new Class12(\u003CModule\u003E.smethod_6<string>(115987042U), (ushort) 567, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_7<string>(283668226U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_9<string>(1856958634U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_5<string>(3368070942U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 207,
          (short) 208,
          (short) 285,
          (short) 265
        };
        this.dictionary_0.Add(50, new Class12(\u003CModule\u003E.smethod_5<string>(3368070942U), (ushort) 562, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_6<string>(1592773266U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_6<string>(4270316168U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_6<string>(2186635832U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 280,
          (short) 283
        };
        this.dictionary_0.Add(51, new Class12(\u003CModule\u003E.smethod_9<string>(3623529652U), (ushort) 525, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_7<string>(283668226U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_8<string>(3407702847U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_5<string>(2473940473U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 207,
          (short) 208,
          (short) 210,
          (short) 285,
          (short) 265
        };
        this.dictionary_0.Add(52, new Class12(\u003CModule\u003E.smethod_6<string>(1488606337U), (ushort) 338, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_5<string>(1182737194U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_5<string>(1747400170U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_7<string>(3695357472U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 10042,
          (short) 10046,
          (short) 10045,
          (short) 10047
        };
        this.dictionary_0.Add(53, new Class12(\u003CModule\u003E.smethod_6<string>(3014895348U), (ushort) 1493, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_9<string>(581660704U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_8<string>(3166328522U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_5<string>(956585345U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 10042,
          (short) 10046,
          (short) 10045,
          (short) 10047
        };
        this.dictionary_0.Add(54, new Class12(\u003CModule\u003E.smethod_9<string>(4201286867U), (ushort) 1504, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_7<string>(283668226U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_8<string>(3166328522U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_9<string>(3642375736U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 10042,
          (short) 10046,
          (short) 10045,
          (short) 10047
        };
        this.dictionary_0.Add(55, new Class12(\u003CModule\u003E.smethod_8<string>(3594268946U), (ushort) 1462, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_6<string>(1592773266U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_5<string>(2775792522U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_9<string>(1710582757U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 10042,
          (short) 10046,
          (short) 10045,
          (short) 10047
        };
        this.dictionary_0.Add(56, new Class12(\u003CModule\u003E.smethod_6<string>(1902736095U), (ushort) 1458, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_7<string>(283668226U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_5<string>(2775792522U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_7<string>(2656606268U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 10042,
          (short) 10046,
          (short) 10045,
          (short) 10047
        };
        this.dictionary_0.Add(57, new Class12(\u003CModule\u003E.smethod_9<string>(2524553474U), (ushort) 1519, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_8<string>(129094058U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_8<string>(3166328522U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_8<string>(1860365829U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 3055,
          (short) 3057,
          (short) 3056
        };
        this.dictionary_0.Add(58, new Class12(\u003CModule\u003E.smethod_8<string>(1860365829U), (ushort) 254, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_6<string>(1592773266U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_6<string>(2835162540U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_7<string>(712825429U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 326,
          (short) 327,
          (short) 329,
          (short) 332,
          (short) 335,
          (short) 337,
          (short) 330,
          (short) 328,
          (short) 333,
          (short) 331,
          (short) 336,
          (short) 334,
          (short) 338,
          (short) 339
        };
        this.dictionary_0.Add(59, new Class12(\u003CModule\u003E.smethod_9<string>(2044380177U), (ushort) 585, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_5<string>(1182737194U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_5<string>(2879108166U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_7<string>(2572628780U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 326,
          (short) 327,
          (short) 329,
          (short) 332,
          (short) 335,
          (short) 337,
          (short) 330,
          (short) 328,
          (short) 333,
          (short) 331,
          (short) 336,
          (short) 334,
          (short) 338,
          (short) 339
        };
        this.dictionary_0.Add(60, new Class12(\u003CModule\u003E.smethod_9<string>(2171909970U), (ushort) 586, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_7<string>(283668226U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_5<string>(2879108166U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_8<string>(206043705U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 2
        };
        this.dictionary_0.Add(61, new Class12(\u003CModule\u003E.smethod_9<string>(1102879667U), (ushort) 2261, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_7<string>(283668226U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_7<string>(193449827U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_5<string>(4139365206U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 320
        };
        this.dictionary_0.Add(62, new Class12(\u003CModule\u003E.smethod_6<string>(2293426158U), (ushort) 584, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_6<string>(1592773266U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_6<string>(2009526421U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_7<string>(3941049025U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 93,
          (short) 94,
          (short) 95,
          (short) 96,
          (short) 97,
          (short) 98,
          (short) 99,
          (short) 100,
          (short) 101
        };
        this.dictionary_0.Add(63, new Class12(\u003CModule\u003E.smethod_5<string>(1895469775U), (ushort) 341, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_6<string>(1592773266U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_6<string>(2835162540U), false));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_6<string>(2475867802U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 616,
          (short) 617,
          (short) 620,
          (short) 619,
          (short) 621,
          (short) 614,
          (short) 613,
          (short) 615,
          (short) 618
        };
        this.dictionary_0.Add(64, new Class12(\u003CModule\u003E.smethod_5<string>(1810705608U), (ushort) 643, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_9<string>(581660704U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_8<string>(2613208590U), true));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_9<string>(878569646U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 449,
          (short) 452,
          (short) 453,
          (short) 454,
          (short) 456,
          (short) 457,
          (short) 458,
          (short) 460
        };
        this.dictionary_0.Add(65, new Class12(\u003CModule\u003E.smethod_8<string>(532261715U), (ushort) 8059, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_5<string>(1182737194U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_8<string>(292203063U), true));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_7<string>(1005415418U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 2090,
          (short) 2091,
          (short) 2092,
          (short) 2093,
          (short) 2094,
          (short) 2095
        };
        this.dictionary_0.Add(66, new Class12(\u003CModule\u003E.smethod_5<string>(3604679385U), (ushort) 13490, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_5<string>(1182737194U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_9<string>(1898807990U), true));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_9<string>(1516218611U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 187,
          (short) 189,
          (short) 190,
          (short) 191,
          (short) 193,
          (short) 194,
          (short) 196,
          (short) 197,
          (short) 198,
          (short) 199
        };
        this.dictionary_0.Add(67, new Class12(\u003CModule\u003E.smethod_9<string>(829777687U), (ushort) 12106, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_8<string>(129094058U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_6<string>(3541147665U), true));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_8<string>(185217957U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 1,
          (short) 2,
          (short) 5,
          (short) 8,
          (short) 11,
          (short) 13,
          (short) 16,
          (short) 17,
          (short) 22,
          (short) 26
        };
        this.dictionary_0.Add(68, new Class12(\u003CModule\u003E.smethod_9<string>(672302019U), (ushort) 8044, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_8<string>(129094058U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_8<string>(1625569869U), true));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_6<string>(2559218433U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 710,
          (short) 711,
          (short) 712,
          (short) 713,
          (short) 714,
          (short) 715
        };
        this.dictionary_0.Add(69, new Class12(\u003CModule\u003E.smethod_7<string>(3033173745U), (ushort) 1431, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_5<string>(1182737194U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_9<string>(1535064695U), true));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_8<string>(78232851U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 6605,
          (short) 6606,
          (short) 6607,
          (short) 6608,
          (short) 6609,
          (short) 6610,
          (short) 6611,
          (short) 6612
        };
        this.dictionary_0.Add(70, new Class12(\u003CModule\u003E.smethod_6<string>(2689448454U), (ushort) 2079, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_9<string>(581660704U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_9<string>(1182421191U), true));
      }
      if (input.StartsWith(\u003CModule\u003E.smethod_7<string>(296333255U)))
      {
        List<short> int_28 = new List<short>()
        {
          (short) 6989,
          (short) 6990,
          (short) 6991,
          (short) 6992,
          (short) 6993,
          (short) 6994,
          (short) 6995
        };
        this.dictionary_0.Add(71, new Class12(\u003CModule\u003E.smethod_6<string>(2121648980U), (ushort) 659, int_28, false, Regex.Match(input, \u003CModule\u003E.smethod_8<string>(129094058U)).Groups[1].Value, (short) 0, (short) 0, "", \u003CModule\u003E.smethod_5<string>(4183150083U), true));
      }
    }
    this.Control2_0.listBox_4.Items.Clear();
    foreach (KeyValuePair<int, Class12> keyValuePair in this.dictionary_0)
    {
      ListBox.ObjectCollection items1 = this.Control2_0.listBox_4.Items;
      ushort uint160 = keyValuePair.Value.UInt16_0;
      string str1 = uint160.ToString();
      if (!items1.Contains((object) str1))
      {
        ListBox.ObjectCollection items2 = this.Control2_0.listBox_4.Items;
        uint160 = keyValuePair.Value.UInt16_0;
        string str2 = uint160.ToString();
        items2.Add((object) str2);
      }
    }
  }

  internal int method_159([In] int obj0, int e) => e << 16 | obj0 & (int) ushort.MaxValue;

  internal void method_160()
  {
    Class137.PostMessage(Process.GetProcessById(this.int_4).MainWindowHandle, 256, 27, this.method_159(1, Class137.MapVirtualKey(27, 0)));
    Class137.PostMessage(Process.GetProcessById(this.int_4).MainWindowHandle, 257, 27, this.method_159(1, Class137.MapVirtualKey(27, 0)));
  }

  internal bool method_161()
  {
    this.Control2_0.checkBox_69.Checked = false;
    this.Control2_0.toolStripMenuItem_2_Click(new object(), new EventArgs());
    string string0 = this.class88_0.String_0;
    using (List<string>.Enumerator enumerator = new List<string>()
    {
      \u003CModule\u003E.smethod_9<string>(2172713660U),
      \u003CModule\u003E.smethod_9<string>(4232036432U),
      \u003CModule\u003E.smethod_8<string>(3227715113U),
      \u003CModule\u003E.smethod_7<string>(3244631891U),
      \u003CModule\u003E.smethod_6<string>(3812015856U),
      \u003CModule\u003E.smethod_5<string>(2512012511U),
      \u003CModule\u003E.smethod_5<string>(332391602U)
    }.GetEnumerator())
    {
label_12:
      while (enumerator.MoveNext())
      {
        string current = enumerator.Current;
        if (this.method_29(current))
        {
          DateTime utcNow = DateTime.UtcNow;
          while (!this.class88_0.String_0.Contains(current.Replace(\u003CModule\u003E.smethod_9<string>(3860546844U), "")))
          {
            if (DateTime.UtcNow.Subtract(utcNow).TotalSeconds <= 2.0)
            {
              Thread.Sleep(10);
            }
            else
            {
              this.method_29(current);
              Thread.Sleep(1000);
              if (this.class88_0.String_0.Contains(current.Replace(\u003CModule\u003E.smethod_5<string>(1721197686U), "")))
                return true;
              if (this.method_24(\u003CModule\u003E.smethod_9<string>(379550265U)))
              {
                while (DateTime.UtcNow.Subtract(utcNow).TotalSeconds < 4.0)
                  this.method_31(\u003CModule\u003E.smethod_6<string>(61408339U), (Class142) null, true, true);
              }
              if (this.class88_0.String_0 != string0)
                return true;
              goto label_12;
            }
          }
          return true;
        }
      }
    }
    if (!this.method_31(\u003CModule\u003E.smethod_5<string>(2383463467U), (Class142) null, true, true))
      this.method_31(\u003CModule\u003E.smethod_9<string>(379550265U), (Class142) null, true, true);
    if (this.class88_0.String_0 != string0)
      return true;
    this.method_60((byte) 0, new List<string>()
    {
      \u003CModule\u003E.smethod_6<string>(2001827108U),
      \u003CModule\u003E.smethod_6<string>(1717927371U),
      \u003CModule\u003E.smethod_5<string>(801833817U),
      \u003CModule\u003E.smethod_8<string>(2827178802U),
      \u003CModule\u003E.smethod_6<string>(2806646929U),
      \u003CModule\u003E.smethod_7<string>(2289858175U),
      \u003CModule\u003E.smethod_6<string>(3220776687U),
      \u003CModule\u003E.smethod_6<string>(996458181U),
      \u003CModule\u003E.smethod_5<string>(3817023512U),
      \u003CModule\u003E.smethod_6<string>(2499307497U)
    }[Class138.smethod_3(0, 10)]);
    Thread.Sleep(1500);
    return false;
  }

  internal void method_162()
  {
    this.control2_0.method_57();
    this.control2_0 = (Control2) null;
  }
}
