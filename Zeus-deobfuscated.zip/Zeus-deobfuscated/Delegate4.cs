﻿// Decompiled with JetBrains decompiler
// Type: Delegate4
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Runtime.InteropServices;

[return: MarshalAs(UnmanagedType.Bool)]
internal delegate void Delegate4(Class29 intptr_0, uint uint_1, [In] string obj2);
