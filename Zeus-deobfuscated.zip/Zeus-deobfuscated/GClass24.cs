﻿// Decompiled with JetBrains decompiler
// Type: GClass24
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.IO;
using System.Runtime.InteropServices;

public class GClass24
{
  public static byte[] smethod_0([In] string obj0)
  {
    uint num1 = 7;
    uint num2 = 0;
    uint num3 = 0;
    uint count = 0;
    byte[] numArray1 = File.ReadAllBytes(obj0);
    byte[] src = new byte[numArray1.Length * 10];
    uint[] numArray2 = new uint[256];
    uint[] numArray3 = new uint[256];
    byte[] numArray4 = new byte[513];
    for (uint index = 0; index < 256U; ++index)
    {
      numArray2[(int) index] = (uint) (2 * (int) index + 1);
      numArray3[(int) index] = (uint) (2 * (int) index + 2);
      numArray4[(int) index * 2 + 1] = (byte) index;
      numArray4[(int) index * 2 + 2] = (byte) index;
    }
    while (num2 != 256U)
    {
      uint index1;
      for (index1 = 0U; index1 <= (uint) byte.MaxValue; index1 = ((int) numArray1[4 + (int) num3 - 1] & 1 << (int) num1) == 0 ? numArray2[(int) index1] : numArray3[(int) index1])
      {
        if (num1 == 7U)
        {
          ++num3;
          num1 = 0U;
        }
        else
          ++num1;
      }
      uint index2 = index1;
      for (uint index3 = (uint) numArray4[(int) index1]; index2 != 0U && index3 != 0U; index3 = (uint) numArray4[(int) index2])
      {
        uint index4 = (uint) numArray4[(int) index3];
        uint index5 = numArray2[(int) index4];
        if ((int) index5 == (int) index3)
        {
          index5 = numArray3[(int) index4];
          numArray3[(int) index4] = index2;
        }
        else
          numArray2[(int) index4] = index2;
        if ((int) numArray2[(int) index3] == (int) index2)
          numArray2[(int) index3] = index5;
        else
          numArray3[(int) index3] = index5;
        numArray4[(int) index2] = (byte) index4;
        numArray4[(int) index5] = (byte) index3;
        index2 = index4;
      }
      num2 = index1 + 4294967040U;
      if (num2 != 256U)
      {
        src[(int) count] = (byte) num2;
        ++count;
      }
    }
    byte[] dst = new byte[(int) count];
    Buffer.BlockCopy((Array) src, 0, (Array) dst, 0, (int) count);
    return dst;
  }

  public static byte[] smethod_1(byte[] point_0)
  {
    uint num1 = 7;
    uint num2 = 0;
    uint num3 = 0;
    uint count = 0;
    byte[] src = new byte[point_0.Length * 10];
    uint[] numArray1 = new uint[256];
    uint[] numArray2 = new uint[256];
    byte[] numArray3 = new byte[513];
    for (uint index = 0; index < 256U; ++index)
    {
      numArray1[(int) index] = (uint) (2 * (int) index + 1);
      numArray2[(int) index] = (uint) (2 * (int) index + 2);
      numArray3[(int) index * 2 + 1] = (byte) index;
      numArray3[(int) index * 2 + 2] = (byte) index;
    }
    while (num2 != 256U)
    {
      uint index1;
      for (index1 = 0U; index1 <= (uint) byte.MaxValue; index1 = ((int) point_0[4 + (int) num3 - 1] & 1 << (int) num1) == 0 ? numArray1[(int) index1] : numArray2[(int) index1])
      {
        if (num1 == 7U)
        {
          ++num3;
          num1 = 0U;
        }
        else
          ++num1;
      }
      uint index2 = index1;
      for (uint index3 = (uint) numArray3[(int) index1]; index2 != 0U && index3 != 0U; index3 = (uint) numArray3[(int) index2])
      {
        uint index4 = (uint) numArray3[(int) index3];
        uint index5 = numArray1[(int) index4];
        if ((int) index5 == (int) index3)
        {
          index5 = numArray2[(int) index4];
          numArray2[(int) index4] = index2;
        }
        else
          numArray1[(int) index4] = index2;
        if ((int) numArray1[(int) index3] == (int) index2)
          numArray1[(int) index3] = index5;
        else
          numArray2[(int) index3] = index5;
        numArray3[(int) index2] = (byte) index4;
        numArray3[(int) index5] = (byte) index3;
        index2 = index4;
      }
      num2 = index1 + 4294967040U;
      if (num2 != 256U)
      {
        src[(int) count] = (byte) num2;
        ++count;
      }
    }
    byte[] dst = new byte[(int) count];
    Buffer.BlockCopy((Array) src, 0, (Array) dst, 0, (int) count);
    return dst;
  }
}
