﻿// Decompiled with JetBrains decompiler
// Type: Enum14
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

internal enum Enum14 : byte
{
  HashRequest = 1,
  KeepAlive = 2,
  UpTimeResponse = 3,
  CharListResponse = 4,
  CharInfoResponse = 5,
  RangerAlert = 6,
  DMUResponse = 7,
  DMURequest = 8,
  Trivia = 50, // 0x32
  KillRequest = 255, // 0xFF
}
