﻿// Decompiled with JetBrains decompiler
// Type: Stream0
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

internal sealed class Stream0 : Stream, IDisposable
{
  private readonly Enum7 enum7_0;
  private bool bool_0;
  private IntPtr intptr_0;

  public virtual long System\u002EIO\u002EStream\u002EPosition { get; [param: In] set; }

  public int Int32_0 { get; set; }

  void object.Finalize()
  {
    try
    {
      ((Stream) this).Dispose(false);
    }
    finally
    {
      // ISSUE: explicit finalizer call
      this.Finalize();
    }
  }

  public virtual bool System\u002EIO\u002EStream\u002ECanRead => (this.enum7_0 & Enum7.VmRead) > Enum7.None;

  public virtual bool System\u002EIO\u002EStream\u002ECanSeek => true;

  public virtual bool System\u002EIO\u002EStream\u002ECanWrite => (this.enum7_0 & (Enum7.VmOperation | Enum7.VmWrite)) > Enum7.None;

  public virtual long System\u002EIO\u002EStream\u002ELength => throw new NotSupportedException(\u003CModule\u003E.smethod_5<string>(2656307445U));

  internal Stream0([In] int obj0, Enum7 class99_0)
  {
    this.enum7_0 = class99_0;
    this.Int32_0 = obj0;
    this.intptr_0 = Class77.OpenProcess(class99_0, false, obj0);
    if (this.intptr_0 == IntPtr.Zero)
      throw new ArgumentException(\u003CModule\u003E.smethod_5<string>(3318573226U));
  }

  public virtual void System\u002EIO\u002EStream\u002EFlush() => throw new NotSupportedException(\u003CModule\u003E.smethod_9<string>(855095160U));

  public virtual int System\u002EIO\u002EStream\u002ERead([In] byte[] obj0, int class99_0, [In] int obj2)
  {
    if (this.bool_0)
      throw new ObjectDisposedException(\u003CModule\u003E.smethod_9<string>(982624953U));
    if (this.intptr_0 == IntPtr.Zero)
      throw new InvalidOperationException(\u003CModule\u003E.smethod_9<string>(1061362787U));
    IntPtr num1 = Marshal.AllocHGlobal(obj2);
    if (num1 == IntPtr.Zero)
      throw new InvalidOperationException(\u003CModule\u003E.smethod_7<string>(1787922857U));
    int num2;
    Class77.ReadProcessMemory(this.intptr_0, (IntPtr) ((Stream) this).Position, num1, obj2, ref num2);
    ((Stream) this).Position = ((Stream) this).Position + (long) num2;
    Marshal.Copy(num1, obj0, class99_0, obj2);
    Marshal.FreeHGlobal(num1);
    return num2;
  }

  public virtual long System\u002EIO\u002EStream\u002ESeek(long class29_0, SeekOrigin class99_0)
  {
    if (this.bool_0)
      throw new ObjectDisposedException(\u003CModule\u003E.smethod_8<string>(4138854227U));
    switch (class99_0)
    {
      case SeekOrigin.Begin:
        ((Stream) this).Position = class29_0;
        break;
      case SeekOrigin.Current:
        ((Stream) this).Position = ((Stream) this).Position + class29_0;
        break;
      case SeekOrigin.End:
        throw new NotSupportedException(\u003CModule\u003E.smethod_8<string>(564062887U));
    }
    return ((Stream) this).Position;
  }

  public virtual void System\u002EIO\u002EStream\u002ESetLength(long class29_0) => throw new NotSupportedException(\u003CModule\u003E.smethod_7<string>(3156343102U));

  public virtual void System\u002EIO\u002EStream\u002EWrite([In] byte[] obj0, int class99_0, [In] int obj2)
  {
    if (this.bool_0)
      throw new ObjectDisposedException(\u003CModule\u003E.smethod_9<string>(982624953U));
    if (this.intptr_0 == IntPtr.Zero)
      throw new InvalidOperationException(\u003CModule\u003E.smethod_8<string>(3551751817U));
    IntPtr num1 = Marshal.AllocHGlobal(obj2);
    if (num1 == IntPtr.Zero)
      throw new InvalidOperationException(\u003CModule\u003E.smethod_9<string>(2865625973U));
    Marshal.Copy(obj0, class99_0, num1, obj2);
    int num2;
    Class77.WriteProcessMemory(this.intptr_0, (IntPtr) ((Stream) this).Position, num1, obj2, ref num2);
    ((Stream) this).Position = ((Stream) this).Position + (long) num2;
    Marshal.FreeHGlobal(num1);
  }

  public virtual void System\u002EIO\u002EStream\u002EWriteByte(byte class29_0) => ((Stream) this).Write(new byte[1]
  {
    class29_0
  }, 0, 1);

  public void method_0([In] string obj0)
  {
    byte[] bytes = Encoding.ASCII.GetBytes(obj0);
    ((Stream) this).Write(bytes, 0, bytes.Length);
  }

  public virtual void System\u002EIO\u002EStream\u002EClose()
  {
    if (this.bool_0)
      throw new ObjectDisposedException(\u003CModule\u003E.smethod_7<string>(2938644045U));
    if (this.intptr_0 != IntPtr.Zero)
    {
      Class77.CloseHandle(this.intptr_0);
      this.intptr_0 = IntPtr.Zero;
    }
    // ISSUE: explicit non-virtual call
    __nonvirtual (((Stream) this).Close());
  }

  void Stream.Dispose(bool class29_0)
  {
    if (!this.bool_0)
    {
      if (this.intptr_0 != IntPtr.Zero)
      {
        Class77.CloseHandle(this.intptr_0);
        this.intptr_0 = IntPtr.Zero;
      }
      // ISSUE: explicit non-virtual call
      __nonvirtual (((Stream) this).Dispose(class29_0));
    }
    this.bool_0 = true;
  }
}
