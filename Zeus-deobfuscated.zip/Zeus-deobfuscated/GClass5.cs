﻿// Decompiled with JetBrains decompiler
// Type: GClass5
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.IO;
using System.Runtime.InteropServices;

public class GClass5
{
  public string String_0 { get; set; }

  public GClass4 this[[In] int obj0]
  {
    get => this.GClass4_0[obj0];
    [param: In] set => this.GClass4_0[obj0] = value;
  }

  public GClass4[] GClass4_0 { get; [param: In] private set; }

  public long Int64_0 { get; private set; }

  public int Int32_0 { get; [param: In] private set; }

  public int Int32_1 { get; [param: In] private set; }

  public int Int32_2 { get; [param: In] private set; }

  public int Int32_3 { get; [param: In] private set; }

  public static GClass5 smethod_0(string int_4) => GClass5.smethod_5((Stream) new FileStream(int_4, FileMode.Open, FileAccess.Read, FileShare.Read), int_4);

  public static GClass5 smethod_1(byte[] int_4, string value) => GClass5.smethod_5((Stream) new MemoryStream(int_4), value);

  public static GClass5 smethod_2(string value, [In] GClass0 obj1) => obj1.method_1(value, true) ? GClass5.smethod_1(obj1.method_5(value, true), value) : (GClass5) null;

  public static GClass5 smethod_3(string value, [In] bool obj1, [In] GClass0 obj2) => obj2.method_1(value, obj1) ? GClass5.smethod_1(obj2.method_5(value, obj1), value) : (GClass5) null;

  public static GClass5 smethod_4(string value, [In] bool obj1, [In] GClass0 obj2)
  {
    int index1 = obj2.method_3(value, true);
    if (index1 == -1)
      return (GClass5) null;
    using (FileStream input = File.Open(obj2.String_0, FileMode.Open, FileAccess.Read, FileShare.Read))
    {
      using (BinaryReader binaryReader = new BinaryReader((Stream) input))
      {
        GClass5 gclass5 = new GClass5()
        {
          String_0 = Path.GetFileName(value).ToLower()
        };
        input.Seek(obj2.List_0[index1].Int64_2, SeekOrigin.Begin);
        gclass5.Int32_3 = (int) binaryReader.ReadUInt16();
        gclass5.Int32_2 = (int) binaryReader.ReadUInt16();
        gclass5.Int32_1 = (int) binaryReader.ReadUInt16();
        gclass5.Int32_0 = (int) binaryReader.ReadUInt16();
        gclass5.Int64_0 = (long) (binaryReader.ReadUInt32() + 12U);
        if (gclass5.Int32_3 <= 0)
          return (GClass5) null;
        gclass5.GClass4_0 = new GClass4[gclass5.Int32_3];
        for (int index2 = 0; index2 < gclass5.Int32_3; ++index2)
        {
          binaryReader.BaseStream.Seek(obj2.List_0[index1].Int64_2 + gclass5.Int64_0 + (long) (index2 * 16), SeekOrigin.Begin);
          int gclass16_0 = (int) binaryReader.ReadUInt16();
          int num1 = (int) binaryReader.ReadUInt16();
          int num2 = (int) binaryReader.ReadUInt16();
          int num3 = (int) binaryReader.ReadUInt16() - num1;
          int num4 = gclass16_0;
          int num5 = num2 - num4;
          uint num6 = binaryReader.ReadUInt32() + 12U;
          uint num7 = binaryReader.ReadUInt32() + 12U;
          binaryReader.BaseStream.Seek(obj2.List_0[index1].Int64_2 + (long) num6, SeekOrigin.Begin);
          byte[] numArray = (long) (num7 - num6) == (long) (num3 * num5) ? binaryReader.ReadBytes((int) num7 - (int) num6) : binaryReader.ReadBytes((int) (gclass5.Int64_0 - (long) num6));
          gclass5.GClass4_0[index2] = new GClass4(num1, gclass16_0, num3, num5, numArray);
        }
        return gclass5;
      }
    }
  }

  private static GClass5 smethod_5(Stream byte_1, [In] string obj1)
  {
    byte_1.Seek(0L, SeekOrigin.Begin);
    BinaryReader binaryReader = new BinaryReader(byte_1);
    GClass5 gclass5 = new GClass5();
    if (obj1 != null || obj1 != string.Empty)
      gclass5.String_0 = Path.GetFileName(obj1).ToLower();
    gclass5.Int32_3 = (int) binaryReader.ReadUInt16();
    gclass5.Int32_2 = (int) binaryReader.ReadUInt16();
    gclass5.Int32_1 = (int) binaryReader.ReadUInt16();
    gclass5.Int32_0 = (int) binaryReader.ReadUInt16();
    gclass5.Int64_0 = (long) (binaryReader.ReadUInt32() + 12U);
    if (gclass5.Int32_3 <= 0)
      return (GClass5) null;
    gclass5.GClass4_0 = new GClass4[gclass5.Int32_3];
    for (int index = 0; index < gclass5.Int32_3; ++index)
    {
      binaryReader.BaseStream.Seek(gclass5.Int64_0 + (long) (index * 16), SeekOrigin.Begin);
      int gclass16_0 = (int) binaryReader.ReadUInt16();
      int num1 = (int) binaryReader.ReadUInt16();
      int num2 = (int) binaryReader.ReadUInt16();
      int num3 = (int) binaryReader.ReadUInt16() - num1;
      int num4 = gclass16_0;
      int num5 = num2 - num4;
      uint offset = binaryReader.ReadUInt32() + 12U;
      uint num6 = binaryReader.ReadUInt32() + 12U;
      binaryReader.BaseStream.Seek((long) offset, SeekOrigin.Begin);
      byte[] numArray = (long) (num6 - offset) == (long) (num3 * num5) ? binaryReader.ReadBytes((int) num6 - (int) offset) : binaryReader.ReadBytes((int) (gclass5.Int64_0 - (long) offset));
      gclass5.GClass4_0[index] = new GClass4(num1, gclass16_0, num3, num5, numArray);
    }
    return gclass5;
  }

  public virtual string System\u002EObject\u002EToString() => \u003CModule\u003E.smethod_8<string>(1972388607U) + this.Int32_3.ToString() + \u003CModule\u003E.smethod_7<string>(1701649345U) + this.Int32_2.ToString() + \u003CModule\u003E.smethod_5<string>(2014490643U) + this.Int32_1.ToString() + \u003CModule\u003E.smethod_6<string>(3931581411U) + this.Int64_0.ToString(\u003CModule\u003E.smethod_5<string>(432860993U)).PadLeft(8, '0') + \u003CModule\u003E.smethod_8<string>(907800239U);
}
