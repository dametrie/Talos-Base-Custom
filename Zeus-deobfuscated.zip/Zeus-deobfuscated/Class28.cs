﻿// Decompiled with JetBrains decompiler
// Type: Class28
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using System.Drawing;
using System.Windows.Forms;

internal class Class28 : ProgressBar
{
  private readonly Bitmap bitmap_0;

  CreateParams ProgressBar.CreateParams
  {
    get
    {
      CreateParams createParams = __nonvirtual (((ProgressBar) this).CreateParams);
      createParams.Style |= 4;
      return createParams;
    }
  }

  internal Class28(string value)
  {
    this.Name = value;
    this.SetStyle(ControlStyles.UserPaint, true);
    this.bitmap_0 = this.Name.Equals(\u003CModule\u003E.smethod_5<string>(3556130420U)) ? Class9.Bitmap_6 : Class9.Bitmap_5;
  }

  void Control.OnPaintBackground(PaintEventArgs value)
  {
  }

  void Control.OnPaint(PaintEventArgs value)
  {
    using (Image image = (Image) new Bitmap(this.Width, this.Height))
    {
      using (Graphics g = Graphics.FromImage(image))
      {
        Rectangle bounds = new Rectangle(0, 0, this.Width, this.Height);
        if (ProgressBarRenderer.IsSupported)
          ProgressBarRenderer.DrawVerticalBar(g, bounds);
        int y = (100 - this.Value) * this.MaximumSize.Height / 100;
        TextureBrush textureBrush = new TextureBrush((Image) this.bitmap_0);
        g.FillRectangle((Brush) textureBrush, 0, y, bounds.Width, bounds.Height);
        value.Graphics.DrawImage(image, 0, 0);
        image.Dispose();
        textureBrush.Dispose();
      }
    }
  }

  void object.Finalize()
  {
    try
    {
      this.bitmap_0?.Dispose();
    }
    finally
    {
      // ISSUE: explicit finalizer call
      this.Finalize();
    }
  }
}
