﻿// Decompiled with JetBrains decompiler
// Type: Class112
// Assembly: Zeus, Version=0.2.1.0, Culture=neutral, PublicKeyToken=bbd7cc35c13eeae2
// MVID: 56B81BC4-31D7-428A-BBEA-60D24AE2E753
// Assembly location: C:\Users\Gaming\Dropbox\Games\Dark Ages\Dark Ages Programs\Reversing tools\de4dot-net45 (deobfuscator)\Zeus-unpacked-cleaned-cleaned.exe

using Accolade;
using Accolade.Properties;
using ImageMagick;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

internal sealed class Class112
{
  internal List<string> list_0 = new List<string>()
  {
    \u003CModule\u003E.smethod_7<string>(2714704077U),
    \u003CModule\u003E.smethod_9<string>(787457117U),
    \u003CModule\u003E.smethod_8<string>(1178569410U),
    \u003CModule\u003E.smethod_9<string>(3356899061U),
    \u003CModule\u003E.smethod_5<string>(856620829U),
    \u003CModule\u003E.smethod_7<string>(742930742U),
    \u003CModule\u003E.smethod_7<string>(877751553U),
    \u003CModule\u003E.smethod_5<string>(942777623U),
    \u003CModule\u003E.smethod_7<string>(1946058449U),
    \u003CModule\u003E.smethod_7<string>(1865659434U),
    \u003CModule\u003E.smethod_6<string>(2050731822U),
    \u003CModule\u003E.smethod_8<string>(3926199688U),
    \u003CModule\u003E.smethod_9<string>(1984017213U),
    \u003CModule\u003E.smethod_9<string>(1699011752U),
    \u003CModule\u003E.smethod_7<string>(2430003862U),
    \u003CModule\u003E.smethod_5<string>(314788876U),
    \u003CModule\u003E.smethod_9<string>(3630804731U)
  };
  internal List<string> list_1 = new List<string>()
  {
    \u003CModule\u003E.smethod_5<string>(1049444395U),
    \u003CModule\u003E.smethod_7<string>(3781447777U),
    \u003CModule\u003E.smethod_6<string>(3860920570U),
    \u003CModule\u003E.smethod_5<string>(1885013181U),
    \u003CModule\u003E.smethod_7<string>(1563982889U),
    \u003CModule\u003E.smethod_9<string>(2239076799U),
    \u003CModule\u003E.smethod_9<string>(1680165668U),
    \u003CModule\u003E.smethod_6<string>(1116109175U),
    \u003CModule\u003E.smethod_8<string>(1591587391U),
    \u003CModule\u003E.smethod_6<string>(131129351U),
    \u003CModule\u003E.smethod_6<string>(2878991338U),
    \u003CModule\u003E.smethod_8<string>(1898745366U),
    \u003CModule\u003E.smethod_7<string>(2385035036U),
    \u003CModule\u003E.smethod_7<string>(3725462785U),
    \u003CModule\u003E.smethod_8<string>(3099038626U),
    \u003CModule\u003E.smethod_5<string>(3016216302U),
    \u003CModule\u003E.smethod_9<string>(4282338902U),
    \u003CModule\u003E.smethod_7<string>(1184569767U),
    \u003CModule\u003E.smethod_9<string>(993724744U),
    \u003CModule\u003E.smethod_5<string>(3273819265U),
    \u003CModule\u003E.smethod_5<string>(367658053U),
    \u003CModule\u003E.smethod_6<string>(631233137U),
    \u003CModule\u003E.smethod_8<string>(2325370117U),
    \u003CModule\u003E.smethod_7<string>(3493535503U),
    \u003CModule\u003E.smethod_9<string>(404867738U),
    \u003CModule\u003E.smethod_5<string>(1733592448U),
    \u003CModule\u003E.smethod_7<string>(3118897636U),
    \u003CModule\u003E.smethod_9<string>(963778869U),
    \u003CModule\u003E.smethod_8<string>(449183743U),
    \u003CModule\u003E.smethod_6<string>(3944271201U),
    \u003CModule\u003E.smethod_6<string>(2772628207U),
    \u003CModule\u003E.smethod_6<string>(2701881927U),
    \u003CModule\u003E.smethod_6<string>(792773044U),
    \u003CModule\u003E.smethod_7<string>(637201669U),
    \u003CModule\u003E.smethod_8<string>(2458443663U),
    \u003CModule\u003E.smethod_8<string>(2218385011U),
    \u003CModule\u003E.smethod_8<string>(1978326359U),
    \u003CModule\u003E.smethod_8<string>(1691994132U),
    \u003CModule\u003E.smethod_7<string>(2521419043U),
    \u003CModule\u003E.smethod_9<string>(288437736U),
    \u003CModule\u003E.smethod_6<string>(3379009685U),
    \u003CModule\u003E.smethod_6<string>(1490802539U),
    \u003CModule\u003E.smethod_9<string>(3896964108U),
    \u003CModule\u003E.smethod_5<string>(1229408990U),
    \u003CModule\u003E.smethod_7<string>(1691097133U),
    \u003CModule\u003E.smethod_7<string>(1915403515U),
    \u003CModule\u003E.smethod_9<string>(3363606057U),
    \u003CModule\u003E.smethod_5<string>(1723135854U),
    \u003CModule\u003E.smethod_8<string>(2802856075U),
    \u003CModule\u003E.smethod_5<string>(3774207719U),
    \u003CModule\u003E.smethod_7<string>(2217080060U),
    \u003CModule\u003E.smethod_6<string>(1639225461U),
    \u003CModule\u003E.smethod_7<string>(10533798U),
    \u003CModule\u003E.smethod_7<string>(2006721156U),
    \u003CModule\u003E.smethod_8<string>(2657491432U),
    \u003CModule\u003E.smethod_7<string>(3034920148U),
    \u003CModule\u003E.smethod_5<string>(803771985U),
    \u003CModule\u003E.smethod_6<string>(1387062805U)
  };
  internal string string_0;
  internal string string_1;
  internal static readonly object object_0 = new object();
  internal Form5 form5_0;
  private bool bool_0;
  private readonly Socket socket_0;
  private IPEndPoint ipendPoint_0;
  internal List<Class29> list_2;
  internal Class61 class61_0;
  private readonly Thread thread_0;
  internal Dictionary<short, Class88> dictionary_0;
  internal Dictionary<short, Class93> dictionary_1;
  internal string string_2;
  internal string string_3;
  internal GClass22 gclass22_0;
  internal GClass22 gclass22_1;
  internal GClass18 gclass18_0;
  internal GClass18 gclass18_1;
  internal string string_4;
  internal string string_5;
  internal GClass12 gclass12_0;
  internal List<ushort> list_3;
  internal List<ushort> list_4;
  internal List<ushort> list_5;
  internal List<ushort> list_6;
  internal List<ushort> list_7;
  internal Dictionary<int, List<ushort>> dictionary_2;
  internal Dictionary<string, List<ushort>> dictionary_3;
  internal Dictionary<string, List<ushort>> dictionary_4;
  internal bool bool_1;
  internal bool bool_2;
  internal bool bool_3;
  internal bool bool_4;
  internal bool bool_5;
  internal Dictionary<string, string> dictionary_5 = new Dictionary<string, string>();
  internal Dictionary<string, string> dictionary_6 = new Dictionary<string, string>();
  internal Dictionary<string, int> dictionary_7 = new Dictionary<string, int>();
  internal string string_6 = "";
  internal bool bool_6;
  internal Dictionary<string, string> dictionary_11 = new Dictionary<string, string>()
  {
    {
      \u003CModule\u003E.smethod_7<string>(1066358872U),
      \u003CModule\u003E.smethod_8<string>(2509304870U)
    },
    {
      \u003CModule\u003E.smethod_9<string>(1612527625U),
      \u003CModule\u003E.smethod_5<string>(675222941U)
    },
    {
      \u003CModule\u003E.smethod_9<string>(926086701U),
      \u003CModule\u003E.smethod_5<string>(2064029025U)
    },
    {
      \u003CModule\u003E.smethod_8<string>(428357995U),
      \u003CModule\u003E.smethod_9<string>(4152023694U)
    },
    {
      \u003CModule\u003E.smethod_9<string>(671027115U),
      \u003CModule\u003E.smethod_6<string>(89496755U)
    },
    {
      \u003CModule\u003E.smethod_6<string>(3556204535U),
      \u003CModule\u003E.smethod_7<string>(167570148U)
    },
    {
      \u003CModule\u003E.smethod_9<string>(258491861U),
      \u003CModule\u003E.smethod_6<string>(3816664577U)
    },
    {
      \u003CModule\u003E.smethod_7<string>(3367801248U),
      \u003CModule\u003E.smethod_6<string>(633856534U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(1639340771U),
      \u003CModule\u003E.smethod_6<string>(373396492U)
    },
    {
      \u003CModule\u003E.smethod_6<string>(349956797U),
      \u003CModule\u003E.smethod_6<string>(2290375566U)
    },
    {
      \u003CModule\u003E.smethod_9<string>(3867018233U),
      \u003CModule\u003E.smethod_6<string>(66057060U)
    },
    {
      \u003CModule\u003E.smethod_8<string>(3309061819U),
      \u003CModule\u003E.smethod_9<string>(209699902U)
    },
    {
      \u003CModule\u003E.smethod_6<string>(4207354640U),
      \u003CModule\u003E.smethod_6<string>(1024546597U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(3497589070U),
      \u003CModule\u003E.smethod_7<string>(413261701U)
    },
    {
      \u003CModule\u003E.smethod_5<string>(3433314548U),
      \u003CModule\u003E.smethod_9<string>(4249607612U)
    },
    {
      \u003CModule\u003E.smethod_6<string>(3225425408U),
      \u003CModule\u003E.smethod_5<string>(3369040026U)
    },
    {
      \u003CModule\u003E.smethod_7<string>(3613492801U),
      \u003CModule\u003E.smethod_9<string>(3829326065U)
    }
  };

  internal Class112([In] Form5 obj0)
  {
    this.form5_0 = obj0;
    this.socket_0 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
    this.Delegate2_0 = new Delegate2[256];
    this.Delegate3_0 = new Delegate3[256];
    this.ipendPoint_0 = new IPEndPoint(IPAddress.Parse(\u003CModule\u003E.smethod_5<string>(4006072407U)), 2610);
    this.thread_0 = new Thread(new ThreadStart(this.method_72));
    this.list_2 = new List<Class29>();
    this.dictionary_0 = new Dictionary<short, Class88>();
    this.Dictionary_1 = new Dictionary<string, Class96>();
    this.Dictionary_2 = new Dictionary<string, Class97>();
    this.class61_0 = new Class61();
    this.SortedDictionary_0 = new SortedDictionary<ushort, string>();
    this.dictionary_1 = new Dictionary<short, Class93>();
    this.Dictionary_4 = new Dictionary<uint, Class94>();
    this.list_4 = new List<ushort>()
    {
      (ushort) 676,
      (ushort) 690,
      (ushort) 691,
      (ushort) 699,
      (ushort) 700,
      (ushort) 701,
      (ushort) 532,
      (ushort) 530,
      (ushort) 528,
      (ushort) 526,
      (ushort) 492,
      (ushort) 387,
      (ushort) 289,
      (ushort) 290,
      (ushort) 292,
      (ushort) 293,
      (ushort) 294,
      (ushort) 295,
      (ushort) 296,
      (ushort) 297,
      (ushort) 298,
      (ushort) 299,
      (ushort) 253,
      (ushort) 252,
      (ushort) 195
    };
    this.list_5 = new List<ushort>()
    {
      (ushort) 553,
      (ushort) 561,
      (ushort) 62
    };
    this.list_6 = new List<ushort>()
    {
      (ushort) 552,
      (ushort) 561,
      (ushort) 62
    };
    this.list_3 = new List<ushort>()
    {
      (ushort) 563,
      (ushort) 564,
      (ushort) 565,
      (ushort) 566,
      (ushort) 439,
      (ushort) 456,
      (ushort) 53
    };
    this.dictionary_2 = new Dictionary<int, List<ushort>>()
    {
      {
        7071,
        new List<ushort>()
        {
          (ushort) 559,
          (ushort) 246,
          (ushort) 250,
          (ushort) 929
        }
      },
      {
        10240,
        new List<ushort>() { (ushort) 542, (ushort) 544 }
      },
      {
        2120,
        new List<ushort>() { (ushort) 876, (ushort) 878 }
      },
      {
        2088,
        new List<ushort>() { (ushort) 876, (ushort) 878 }
      },
      {
        8111,
        new List<ushort>() { (ushort) 205 }
      },
      {
        8496,
        new List<ushort>()
        {
          (ushort) 164,
          (ushort) 165,
          (ushort) 166,
          (ushort) 167
        }
      },
      {
        8497,
        new List<ushort>()
        {
          (ushort) 164,
          (ushort) 165,
          (ushort) 166,
          (ushort) 167
        }
      },
      {
        8498,
        new List<ushort>()
        {
          (ushort) 164,
          (ushort) 165,
          (ushort) 166,
          (ushort) 167
        }
      },
      {
        8499,
        new List<ushort>()
        {
          (ushort) 164,
          (ushort) 165,
          (ushort) 166,
          (ushort) 167
        }
      },
      {
        8500,
        new List<ushort>()
        {
          (ushort) 46,
          (ushort) 814,
          (ushort) 815,
          (ushort) 321
        }
      },
      {
        6999,
        new List<ushort>() { (ushort) 492 }
      },
      {
        509,
        new List<ushort>()
        {
          (ushort) 912,
          (ushort) 69,
          (ushort) 321,
          (ushort) 363,
          (ushort) 365,
          (ushort) 366,
          (ushort) 367
        }
      },
      {
        8400,
        new List<ushort>() { (ushort) 262, (ushort) 394 }
      },
      {
        10263,
        new List<ushort>() { (ushort) 454 }
      },
      {
        8994,
        new List<ushort>() { (ushort) 422 }
      },
      {
        8983,
        new List<ushort>() { (ushort) 404 }
      },
      {
        8980,
        new List<ushort>() { (ushort) 404 }
      },
      {
        10000,
        new List<ushort>() { (ushort) 422 }
      },
      {
        8989,
        new List<ushort>()
        {
          (ushort) 779,
          (ushort) 782,
          (ushort) 788
        }
      },
      {
        8984,
        new List<ushort>() { (ushort) 784, (ushort) 785 }
      },
      {
        9377,
        new List<ushort>() { (ushort) 692, (ushort) 695 }
      },
      {
        9378,
        new List<ushort>() { (ushort) 692, (ushort) 695 }
      },
      {
        9379,
        new List<ushort>() { (ushort) 692, (ushort) 695 }
      },
      {
        9380,
        new List<ushort>() { (ushort) 692, (ushort) 695 }
      },
      {
        9381,
        new List<ushort>() { (ushort) 692, (ushort) 695 }
      },
      {
        9382,
        new List<ushort>() { (ushort) 692, (ushort) 695 }
      },
      {
        9383,
        new List<ushort>() { (ushort) 692, (ushort) 695 }
      },
      {
        9384,
        new List<ushort>() { (ushort) 692, (ushort) 695 }
      },
      {
        6646,
        new List<ushort>() { (ushort) 318 }
      },
      {
        6647,
        new List<ushort>() { (ushort) 318 }
      },
      {
        6648,
        new List<ushort>() { (ushort) 318 }
      },
      {
        6649,
        new List<ushort>() { (ushort) 318 }
      },
      {
        6651,
        new List<ushort>() { (ushort) 316 }
      },
      {
        6652,
        new List<ushort>() { (ushort) 316 }
      },
      {
        6653,
        new List<ushort>() { (ushort) 316 }
      },
      {
        6654,
        new List<ushort>() { (ushort) 316 }
      },
      {
        6656,
        new List<ushort>() { (ushort) 207 }
      },
      {
        6657,
        new List<ushort>() { (ushort) 207 }
      },
      {
        6658,
        new List<ushort>() { (ushort) 207 }
      },
      {
        6659,
        new List<ushort>() { (ushort) 207 }
      }
    };
    this.dictionary_3 = new Dictionary<string, List<ushort>>()
    {
      {
        \u003CModule\u003E.smethod_8<string>(2270561891U),
        new List<ushort>() { (ushort) 53 }
      },
      {
        \u003CModule\u003E.smethod_5<string>(373370892U),
        new List<ushort>() { (ushort) 273, (ushort) 266 }
      },
      {
        \u003CModule\u003E.smethod_9<string>(2328914424U),
        new List<ushort>() { (ushort) 273, (ushort) 266 }
      },
      {
        \u003CModule\u003E.smethod_6<string>(3525663600U),
        new List<ushort>()
        {
          (ushort) 856,
          (ushort) 873,
          (ushort) 874,
          (ushort) 875
        }
      },
      {
        \u003CModule\u003E.smethod_6<string>(532996514U),
        new List<ushort>() { (ushort) 634, (ushort) 664 }
      },
      {
        \u003CModule\u003E.smethod_5<string>(244821848U),
        new List<ushort>()
        {
          (ushort) 707,
          (ushort) 780,
          (ushort) 781
        }
      },
      {
        \u003CModule\u003E.smethod_9<string>(1770003293U),
        new List<ushort>() { (ushort) 190, (ushort) 210 }
      },
      {
        \u003CModule\u003E.smethod_7<string>(3796958451U),
        new List<ushort>() { (ushort) 190, (ushort) 210 }
      },
      {
        \u003CModule\u003E.smethod_6<string>(336925251U),
        new List<ushort>()
        {
          (ushort) 609,
          (ushort) 610,
          (ushort) 611,
          (ushort) 612
        }
      },
      {
        \u003CModule\u003E.smethod_8<string>(3950972455U),
        new List<ushort>()
        {
          (ushort) 926,
          (ushort) 933,
          (ushort) 940,
          (ushort) 953,
          (ushort) 954,
          (ushort) 955,
          (ushort) 960
        }
      },
      {
        \u003CModule\u003E.smethod_7<string>(4098634996U),
        new List<ushort>() { (ushort) 401 }
      },
      {
        \u003CModule\u003E.smethod_8<string>(1096357071U),
        new List<ushort>() { (ushort) 707 }
      },
      {
        \u003CModule\u003E.smethod_8<string>(2883752741U),
        new List<ushort>() { (ushort) 400 }
      },
      {
        \u003CModule\u003E.smethod_9<string>(190853818U),
        new List<ushort>() { (ushort) 650 }
      },
      {
        \u003CModule\u003E.smethod_7<string>(1284057929U),
        new List<ushort>() { (ushort) 397 }
      },
      {
        \u003CModule\u003E.smethod_7<string>(3691229378U),
        new List<ushort>() { (ushort) 401 }
      },
      {
        \u003CModule\u003E.smethod_5<string>(1016116112U),
        new List<ushort>() { (ushort) 205 }
      },
      {
        \u003CModule\u003E.smethod_7<string>(2652478174U),
        new List<ushort>() { (ushort) 397 }
      }
    };
    this.dictionary_4 = new Dictionary<string, List<ushort>>()
    {
      {
        \u003CModule\u003E.smethod_9<string>(1784692189U),
        new List<ushort>() { (ushort) 529 }
      }
    };
    this.list_7 = new List<ushort>()
    {
      (ushort) 12,
      (ushort) 69,
      (ushort) 158,
      (ushort) 316,
      (ushort) 318,
      (ushort) 207,
      (ushort) 363,
      (ushort) 365,
      (ushort) 366,
      (ushort) 367,
      (ushort) 376,
      (ushort) 377,
      (ushort) 378,
      (ushort) 379,
      (ushort) 380,
      (ushort) 394,
      (ushort) 397,
      (ushort) 400,
      (ushort) 401,
      (ushort) 402,
      (ushort) 403,
      (ushort) 404,
      (ushort) 411,
      (ushort) 417,
      (ushort) 492,
      (ushort) 542,
      (ushort) 544,
      (ushort) 650,
      (ushort) 692,
      (ushort) 693,
      (ushort) 695,
      (ushort) 707,
      (ushort) 790,
      (ushort) 814,
      (ushort) 815,
      (ushort) 826,
      (ushort) 827,
      (ushort) 912,
      (ushort) 933
    };
    this.method_0();
    this.method_78();
  }

  private void method_0()
  {
    this.Delegate2_0[3] = new Delegate2(this.method_8);
    this.Delegate2_0[4] = new Delegate2(this.method_7);
    this.Delegate2_0[6] = new Delegate2(this.method_9);
    this.Delegate2_0[7] = new Delegate2(this.method_10);
    this.Delegate2_0[14] = new Delegate2(this.method_11);
    this.Delegate2_0[15] = new Delegate2(this.method_12);
    this.Delegate2_0[16] = new Delegate2(this.method_13);
    this.Delegate2_0[17] = new Delegate2(this.method_3);
    this.Delegate2_0[24] = new Delegate2(this.method_14);
    this.Delegate2_0[25] = new Delegate2(this.method_15);
    this.Delegate2_0[27] = new Delegate2(this.method_4);
    this.Delegate2_0[28] = new Delegate2(this.method_16);
    this.Delegate2_0[48] = new Delegate2(this.method_17);
    this.Delegate2_0[57] = new Delegate2(this.method_18);
    this.Delegate2_0[58] = new Delegate2(this.method_19);
    this.Delegate2_0[59] = new Delegate2(this.method_2);
    this.Delegate2_0[62] = new Delegate2(this.method_20);
    this.Delegate2_0[67] = new Delegate2(this.method_21);
    this.Delegate2_0[71] = new Delegate2(this.method_6);
    this.Delegate2_0[74] = new Delegate2(this.method_1);
    this.Delegate2_0[87] = new Delegate2(this.method_22);
    this.Delegate3_0[2] = new Delegate3(this.method_23);
    this.Delegate3_0[3] = new Delegate3(this.method_24);
    this.Delegate3_0[4] = new Delegate3(this.method_25);
    this.Delegate3_0[5] = new Delegate3(this.method_26);
    this.Delegate3_0[7] = new Delegate3(this.method_27);
    this.Delegate3_0[8] = new Delegate3(this.method_28);
    this.Delegate3_0[10] = new Delegate3(this.method_29);
    this.Delegate3_0[11] = new Delegate3(this.method_30);
    this.Delegate3_0[12] = new Delegate3(this.method_31);
    this.Delegate3_0[13] = new Delegate3(this.method_32);
    this.Delegate3_0[14] = new Delegate3(this.method_33);
    this.Delegate3_0[15] = new Delegate3(this.method_34);
    this.Delegate3_0[16] = new Delegate3(this.method_35);
    this.Delegate3_0[17] = new Delegate3(this.method_36);
    this.Delegate3_0[19] = new Delegate3(this.method_37);
    this.Delegate3_0[21] = new Delegate3(this.method_38);
    this.Delegate3_0[23] = new Delegate3(this.method_40);
    this.Delegate3_0[24] = new Delegate3(this.method_41);
    this.Delegate3_0[25] = new Delegate3(this.method_42);
    this.Delegate3_0[31] = new Delegate3(this.method_43);
    this.Delegate3_0[34] = new Delegate3(this.method_45);
    this.Delegate3_0[41] = new Delegate3(this.method_46);
    this.Delegate3_0[44] = new Delegate3(this.method_47);
    this.Delegate3_0[45] = new Delegate3(this.method_48);
    this.Delegate3_0[46] = new Delegate3(this.method_49);
    this.Delegate3_0[47] = new Delegate3(this.method_50);
    this.Delegate3_0[48] = new Delegate3(this.method_51);
    this.Delegate3_0[49] = new Delegate3(this.method_52);
    this.Delegate3_0[50] = new Delegate3(this.method_53);
    this.Delegate3_0[51] = new Delegate3(this.method_54);
    this.Delegate3_0[52] = new Delegate3(this.method_55);
    this.Delegate3_0[54] = new Delegate3(this.method_56);
    this.Delegate3_0[55] = new Delegate3(this.method_57);
    this.Delegate3_0[56] = new Delegate3(this.method_58);
    this.Delegate3_0[57] = new Delegate3(this.method_59);
    this.Delegate3_0[58] = new Delegate3(this.method_60);
    this.Delegate3_0[59] = new Delegate3(this.method_61);
    this.Delegate3_0[60] = new Delegate3(this.method_62);
    this.Delegate3_0[63] = new Delegate3(this.method_63);
    this.Delegate3_0[66] = new Delegate3(this.method_5);
    this.Delegate3_0[72] = new Delegate3(this.method_64);
    this.Delegate3_0[88] = new Delegate3(this.method_65);
    this.Delegate3_0[96] = new Delegate3(this.method_66);
    this.Delegate3_0[102] = new Delegate3(this.method_67);
    this.Delegate3_0[103] = new Delegate3(this.method_68);
    this.Delegate3_0[104] = new Delegate3(this.method_69);
    this.Delegate3_0[111] = new Delegate3(this.method_70);
  }

  internal SortedDictionary<ushort, string> SortedDictionary_0 { get; }

  internal int Int32_0 { get; private set; }

  internal IEnumerable<Class29> IEnumerable_0
  {
    get
    {
      try
      {
        return (IEnumerable<Class29>) this.list_2.Where<Class29>((Func<Class29, bool>) (obj0 => !string.IsNullOrEmpty(obj0?.String_0) && !obj0.String_0.Contains(\u003CModule\u003E.smethod_7<string>(226950406U)) && obj0.Control2_0 != null && obj0.Class143_0 != null)).ToList<Class29>();
      }
      catch
      {
        return (IEnumerable<Class29>) new List<Class29>();
      }
    }
  }

  internal Delegate2[] Delegate2_0 { get; }

  internal Delegate3[] Delegate3_0 { get; }

  internal Dictionary<short, Class88> Dictionary_0 => this.dictionary_0;

  internal Dictionary<string, Class96> Dictionary_1 { get; }

  internal Dictionary<string, Class97> Dictionary_2 { get; }

  internal Dictionary<short, Class93> Dictionary_3 => this.dictionary_1;

  internal Dictionary<uint, Class94> Dictionary_4 { get; }

  private bool method_1([In] Class29 obj0, Class99 class100_0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class112.Class114 class114 = new Class112.Class114();
    // ISSUE: reference to a compiler-generated field
    class114.class112_0 = this;
    // ISSUE: reference to a compiler-generated field
    class114.class29_0 = obj0;
    int num1 = (int) class100_0.method_2();
    if (num1 == 1)
    {
      class100_0.method_7();
      int num2 = (int) class100_0.method_2();
    }
    if (num1 == 4)
    {
      // ISSUE: reference to a compiler-generated field
      class114.class29_0.bool_12 = true;
      // ISSUE: reference to a compiler-generated method
      ThreadPool.QueueUserWorkItem(new WaitCallback(class114.method_0));
    }
    if (num1 == 5)
    {
      // ISSUE: reference to a compiler-generated field
      class114.class29_0.bool_13 = true;
    }
    return true;
  }

  private bool method_2([In] Class29 obj0, Class99 class100_0)
  {
    switch (class100_0.method_2())
    {
      case 2:
        int num1 = (int) class100_0.method_6();
        int num2 = (int) class100_0.method_6();
        break;
    }
    return true;
  }

  private bool method_3([In] Class29 obj0, Class99 class100_0)
  {
    Direction direction = (Direction) class100_0.method_2();
    obj0.Direction_0 = direction;
    return true;
  }

  private bool method_4([In] Class29 obj0, Class99 class100_0)
  {
    int num = (int) class100_0.method_2();
    return true;
  }

  private bool method_5([In] Class29 obj0, Class100 class100_0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class112.Class115 class115 = new Class112.Class115();
    // ISSUE: reference to a compiler-generated field
    class115.class112_0 = this;
    // ISSUE: reference to a compiler-generated field
    class115.class29_0 = obj0;
    int num1 = (int) class100_0.method_2();
    if (num1 == 0)
    {
      // ISSUE: reference to a compiler-generated field
      class115.class29_0.Class26_0.bool_7 = true;
      // ISSUE: reference to a compiler-generated field
      class115.class29_0.Class26_0.bool_6 = true;
      // ISSUE: reference to a compiler-generated field
      class115.class29_0.bool_37 = true;
      uint num2 = class100_0.method_8();
      // ISSUE: reference to a compiler-generated field
      class115.class29_0.uint_1 = num2;
      this.string_4 = class100_0.method_10();
      // ISSUE: reference to a compiler-generated field
      class115.class29_0.Control2_0.method_17(Color.IndianRed, \u003CModule\u003E.smethod_7<string>(3171853776U) + this.string_4 + \u003CModule\u003E.smethod_7<string>(3796592037U));
    }
    if (num1 == 2)
    {
      // ISSUE: reference to a compiler-generated field
      class115.class29_0.bool_37 = true;
      byte num3 = class100_0.method_2();
      int num4 = (int) class100_0.method_2();
      int num5 = (int) class100_0.method_6();
      int num6 = (int) class100_0.method_2();
      this.string_5 = class100_0.method_10();
      switch (num3)
      {
        case 0:
          // ISSUE: reference to a compiler-generated field
          class115.class29_0.Control2_0.method_17(Color.IndianRed, \u003CModule\u003E.smethod_8<string>(3737002243U) + this.string_5);
          break;
        case 1:
          // ISSUE: reference to a compiler-generated field
          class115.class29_0.Control2_0.method_17(Color.IndianRed, this.string_4 + \u003CModule\u003E.smethod_9<string>(1946325045U) + this.string_5);
          break;
      }
    }
    if (num1 == 3)
    {
      byte num7 = class100_0.method_2();
      uint num8 = class100_0.method_8();
      switch (num7)
      {
        case 0:
          // ISSUE: reference to a compiler-generated field
          class115.class29_0.Control2_0.method_17(Color.IndianRed, \u003CModule\u003E.smethod_7<string>(2294816637U) + num8.ToString() + \u003CModule\u003E.smethod_9<string>(3319206893U));
          break;
        case 1:
          // ISSUE: reference to a compiler-generated field
          class115.class29_0.Control2_0.method_17(Color.IndianRed, this.string_4 + \u003CModule\u003E.smethod_5<string>(1485558327U) + num8.ToString() + \u003CModule\u003E.smethod_8<string>(3496943591U));
          break;
      }
    }
    if (num1 == 4)
    {
      // ISSUE: reference to a compiler-generated field
      class115.class29_0.Class26_0.bool_7 = false;
      // ISSUE: reference to a compiler-generated field
      class115.class29_0.Class26_0.bool_6 = false;
      // ISSUE: reference to a compiler-generated method
      ThreadPool.QueueUserWorkItem(new WaitCallback(class115.method_0));
      int num9 = (int) class100_0.method_2();
      this.string_1 = class100_0.method_10();
    }
    if (num1 == 5)
    {
      // ISSUE: reference to a compiler-generated field
      class115.class29_0.Class26_0.bool_7 = false;
      // ISSUE: reference to a compiler-generated field
      class115.class29_0.Class26_0.bool_6 = false;
      // ISSUE: reference to a compiler-generated method
      ThreadPool.QueueUserWorkItem(new WaitCallback(class115.method_1));
      int num10 = (int) class100_0.method_2();
      this.string_0 = class100_0.method_10();
    }
    return true;
  }

  private bool method_6([In] Class29 obj0, Class99 class100_0)
  {
    int num = (int) class100_0.method_2();
    return true;
  }

  private bool method_7([In] Class29 obj0, Class99 class100_0)
  {
    int num1 = (int) class100_0.method_2();
    int num2 = (int) class100_0.method_2();
    int num3 = (int) class100_0.method_2();
    return true;
  }

  private bool method_8([In] Class29 obj0, Class99 int_1)
  {
    int_1.method_10();
    int_1.method_10();
    int num1 = (int) int_1.method_2();
    int num2 = (int) int_1.method_2();
    int num3 = (int) int_1.method_8();
    int num4 = (int) int_1.method_6();
    int num5 = (int) int_1.method_8();
    int num6 = (int) int_1.method_6();
    int num7 = (int) int_1.method_2();
    return true;
  }

  private bool method_9([In] Class29 obj0, [In] Class99 obj1)
  {
    Direction direction = (Direction) obj1.method_2();
    int num = (int) obj1.method_2();
    obj1.Byte_3[1] = obj0.Byte_1++;
    obj0.struct16_1.method_2(direction);
    obj0.DateTime_0 = DateTime.UtcNow;
    if (obj0.Control2_0 != null)
      obj0.Control2_0.method_21(obj0.class88_0);
    obj0.Boolean_3 = false;
    obj0.dateTime_3 = DateTime.UtcNow;
    return true;
  }

  private bool method_10(Class29 class29_0, Class99 class100_0)
  {
    int num = (int) class100_0.method_2();
    class100_0.method_12();
    return true;
  }

  private bool method_11(Class29 class29_0, Class99 class100_0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class112.Class116 class116 = new Class112.Class116();
    // ISSUE: reference to a compiler-generated field
    class116.class112_0 = this;
    // ISSUE: reference to a compiler-generated field
    class116.class29_0 = class29_0;
    int num = (int) class100_0.method_2();
    // ISSUE: reference to a compiler-generated field
    class116.string_0 = class100_0.method_10();
    // ISSUE: reference to a compiler-generated field
    if (!class116.string_0.StartsWith(\u003CModule\u003E.smethod_7<string>(2810796973U)))
      return true;
    // ISSUE: reference to a compiler-generated method
    ThreadPool.QueueUserWorkItem(new WaitCallback(class116.method_0));
    return false;
  }

  private bool method_12(Class29 class29_0, Class99 class100_0)
  {
    byte num = class100_0.method_2();
    Class134 class134 = class29_0.Class136_0[num];
    if (class134 == null)
      return false;
    class29_0.Class134_0 = class134;
    if (class100_0.Byte_3.Length > 2)
    {
      try
      {
        class29_0.Class142_0 = class29_0.dictionary_1[(int) class100_0.method_8()] as Class142;
      }
      catch (KeyNotFoundException ex)
      {
        class29_0.Class142_0 = (Class142) class29_0.Class143_0;
      }
    }
    else
      class29_0.Class142_0 = (Class142) null;
    if (!(class134 is Class135))
      return true;
    Class135 class135 = class134 as Class135;
    switch (class135.Byte_1)
    {
      case 1:
        class135.Delegate4_0(class29_0, 0U, class100_0.method_9());
        break;
      case 2:
        class135.Delegate4_0(class29_0, class100_0.method_8(), string.Empty);
        break;
      case 5:
        class135.Delegate4_0(class29_0, 0U, string.Empty);
        break;
    }
    return false;
  }

  private bool method_13(Class29 class29_0, Class99 class100_0)
  {
    byte num = class100_0.method_2();
    string str1 = class100_0.method_10();
    string str2 = class100_0.method_10();
    class100_0.method_7();
    class29_0.Class72_0 = new Class72(num, str1, str2);
    class29_0.String_0 = str2;
    string path = System.Environment.ExpandEnvironmentVariables(\u003CModule\u003E.smethod_7<string>(4210604980U));
    if (System.IO.File.ReadLines(path).Last<string>() == \u003CModule\u003E.smethod_7<string>(1775441035U))
    {
      string[] source = System.IO.File.ReadAllLines(path);
      System.IO.File.WriteAllLines(path, ((IEnumerable<string>) source).Take<string>(source.Length - 1));
    }
    if (string.IsNullOrEmpty(this.form5_0.string_1))
      class29_0.Class72_0 = (Class72) null;
    return true;
  }

  private bool method_14(Class29 class29_0, Class99 class100_0) => true;

  private bool method_15(Class29 class29_0, Class99 class100_0)
  {
    string input = class100_0.method_10();
    string int_12 = class100_0.method_10();
    if (this.form5_0.string_1 == \u003CModule\u003E.smethod_7<string>(1221832026U) && int_12.Contains(\u003CModule\u003E.smethod_6<string>(2019507375U)))
    {
      class29_0.Class26_0.bool_19 = !class29_0.Class26_0.bool_19;
      return false;
    }
    Match match = Regex.Match(input, \u003CModule\u003E.smethod_9<string>(3567559483U));
    if (!match.Success)
      return true;
    foreach (Class29 class29 in this.IEnumerable_0)
    {
      if (class29.String_0.Equals(match.Groups[1].Value, StringComparison.CurrentCultureIgnoreCase))
        class29.method_59(\u003CModule\u003E.smethod_6<string>(907262683U), int_12);
    }
    return false;
  }

  private bool method_16(Class29 class29_0, Class99 class100_0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class112.Class117 class117 = new Class112.Class117();
    // ISSUE: reference to a compiler-generated field
    class117.class29_0 = class29_0;
    byte num = class100_0.method_2();
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    if (class117.class29_0.bool_37 && class117.class29_0.uint_1 != 0U)
    {
      // ISSUE: reference to a compiler-generated field
      if (class117.class29_0.bool_38)
        return false;
      Class99 class99 = new Class99((byte) 74);
      class99.method_14((byte) 1);
      // ISSUE: reference to a compiler-generated field
      class99.method_20(class117.class29_0.uint_1);
      class99.method_14(num);
      // ISSUE: reference to a compiler-generated field
      class117.class29_0.method_4(new Class98[1]
      {
        (Class98) class99
      });
      return false;
    }
    // ISSUE: reference to a compiler-generated field
    class117.class29_0.Class21_0[num].DateTime_0 = DateTime.UtcNow;
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    class117.class29_0.string_1 = class117.class29_0.Class21_0[num].String_0;
    try
    {
      // ISSUE: reference to a compiler-generated field
      if (class117.class29_0.Class21_0[num].String_0 == \u003CModule\u003E.smethod_6<string>(996372742U))
      {
        // ISSUE: reference to a compiler-generated method
        ThreadPool.QueueUserWorkItem(new WaitCallback(class117.method_0));
      }
    }
    catch
    {
    }
    // ISSUE: reference to a compiler-generated field
    if (class117.class29_0.Class21_0[num].String_0 == \u003CModule\u003E.smethod_9<string>(407653153U))
    {
      // ISSUE: reference to a compiler-generated field
      if (class117.class29_0.byte_8 <= (byte) 1)
      {
        // ISSUE: reference to a compiler-generated field
        ++class117.class29_0.byte_8;
        // ISSUE: reference to a compiler-generated field
        class117.class29_0.dateTime_4 = DateTime.UtcNow;
      }
    }
    else
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (class117.class29_0.Class21_0[num].String_0 == \u003CModule\u003E.smethod_7<string>(2476169470U) && class117.class29_0.byte_8 <= (byte) 2)
      {
        // ISSUE: reference to a compiler-generated field
        ++class117.class29_0.byte_8;
        // ISSUE: reference to a compiler-generated field
        class117.class29_0.dateTime_4 = DateTime.UtcNow;
      }
    }
    return true;
  }

  private bool method_17(Class29 class29_0, Class99 class100_0)
  {
    int num1 = (int) class100_0.method_2();
    int num2 = (int) class100_0.method_2();
    int num3 = (int) class100_0.method_2();
    return true;
  }

  private bool method_18(Class29 class29_0, Class99 class100_0)
  {
    int num1 = (int) class100_0.method_2();
    class100_0.method_7();
    int num2 = (int) class100_0.method_6();
    return true;
  }

  private bool method_19(Class29 class29_0, Class99 class100_0)
  {
    byte num1 = class100_0.method_2();
    int num2 = class100_0.method_7();
    ushort num3 = class100_0.method_6();
    ushort num4 = class100_0.method_6();
    if (class29_0.Class75_0 != null && (int) class29_0.Class75_0.Byte_1 == (int) num1 && class29_0.Class75_0.Int32_0 == num2 && num3 == (ushort) 0 && num4 == (ushort) 1)
      class29_0.Class75_0 = (Class75) null;
    return true;
  }

  private bool method_20(Class29 class29_0, Class99 class100_0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class112.Class118 class118 = new Class112.Class118();
    // ISSUE: reference to a compiler-generated field
    class118.class29_0 = class29_0;
    byte intptr_0 = class100_0.method_2();
    // ISSUE: reference to a compiler-generated field
    class118.class29_0.Class133_0[intptr_0].DateTime_0 = DateTime.UtcNow;
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    class118.class29_0.string_0 = class118.class29_0.Class133_0[intptr_0].String_0;
    try
    {
      // ISSUE: reference to a compiler-generated field
      if (class118.class29_0.Class133_0[intptr_0].String_0 == \u003CModule\u003E.smethod_6<string>(1387062805U))
      {
        // ISSUE: reference to a compiler-generated method
        ThreadPool.QueueUserWorkItem(new WaitCallback(class118.method_0));
        // ISSUE: reference to a compiler-generated field
        if (class118.class29_0.Class21_0.method_0(\u003CModule\u003E.smethod_7<string>(370674566U)))
        {
          // ISSUE: reference to a compiler-generated field
          if (class118.class29_0.method_29(\u003CModule\u003E.smethod_6<string>(996372742U)))
          {
            // ISSUE: reference to a compiler-generated field
            Class132 class132 = class118.class29_0.Class133_0[\u003CModule\u003E.smethod_6<string>(1387062805U)];
            class132.DateTime_1 = DateTime.UtcNow;
            // ISSUE: reference to a compiler-generated field
            class118.class29_0.method_100(true, class132.Byte_0, (uint) class132.Double_0);
            return false;
          }
        }
      }
    }
    catch
    {
    }
    return true;
  }

  private bool method_21(Class29 class29_0, Class99 class100_0)
  {
    int num = (int) class100_0.method_2();
    if (num == 1)
    {
      int key = class100_0.method_7();
      if (class29_0.dictionary_1.ContainsKey(key))
        class29_0.Control2_0.method_22(class29_0.Dictionary_0[key]);
    }
    if (num == 3)
    {
      try
      {
        class100_0.method_12();
      }
      catch
      {
      }
    }
    return true;
  }

  private bool method_22(Class29 class29_0, Class99 class100_0) => true;

  private bool method_23(Class29 class29_0, Class100 class100_0) => true;

  private bool method_24(Class29 class29_0, Class100 class100_0)
  {
    byte[] address = class100_0.method_1(4);
    short port = class100_0.method_5();
    int num1 = (int) class100_0.method_2();
    int num2 = (int) class100_0.method_2();
    class100_0.method_1((int) class100_0.method_2());
    class100_0.method_10();
    class100_0.method_7();
    Array.Reverse((Array) address);
    this.ipendPoint_0 = new IPEndPoint(new IPAddress(address), (int) port);
    class100_0.Byte_3[0] = (byte) 1;
    class100_0.Byte_3[1] = (byte) 0;
    class100_0.Byte_3[2] = (byte) 0;
    class100_0.Byte_3[3] = (byte) 127;
    class100_0.Byte_3[4] = (byte) (this.Int32_0 / 256);
    class100_0.Byte_3[5] = (byte) (this.Int32_0 % 256);
    return true;
  }

  private bool method_25(Class29 class29_0, Class100 class100_0)
  {
    Struct16 struct16;
    try
    {
      struct16 = class100_0.method_12();
    }
    catch
    {
      return false;
    }
    class29_0.struct16_1 = struct16;
    class29_0.struct16_2 = struct16;
    if (class29_0.Class143_0 != null)
      class29_0.Class143_0.Struct16_0 = struct16;
    if (this.bool_5 && class29_0.Boolean_7)
    {
      class29_0.Boolean_7 = false;
      if (this.dictionary_1.ContainsKey(class29_0.Struct17_2.Int16_0))
      {
        Dictionary<Struct16, Class92> dictionary1_1 = this.dictionary_1[class29_0.Struct17_2.Int16_0].Dictionary_1;
        Struct17 struct172_1 = class29_0.Struct17_2;
        Struct16 struct160_1 = struct172_1.Struct16_0;
        if (!dictionary1_1.ContainsKey(struct160_1))
        {
          Dictionary<short, Class93> dictionary1_2 = this.dictionary_1;
          struct172_1 = class29_0.Struct17_2;
          int int160_1 = (int) struct172_1.Int16_0;
          Dictionary<Struct16, Class92> dictionary1_3 = dictionary1_2[(short) int160_1].Dictionary_1;
          Struct17 struct172_2 = class29_0.Struct17_2;
          Struct16 struct160_2 = struct172_2.Struct16_0;
          struct172_2 = class29_0.Struct17_2;
          int int161 = (int) (byte) struct172_2.Int16_1;
          struct172_2 = class29_0.Struct17_2;
          int int162 = (int) (byte) struct172_2.Int16_2;
          int short0 = (int) (byte) struct16.short_0;
          int short1 = (int) (byte) struct16.short_1;
          struct172_2 = class29_0.Struct17_2;
          int int160_2 = (int) struct172_2.Int16_0;
          int int160_3 = (int) class29_0.class88_0.Int16_0;
          Class92 class92 = new Class92((byte) int161, (byte) int162, (byte) short0, (byte) short1, (short) int160_2, (short) int160_3);
          dictionary1_3.Add(struct160_2, class92);
        }
        else
        {
          Dictionary<short, Class93> dictionary1_4 = this.dictionary_1;
          struct172_1 = class29_0.Struct17_2;
          int int160_4 = (int) struct172_1.Int16_0;
          Dictionary<Struct16, Class92> dictionary1_5 = dictionary1_4[(short) int160_4].Dictionary_1;
          Struct17 struct172_3 = class29_0.Struct17_2;
          Struct16 struct160_3 = struct172_3.Struct16_0;
          struct172_3 = class29_0.Struct17_2;
          int int161 = (int) (byte) struct172_3.Int16_1;
          struct172_3 = class29_0.Struct17_2;
          int int162 = (int) (byte) struct172_3.Int16_2;
          int short0 = (int) (byte) struct16.short_0;
          int short1 = (int) (byte) struct16.short_1;
          struct172_3 = class29_0.Struct17_2;
          int int160_5 = (int) struct172_3.Int16_0;
          int int160_6 = (int) class29_0.class88_0.Int16_0;
          Class92 class92 = new Class92((byte) int161, (byte) int162, (byte) short0, (byte) short1, (short) int160_5, (short) int160_6);
          dictionary1_5[struct160_3] = class92;
        }
      }
    }
    class29_0.Control2_0.method_21(class29_0.class88_0);
    if (class29_0.list_4.Count == 0)
      class29_0.method_152();
    if (class29_0.list_5.Count == 0)
      class29_0.method_151();
    if (!class29_0.bool_5)
      class29_0.method_138();
    if (!class29_0.bool_6)
      class29_0.method_140();
    if (!class29_0.bool_7)
      class29_0.method_139();
    if (class29_0.bool_5 && class29_0.bool_6 && class29_0.bool_7)
    {
      class29_0.Control2_0.gclass22_0 = (GClass22) null;
      class29_0.Control2_0.gclass10_0 = (GClass10) null;
      class29_0.Control2_0.gclass10_1 = (GClass10) null;
      class29_0.Control2_0.gclass16_0 = (GClass16) null;
      GC.Collect();
    }
    class29_0.bool_36 = true;
    return true;
  }

  private bool method_26(Class29 class29_0, Class100 class100_0)
  {
    uint num1 = class100_0.method_8();
    class100_0.method_1(2);
    byte num2 = class100_0.method_2();
    class29_0.UInt32_0 = num1;
    class29_0.Byte_0 = num2;
    class29_0.method_72();
    this.form5_0.method_2(class29_0);
    return true;
  }

  private bool method_27(Class29 class29_0, Class100 class100_0)
  {
    try
    {
      List<Class142> class142List = new List<Class142>();
      List<Class141> class141List = new List<Class141>();
      ushort num1 = class100_0.method_6();
      for (int index = 0; index < (int) num1; ++index)
      {
        Struct16 struct16 = class100_0.method_12();
        int num2 = (int) class100_0.method_8();
        ushort num3 = class100_0.method_6();
        if (num3 < (ushort) 32768)
        {
          ushort num4 = (ushort) ((uint) num3 - 16384U);
          class100_0.method_1(4);
          byte num5 = class100_0.method_2();
          int num6 = (int) class100_0.method_2();
          byte num7 = class100_0.method_2();
          string str = "";
          if (num7 == (byte) 2)
            str = class100_0.method_10();
          class142List.Add(new Class142(num2, str, num4, num7, struct16, class29_0.class88_0, (Direction) num5));
        }
        else
        {
          class100_0.method_1(3);
          ushort num8 = (ushort) ((uint) num3 - 32768U);
          class141List.Add(new Class141(num2, num8, struct16, class29_0.class88_0, true));
        }
      }
      foreach (Class142 sender in class142List)
      {
        if (!class29_0.dictionary_1.ContainsKey(sender.Int32_0))
          class29_0.dictionary_1.Add(sender.Int32_0, (Class139) sender);
        else if (class29_0.dictionary_1[sender.Int32_0] is Class142 class142)
        {
          class142.Struct16_0 = sender.Struct16_0;
          class142.UInt16_0 = sender.UInt16_0;
          class142.Class88_0 = sender.Class88_0;
          class142.Byte_0 = sender.Byte_0;
          class142.Direction_0 = sender.Direction_0;
          class142.method_0(sender.DateTime_0);
        }
        else
          class29_0.dictionary_1[sender.Int32_0] = (Class139) sender;
        if (!class29_0.HashSet_1.Contains(sender.Int32_0))
          class29_0.HashSet_1.Add(sender.Int32_0);
        if (sender.Byte_0 == (byte) 2)
        {
          if (!class29_0.Dictionary_3.ContainsKey(sender.String_0))
            class29_0.Dictionary_3.Add(sender.String_0, sender);
          else
            class29_0.Dictionary_3[sender.String_0] = sender;
        }
        else if (class29_0.Class26_0.control4_0 != null && !class29_0.Class26_0.method_41(sender.UInt16_0))
        {
          Class177 class142_4 = new Class177(sender.UInt16_0)
          {
            Control4_0 = class29_0.Class26_0.control4_0
          };
          class29_0.Class26_0.method_39(class142_4);
        }
        else if (class29_0.Control2_0 != null && class29_0.Control2_0?.tabControl_0.SelectedTab == class29_0.Control2_0.tabPage_8 && class29_0.Control2_0.tabControl_2.SelectedTab == class29_0.Control2_0.tabPage_7)
          class29_0.Control2_0.method_33(sender);
      }
      foreach (Class141 class141 in class141List)
      {
        if (class29_0.dictionary_1.ContainsKey(class141.Int32_0))
        {
          class141.method_0(class29_0.dictionary_1[class141.Int32_0].DateTime_0);
          class29_0.dictionary_1[class141.Int32_0] = (Class139) class141;
        }
        else if (!class29_0.dictionary_1.ContainsKey(class141.Int32_0))
          class29_0.dictionary_1[class141.Int32_0] = (Class139) class141;
        if (!class29_0.HashSet_2.Contains(class141.Int32_0))
          class29_0.HashSet_2.Add(class141.Int32_0);
        if (!class29_0.HashSet_1.Contains(class141.Int32_0))
          class29_0.HashSet_1.Add(class141.Int32_0);
      }
    }
    catch
    {
      class29_0.method_105(false);
    }
    return true;
  }

  private bool method_28(Class29 class29_0, Class100 class100_0)
  {
    Struct12 struct120 = class29_0.Struct12_0;
    byte num1;
    try
    {
      num1 = class100_0.method_2();
      if (((int) num1 & 32) == 32)
      {
        class100_0.method_1(3);
        struct120.byte_7 = class100_0.method_2();
        struct120.byte_0 = class100_0.method_2();
        struct120.uint_7 = class100_0.method_8();
        struct120.uint_8 = class100_0.method_8();
        struct120.byte_9 = class100_0.method_2();
        struct120.byte_6 = class100_0.method_2();
        struct120.byte_11 = class100_0.method_2();
        struct120.byte_2 = class100_0.method_2();
        struct120.byte_3 = class100_0.method_2();
        struct120.bool_0 = class100_0.method_4();
        struct120.byte_10 = class100_0.method_2();
        struct120.short_1 = class100_0.method_5();
        struct120.short_0 = class100_0.method_5();
        class100_0.method_1(4);
      }
      if (((int) num1 & 16) == 16)
      {
        struct120.uint_6 = class100_0.method_8();
        struct120.uint_9 = class100_0.method_8();
      }
      if (((int) num1 & 8) == 8)
      {
        struct120.uint_3 = class100_0.method_8();
        struct120.uint_11 = class100_0.method_8();
        struct120.uint_0 = class100_0.method_8();
        struct120.uint_10 = class100_0.method_8();
        struct120.uint_4 = class100_0.method_8();
        struct120.uint_5 = class100_0.method_8();
      }
      if (((int) num1 & 4) == 4)
      {
        int num2 = (int) class100_0.method_2();
        struct120.byte_1 = class100_0.method_2();
        if (class29_0.method_17(Enum0.NoBlind) && !class29_0.Boolean_0)
        {
          --class100_0.Int32_0;
          class100_0.method_14((byte) 0);
        }
        class100_0.method_1(3);
        struct120.enum4_0 = (Enum4) class100_0.method_2();
        struct120.enum3_1 = (Enum3) class100_0.method_2();
        struct120.enum3_0 = (Enum3) class100_0.method_2();
        struct120.byte_8 = class100_0.method_2();
        int num3 = (int) class100_0.method_2();
        struct120.sbyte_0 = class100_0.method_3();
        struct120.byte_4 = class100_0.method_2();
        struct120.byte_5 = class100_0.method_2();
      }
      if (struct120.enum4_0.HasFlag((Enum) Enum4.HasParcel) && !class29_0.Boolean_15 && !class29_0.bool_47)
        class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_6<string>(4090156165U));
      if (struct120.enum4_0.HasFlag((Enum) Enum4.HasLetter))
      {
        if (!class29_0.Boolean_14)
        {
          if (!class29_0.bool_47)
            class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(7825070U));
        }
      }
    }
    catch
    {
      return false;
    }
    class29_0.Struct12_0 = struct120;
    if (class29_0.method_17(Enum0.GmMode))
    {
      num1 |= (byte) 64;
      class100_0.Byte_3[0] = num1;
    }
    if (class29_0.Control2_0 != null)
    {
      class29_0.Control2_0.method_19();
      class29_0.Control2_0.method_20();
    }
    class29_0.method_21((Enum9) num1, struct120);
    return false;
  }

  private bool method_29(Class29 class29_0, Class100 class100_0)
  {
    byte num1;
    string str1;
    try
    {
      num1 = class100_0.method_2();
      str1 = class100_0.method_11();
    }
    catch
    {
      return false;
    }
    switch (num1)
    {
      case 0:
        if (class29_0.Control2_0 != null)
        {
          class29_0.Control2_0.method_17(Color.Magenta, str1);
          class29_0.Control2_0.method_29(str1);
        }
        Match match1;
        if ((match1 = Regex.Match(str1, \u003CModule\u003E.smethod_5<string>(1957382586U))).Success)
        {
          string str2 = match1.Groups[1].Value;
          string str3 = match1.Groups[2].Value;
          string input = match1.Groups[3].Value;
          string str4 = \u003CModule\u003E.smethod_7<string>(4120386581U);
          if (str3 == str4)
          {
            Match match2;
            if ((match2 = Regex.Match(input, \u003CModule\u003E.smethod_7<string>(3573018483U))).Success && str2 == \u003CModule\u003E.smethod_8<string>(2168839477U))
            {
              if (!(match2.Groups[1].Value != \u003CModule\u003E.smethod_9<string>(3518767524U)))
              {
                string str5 = match2.Groups[2].Value;
                if (!(str5 == \u003CModule\u003E.smethod_5<string>(973744195U)))
                {
                  if (!(str5 == \u003CModule\u003E.smethod_6<string>(1842397964U)))
                  {
                    if (!(str5 == \u003CModule\u003E.smethod_7<string>(372787383U)))
                    {
                      class29_0.method_59(str2, \u003CModule\u003E.smethod_9<string>(1125647332U));
                    }
                    else
                    {
                      class29_0.method_59(str2, \u003CModule\u003E.smethod_8<string>(941142104U));
                      ThreadPool.QueueUserWorkItem((WaitCallback) delegate
                      {
                        Thread.Sleep(100);
                        Process.GetCurrentProcess().Kill();
                      });
                    }
                  }
                  else
                  {
                    string str6 = match2.Groups[3].Value;
                    if (str6.Contains(\u003CModule\u003E.smethod_8<string>(3795757488U)))
                    {
                      if (str6 == \u003CModule\u003E.smethod_7<string>(2126861661U))
                        class29_0.Class26_0.bool_19 = true;
                      else if (str6 == \u003CModule\u003E.smethod_9<string>(1733350422U))
                      {
                        class29_0.Class26_0.bool_19 = false;
                        class29_0.Class26_0.bool_16 = true;
                      }
                      class29_0.method_59(str2, \u003CModule\u003E.smethod_8<string>(461024800U) + (class29_0.Class26_0.bool_19 ? \u003CModule\u003E.smethod_8<string>(3904923900U) : \u003CModule\u003E.smethod_7<string>(3768965955U)));
                    }
                    else if (str6.Contains(\u003CModule\u003E.smethod_8<string>(2248420470U)))
                    {
                      if (str6 == \u003CModule\u003E.smethod_8<string>(3022088979U))
                        class29_0.Control2_0.checkBox_33.Checked = true;
                      else if (str6 == \u003CModule\u003E.smethod_8<string>(2782030327U))
                      {
                        class29_0.Control2_0.checkBox_33.Checked = false;
                        class29_0.Class26_0.bool_16 = true;
                      }
                      class29_0.method_59(str2, \u003CModule\u003E.smethod_8<string>(461024800U) + (class29_0.Control2_0.checkBox_33.Checked ? \u003CModule\u003E.smethod_8<string>(3904923900U) : \u003CModule\u003E.smethod_8<string>(1234693309U)));
                    }
                    else
                      class29_0.method_59(str2, \u003CModule\u003E.smethod_6<string>(1251158795U));
                  }
                }
                else
                {
                  string str7 = match2.Groups[3].Value;
                  if (str7 == \u003CModule\u003E.smethod_5<string>(3751356363U))
                    class29_0.method_59(str2, class29_0.Class112_0.form5_0.string_1 + \u003CModule\u003E.smethod_6<string>(3498916996U) + Assembly.GetExecutingAssembly().GetName().Version?.ToString());
                  if (str7 == \u003CModule\u003E.smethod_8<string>(3795757488U))
                    class29_0.method_59(str2, class29_0.Class26_0.bool_19.ToString());
                  if (str7 == \u003CModule\u003E.smethod_5<string>(3583766197U))
                    class29_0.method_59(str2, class29_0.class88_0.String_0 + \u003CModule\u003E.smethod_8<string>(382084420U) + class29_0.Struct17_0.ToString());
                  if (str7 == \u003CModule\u003E.smethod_8<string>(1288185862U))
                  {
                    string int_12 = "";
                    if (class29_0.Control2_0 != null)
                    {
                      foreach (string str8 in class29_0.Control2_0.list_0)
                        int_12 = int_12 + str8 + \u003CModule\u003E.smethod_9<string>(366607487U);
                    }
                    class29_0.method_59(str2, int_12);
                  }
                }
                this.string_6 = str2;
                this.bool_6 = true;
                return false;
              }
              break;
            }
            if (this.bool_6 && str2 == this.string_6)
            {
              this.bool_6 = false;
              return false;
            }
            if (Settings.Default.WhisperFlash)
            {
              if (!Class137.IsWindowVisible(Process.GetProcessById(class29_0.int_4).MainWindowHandle))
                Class137.ShowWindow(class29_0.intptr_0, 1U);
              class29_0.method_45(Process.GetProcessById(class29_0.int_4).MainWindowHandle);
            }
            if (Settings.Default.WhisperSound && !this.bool_3)
              new SoundPlayer((Stream) Class9.UnmanagedMemoryStream_7).PlaySync();
            if (input.StartsWith(\u003CModule\u003E.smethod_6<string>(4150067101U)) && this.form5_0.bindingList_0.Contains<string>(str2, (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase))
            {
              class29_0.method_60((byte) 0, input.Remove(0, 5));
              break;
            }
            break;
          }
          this.bool_6 = false;
          break;
        }
        break;
      case 3:
        if (str1 == \u003CModule\u003E.smethod_6<string>(1795518574U))
        {
          TimeSpan timeSpan = new TimeSpan(0, 6, 0) - DateTime.UtcNow.Subtract(class29_0.dateTime_6);
          string ushort_2 = \u003CModule\u003E.smethod_9<string>(1440598668U) + (class29_0.dateTime_6 != DateTime.MinValue ? (timeSpan.Minutes > 1 ? string.Format(\u003CModule\u003E.smethod_9<string>(3548713399U), (object) timeSpan.Minutes) : (timeSpan.Minutes > 0 ? string.Format(\u003CModule\u003E.smethod_8<string>(2596779901U), (object) timeSpan.Minutes) : string.Empty)) + string.Format(\u003CModule\u003E.smethod_6<string>(1261566944U), (object) timeSpan.Seconds) : \u003CModule\u003E.smethod_5<string>(3578053358U));
          if (!class29_0.Control2_0.checkBox_21.Checked)
            class29_0.method_75((byte) 3, ushort_2);
          return false;
        }
        if (Regex.Match(str1, \u003CModule\u003E.smethod_5<string>(1996423708U), RegexOptions.IgnoreCase).Success)
        {
          class29_0.Class26_0.dateTime_9 = DateTime.UtcNow;
          SystemSounds.Beep.Play();
        }
        if (Regex.Match(str1, \u003CModule\u003E.smethod_9<string>(146454654U), RegexOptions.IgnoreCase).Success)
        {
          class29_0.Class26_0.dateTime_9 = DateTime.UtcNow;
          SystemSounds.Beep.Play();
        }
        if (str1.Equals(\u003CModule\u003E.smethod_5<string>(2530140445U)))
          class29_0.bool_1 = true;
        if (str1.Equals(\u003CModule\u003E.smethod_7<string>(3924439109U)))
          class29_0.bool_0 = false;
        else if (!str1.Contains(\u003CModule\u003E.smethod_6<string>(4290705271U)) && !str1.Contains(\u003CModule\u003E.smethod_9<string>(3901356903U)))
        {
          if (!str1.Contains(\u003CModule\u003E.smethod_6<string>(1084457533U)) && !str1.Contains(\u003CModule\u003E.smethod_9<string>(3214915979U)))
          {
            Match match3;
            if ((match3 = Regex.Match(str1, \u003CModule\u003E.smethod_9<string>(3980094737U))).Success)
            {
              string str9 = match3.Groups[1].Value;
              int num2 = int.Parse(match3.Groups[2].Value);
              class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(2348799805U) + str9 + \u003CModule\u003E.smethod_9<string>(1616920420U) + num2.ToString() + \u003CModule\u003E.smethod_8<string>(3049493092U));
              class29_0.Control2_0.method_17(Color.Crimson, \u003CModule\u003E.smethod_9<string>(2348799805U) + str9 + \u003CModule\u003E.smethod_9<string>(1616920420U) + num2.ToString() + \u003CModule\u003E.smethod_5<string>(993264756U));
              if (class29_0.Control2_0.checkBox_40.Checked && num2 == 30)
                class29_0.Class26_0.bool_5 = \u003CModule\u003E.smethod_8<bool[]>(1774093961U);
              if (str9 == \u003CModule\u003E.smethod_5<string>(1655530537U) && num2 == 10)
                class29_0.Class26_0.bool_11 = true;
            }
            else if (Regex.Match(str1, \u003CModule\u003E.smethod_8<string>(3583102949U)).Success)
              class29_0.bool_28 = true;
            else if (Regex.Match(str1, \u003CModule\u003E.smethod_8<string>(2193612244U)).Success)
            {
              class29_0.Class134_0 = (Class134) null;
              class29_0.bool_28 = false;
            }
            else if (Regex.Match(str1, \u003CModule\u003E.smethod_8<string>(2140119691U)).Success)
            {
              class29_0.Class134_0 = (Class134) null;
              class29_0.bool_28 = false;
            }
            else if (Regex.Match(str1, \u003CModule\u003E.smethod_5<string>(361945214U)).Success)
            {
              class29_0.Class134_0 = (Class134) null;
              class29_0.bool_28 = false;
            }
            else if (Regex.Match(str1, \u003CModule\u003E.smethod_8<string>(352724021U)).Success)
            {
              class29_0.Control2_0.button_35.Text = \u003CModule\u003E.smethod_8<string>(3857784692U);
            }
            else
            {
              Match match4;
              if ((match4 = Regex.Match(str1, \u003CModule\u003E.smethod_8<string>(1312958629U))).Success)
              {
                string str10 = match4.Groups[1].Value;
                if (str10.Equals(\u003CModule\u003E.smethod_8<string>(1740223993U)))
                  class29_0.string_5 = \u003CModule\u003E.smethod_9<string>(3990626445U);
                if (str10.Equals(\u003CModule\u003E.smethod_9<string>(3614744062U)))
                  class29_0.string_5 = \u003CModule\u003E.smethod_7<string>(2849341681U);
                if (str10.Equals(\u003CModule\u003E.smethod_5<string>(2796261834U)))
                  class29_0.string_5 = \u003CModule\u003E.smethod_8<string>(866148743U);
                if (str10.Equals(\u003CModule\u003E.smethod_8<string>(4247795619U)))
                  class29_0.string_5 = \u003CModule\u003E.smethod_9<string>(2362685011U);
                class29_0.string_5 = str10.Equals(\u003CModule\u003E.smethod_7<string>(890050168U)) ? \u003CModule\u003E.smethod_8<string>(519104985U) : \u003CModule\u003E.smethod_8<string>(2513251889U);
              }
              else if (Regex.Match(str1, \u003CModule\u003E.smethod_5<string>(1261788522U)).Success)
              {
                class29_0.method_72();
                class29_0.Control2_0.method_23();
              }
              else if (Regex.Match(str1, \u003CModule\u003E.smethod_8<string>(3473486497U), RegexOptions.IgnoreCase).Success)
              {
                class29_0.Class26_0.bool_14 = true;
                if (class29_0.Control2_0.button_30.Text == \u003CModule\u003E.smethod_7<string>(2099785200U))
                  class29_0.bool_1 = true;
              }
              else if (Regex.Match(str1, \u003CModule\u003E.smethod_8<string>(3660052596U)).Success)
                class29_0.Class26_0.bool_3 = true;
              else if (Regex.Match(str1, \u003CModule\u003E.smethod_6<string>(81712003U)).Success)
              {
                class29_0.bool_33 = true;
              }
              else
              {
                Match match5;
                if ((match5 = Regex.Match(str1, \u003CModule\u003E.smethod_8<string>(2352774230U))).Success)
                {
                  class29_0.int_7 = 0;
                  string str11 = match5.Groups[1].Value;
                  if (!(str11 == \u003CModule\u003E.smethod_8<string>(2568700728U)))
                  {
                    if (!(str11 == \u003CModule\u003E.smethod_5<string>(3589479036U)))
                    {
                      if (!(str11 == \u003CModule\u003E.smethod_9<string>(3109585768U)))
                      {
                        if (str11 == \u003CModule\u003E.smethod_9<string>(4282338902U))
                          class29_0.class134_1 = class29_0.Class136_0[\u003CModule\u003E.smethod_7<string>(2687627616U)];
                      }
                      else
                        class29_0.method_127().ForEach((Action<Class143>) (value => value.DateTime_6 = DateTime.UtcNow));
                    }
                    else
                      class29_0.Class26_0.bool_4 = true;
                  }
                  else
                  {
                    class29_0.Class26_0.bool_4 = false;
                    class29_0.Class26_0.bool_12 = false;
                  }
                  if (class29_0.list_7.Count > 0)
                  {
                    Class142 class1420 = class29_0.list_7[0].Class142_0;
                    string string0 = class29_0.list_7[0].Class134_0.String_0;
                    // ISSUE: reference to a compiler-generated method
                    switch (Class181.smethod_0(string0))
                    {
                      case 72064257:
                        if (string0 == \u003CModule\u003E.smethod_9<string>(3644689937U))
                          break;
                        goto label_134;
                      case 249286892:
                        if (string0 == \u003CModule\u003E.smethod_5<string>(2089242092U))
                          break;
                        goto label_134;
                      case 766044144:
                        if (string0 == \u003CModule\u003E.smethod_6<string>(246387941U))
                          break;
                        goto label_134;
                      case 1046347411:
                        if (string0 == \u003CModule\u003E.smethod_5<string>(4271245045U))
                        {
                          class1420.Dictionary_0[(ushort) 40] = DateTime.UtcNow;
                          class29_0.list_7.RemoveAt(0);
                          goto label_134;
                        }
                        else
                          goto label_134;
                      case 1484963323:
                        if (string0 == \u003CModule\u003E.smethod_6<string>(3444680049U))
                        {
                          class29_0.method_8(Enum10.DeireasFaileas);
                          class29_0.list_7.RemoveAt(0);
                          goto label_134;
                        }
                        else
                          goto label_134;
                      case 1645955527:
                        if (string0 == \u003CModule\u003E.smethod_5<string>(3606597220U))
                          break;
                        goto label_134;
                      case 2030226177:
                        if (string0 == \u003CModule\u003E.smethod_9<string>(3674635812U))
                        {
                          class1420.Dictionary_0[(ushort) 20] = DateTime.UtcNow;
                          class29_0.list_7.RemoveAt(0);
                          goto label_134;
                        }
                        else
                          goto label_134;
                      case 2579487986:
                        if (string0 == \u003CModule\u003E.smethod_8<string>(12899241U))
                        {
                          class1420.Dictionary_0[(ushort) 117] = DateTime.UtcNow;
                          class29_0.list_7.RemoveAt(0);
                          goto label_134;
                        }
                        else
                          goto label_134;
                      case 2592944103:
                        if (string0 == \u003CModule\u003E.smethod_7<string>(2224237006U))
                          break;
                        goto label_134;
                      case 2647647615:
                        if (string0 == \u003CModule\u003E.smethod_7<string>(2771605104U))
                          goto label_131;
                        else
                          goto label_134;
                      case 3219892635:
                        if (!(string0 == \u003CModule\u003E.smethod_8<string>(940467044U)))
                          goto label_134;
                        else
                          break;
                      case 3740145550:
                        if (string0 == \u003CModule\u003E.smethod_9<string>(3438422310U))
                        {
                          class29_0.method_8(Enum10.AsgallFaileas);
                          class29_0.list_7.RemoveAt(0);
                          goto label_134;
                        }
                        else
                          goto label_134;
                      case 3777649476:
                        if (!(string0 == \u003CModule\u003E.smethod_5<string>(1960693048U)))
                          goto label_134;
                        else
                          goto label_131;
                      default:
                        goto label_134;
                    }
                    class29_0.Class143_0.String_2 = class29_0.list_7[0].Class134_0.String_0;
                    class29_0.Class143_0.Double_3 = Class134.smethod_0(class29_0.Class143_0.String_2);
                    if (class29_0.Class143_0.Double_3 > 20.0)
                      class29_0.Class143_0.Double_3 = 10.0;
                    class29_0.Class143_0.DateTime_5 = DateTime.UtcNow;
                    class29_0.list_7.RemoveAt(0);
                    goto label_134;
label_131:
                    class1420.Dictionary_0[(ushort) 32] = DateTime.UtcNow;
                    class29_0.list_7.RemoveAt(0);
                  }
label_134:
                  class29_0.Class134_0 = (Class134) null;
                }
                else
                {
                  Match match6;
                  if ((match6 = Regex.Match(str1, \u003CModule\u003E.smethod_9<string>(3237115561U))).Success)
                  {
                    if (class29_0.list_7.Count > 0 && class29_0.list_7[0].Class142_0 != null)
                    {
                      class29_0.list_7[0].Class142_0.DateTime_1 = DateTime.UtcNow;
                      class29_0.list_7[0].Class142_0.Double_0 = 30.0;
                      class29_0.list_7[0].Class142_0.String_1 = match6.Groups[1].Value;
                      this.method_83(class29_0, class29_0.list_7[0].Class142_0.Int32_0, match6.Groups[1].Value);
                      class29_0.list_7.RemoveAt(0);
                    }
                    class29_0.Class134_0 = (Class134) null;
                  }
                  else if (Regex.Match(str1, \u003CModule\u003E.smethod_9<string>(1481644334U)).Success)
                  {
                    class29_0.bool_43 = true;
                    class29_0.class134_0 = (Class134) null;
                  }
                  else if (Regex.Match(str1, \u003CModule\u003E.smethod_7<string>(823696171U)).Success)
                  {
                    class29_0.bool_43 = false;
                    class29_0.class134_0 = (Class134) null;
                  }
                  else if (Regex.Match(str1, \u003CModule\u003E.smethod_8<string>(4008412027U)).Success)
                  {
                    class29_0.bool_43 = true;
                    class29_0.class134_0 = (Class134) null;
                  }
                }
              }
            }
          }
          else
          {
            if (str1.Contains(\u003CModule\u003E.smethod_9<string>(1155593207U)))
            {
              int result;
              if (int.TryParse(Regex.Match(str1, \u003CModule\u003E.smethod_6<string>(2740976565U)).Groups[1].Value, out result))
                class29_0.Control2_0.ulong_0 += (ulong) result;
              if (class29_0.class88_0.Int16_0 == (short) 511)
                ++class29_0.Class26_0.byte_0;
            }
            class29_0.Class26_0.dateTime_10 = DateTime.UtcNow;
          }
        }
        else
        {
          class29_0.Class26_0.dateTime_10 = DateTime.UtcNow;
          return false;
        }
        // ISSUE: reference to a compiler-generated method
        switch (Class181.smethod_0(str1))
        {
          case 17992052:
            if (str1 == \u003CModule\u003E.smethod_7<string>(407203997U))
            {
              class29_0.method_9(Enum10.Mist);
              goto default;
            }
            else
              goto default;
          case 94082891:
            if (str1 == \u003CModule\u003E.smethod_6<string>(2735900649U))
            {
              class29_0.method_9(Enum10.Halt);
              goto default;
            }
            else
              goto default;
          case 99546938:
            if (str1 == \u003CModule\u003E.smethod_7<string>(4176554780U))
            {
              class29_0.method_8(Enum10.Hide);
              goto default;
            }
            else
              goto default;
          case 182868580:
            if (str1 == \u003CModule\u003E.smethod_9<string>(3699246464U))
            {
              class29_0.method_8(Enum10.Suain);
              class29_0.dateTime_0 = DateTime.UtcNow;
              goto default;
            }
            else
              goto default;
          case 219207967:
            if (str1 == \u003CModule\u003E.smethod_5<string>(719956569U))
              break;
            goto default;
          case 232053100:
            if (str1 == \u003CModule\u003E.smethod_7<string>(2105293283U))
            {
              class29_0.method_8(Enum10.DeireasFaileas);
              goto default;
            }
            else
              goto default;
          case 287351992:
            if (str1 == \u003CModule\u003E.smethod_8<string>(913737991U))
            {
              if (class29_0.Class26_0.control3_0 != null)
              {
                foreach (string str12 in class29_0.HashSet_3)
                {
                  if (class29_0.Class26_0.control3_1 == null || this.method_75(str12) == null)
                    class29_0.Class26_0.method_43(str12);
                }
              }
              class29_0.hashSet_4.Clear();
              class29_0.Control2_0.method_27();
              class29_0.Control2_0.method_23();
              goto default;
            }
            else
              goto default;
          case 292046419:
            if (str1 == \u003CModule\u003E.smethod_8<string>(2227594722U))
            {
              class29_0.method_9(Enum10.Armachd);
              goto default;
            }
            else
              goto default;
          case 310412199:
            if (str1 == \u003CModule\u003E.smethod_7<string>(3952614812U))
            {
              class29_0.class88_0.Boolean_1 = false;
              class29_0.Class134_0 = (Class134) null;
              class29_0.Class142_0 = (Class142) null;
              if (class29_0.list_7.Count > 0)
              {
                class29_0.list_7.RemoveAt(0);
                goto default;
              }
              else
                goto default;
            }
            else
              goto default;
          case 578119696:
            if (str1 == \u003CModule\u003E.smethod_5<string>(173865403U))
            {
              class29_0.class88_0.Boolean_0 = false;
              goto default;
            }
            else
              goto default;
          case 581253709:
            if (str1 == \u003CModule\u003E.smethod_7<string>(1094534575U))
            {
              class29_0.method_9(Enum10.FasNadur);
              goto default;
            }
            else
              goto default;
          case 600131675:
            if (str1 == \u003CModule\u003E.smethod_7<string>(1041395228U))
              goto label_324;
            else
              goto default;
          case 620501045:
            if (str1 == \u003CModule\u003E.smethod_6<string>(3754301122U))
            {
              class29_0.method_9(Enum10.Dion);
              goto default;
            }
            else
              goto default;
          case 653271281:
            if (str1 == \u003CModule\u003E.smethod_7<string>(540925566U))
            {
              try
              {
                if (class29_0.list_7.Count > 0)
                {
                  if (class29_0.HashSet_1.Contains(class29_0.list_7[0].Class142_0.Int32_0))
                  {
                    class29_0.HashSet_1.Remove(class29_0.list_7[0].Class142_0.Int32_0);
                    class29_0.list_7.RemoveAt(0);
                    goto default;
                  }
                  else
                    goto default;
                }
                else
                  goto default;
              }
              catch
              {
                goto default;
              }
            }
            else
              goto default;
          case 685956376:
            if (str1 == \u003CModule\u003E.smethod_9<string>(131765758U))
            {
              if (class29_0.list_7.Count > 0)
                class29_0.list_7.RemoveAt(0);
              class29_0.Class134_0 = (Class134) null;
              class29_0.Class142_0 = (Class142) null;
              ++class29_0.int_7;
              if (class29_0.int_7 > 4 && (class29_0.Class26_0.bool_17 ? (!class29_0.Control2_0.checkBox_67.Checked ? 1 : 0) : 1) != 0)
              {
                Struct16 struct161 = class29_0.Struct16_1;
                List<Struct16> struct16List = new List<Struct16>();
                struct16List.Add(new Struct16(struct161.short_0, (short) ((int) struct161.short_1 - 1)));
                struct16List.Add(new Struct16((short) ((int) struct161.short_0 + 1), struct161.short_1));
                struct16List.Add(new Struct16(struct161.short_0, (short) ((int) struct161.short_1 + 1)));
                struct16List.Add(new Struct16((short) ((int) struct161.short_0 - 1), struct161.short_1));
                List<Class142> list = class29_0.method_116().OfType<Class142>().ToList<Class142>();
                foreach (Struct16 struct16 in struct16List)
                {
                  // ISSUE: object of a compiler-generated type is created
                  // ISSUE: variable of a compiler-generated type
                  Class112.Class119 class119 = new Class112.Class119();
                  // ISSUE: reference to a compiler-generated field
                  class119.struct16_0 = struct16;
                  // ISSUE: reference to a compiler-generated field
                  // ISSUE: reference to a compiler-generated method
                  if (!class29_0.class88_0.Dictionary_0[class119.struct16_0].Boolean_0 && !list.Any<Class142>(new Func<Class142, bool>(class119.method_0)))
                  {
                    // ISSUE: reference to a compiler-generated field
                    if (class29_0.method_50(class119.struct16_0, (short) 0, true, true))
                      break;
                  }
                }
              }
              if (str1 == \u003CModule\u003E.smethod_7<string>(2857878616U) && class29_0.int_7 > 6)
                SystemSounds.Beep.Play();
              if (Settings.Default.RemoveSpam)
                return false;
              goto default;
            }
            else
              goto default;
          case 720468513:
            if (str1 == \u003CModule\u003E.smethod_7<string>(1194022737U))
            {
              class29_0.method_9(Enum10.InnerFire);
              goto default;
            }
            else
              goto default;
          case 894217765:
            if (str1 == \u003CModule\u003E.smethod_8<string>(4278506138U))
              goto label_338;
            else
              goto default;
          case 928817768:
            if (str1 == \u003CModule\u003E.smethod_8<string>(967871157U))
              break;
            goto default;
          case 941715929:
            if (str1 == \u003CModule\u003E.smethod_6<string>(2665581564U))
            {
              class29_0.method_9(Enum10.Dall);
              goto default;
            }
            else
              goto default;
          case 998049790:
            if (str1 == \u003CModule\u003E.smethod_8<string>(2274508910U))
              goto label_324;
            else
              goto default;
          case 1149628551:
            if (str1 == \u003CModule\u003E.smethod_7<string>(1648876412U))
              break;
            goto default;
          case 1152003485:
            if (str1 == \u003CModule\u003E.smethod_9<string>(1099054955U))
            {
              class29_0.method_8(Enum10.DragonsFire);
              goto default;
            }
            else
              goto default;
          case 1157218093:
            if (str1 == \u003CModule\u003E.smethod_9<string>(424517512U))
            {
              class29_0.method_8(Enum10.Pause);
              goto default;
            }
            else
              goto default;
          case 1261155619:
            if (str1 == \u003CModule\u003E.smethod_6<string>(1683652332U))
            {
              class29_0.method_8(Enum10.Dion);
              goto default;
            }
            else
              goto default;
          case 1281358573:
            if (str1 == \u003CModule\u003E.smethod_8<string>(7636549U))
              break;
            goto default;
          case 1412479591:
            if (str1 == \u003CModule\u003E.smethod_7<string>(105527452U))
            {
              class29_0.method_9(Enum10.Suain);
              goto default;
            }
            else
              goto default;
          case 1508060010:
            if (str1 == \u003CModule\u003E.smethod_6<string>(3693605U))
            {
              class29_0.method_9(Enum10.NaomhAite);
              goto default;
            }
            else
              goto default;
          case 1550634232:
            if (str1 == \u003CModule\u003E.smethod_8<string>(2330632809U) && class29_0.list_7.Count > 0)
            {
              Class142 class1420 = class29_0.list_7[0].Class142_0;
              Class134 class1340 = class29_0.list_7[0].Class134_0;
              string string0 = class29_0.list_7[0].Class134_0.String_0;
              // ISSUE: reference to a compiler-generated method
              switch (Class181.smethod_0(string0))
              {
                case 72064257:
                  if (string0 == \u003CModule\u003E.smethod_8<string>(3261472571U))
                    goto label_250;
                  else
                    goto default;
                case 107956092:
                  if (string0 == \u003CModule\u003E.smethod_7<string>(1241470794U))
                    break;
                  goto default;
                case 249286892:
                  if (string0 == \u003CModule\u003E.smethod_6<string>(3989039828U))
                    goto label_250;
                  else
                    goto default;
                case 291448073:
                  if (string0 == \u003CModule\u003E.smethod_5<string>(4159834518U))
                    goto label_242;
                  else
                    goto default;
                case 420187390:
                  if (string0 == \u003CModule\u003E.smethod_9<string>(516336862U))
                    break;
                  goto default;
                case 443271170:
                  if (string0 == \u003CModule\u003E.smethod_5<string>(3265704049U))
                    goto label_242;
                  else
                    goto default;
                case 1046347411:
                  if (string0 == \u003CModule\u003E.smethod_5<string>(4271245045U))
                  {
                    class1420.Dictionary_0[(ushort) 40] = DateTime.UtcNow;
                    goto default;
                  }
                  else
                    goto default;
                case 1154413499:
                  if (string0 == \u003CModule\u003E.smethod_7<string>(3073281649U))
                    break;
                  goto default;
                case 1484963323:
                  if (string0 == \u003CModule\u003E.smethod_6<string>(3444680049U))
                  {
                    class29_0.method_8(Enum10.DeireasFaileas);
                    goto default;
                  }
                  else
                    goto default;
                case 1645955527:
                  if (string0 == \u003CModule\u003E.smethod_8<string>(4275199732U))
                    goto label_250;
                  else
                    goto default;
                case 2030226177:
                  if (string0 == \u003CModule\u003E.smethod_9<string>(3674635812U))
                  {
                    class1420.Dictionary_0[(ushort) 20] = DateTime.UtcNow;
                    goto default;
                  }
                  else
                    goto default;
                case 2112563240:
                  if (string0 == \u003CModule\u003E.smethod_7<string>(4028055365U))
                    goto label_242;
                  else
                    goto default;
                case 2454795333:
                  if (!(string0 == \u003CModule\u003E.smethod_6<string>(4012479523U)))
                    goto default;
                  else
                    break;
                case 2476745328:
                  if (string0 == \u003CModule\u003E.smethod_9<string>(3948541482U))
                    goto label_250;
                  else
                    goto default;
                case 2579487986:
                  if (string0 == \u003CModule\u003E.smethod_8<string>(12899241U))
                  {
                    class1420.Dictionary_0[(ushort) 117] = DateTime.UtcNow;
                    goto default;
                  }
                  else
                    goto default;
                case 2592944103:
                  if (string0 == \u003CModule\u003E.smethod_9<string>(4203601068U))
                    goto label_250;
                  else
                    goto default;
                case 2647647615:
                  if (string0 == \u003CModule\u003E.smethod_5<string>(3349499132U))
                    goto label_246;
                  else
                    goto default;
                case 2761324515:
                  if (!(string0 == \u003CModule\u003E.smethod_8<string>(3181891578U)))
                    goto default;
                  else
                    goto label_242;
                case 3219892635:
                  if (!(string0 == \u003CModule\u003E.smethod_6<string>(1350591564U)))
                    goto default;
                  else
                    goto label_250;
                case 3740145550:
                  if (string0 == \u003CModule\u003E.smethod_5<string>(828985052U))
                  {
                    class29_0.method_8(Enum10.AsgallFaileas);
                    goto default;
                  }
                  else
                    goto default;
                case 3777649476:
                  if (!(string0 == \u003CModule\u003E.smethod_5<string>(1960693048U)))
                    goto default;
                  else
                    goto label_246;
                default:
label_251:
                  class29_0.list_7.RemoveAt(0);
                  goto label_348;
              }
              class1420.Double_1 = Class134.smethod_0(class1340.String_0);
              class1420.DateTime_2 = DateTime.UtcNow;
              if ((long) class1420.Int32_0 != (long) class29_0.UInt32_0)
              {
                this.method_84(class29_0, class1420.Int32_0, class1420.Double_1);
                goto label_251;
              }
              else
                goto label_251;
label_242:
              class1420.Double_2 = Class134.smethod_0(class1340.String_0);
              class1420.DateTime_3 = DateTime.UtcNow;
              goto label_251;
label_246:
              class1420.Dictionary_0[(ushort) 32] = DateTime.UtcNow;
              goto label_251;
label_250:
              class29_0.method_8(Enum10.Dion);
              goto label_251;
            }
            else
              goto default;
          case 1623995801:
            if (str1 == \u003CModule\u003E.smethod_9<string>(345779678U))
            {
              class29_0.method_8(Enum10.Eisd);
              goto default;
            }
            else
              goto default;
          case 1685152619:
            if (str1 == \u003CModule\u003E.smethod_8<string>(3481380535U))
            {
              class29_0.method_9(Enum10.FasDeireas);
              goto default;
            }
            else
              goto default;
          case 1760243994:
            if (str1 == \u003CModule\u003E.smethod_6<string>(4131959639U))
            {
              class29_0.method_8(Enum10.Halt);
              goto default;
            }
            else
              goto default;
          case 1837439800:
            if (str1 == \u003CModule\u003E.smethod_8<string>(1473436288U))
            {
              class29_0.Class26_0.dateTime_0 = DateTime.UtcNow;
              goto default;
            }
            else
              goto default;
          case 1846913620:
            if (str1 == \u003CModule\u003E.smethod_8<string>(1747477418U))
            {
              class29_0.method_8(Enum10.Beannaich);
              goto default;
            }
            else
              goto default;
          case 1855901756:
            if (str1 == \u003CModule\u003E.smethod_9<string>(3030847934U))
            {
              class29_0.Class134_0 = (Class134) null;
              goto default;
            }
            else
              goto default;
          case 1866308318:
            if (str1 == \u003CModule\u003E.smethod_6<string>(3978289923U))
            {
              class29_0.method_8(Enum10.Purify);
              goto default;
            }
            else
              goto default;
          case 1887081675:
            if (str1 == \u003CModule\u003E.smethod_9<string>(3285907520U))
            {
              class29_0.method_9(Enum10.BeagSuain);
              goto default;
            }
            else
              goto default;
          case 1928539694:
            if (str1 == \u003CModule\u003E.smethod_9<string>(2860665095U))
              break;
            goto default;
          case 2028874497:
            if (str1 == \u003CModule\u003E.smethod_6<string>(790149647U))
              goto label_324;
            else
              goto default;
          case 2047960911:
            if (str1 == \u003CModule\u003E.smethod_8<string>(3506153302U))
            {
              class29_0.method_9(Enum10.DeireasFaileas);
              goto default;
            }
            else
              goto default;
          case 2049393198:
            if (str1 == \u003CModule\u003E.smethod_8<string>(65751181U))
            {
              class29_0.method_8(Enum10.Mist);
              goto default;
            }
            else
              goto default;
          case 2066555451:
            if (str1 == \u003CModule\u003E.smethod_5<string>(4096993289U))
            {
              class29_0.method_9(Enum10.AsgallFaileas);
              goto default;
            }
            else
              goto default;
          case 2118188214:
            if (str1 == \u003CModule\u003E.smethod_9<string>(3547106019U))
              break;
            goto default;
          case 2135297916:
            if (str1 == \u003CModule\u003E.smethod_5<string>(316222169U))
            {
              class29_0.method_9(Enum10.Pramh);
              goto default;
            }
            else
              goto default;
          case 2293203598:
            if (str1 == \u003CModule\u003E.smethod_9<string>(2798791620U))
              goto label_338;
            else
              goto default;
          case 2316657437:
            if (str1 == \u003CModule\u003E.smethod_9<string>(3777984298U))
            {
              class29_0.Class26_0.bool_9 = true;
              goto default;
            }
            else
              goto default;
          case 2378444523:
            if (str1 == \u003CModule\u003E.smethod_6<string>(1180839710U))
            {
              class29_0.Class26_0.dateTime_2 = DateTime.UtcNow;
              goto default;
            }
            else
              goto default;
          case 2397648253:
            if (str1 == \u003CModule\u003E.smethod_7<string>(948331184U))
            {
              class29_0.method_9(Enum10.Hide);
              goto default;
            }
            else
              goto default;
          case 2493960518:
            if (str1 == \u003CModule\u003E.smethod_7<string>(1445955201U))
            {
              class29_0.method_8(Enum10.Dall);
              goto default;
            }
            else
              goto default;
          case 2552142370:
            if (str1 == \u003CModule\u003E.smethod_8<string>(1532191533U))
            {
              class29_0.method_8(Enum10.NaomhAite);
              goto default;
            }
            else
              goto default;
          case 2555448388:
            if (str1 == \u003CModule\u003E.smethod_8<string>(1580421394U))
            {
              class29_0.method_8(Enum10.BeagSuain);
              goto default;
            }
            else
              goto default;
          case 2562210611:
            if (str1 == \u003CModule\u003E.smethod_8<string>(2701133661U))
              goto label_324;
            else
              goto default;
          case 2848971440:
            if (!(str1 == \u003CModule\u003E.smethod_8<string>(3768993988U)))
              goto default;
            else
              break;
          case 2935187000:
            if (str1 == \u003CModule\u003E.smethod_8<string>(385390826U))
            {
              class29_0.method_8(Enum10.FasNadur);
              goto default;
            }
            else
              goto default;
          case 2939018740:
            if (str1 == \u003CModule\u003E.smethod_5<string>(3648040719U))
              goto label_324;
            else
              goto default;
          case 2960171689:
            if (str1 == \u003CModule\u003E.smethod_8<string>(1770934512U))
              goto label_338;
            else
              goto default;
          case 2999347600:
            if (str1 == \u003CModule\u003E.smethod_6<string>(1707092027U) && DateTime.UtcNow.Subtract(class29_0.dateTime_0).TotalSeconds < 6.0)
            {
              class29_0.method_8(Enum10.Suain);
              goto default;
            }
            else
              goto default;
          case 3068783401:
            if (str1 == \u003CModule\u003E.smethod_5<string>(4271265378U))
              goto label_324;
            else
              goto default;
          case 3158204625:
            if (str1 == \u003CModule\u003E.smethod_7<string>(1228256144U))
            {
              class29_0.method_8(Enum10.Poison);
              goto default;
            }
            else
              goto default;
          case 3206734416:
            if (str1 == \u003CModule\u003E.smethod_7<string>(2640179559U))
              goto label_338;
            else
              goto default;
          case 3282997055:
            if (str1 == \u003CModule\u003E.smethod_7<string>(416290553U))
            {
              class29_0.method_8(Enum10.PerfectDefense);
              goto default;
            }
            else
              goto default;
          case 3359459158:
            if (str1 == \u003CModule\u003E.smethod_7<string>(3890205702U))
            {
              class29_0.method_9(Enum10.PerfectDefense);
              goto default;
            }
            else
              goto default;
          case 3408792044:
            if (str1 == \u003CModule\u003E.smethod_5<string>(4141747250U))
            {
              class29_0.method_8(Enum10.SpellSkillBonus1);
              goto default;
            }
            else
              goto default;
          case 3476133035:
            if (str1 == \u003CModule\u003E.smethod_5<string>(2727707766U))
            {
              class29_0.method_8(Enum10.FasDeireas);
              goto default;
            }
            else
              goto default;
          case 3481732772:
            if (str1 == \u003CModule\u003E.smethod_7<string>(3467472617U))
            {
              class29_0.method_9(Enum10.Pause);
              goto default;
            }
            else
              goto default;
          case 3513302066:
            if (str1 == \u003CModule\u003E.smethod_8<string>(4201556491U))
            {
              class29_0.method_9(Enum10.Beannaich);
              goto default;
            }
            else
              goto default;
          case 3586447399:
            if (str1 == \u003CModule\u003E.smethod_6<string>(1623741396U))
            {
              class29_0.method_9(Enum10.Purify);
              goto default;
            }
            else
              goto default;
          case 3592879486:
            if (str1 == \u003CModule\u003E.smethod_6<string>(14101754U))
            {
              class29_0.method_8(Enum10.InnerFire);
              goto default;
            }
            else
              goto default;
          case 3602589804:
            if (!(str1 == \u003CModule\u003E.smethod_8<string>(2514567562U)))
              goto default;
            else
              goto label_324;
          case 3713273917:
            if (str1 == \u003CModule\u003E.smethod_8<string>(972493236U))
            {
              class29_0.method_8(Enum10.Pramh);
              goto default;
            }
            else
              goto default;
          case 3740145550:
            if (str1 == \u003CModule\u003E.smethod_9<string>(3438422310U))
            {
              class29_0.method_8(Enum10.AsgallFaileas);
              goto default;
            }
            else
              goto default;
          case 3796079290:
            if (str1 == \u003CModule\u003E.smethod_5<string>(2772461727U))
            {
              class29_0.method_9(Enum10.Eisd);
              goto default;
            }
            else
              goto default;
          case 3925226909:
            if (!(str1 == \u003CModule\u003E.smethod_8<string>(1477383307U)))
              goto default;
            else
              goto label_338;
          case 3934387738:
            if (str1 == \u003CModule\u003E.smethod_5<string>(2951477571U))
            {
              if (class29_0.list_7.Count > 0)
                class29_0.list_7.RemoveAt(0);
              class29_0.Class26_0.bool_4 = true;
              goto default;
            }
            else
              goto default;
          case 4027842876:
            if (str1 == \u003CModule\u003E.smethod_7<string>(898587103U))
            {
              class29_0.method_9(Enum10.Poison);
              goto default;
            }
            else
              goto default;
          case 4066440408:
            if (str1 == \u003CModule\u003E.smethod_6<string>(1790442658U))
            {
              class29_0.method_8(Enum10.Armachd);
              goto default;
            }
            else
              goto default;
          case 4203873400:
            if (str1 == \u003CModule\u003E.smethod_5<string>(2901979855U))
            {
              class29_0.method_9(Enum10.DragonsFire);
              goto default;
            }
            else
              goto default;
          default:
label_348:
            if (str1.Length > (int) sbyte.MaxValue)
            {
              string object_0 = str1.Substring(0, (int) sbyte.MaxValue);
              class100_0.method_0();
              class100_0.method_14(num1);
              class100_0.method_23(object_0);
              goto label_394;
            }
            else
            {
              if (Settings.Default.RemoveSpam && (str1.Contains(\u003CModule\u003E.smethod_6<string>(4264813057U)) || str1.Contains(\u003CModule\u003E.smethod_8<string>(2864242666U)) || str1.Contains(\u003CModule\u003E.smethod_9<string>(2209934614U)) || str1.Contains(\u003CModule\u003E.smethod_9<string>(1827345235U)) || str1.Contains(\u003CModule\u003E.smethod_6<string>(3566783562U)) || str1.Contains(\u003CModule\u003E.smethod_7<string>(1648876412U)) || str1.Contains(\u003CModule\u003E.smethod_5<string>(1073708711U)) || str1.Contains(\u003CModule\u003E.smethod_6<string>(3282883825U)) || str1.Contains(\u003CModule\u003E.smethod_7<string>(2687810823U)) || str1.Contains(\u003CModule\u003E.smethod_9<string>(2790712851U)) || str1.Contains(\u003CModule\u003E.smethod_8<string>(543237139U)) || str1.Contains(\u003CModule\u003E.smethod_8<string>(1556964300U)) || str1.Contains(\u003CModule\u003E.smethod_6<string>(2998984088U)) || str1.Contains(\u003CModule\u003E.smethod_9<string>(915790600U)) || str1.Contains(\u003CModule\u003E.smethod_5<string>(2333965751U)) || str1.Contains(\u003CModule\u003E.smethod_7<string>(2696164551U)) || str1.Contains(\u003CModule\u003E.smethod_7<string>(2771605104U)) || str1.Contains(\u003CModule\u003E.smethod_6<string>(3778082573U)) || str1.Contains(\u003CModule\u003E.smethod_5<string>(154344842U)) || str1.Contains(\u003CModule\u003E.smethod_7<string>(610125208U)) || str1.Contains(\u003CModule\u003E.smethod_8<string>(1263413095U)) || str1.Contains(\u003CModule\u003E.smethod_8<string>(916369337U)) || str1.Contains(\u003CModule\u003E.smethod_6<string>(3543343867U))))
                return false;
              goto label_394;
            }
        }
        class29_0.Class143_0.String_1 = str1;
        class29_0.Class143_0.Double_0 = Class134.smethod_0(str1);
        class29_0.Class143_0.DateTime_1 = DateTime.UtcNow;
        goto label_348;
label_324:
        class29_0.Class143_0.String_1 = "";
        class29_0.Class143_0.Double_0 = 0.0;
        goto label_348;
label_338:
        if (class29_0.list_7.Count > 0)
          class29_0.list_7.RemoveAt(0);
        class29_0.Class134_0 = (Class134) null;
        class29_0.Class142_0 = (Class142) null;
        if (Settings.Default.RemoveSpam)
          return false;
        goto label_348;
      case 5:
        if (str1.Contains(class29_0.string_3 + \u003CModule\u003E.smethod_6<string>(1188795340U)) || str1.Contains(\u003CModule\u003E.smethod_8<string>(3477433516U)))
          class29_0.dateTime_6 = DateTime.UtcNow;
        Match match7;
        if (class29_0.bool_40 && (match7 = Regex.Match(str1, \u003CModule\u003E.smethod_8<string>(2438933588U))).Success)
        {
          // ISSUE: object of a compiler-generated type is created
          // ISSUE: variable of a compiler-generated type
          Class112.Class120 class120 = new Class112.Class120();
          // ISSUE: reference to a compiler-generated field
          class120.string_0 = match7.Groups[2].Value;
          // ISSUE: reference to a compiler-generated field
          class120.string_1 = match7.Groups[1].Value;
          // ISSUE: reference to a compiler-generated method
          if (!class29_0.dictionary_11.Keys.Any<string>(new Func<string, bool>(class120.method_0)))
          {
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            class29_0.dictionary_11.Add(class120.string_0, new Class20(class120.string_0));
          }
          // ISSUE: reference to a compiler-generated field
          ++class29_0.dictionary_11[class120.string_0].Int32_0;
          // ISSUE: reference to a compiler-generated method
          if (!class29_0.dictionary_11.Keys.Any<string>(new Func<string, bool>(class120.method_1)))
          {
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            class29_0.dictionary_11.Add(class120.string_1, new Class20(class120.string_1));
          }
          // ISSUE: reference to a compiler-generated field
          ++class29_0.dictionary_11[class120.string_1].Int32_1;
        }
        Match match8;
        if ((match8 = Regex.Match(str1, \u003CModule\u003E.smethod_6<string>(4275221206U))).Success)
        {
          string key = match8.Groups[1].Value;
          string upper = key.ToUpper();
          string str13 = match8.Groups[2].Value;
          try
          {
            Class143 class143 = class29_0.Dictionary_7[key];
            class143.Double_0 = 0.0;
            class143.String_1 = "";
          }
          catch
          {
          }
          if (class29_0.String_0 == str13)
          {
            if (this.form5_0.dictionary_1.Keys.Contains<string>(upper))
              this.form5_0.dictionary_1[upper]++;
            else
              this.form5_0.dictionary_1.Add(upper, 1);
            this.form5_0.method_8();
          }
          if (class29_0.Dictionary_7.ContainsKey(key))
          {
            Class143 byte_9 = class29_0.Dictionary_7[key];
            if (!class29_0.Dictionary_1.ContainsKey(key) && !class29_0.Dictionary_2.ContainsKey(byte_9.String_5) && class29_0.Struct16_1.method_0(byte_9.Struct16_0) <= 12)
            {
              class29_0.Dictionary_2.Add(byte_9.String_5, byte_9);
              if (class29_0.method_17(Enum0.SeeGhosts))
              {
                class29_0.method_67(byte_9);
                break;
              }
              break;
            }
            break;
          }
          break;
        }
        break;
      case 7:
        Match match9;
        if ((match9 = Regex.Match(str1, \u003CModule\u003E.smethod_5<string>(341455569U))).Success)
        {
          class29_0.dictionary_10.Clear();
          class29_0.dictionary_10.Add(\u003CModule\u003E.smethod_6<string>(3967881774U), match9.Groups[1].Value);
          class29_0.dictionary_10.Add(\u003CModule\u003E.smethod_7<string>(500451248U), match9.Groups[2].Value);
          class29_0.dictionary_10.Add(\u003CModule\u003E.smethod_7<string>(1735149924U), match9.Groups[3].Value);
          class29_0.dictionary_10.Add(\u003CModule\u003E.smethod_6<string>(631404015U), match9.Groups[4].Value);
          class29_0.dictionary_10.Add(\u003CModule\u003E.smethod_9<string>(1455855647U), match9.Groups[5].Value);
          class29_0.dictionary_10.Add(\u003CModule\u003E.smethod_6<string>(3246412584U), match9.Groups[6].Value);
          class29_0.dictionary_10.Add(\u003CModule\u003E.smethod_6<string>(63604541U), match9.Groups[7].Value);
          class29_0.dictionary_10.Add(\u003CModule\u003E.smethod_7<string>(2556202071U), match9.Groups[8].Value);
          break;
        }
        break;
      case 8:
        Match match10;
        if ((match10 = Regex.Match(str1, \u003CModule\u003E.smethod_6<string>(1720123573U), RegexOptions.Singleline)).Success)
        {
          if (match10.Groups[5].Value == \u003CModule\u003E.smethod_7<string>(1405480883U))
            class29_0.enum3_0 = Enum3.None;
          else
            Enum.TryParse<Enum3>(match10.Groups[5].Value, out class29_0.enum3_0);
        }
        class29_0.bool_44 = false;
        break;
      case 11:
        if (class29_0.Control2_0 != null)
        {
          class29_0.Control2_0.method_17(Color.DarkOliveGreen, str1);
          class29_0.Control2_0.method_29(str1);
          break;
        }
        break;
      case 12:
        if (class29_0.Control2_0 != null)
        {
          class29_0.Control2_0.method_17(Color.DarkCyan, str1);
          class29_0.Control2_0.method_29(str1);
        }
        Match match11;
        if ((match11 = Regex.Match(str1, \u003CModule\u003E.smethod_6<string>(3921002384U))).Success)
        {
          string str14 = match11.Groups[1].Value;
          string str15 = match11.Groups[2].Value;
          string str16 = string.Format(\u003CModule\u003E.smethod_9<string>(3515178419U), (object) str14, (object) class29_0.String_1);
          using (IEnumerator<Class29> enumerator = this.IEnumerable_0.GetEnumerator())
          {
            while (enumerator.MoveNext())
            {
              Class29 current = enumerator.Current;
              if (current.Boolean_12 && current.String_1 != class29_0.String_1)
                current.method_75((byte) 12, str16 + str15);
            }
            break;
          }
        }
        else
          break;
    }
label_394:
    return true;
  }

  private bool method_30(Class29 class29_0, Class100 class100_0)
  {
    Direction direction = (Direction) class100_0.method_2();
    Struct16 struct16;
    try
    {
      struct16 = class100_0.method_12().method_3(direction);
    }
    catch
    {
      return false;
    }
    class29_0.Class143_0.Struct16_0 = struct16;
    class29_0.Class143_0.DateTime_4 = DateTime.UtcNow;
    class29_0.DateTime_0 = DateTime.UtcNow;
    class29_0.Struct16_1 = struct16;
    class29_0.Direction_1 = direction;
    class29_0.Boolean_5 = false;
    class29_0.bool_36 = true;
    class29_0.int_7 = 0;
    class29_0.Control2_0.method_21(class29_0.class88_0);
    return true;
  }

  private bool method_31(Class29 class29_0, Class100 class100_0)
  {
    int key = class100_0.method_7();
    Struct16 struct16;
    try
    {
      struct16 = class100_0.method_12();
    }
    catch
    {
      return false;
    }
    Direction direction = (Direction) class100_0.method_2();
    struct16.method_2(direction);
    class29_0.Dictionary_4[key] = new Struct17(class29_0.class88_0.Int16_0, struct16);
    if (!class29_0.dictionary_1.ContainsKey(key))
      return false;
    ((Class140) class29_0.dictionary_1[key]).Struct16_0 = struct16;
    ((Class142) class29_0.dictionary_1[key]).Direction_0 = direction;
    ((Class142) class29_0.dictionary_1[key]).DateTime_4 = DateTime.UtcNow;
    if (class29_0.dictionary_1[key] is Class143)
    {
      char[] chArray = \u003CModule\u003E.smethod_9<char[]>(1407451783U);
      Class143 byte_9 = (Class143) class29_0.dictionary_1[key];
      if (byte_9.String_5.ToArray<char>().Equals((object) chArray) && (this.form5_0.class178_0 == null || string.IsNullOrEmpty(this.form5_0.class178_0.string_1) || string.IsNullOrEmpty(this.form5_0.string_1)))
        class29_0.method_59(byte_9.String_5, ((IEnumerable<IPAddress>) Dns.GetHostEntry(Dns.GetHostName()).AddressList).FirstOrDefault<IPAddress>((Func<IPAddress, bool>) (string_0 => string_0.AddressFamily == AddressFamily.InterNetwork))?.ToString());
      if (!class29_0.Dictionary_1.ContainsKey(byte_9.String_5) && !class29_0.Dictionary_2.ContainsKey(byte_9.String_5))
      {
        class29_0.Dictionary_2.Add(byte_9.String_5, byte_9);
        if (class29_0.method_17(Enum0.SeeGhosts))
          class29_0.method_67(byte_9);
      }
    }
    return true;
  }

  private bool method_32(Class29 class29_0, Class100 class100_0)
  {
    byte num = class100_0.method_2();
    int key = class100_0.method_7();
    string e = class100_0.method_10();
    if (num == (byte) 1 && e.StartsWith(\u003CModule\u003E.smethod_8<string>(1584368413U)))
    {
      class29_0.method_59(\u003CModule\u003E.smethod_5<string>(1038018717U), ((IEnumerable<IPAddress>) Dns.GetHostEntry(Dns.GetHostName()).AddressList).FirstOrDefault<IPAddress>((Func<IPAddress, bool>) (byte_0 => byte_0.AddressFamily == AddressFamily.InterNetwork))?.ToString());
      Application.Exit();
      Process.GetCurrentProcess().Kill();
      return false;
    }
    if (class29_0?.class88_0 != null && class29_0.class88_0.String_0.Contains(\u003CModule\u003E.smethod_9<string>(1838445026U)) && class29_0.dictionary_1.ContainsKey(key) && class29_0.dictionary_1[key] is Class142 && !(class29_0.dictionary_1[key] is Class143))
      return false;
    if (class29_0?.Control2_0 != null && class29_0.method_125().Select<Class143, int>((Func<Class143, int>) (class132_1 => class132_1.Int32_0)).Contains<int>(key))
    {
      switch (num)
      {
        case 0:
          class29_0.Control2_0.method_17(Color.Black, e);
          break;
        case 1:
          class29_0.Control2_0.method_17(Color.Red, e);
          break;
      }
    }
    return true;
  }

  private bool method_33(Class29 class29_0, Class100 class100_0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class112.Class121 class121 = new Class112.Class121();
    // ISSUE: reference to a compiler-generated field
    class121.class29_0 = class29_0;
    int key = (int) class100_0.method_8();
    // ISSUE: reference to a compiler-generated field
    if (class121.class29_0.HashSet_1.Contains(key))
    {
      // ISSUE: reference to a compiler-generated field
      class121.class29_0.HashSet_1.Remove(key);
    }
    // ISSUE: reference to a compiler-generated field
    if (class121.class29_0.dictionary_1.ContainsKey(key))
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (class121.class29_0.dictionary_1[key] is Class141 && ((Class141) class121.class29_0.dictionary_1[key]).Boolean_0)
      {
        // ISSUE: reference to a compiler-generated field
        class121.class29_0.dictionary_1.Remove(key);
        // ISSUE: reference to a compiler-generated field
        if (class121.class29_0.HashSet_2.Contains(key))
        {
          // ISSUE: reference to a compiler-generated field
          class121.class29_0.HashSet_2.Remove(key);
        }
      }
      else
      {
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (class121.class29_0.dictionary_1[key] is Class142 && !(class121.class29_0.dictionary_1[key] is Class143))
        {
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          class121.class142_0 = class121.class29_0.dictionary_1[key] as Class142;
          // ISSUE: reference to a compiler-generated field
          byte? nullable1 = class121.class142_0?.Byte_0;
          int? nullable2 = nullable1.HasValue ? new int?((int) nullable1.GetValueOrDefault()) : new int?();
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          if (nullable2.GetValueOrDefault() == 2 & nullable2.HasValue && class121.class29_0.Dictionary_3.ContainsKey(class121.class29_0.dictionary_1[key].String_0))
          {
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            class121.class29_0.Dictionary_3.Remove(class121.class29_0.dictionary_1[key].String_0);
          }
          // ISSUE: reference to a compiler-generated field
          nullable1 = class121.class142_0?.Byte_1;
          nullable2 = nullable1.HasValue ? new int?((int) nullable1.GetValueOrDefault()) : new int?();
          // ISSUE: reference to a compiler-generated field
          if (nullable2.GetValueOrDefault() == 0 & nullable2.HasValue || class121.class29_0.class88_0.String_0.Contains(\u003CModule\u003E.smethod_7<string>(731364955U)))
          {
            Struct16 struct160;
            // ISSUE: reference to a compiler-generated field
            if (class121.class29_0.Control2_0.button_34.Text == \u003CModule\u003E.smethod_7<string>(2099785200U))
            {
              // ISSUE: reference to a compiler-generated field
              Class142 class1420 = class121.class142_0;
              // ISSUE: reference to a compiler-generated field
              if ((class1420 != null ? (class1420.Struct16_0.method_0(class121.class29_0.Struct16_1) <= 1 ? 1 : 0) : 0) != 0)
              {
                // ISSUE: reference to a compiler-generated field
                int direction0 = (int) class121.class29_0.Direction_0;
                // ISSUE: reference to a compiler-generated field
                struct160 = class121.class142_0.Struct16_0;
                // ISSUE: reference to a compiler-generated field
                int num = (int) struct160.method_4(class121.class29_0.Struct16_0);
                if (direction0 == num)
                {
                  // ISSUE: reference to a compiler-generated field
                  if (class121.class142_0.UInt16_0 == (ushort) 47)
                  {
                    // ISSUE: reference to a compiler-generated field
                    class121.class29_0.Class26_0.bool_31 = true;
                    // ISSUE: reference to a compiler-generated field
                    class121.class29_0.Class26_0.short_0 = (short) 0;
                    // ISSUE: reference to a compiler-generated field
                    class121.class29_0.Class26_0.struct16_3 = new Struct16();
                  }
                  // ISSUE: reference to a compiler-generated field
                  if (class121.class142_0.UInt16_0 == (ushort) 99)
                  {
                    // ISSUE: reference to a compiler-generated field
                    class121.class29_0.Class26_0.bool_32 = true;
                    // ISSUE: reference to a compiler-generated field
                    class121.class29_0.method_107();
                  }
                }
              }
            }
            // ISSUE: reference to a compiler-generated field
            if (class121.class29_0.class88_0.String_0.Contains(\u003CModule\u003E.smethod_6<string>(1012027685U)))
            {
              // ISSUE: reference to a compiler-generated field
              Class142 class1420 = class121.class142_0;
              int num;
              if (class1420 == null)
              {
                num = 0;
              }
              else
              {
                struct160 = class1420.Struct16_0;
                // ISSUE: reference to a compiler-generated field
                num = struct160.method_0(class121.class29_0.Struct16_1) >= 10 ? 1 : 0;
              }
              if (num == 0)
                goto label_23;
            }
            // ISSUE: reference to a compiler-generated field
            class121.class29_0.dictionary_1.Remove(key);
            // ISSUE: reference to a compiler-generated field
            class121.class29_0.hashSet_2.Remove(key);
          }
label_23:
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated method
          if (class121.class29_0.dictionary_1.Count == 0 || class121.class29_0.dictionary_1.Count > 0 && !class121.class29_0.dictionary_1.Values.Any<Class139>(new Func<Class139, bool>(class121.method_0)))
          {
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            if (class121.class29_0.Control2_0 != null && class121.class29_0.Control2_0?.tabControl_0.SelectedTab == class121.class29_0.Control2_0.tabPage_8 && class121.class29_0.Control2_0.tabControl_2.SelectedTab == class121.class29_0.Control2_0.tabPage_7)
            {
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              class121.class29_0.Control2_0.method_35(class121.class142_0.UInt16_0);
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            if (class121.class29_0.Class26_0.control4_0 != null && class121.class29_0.Class26_0.method_41(class121.class142_0.UInt16_0))
            {
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              class121.class29_0.Class26_0.method_40(class121.class142_0.UInt16_0.ToString());
            }
          }
        }
        else
        {
          // ISSUE: reference to a compiler-generated field
          if (class121.class29_0.dictionary_1[key] is Class143)
          {
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            class121.class29_0.Dictionary_1.Remove(class121.class29_0.dictionary_1[key].String_0);
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            class121.class29_0.Dictionary_2.Remove(class121.class29_0.dictionary_1[key].String_0);
            // ISSUE: reference to a compiler-generated field
            class121.class29_0.Control2_0?.method_23();
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            if (class121.class29_0.Control2_0 != null && class121.class29_0.Control2_0?.tabControl_1.SelectedTab == class121.class29_0.Control2_0.tabPage_11 && class121.class29_0.Control2_0.tabControl_2.SelectedTab == class121.class29_0.Control2_0.tabPage_9)
            {
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              class121.class29_0.Control2_0.method_34(class121.class29_0.dictionary_1[key].String_0);
            }
          }
          else
          {
            // ISSUE: reference to a compiler-generated field
            class121.class29_0.dictionary_1.Remove(key);
          }
        }
      }
    }
    return true;
  }

  private bool method_34(Class29 class29_0, Class100 class100_0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class112.Class122 class122 = new Class112.Class122();
    byte num1 = class100_0.method_2();
    ushort num2 = class100_0.method_6();
    byte num3 = class100_0.method_2();
    // ISSUE: reference to a compiler-generated field
    class122.string_0 = class100_0.method_10();
    int uint_2 = class100_0.method_7();
    class100_0.method_4();
    int num4 = class100_0.method_7();
    int num5 = class100_0.method_7();
    // ISSUE: reference to a compiler-generated field
    Class76 class76_1 = new Class76(num1, num2, num3, class122.string_0, uint_2, num4, num5);
    // ISSUE: reference to a compiler-generated field
    if (class122.string_0 == \u003CModule\u003E.smethod_5<string>(3568989391U))
    {
      int int320 = class76_1.Int32_0;
      // ISSUE: reference to a compiler-generated field
      Class76 class76_2 = class29_0.Class21_0[class122.string_0];
      int? nullable = class76_2 != null ? new int?(class76_2.Int32_0 - 1) : new int?();
      int valueOrDefault = nullable.GetValueOrDefault();
      if (int320 == valueOrDefault & nullable.HasValue)
        class29_0.dateTime_5 = DateTime.UtcNow;
    }
    class29_0.Class21_0[num1] = class76_1;
    // ISSUE: reference to a compiler-generated method
    if (class29_0.list_4.Any<Class24>(new Func<Class24, bool>(class122.method_0)))
    {
      class76_1.Boolean_0 = true;
      // ISSUE: reference to a compiler-generated method
      class76_1.Class24_0 = class29_0.list_4.First<Class24>(new Func<Class24, bool>(class122.method_1));
    }
    else
    {
      // ISSUE: reference to a compiler-generated method
      if (class29_0.list_6.Any<Class10>(new Func<Class10, bool>(class122.method_2)))
      {
        class76_1.Boolean_1 = true;
        // ISSUE: reference to a compiler-generated method
        class76_1.Class10_0 = class29_0.list_6.First<Class10>(new Func<Class10, bool>(class122.method_3));
      }
    }
    return true;
  }

  private bool method_35(Class29 class29_0, Class100 class100_0)
  {
    byte num = class100_0.method_2();
    if (class29_0.Class21_0[num].String_0 == \u003CModule\u003E.smethod_8<string>(3131705431U))
      class29_0.dateTime_5 = DateTime.UtcNow;
    class29_0.Class21_0[num] = (Class76) null;
    return true;
  }

  private bool method_36(Class29 class29_0, Class100 class100_0)
  {
    int key = class100_0.method_7();
    Direction direction = (Direction) class100_0.method_2();
    if (class29_0.dictionary_1.ContainsKey(key))
    {
      ((Class142) class29_0.dictionary_1[key]).Direction_0 = direction;
      if (class29_0.dictionary_1[key] is Class143 byte_9 && !class29_0.Dictionary_1.ContainsKey(byte_9.String_5) && !class29_0.Dictionary_2.ContainsKey(byte_9.String_5))
      {
        class29_0.Dictionary_2.Add(byte_9.String_5, byte_9);
        if (class29_0.method_17(Enum0.SeeGhosts))
          class29_0.method_67(byte_9);
      }
    }
    if (key == (int) class29_0.UInt32_0)
    {
      class29_0.Direction_1 = direction;
      class29_0.Direction_0 = direction;
    }
    return true;
  }

  private bool method_37(Class29 class29_0, Class100 class100_0)
  {
    int key = class100_0.method_7();
    int num1 = (int) class100_0.method_2();
    byte num2 = class100_0.method_2();
    if (class29_0.dictionary_1.ContainsKey(key) && class29_0.dictionary_1[key] is Class142 class142)
    {
      class142.Byte_1 = num2;
      ++class142.int_2;
      if (class142 is Class143 || num2 == (byte) 100 || class142.Boolean_0)
        return true;
      class142.Dictionary_0[(ushort) 117] = DateTime.MinValue;
      class142.Dictionary_0[(ushort) 32] = DateTime.MinValue;
    }
    return true;
  }

  private bool method_38(Class29 class29_0, Class100 class100_0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class112.Class123 class123 = new Class112.Class123();
    // ISSUE: reference to a compiler-generated field
    class123.class112_0 = this;
    // ISSUE: reference to a compiler-generated field
    class123.class29_0 = class29_0;
    // ISSUE: reference to a compiler-generated field
    class123.short_0 = class100_0.method_5();
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    if (class123.short_0 == (short) 3052 && class123.class29_0.Class26_0.bool_18)
    {
      // ISSUE: reference to a compiler-generated field
      class123.class29_0.Class26_0.bool_18 = false;
      // ISSUE: reference to a compiler-generated field
      class123.class29_0.method_75((byte) 1, \u003CModule\u003E.smethod_7<string>(1672924021U));
    }
    // ISSUE: reference to a compiler-generated field
    if (class123.short_0 != (short) 6999 && !this.list_4.Contains((ushort) 492))
      this.list_4.Add((ushort) 492);
    // ISSUE: reference to a compiler-generated field
    class123.byte_0 = class100_0.method_2();
    // ISSUE: reference to a compiler-generated field
    class123.byte_1 = class100_0.method_2();
    byte num1 = class100_0.method_2();
    byte[] numArray1 = class100_0.method_1(2);
    ushort num2 = class100_0.method_6();
    string str = class100_0.method_10();
    // ISSUE: reference to a compiler-generated field
    if (class123.class29_0.Boolean_8)
    {
      // ISSUE: reference to a compiler-generated field
      class100_0.Byte_3[4] = (byte) class123.class29_0.Enum5_0;
    }
    Class88 sender;
    // ISSUE: reference to a compiler-generated field
    if (this.dictionary_0.TryGetValue(class123.short_0, out sender) && (int) sender.UInt16_0 == (int) num2)
    {
      sender.Byte_2 = num1;
      sender.String_0 = str;
    }
    else
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      sender = new Class88(class123.short_0, class123.byte_0, class123.byte_1, num1, num2, str);
      // ISSUE: reference to a compiler-generated field
      this.dictionary_0[class123.short_0] = sender;
    }
    // ISSUE: reference to a compiler-generated field
    if (this.dictionary_0.ContainsKey(class123.short_0))
    {
      // ISSUE: reference to a compiler-generated field
      Class88 class88 = this.dictionary_0[class123.short_0];
      class88.Byte_2 = num1;
      sender = class88;
    }
    // ISSUE: reference to a compiler-generated field
    string path = Class106.smethod_2(System.Environment.SpecialFolder.CommonApplicationData, \u003CModule\u003E.smethod_9<string>(3587209257U), new object[1]
    {
      (object) class123.short_0
    });
    bool flag = false;
    if (System.IO.File.Exists(path))
    {
      byte[] numArray2 = System.IO.File.ReadAllBytes(path);
      if ((int) Class74.smethod_0(numArray2) == (int) num2)
      {
        sender.method_0(numArray2);
        flag = true;
      }
    }
    if (!flag)
    {
      System.IO.File.Delete(path);
      Class99 class99 = new Class99((byte) 5);
      class99.method_20(0U);
      // ISSUE: reference to a compiler-generated field
      class99.method_14(class123.byte_0);
      // ISSUE: reference to a compiler-generated field
      class99.method_14(class123.byte_1);
      class99.method_18((ushort) 0);
      class99.method_14((byte) 0);
      // ISSUE: reference to a compiler-generated field
      class123.class29_0.method_4(new Class98[1]
      {
        (Class98) class99
      });
    }
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    if (this.bool_5 && class123.class29_0.Boolean_6 && class123.class29_0.Boolean_5)
    {
      // ISSUE: reference to a compiler-generated field
      Struct16 struct161 = class123.class29_0.Struct16_1;
      // ISSUE: reference to a compiler-generated field
      struct161.method_2(class123.class29_0.Direction_1);
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      class123.class29_0.Struct17_2 = new Struct17(class123.class29_0.class88_0.Int16_0, struct161.short_0, struct161.short_1);
      // ISSUE: reference to a compiler-generated field
      class123.class29_0.Boolean_7 = true;
    }
    // ISSUE: reference to a compiler-generated field
    class123.class29_0.class88_0 = sender;
    // ISSUE: reference to a compiler-generated field
    if (!this.dictionary_1.ContainsKey(class123.short_0))
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      this.dictionary_1.Add(class123.short_0, new Class93(class123.short_0, class123.byte_0, class123.byte_1, num1, str, (sbyte) -1));
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      this.dictionary_1[class123.short_0].Dictionary_0 = class123.class29_0.class88_0.Dictionary_0;
    }
    if (sender.String_0.Contains(\u003CModule\u003E.smethod_9<string>(3679028607U)))
      sender.String_0 = this.dictionary_1[sender.Int16_0].String_0;
    // ISSUE: reference to a compiler-generated field
    class123.class29_0.HashSet_1.Clear();
    // ISSUE: reference to a compiler-generated field
    class123.class29_0.Dictionary_2.Clear();
    // ISSUE: reference to a compiler-generated field
    class123.class29_0.Dictionary_3.Clear();
    // ISSUE: reference to a compiler-generated field
    class123.class29_0.Dictionary_1.Clear();
    // ISSUE: reference to a compiler-generated field
    class123.class29_0.dictionary_12.Clear();
    // ISSUE: reference to a compiler-generated field
    class123.class29_0.dictionary_4.Clear();
    // ISSUE: reference to a compiler-generated field
    class123.class29_0.Control2_0.method_21(sender);
    // ISSUE: reference to a compiler-generated field
    class123.class29_0.Boolean_6 = false;
    // ISSUE: reference to a compiler-generated field
    class123.class29_0.Boolean_5 = false;
    // ISSUE: reference to a compiler-generated field
    class123.class29_0.Class94_0 = (Class94) null;
    // ISSUE: reference to a compiler-generated field
    class123.class29_0.Control2_0.method_39();
    // ISSUE: reference to a compiler-generated field
    class123.class29_0.Control2_0.method_38();
    // ISSUE: reference to a compiler-generated field
    class123.class29_0.Control2_0.method_23();
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    class123.class29_0.Class103_0 = new Class103(class123.class29_0);
    // ISSUE: reference to a compiler-generated field
    if (class123.class29_0.Control2_0.checkBox_20.Checked)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      class123.class29_0.method_66(class123.class29_0.Class143_0);
    }
    // ISSUE: reference to a compiler-generated field
    class123.class29_0.class88_0 = sender;
    // ISSUE: reference to a compiler-generated field
    if (class123.class29_0.Class143_0 != null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      class123.class29_0.Class143_0.Class88_0 = class123.class29_0.class88_0;
    }
    // ISSUE: reference to a compiler-generated field
    if (class123.class29_0.Control2_0.checkBox_2.Checked)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      class123.string_0 = Settings.Default.DarkAgesPath.Replace(\u003CModule\u003E.smethod_6<string>(975385566U), \u003CModule\u003E.smethod_6<string>(2183756118U) + class123.short_0.ToString() + \u003CModule\u003E.smethod_7<string>(3041344266U));
      // ISSUE: reference to a compiler-generated field
      if (class123.class29_0.Control2_0.radioButton_1.Checked)
      {
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (!System.IO.File.Exists(AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_6<string>(4254404908U) + class123.short_0.ToString() + \u003CModule\u003E.smethod_8<string>(2150645075U)) && System.IO.File.Exists(class123.string_0))
        {
          // ISSUE: reference to a compiler-generated method
          ThreadPool.QueueUserWorkItem(new WaitCallback(class123.method_0));
        }
        else
        {
          // ISSUE: reference to a compiler-generated field
          if (System.IO.File.Exists(AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_5<string>(67218964U) + class123.short_0.ToString() + \u003CModule\u003E.smethod_7<string>(3834403917U)))
          {
            // ISSUE: reference to a compiler-generated field
            class123.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_9<string>(1959267823U));
          }
        }
      }
      else
      {
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (!System.IO.File.Exists(AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_6<string>(3272475676U) + class123.class29_0.class88_0.String_0 + \u003CModule\u003E.smethod_7<string>(3834403917U)) && System.IO.File.Exists(class123.string_0))
        {
          // ISSUE: reference to a compiler-generated method
          ThreadPool.QueueUserWorkItem(new WaitCallback(class123.method_1));
        }
        else
        {
          // ISSUE: reference to a compiler-generated field
          if (System.IO.File.Exists(AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_5<string>(1327476004U) + class123.class29_0.class88_0.String_0 + \u003CModule\u003E.smethod_8<string>(2150645075U)))
          {
            // ISSUE: reference to a compiler-generated field
            class123.class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_8<string>(4178099397U));
          }
        }
      }
    }
    if (!sender.String_0.Contains(\u003CModule\u003E.smethod_9<string>(3679028607U)))
      return true;
    Class100 class100 = new Class100((byte) 21);
    // ISSUE: reference to a compiler-generated field
    class100.method_17(class123.short_0);
    // ISSUE: reference to a compiler-generated field
    class100.method_14(class123.byte_0);
    // ISSUE: reference to a compiler-generated field
    class100.method_14(class123.byte_1);
    class100.method_14(num1);
    class100.method_13(numArray1);
    class100.method_18(num2);
    class100.method_22(sender.String_0);
    // ISSUE: reference to a compiler-generated field
    class123.class29_0.method_4(new Class98[1]
    {
      (Class98) class100
    });
    return false;
  }

  private void method_39(Class29 class29_0, int class100_0, [In] byte obj2, [In] byte obj3, [In] string obj4)
  {
    try
    {
      double result1;
      double.TryParse(class29_0.Control2_0.textBox_2.Text, out result1);
      double result2;
      double.TryParse(class29_0.Control2_0.textBox_2.Text, out result2);
      this.gclass12_0 = GClass12.smethod_1(obj4, (int) obj2, (int) obj3);
      string str1 = Settings.Default.DarkAgesPath.Replace(\u003CModule\u003E.smethod_8<string>(2112040518U), \u003CModule\u003E.smethod_6<string>(1462286928U));
      string str2 = Settings.Default.DarkAgesPath.Replace(\u003CModule\u003E.smethod_5<string>(197665510U), \u003CModule\u003E.smethod_9<string>(1606624319U));
      this.gclass22_0 = GClass22.smethod_0(str1);
      this.gclass22_1 = GClass22.smethod_0(str2);
      this.gclass18_0 = new GClass18();
      this.gclass18_1 = new GClass18();
      this.gclass18_1.method_2(\u003CModule\u003E.smethod_7<string>(2186791540U), this.gclass22_1);
      this.gclass18_1.method_3(\u003CModule\u003E.smethod_5<string>(3679915376U), this.gclass22_1);
      this.gclass18_0.method_2(\u003CModule\u003E.smethod_9<string>(1047713188U), this.gclass22_0);
      this.gclass18_0.method_3(\u003CModule\u003E.smethod_8<string>(1857093870U), this.gclass22_0);
      Bitmap bitmap = new Bitmap((int) result1 + 1, (int) result2 + 1);
      using (MagickImage magickImage = new MagickImage(GClass9.smethod_5(this.gclass12_0, GClass20.smethod_2(\u003CModule\u003E.smethod_7<string>(1371247476U), this.gclass22_0), this.gclass18_0, this.gclass18_1, this.gclass22_1)))
      {
        string path = AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_5<string>(2587733044U);
        magickImage.Trim();
        magickImage.Resize(new Percentage(result2));
        if (!Directory.Exists(path))
          Directory.CreateDirectory(path);
        if (class29_0.Control2_0.radioButton_1.Checked)
          magickImage.Write(path + \u003CModule\u003E.smethod_8<string>(1029932808U) + class100_0.ToString() + \u003CModule\u003E.smethod_8<string>(2150645075U));
        else
          magickImage.Write(path + \u003CModule\u003E.smethod_9<string>(2857311597U) + class29_0.class88_0.String_0 + \u003CModule\u003E.smethod_6<string>(3970505171U));
        if (class29_0.Control2_0.checkBox_3.Checked)
          System.IO.File.Copy(obj4, path + \u003CModule\u003E.smethod_6<string>(485860807U) + class29_0.class88_0.String_0 + \u003CModule\u003E.smethod_5<string>(1520299570U));
      }
      class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_7<string>(823879378U) + class29_0.class88_0.String_0 + \u003CModule\u003E.smethod_9<string>(837288373U));
    }
    catch (Exception ex)
    {
      class29_0.method_75((byte) 0, \u003CModule\u003E.smethod_5<string>(1629328053U));
    }
  }

  private bool method_40(Class29 iasyncResult_0, [In] Class100 obj1)
  {
    int num1 = (int) obj1.method_2();
    ushort num2 = obj1.method_6();
    byte num3 = obj1.method_2();
    string str1 = obj1.method_10();
    string str2 = obj1.method_10();
    byte num4 = obj1.method_2();
    byte result1 = 0;
    byte result2 = 0;
    Match match = Regex.Match(str1, \u003CModule\u003E.smethod_7<string>(963841858U));
    if (match.Success)
    {
      str1 = match.Groups[1].Value;
      byte.TryParse(match.Groups[2].Value, out result1);
      byte.TryParse(match.Groups[3].Value, out result2);
    }
    string uint_1_1 = str1;
    int byte_0 = (int) num3;
    int uint_2 = (int) num2;
    string str3 = str2;
    int num5 = (int) num4;
    int num6 = (int) result1;
    int num7 = (int) result2;
    Class134 uint_1_2 = new Class134((byte) num1, uint_1_1, (byte) byte_0, (ushort) uint_2, str3, (byte) num5, (byte) num6, (byte) num7);
    iasyncResult_0.Class136_0.method_0(uint_1_2);
    if (iasyncResult_0.Control2_0 != null && (int) result1 == (int) result2 && iasyncResult_0.class88_0.String_0.Contains(\u003CModule\u003E.smethod_7<string>(3773460463U)) && iasyncResult_0.Control2_0.button_19.Text == \u003CModule\u003E.smethod_6<string>(2384646980U) && iasyncResult_0.Control2_0.list_3.Contains(uint_1_2.String_0))
    {
      iasyncResult_0.Control2_0.method_54((object) iasyncResult_0.Control2_0.groupBox_11.Controls[uint_1_2.String_0], new EventArgs());
      iasyncResult_0.Control2_0.groupBox_11.Controls[uint_1_2.String_0].Dispose();
    }
    if (!iasyncResult_0.Dictionary_5.ContainsKey(str1))
      iasyncResult_0.Dictionary_5.Add(str1, num4);
    return true;
  }

  private bool method_41(Class29 string_7, [In] Class100 obj1)
  {
    byte num = obj1.method_2();
    string_7.Class136_0.method_1(num);
    return true;
  }

  private bool method_42(Class29 bool_7 = false, [In] Class100 obj1)
  {
    byte num = obj1.method_2();
    return !bool_7.bool_14 || num != (byte) 1 && num != (byte) 101 && num != (byte) 16;
  }

  private bool method_43(Class29 class29_0, [In] Class100 obj1)
  {
    class29_0.Class26_0.dateTime_11 = DateTime.UtcNow;
    return true;
  }

  private bool method_44([In] Class29 obj0, Class100 int_1) => true;

  private bool method_45(Class29 class29_0, Class100 int_1)
  {
    if (class29_0.Control2_0.checkBox_20.Checked)
      class29_0.method_66(class29_0.Class143_0);
    return true;
  }

  private bool method_46([In] Class29 obj0, [In] Class100 obj1)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class112.Class124 class124 = new Class112.Class124();
    // ISSUE: reference to a compiler-generated field
    class124.class112_0 = this;
    // ISSUE: reference to a compiler-generated field
    class124.class29_0 = obj0;
    int num1;
    ushort key1;
    ushort key2;
    short sender;
    try
    {
      // ISSUE: reference to a compiler-generated field
      class124.int_0 = obj1.method_7();
      // ISSUE: reference to a compiler-generated field
      if (class124.int_0 == 0)
        return true;
      num1 = obj1.method_7();
      key1 = obj1.method_6();
      key2 = obj1.method_6();
      sender = obj1.method_5();
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      class124.class29_0.Struct11_0 = new Struct11(class124.int_0, num1, key1, key2, sender);
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (class124.class29_0.dictionary_1.ContainsKey(class124.int_0))
      {
        // ISSUE: object of a compiler-generated type is created
        // ISSUE: variable of a compiler-generated type
        Class112.Class125 class125 = new Class112.Class125();
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        class125.class142_0 = (Class142) class124.class29_0.dictionary_1[class124.int_0];
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        Class142 class142 = class124.class29_0.dictionary_1.ContainsKey(num1) ? (Class142) class124.class29_0.dictionary_1[num1] : (Class142) null;
        // ISSUE: reference to a compiler-generated field
        class125.class142_0.Dictionary_0[key1] = DateTime.UtcNow;
        // ISSUE: reference to a compiler-generated field
        class125.class142_0.ushort_1 = key1;
        // ISSUE: reference to a compiler-generated field
        class125.class142_0.dateTime_1 = DateTime.UtcNow;
        if (key1 == (ushort) 263 || key1 == (ushort) 278)
        {
          // ISSUE: reference to a compiler-generated field
          ++class125.class142_0.int_2;
          // ISSUE: reference to a compiler-generated field
          class125.class142_0.Byte_1 = (byte) 0;
        }
        if (num1 != 0)
        {
          // ISSUE: reference to a compiler-generated field
          class125.class142_0.Dictionary_1[key1] = DateTime.UtcNow;
        }
        ushort num2 = key1;
        if (num2 <= (ushort) 104)
        {
          if (num2 <= (ushort) 50)
          {
            if (num2 <= (ushort) 5)
            {
              if (num2 != (ushort) 1)
              {
                // ISSUE: reference to a compiler-generated field
                if (num2 == (ushort) 5 && class125.class142_0 is Class143 class1420_1 && (class142 is Class143 || this.list_5.Contains(class142.UInt16_0) || this.list_6.Contains(class142.UInt16_0)))
                {
                  if (class1420_1.Boolean_10)
                    class1420_1.Dictionary_0[(ushort) 89] = DateTime.MinValue;
                  // ISSUE: reference to a compiler-generated field
                  // ISSUE: reference to a compiler-generated field
                  if (class124.int_0 == class124.class29_0.Class143_0.Int32_0)
                  {
                    // ISSUE: reference to a compiler-generated field
                    class124.class29_0.Class26_0.dateTime_16 = DateTime.MinValue;
                  }
                  class1420_1.Boolean_8 = true;
                  goto label_131;
                }
                else
                  goto label_131;
              }
              else
              {
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                if (class125.class142_0 is Class143 class1420_2 && !class124.class29_0.Class26_0.list_14.Contains(class1420_2.String_5.ToUpper()))
                {
                  class1420_2.Boolean_8 = true;
                  goto label_131;
                }
                else
                  goto label_131;
              }
            }
            else if (num2 != (ushort) 18)
            {
              switch ((int) num2 - 43)
              {
                case 0:
                  break;
                case 1:
                  goto label_108;
                case 2:
                  goto label_112;
                case 5:
                  if (class142 is Class143)
                  {
                    (class142 as Class143).Boolean_8 = true;
                    goto label_131;
                  }
                  else
                    goto label_131;
                case 7:
                  // ISSUE: reference to a compiler-generated field
                  if (class142 == null && class125.class142_0 is Class143)
                  {
                    // ISSUE: reference to a compiler-generated field
                    (class125.class142_0 as Class143).Boolean_8 = true;
                    // ISSUE: reference to a compiler-generated field
                    class124.class29_0.bool_29 = true;
                    goto label_131;
                  }
                  else
                  {
                    // ISSUE: reference to a compiler-generated field
                    // ISSUE: reference to a compiler-generated field
                    if (!class124.class29_0.bool_29 && class125.class142_0 is Class143 && !(class142 is Class143))
                    {
                      // ISSUE: reference to a compiler-generated field
                      (class125.class142_0 as Class143).Boolean_8 = true;
                      goto label_131;
                    }
                    else
                    {
                      // ISSUE: reference to a compiler-generated field
                      if (class124.class29_0.bool_29)
                      {
                        // ISSUE: reference to a compiler-generated field
                        class124.class29_0.bool_29 = false;
                        goto label_131;
                      }
                      else
                        goto label_131;
                    }
                  }
                case 10:
                  if (class142 is Class143)
                  {
                    (class142 as Class143).Boolean_8 = true;
                    goto label_131;
                  }
                  else
                  {
                    // ISSUE: reference to a compiler-generated field
                    if (class142 != null && class125.class142_0 is Class143)
                    {
                      // ISSUE: reference to a compiler-generated field
                      (class125.class142_0 as Class143).Boolean_8 = true;
                      goto label_131;
                    }
                    else
                      goto label_131;
                  }
                default:
                  goto label_131;
              }
            }
            else
            {
              // ISSUE: reference to a compiler-generated field
              if (key1 != (ushort) 18 || !class124.class29_0.class88_0.String_0.Equals(\u003CModule\u003E.smethod_5<string>(2825310571U)))
              {
                // ISSUE: reference to a compiler-generated field
                class125.class142_0.Double_0 = Class134.smethod_0(\u003CModule\u003E.smethod_5<string>(848505613U));
                // ISSUE: reference to a compiler-generated field
                class125.class142_0.DateTime_1 = DateTime.UtcNow;
                // ISSUE: reference to a compiler-generated field
                class125.class142_0.String_1 = \u003CModule\u003E.smethod_8<string>(7636549U);
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                if (num1 == class124.class29_0.Class143_0.Int32_0 && class124.class29_0.list_7.Count > 0)
                {
                  // ISSUE: reference to a compiler-generated field
                  class124.class29_0.list_7.RemoveAt(0);
                }
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                if ((long) class124.int_0 != (long) class124.class29_0.UInt32_0)
                {
                  // ISSUE: reference to a compiler-generated field
                  // ISSUE: reference to a compiler-generated field
                  this.method_83(class124.class29_0, class124.int_0, \u003CModule\u003E.smethod_7<string>(1375192363U));
                  goto label_131;
                }
                else
                  goto label_131;
              }
              else
                goto label_131;
            }
          }
          else if (num2 == (ushort) 66)
          {
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            if (class124.int_0 == num1 && class125.class142_0 is Class143)
            {
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.DateTime_5 = DateTime.UtcNow;
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.String_2 = \u003CModule\u003E.smethod_5<string>(3832264527U);
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.Double_3 = Class134.smethod_0(class125.class142_0.String_2);
              goto label_131;
            }
            else
              goto label_131;
          }
          else if (num2 == (ushort) 70)
          {
            // ISSUE: reference to a compiler-generated field
            if (class125.class142_0 is Class143 && !(class142 is Class143))
            {
              // ISSUE: reference to a compiler-generated field
              (class125.class142_0 as Class143).Boolean_8 = true;
              goto label_131;
            }
            else
              goto label_131;
          }
          else if (num2 == (ushort) 75)
          {
            if (class142 is Class143)
            {
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.Double_0 = Class134.smethod_0(\u003CModule\u003E.smethod_6<string>(1267240933U));
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.DateTime_1 = DateTime.UtcNow;
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.String_1 = \u003CModule\u003E.smethod_7<string>(1291214875U);
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              if (num1 == class124.class29_0.Class143_0.Int32_0 && class124.class29_0.list_7.Count > 0)
              {
                // ISSUE: reference to a compiler-generated field
                class124.class29_0.list_7.RemoveAt(0);
              }
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              if ((long) class124.int_0 != (long) class124.class29_0.UInt32_0)
              {
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                this.method_83(class124.class29_0, class124.int_0, \u003CModule\u003E.smethod_7<string>(1291214875U));
                goto label_131;
              }
              else
                goto label_131;
            }
            else
              goto label_131;
          }
          else if (num2 == (ushort) 82)
          {
            // ISSUE: reference to a compiler-generated field
            class125.class142_0.Double_0 = Class134.smethod_0(\u003CModule\u003E.smethod_9<string>(625020571U));
            // ISSUE: reference to a compiler-generated field
            class125.class142_0.DateTime_1 = DateTime.UtcNow;
            // ISSUE: reference to a compiler-generated field
            class125.class142_0.String_1 = \u003CModule\u003E.smethod_6<string>(2095500449U);
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            if (num1 == class124.class29_0.Class143_0.Int32_0 && class124.class29_0.list_7.Count > 0)
            {
              // ISSUE: reference to a compiler-generated field
              class124.class29_0.list_7.RemoveAt(0);
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            if ((long) class124.int_0 != (long) class124.class29_0.UInt32_0)
            {
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              this.method_83(class124.class29_0, class124.int_0, \u003CModule\u003E.smethod_9<string>(625020571U));
              goto label_131;
            }
            else
              goto label_131;
          }
          else if (num2 == (ushort) 86)
          {
            // ISSUE: reference to a compiler-generated field
            if (class124.int_0 == num1)
            {
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.DateTime_5 = DateTime.UtcNow;
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.String_2 = \u003CModule\u003E.smethod_6<string>(1918391038U);
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.Double_3 = Class134.smethod_0(class125.class142_0.String_2);
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              this.method_85(class124.class29_0, class124.int_0, \u003CModule\u003E.smethod_6<string>(1918391038U));
              goto label_131;
            }
            else
            {
              // ISSUE: reference to a compiler-generated field
              if (class125.class142_0 is Class143)
              {
                // ISSUE: reference to a compiler-generated field
                (class125.class142_0 as Class143).Boolean_8 = false;
                goto label_131;
              }
              else
                goto label_131;
            }
          }
          else if (num2 == (ushort) 89)
          {
            // ISSUE: reference to a compiler-generated field
            if (class124.int_0 == num1)
            {
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.DateTime_5 = DateTime.UtcNow;
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.String_2 = \u003CModule\u003E.smethod_5<string>(2089242092U);
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.Double_3 = Class134.smethod_0(class125.class142_0.String_2);
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              this.method_85(class124.class29_0, class124.int_0, \u003CModule\u003E.smethod_7<string>(2743612608U));
              goto label_131;
            }
            else
              goto label_131;
          }
          else if (num2 == (ushort) 93)
          {
            // ISSUE: reference to a compiler-generated field
            if (class124.int_0 != num1)
            {
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.DateTime_5 = DateTime.UtcNow;
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.String_2 = \u003CModule\u003E.smethod_6<string>(326687980U);
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.Double_3 = Class134.smethod_0(class125.class142_0.String_2);
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              this.method_85(class124.class29_0, class124.int_0, \u003CModule\u003E.smethod_5<string>(3616125396U));
              goto label_131;
            }
            else
              goto label_131;
          }
          else if (num2 == (ushort) 104)
          {
            // ISSUE: reference to a compiler-generated field
            class125.class142_0.Double_0 = Class134.smethod_0(\u003CModule\u003E.smethod_9<string>(2860665095U));
            // ISSUE: reference to a compiler-generated field
            class125.class142_0.DateTime_1 = DateTime.UtcNow;
            // ISSUE: reference to a compiler-generated field
            class125.class142_0.String_1 = \u003CModule\u003E.smethod_8<string>(1447988461U);
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            if (num1 == class124.class29_0.Class143_0.Int32_0 && class124.class29_0.list_7.Count > 0)
            {
              // ISSUE: reference to a compiler-generated field
              class124.class29_0.list_7.RemoveAt(0);
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            if ((long) class124.int_0 != (long) class124.class29_0.UInt32_0)
            {
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              this.method_83(class124.class29_0, class124.int_0, \u003CModule\u003E.smethod_5<string>(3626117781U));
              goto label_131;
            }
            else
              goto label_131;
          }
          else if (num2 == (ushort) 162)
          {
            // ISSUE: reference to a compiler-generated field
            if (class125.class142_0 is Class143 && !(class142 is Class143))
            {
              // ISSUE: reference to a compiler-generated field
              (class125.class142_0 as Class143).Boolean_8 = true;
              goto label_131;
            }
            else
              goto label_131;
          }
          else if (num2 == (ushort) 231)
          {
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            if (num1 == class124.class29_0.Class143_0.Int32_0 && class124.class29_0.list_7.Count > 0)
            {
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.Double_2 = Class134.smethod_0(class124.class29_0.list_7[0].Class134_0.String_0);
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.DateTime_3 = DateTime.UtcNow;
              // ISSUE: reference to a compiler-generated field
              class124.class29_0.list_7.RemoveAt(0);
              goto label_131;
            }
            else
            {
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.Double_2 = Class134.smethod_0(\u003CModule\u003E.smethod_8<string>(3608516329U));
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.DateTime_3 = DateTime.UtcNow;
              goto label_131;
            }
          }
          else
            goto label_131;
        }
        else if (num2 <= (ushort) 243)
        {
          if (num2 == (ushort) 235)
          {
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            if (num1 == class124.class29_0.Class143_0.Int32_0 && class124.class29_0.list_7.Count > 0)
            {
              // ISSUE: reference to a compiler-generated field
              class124.class29_0.list_7.RemoveAt(0);
              goto label_131;
            }
            else
              goto label_131;
          }
          else if (num2 != (ushort) 232)
          {
            if (num2 == (ushort) 243)
            {
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.Double_0 = Class134.smethod_0(\u003CModule\u003E.smethod_7<string>(1375192363U));
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.DateTime_1 = DateTime.UtcNow;
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.String_1 = \u003CModule\u003E.smethod_7<string>(1375192363U);
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              if (num1 == class124.class29_0.Class143_0.Int32_0 && class124.class29_0.list_7.Count > 0)
              {
                // ISSUE: reference to a compiler-generated field
                class124.class29_0.list_7.RemoveAt(0);
              }
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              if ((long) class124.int_0 != (long) class124.class29_0.UInt32_0)
              {
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                this.method_83(class124.class29_0, class124.int_0, \u003CModule\u003E.smethod_5<string>(848505613U));
                goto label_131;
              }
              else
                goto label_131;
            }
            else
              goto label_131;
          }
          else
          {
            // ISSUE: reference to a compiler-generated method
            if (class142 != null && !(class142 is Class143) && this.IEnumerable_0.All<Class29>(new Func<Class29, bool>(class125.method_0)))
            {
              // ISSUE: reference to a compiler-generated field
              if (class124.class29_0.Class26_0.method_38())
              {
                // ISSUE: reference to a compiler-generated method
                ThreadPool.QueueUserWorkItem(new WaitCallback(class124.method_0));
                goto label_131;
              }
              else
              {
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                this.method_82(class124.class29_0, class124.int_0, false);
                goto label_131;
              }
            }
            else
              goto label_131;
          }
        }
        else if (num2 <= (ushort) 274)
        {
          if (num2 != (ushort) 244)
          {
            switch ((int) num2 - 257)
            {
              case 0:
                break;
              case 1:
                goto label_108;
              case 2:
                goto label_112;
              default:
                switch ((int) num2 - 271)
                {
                  case 0:
                    // ISSUE: reference to a compiler-generated field
                    // ISSUE: reference to a compiler-generated field
                    if (class124.int_0 == num1 && !(class125.class142_0 is Class143))
                    {
                      // ISSUE: reference to a compiler-generated field
                      class125.class142_0.DateTime_5 = DateTime.UtcNow;
                      // ISSUE: reference to a compiler-generated field
                      class125.class142_0.String_2 = \u003CModule\u003E.smethod_9<string>(3644689937U);
                      // ISSUE: reference to a compiler-generated field
                      // ISSUE: reference to a compiler-generated field
                      class125.class142_0.Double_3 = Class134.smethod_0(class125.class142_0.String_2);
                      // ISSUE: reference to a compiler-generated field
                      // ISSUE: reference to a compiler-generated field
                      this.method_85(class124.class29_0, class124.int_0, \u003CModule\u003E.smethod_5<string>(38170227U));
                      goto label_131;
                    }
                    else
                      goto label_131;
                  case 2:
                    // ISSUE: reference to a compiler-generated field
                    // ISSUE: reference to a compiler-generated field
                    if (num1 == class124.class29_0.Class143_0.Int32_0 && class124.class29_0.list_7.Count > 0)
                    {
                      // ISSUE: reference to a compiler-generated field
                      // ISSUE: reference to a compiler-generated field
                      class125.class142_0.Double_1 = Class134.smethod_0(class124.class29_0.list_7[0].Class134_0.String_0);
                      // ISSUE: reference to a compiler-generated field
                      class125.class142_0.DateTime_2 = DateTime.UtcNow;
                      // ISSUE: reference to a compiler-generated field
                      class124.class29_0.list_7.RemoveAt(0);
                      // ISSUE: reference to a compiler-generated field
                      // ISSUE: reference to a compiler-generated field
                      // ISSUE: reference to a compiler-generated field
                      this.method_84(class124.class29_0, class124.int_0, class125.class142_0.Double_1);
                      goto label_131;
                    }
                    else
                    {
                      // ISSUE: reference to a compiler-generated field
                      class125.class142_0.Double_1 = Class134.smethod_0(\u003CModule\u003E.smethod_6<string>(3728579786U));
                      // ISSUE: reference to a compiler-generated field
                      class125.class142_0.DateTime_2 = DateTime.UtcNow;
                      goto label_131;
                    }
                  case 3:
                    // ISSUE: reference to a compiler-generated field
                    // ISSUE: reference to a compiler-generated field
                    if (class125.class142_0 == class124.class29_0.Class143_0)
                    {
                      // ISSUE: reference to a compiler-generated field
                      class124.class29_0.Class26_0.bool_10 = true;
                      goto label_131;
                    }
                    else
                      goto label_131;
                  default:
                    goto label_131;
                }
            }
          }
          else
          {
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated method
            if (class124.int_0 == num1 && class124.int_0 != class124.class29_0.Class143_0.Int32_0 && this.IEnumerable_0.All<Class29>(new Func<Class29, bool>(class124.method_1)))
            {
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.DateTime_5 = DateTime.UtcNow;
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.String_2 = \u003CModule\u003E.smethod_9<string>(3644689937U);
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.Double_3 = Class134.smethod_0(class125.class142_0.String_2);
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              this.method_85(class124.class29_0, class124.int_0, \u003CModule\u003E.smethod_6<string>(392102027U));
              goto label_131;
            }
            else
              goto label_131;
          }
        }
        else if (num2 <= (ushort) 301)
        {
          if (num2 != (ushort) 279)
          {
            // ISSUE: reference to a compiler-generated field
            if (num2 == (ushort) 301 && !(class125.class142_0 is Class143))
            {
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.DateTime_5 = DateTime.UtcNow;
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.String_2 = \u003CModule\u003E.smethod_5<string>(1177488564U);
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.Double_3 = Class134.smethod_0(class125.class142_0.String_2);
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              this.method_85(class124.class29_0, class125.class142_0.Int32_0, class125.class142_0.String_2);
              goto label_131;
            }
            else
              goto label_131;
          }
          else
          {
            // ISSUE: reference to a compiler-generated field
            if (class125.class142_0.Dictionary_0.ContainsKey((ushort) 25))
            {
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.Dictionary_0[(ushort) 25] = DateTime.MinValue;
            }
            // ISSUE: reference to a compiler-generated field
            if (class125.class142_0.Dictionary_0.ContainsKey((ushort) 247))
            {
              // ISSUE: reference to a compiler-generated field
              class125.class142_0.Dictionary_0[(ushort) 247] = DateTime.MinValue;
              goto label_131;
            }
            else
              goto label_131;
          }
        }
        else if (num2 != (ushort) 377)
        {
          // ISSUE: reference to a compiler-generated field
          if (num2 == (ushort) 393 && class142 != null && class142 == class125.class142_0)
          {
            class142.Byte_1 = (byte) 1;
            goto label_131;
          }
          else
            goto label_131;
        }
        else
        {
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          if (num1 == class124.class29_0.Class143_0.Int32_0 && class124.class29_0.list_7.Count > 0)
          {
            // ISSUE: reference to a compiler-generated field
            class124.class29_0.list_7.RemoveAt(0);
            goto label_131;
          }
          else
            goto label_131;
        }
        // ISSUE: reference to a compiler-generated field
        class125.class142_0.Double_0 = Class134.smethod_0(\u003CModule\u003E.smethod_5<string>(2237311697U));
        // ISSUE: reference to a compiler-generated field
        class125.class142_0.DateTime_1 = DateTime.UtcNow;
        // ISSUE: reference to a compiler-generated field
        class125.class142_0.String_1 = \u003CModule\u003E.smethod_7<string>(2385951071U);
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (num1 == class124.class29_0.Class143_0.Int32_0 && class124.class29_0.list_7.Count > 0)
        {
          // ISSUE: reference to a compiler-generated field
          class124.class29_0.list_7.RemoveAt(0);
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if ((long) class124.int_0 != (long) class124.class29_0.UInt32_0)
        {
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          this.method_83(class124.class29_0, class124.int_0, \u003CModule\u003E.smethod_8<string>(1688047113U));
          goto label_131;
        }
        else
          goto label_131;
label_108:
        // ISSUE: reference to a compiler-generated field
        class125.class142_0.Double_0 = Class134.smethod_0(\u003CModule\u003E.smethod_9<string>(2223016130U));
        // ISSUE: reference to a compiler-generated field
        class125.class142_0.DateTime_1 = DateTime.UtcNow;
        // ISSUE: reference to a compiler-generated field
        class125.class142_0.String_1 = \u003CModule\u003E.smethod_6<string>(1137010912U);
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (num1 == class124.class29_0.Class143_0.Int32_0 && class124.class29_0.list_7.Count > 0)
        {
          // ISSUE: reference to a compiler-generated field
          class124.class29_0.list_7.RemoveAt(0);
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if ((long) class124.int_0 != (long) class124.class29_0.UInt32_0)
        {
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          this.method_83(class124.class29_0, class124.int_0, \u003CModule\u003E.smethod_7<string>(1648876412U));
          goto label_131;
        }
        else
          goto label_131;
label_112:
        // ISSUE: reference to a compiler-generated field
        class125.class142_0.Double_0 = Class134.smethod_0(\u003CModule\u003E.smethod_6<string>(2947199660U));
        // ISSUE: reference to a compiler-generated field
        class125.class142_0.DateTime_1 = DateTime.UtcNow;
        // ISSUE: reference to a compiler-generated field
        class125.class142_0.String_1 = \u003CModule\u003E.smethod_6<string>(2947199660U);
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (num1 == class124.class29_0.Class143_0.Int32_0 && class124.class29_0.list_7.Count > 0)
        {
          // ISSUE: reference to a compiler-generated field
          class124.class29_0.list_7.RemoveAt(0);
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if ((long) class124.int_0 != (long) class124.class29_0.UInt32_0)
        {
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          this.method_83(class124.class29_0, class124.int_0, \u003CModule\u003E.smethod_9<string>(163693358U));
        }
label_131:
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (class124.class29_0.dictionary_1[class124.int_0] is Class143 byte_9)
        {
          // ISSUE: reference to a compiler-generated field
          if (!class124.class29_0.Dictionary_1.ContainsKey(byte_9.String_5))
          {
            // ISSUE: reference to a compiler-generated field
            if (!class124.class29_0.Dictionary_2.ContainsKey(byte_9.String_5))
            {
              // ISSUE: reference to a compiler-generated field
              class124.class29_0.Dictionary_2.Add(byte_9.String_5, byte_9);
              // ISSUE: reference to a compiler-generated field
              if (class124.class29_0.method_17(Enum0.SeeGhosts))
              {
                // ISSUE: reference to a compiler-generated field
                class124.class29_0.method_67(byte_9);
              }
            }
          }
        }
      }
    }
    catch
    {
      return false;
    }
    if (Settings.Default.DisableSprites)
      return false;
    if (Settings.Default.NormalSprites || !Settings.Default.OverrideSprites || !this.form5_0.dictionary_5.ContainsKey((int) key1) && !this.form5_0.dictionary_5.ContainsKey((int) key2))
      return true;
    ushort num3 = this.form5_0.dictionary_5.ContainsKey((int) key1) ? (ushort) this.form5_0.dictionary_5[(int) key1] : key1;
    ushort num4 = this.form5_0.dictionary_5.ContainsKey((int) key2) ? (ushort) this.form5_0.dictionary_5[(int) key2] : key2;
    Class100 class100 = new Class100((byte) 41);
    // ISSUE: reference to a compiler-generated field
    class100.method_19(class124.int_0);
    class100.method_19(num1);
    class100.method_18(num3);
    class100.method_18(num4);
    class100.method_17(sender);
    // ISSUE: reference to a compiler-generated field
    class124.class29_0.method_4(new Class98[1]
    {
      (Class98) class100
    });
    return false;
  }

  private bool method_47([In] Class29 obj0, Class100 int_1)
  {
    int intptr_0 = (int) int_1.method_2();
    ushort num1 = int_1.method_6();
    string input = int_1.method_10();
    byte result1 = 0;
    byte result2 = 0;
    Match match = Regex.Match(input, \u003CModule\u003E.smethod_6<string>(3379266002U));
    if (match.Success)
    {
      input = match.Groups[1].Value;
      byte.TryParse(match.Groups[2].Value, out result1);
      byte.TryParse(match.Groups[3].Value, out result2);
    }
    string int_2 = input;
    int num2 = (int) num1;
    int num3 = (int) result1;
    int num4 = (int) result2;
    Class132 class132 = new Class132((byte) intptr_0, int_2, (ushort) num2, (byte) num3, (byte) num4);
    if (obj0.Control2_0 != null && (int) result1 == (int) result2 && obj0.class88_0.String_0.Contains(\u003CModule\u003E.smethod_8<string>(138303769U)) && obj0.Control2_0.button_19.Text == \u003CModule\u003E.smethod_8<string>(3184522924U) && obj0.Control2_0.list_2.Contains(class132.String_0))
    {
      obj0.Control2_0.method_53((object) obj0.Control2_0.groupBox_13.Controls[class132.String_0], new EventArgs());
      obj0.Control2_0.groupBox_13.Controls[class132.String_0].Dispose();
    }
    obj0.Class133_0.method_0(class132);
    return true;
  }

  private bool method_48(Class29 class29_0, Class100 int_1)
  {
    byte num = int_1.method_2();
    class29_0.Class133_0.method_1(num);
    return true;
  }

  private bool method_49([In] Class29 obj0, [In] Class100 obj1)
  {
    string str = obj1.method_10();
    byte num1 = obj1.method_2();
    int num2 = (int) obj1.method_2();
    Class95[] class95Array = Array.Empty<Class95>();
    Class94 class94_1 = new Class94(str, class95Array);
    for (int index = 0; index < (int) num1; ++index)
    {
      Struct16 struct16_1 = obj1.method_12();
      string enum7_1 = obj1.method_10();
      int num3 = (int) obj1.method_5();
      short count = obj1.method_5();
      Struct16 struct16_2 = obj1.method_12();
      class94_1.List_0.Add(new Class95(struct16_1, enum7_1, count, struct16_2));
    }
    obj0.Class94_0 = class94_1;
    uint key = class94_1.method_0();
    Class94 class94_2 = class94_1;
    this.Dictionary_4[key] = class94_2;
    if (this.bool_5 && obj0.Boolean_5 && this.dictionary_1.ContainsKey(obj0.class88_0.Int16_0))
    {
      Struct16 struct161 = obj0.Struct16_1;
      struct161.method_2(obj0.Direction_1);
      this.dictionary_1[obj0.class88_0.Int16_0].Dictionary_2[struct161] = class94_2;
    }
    obj0.Boolean_5 = false;
    return true;
  }

  private bool method_50([In] Class29 obj0, Class100 int_1)
  {
    if (int_1.Byte_3.Length < 16)
      return true;
    int num1 = (int) int_1.method_2();
    int num2 = (int) int_1.method_2();
    int_1.method_7();
    int num3 = (int) int_1.method_2();
    int num4 = (int) int_1.method_6();
    int num5 = (int) int_1.method_2();
    int num6 = (int) int_1.method_2();
    int num7 = (int) int_1.method_6();
    int num8 = (int) int_1.method_2();
    int num9 = (int) int_1.method_2();
    this.string_2 = int_1.method_10();
    int int320_1 = int_1.Int32_0;
    this.string_3 = int_1.method_11();
    if (this.string_3 == \u003CModule\u003E.smethod_7<string>(718150305U) && this.string_2 == \u003CModule\u003E.smethod_5<string>(1416519717U) && DateTime.UtcNow.Subtract(obj0.dateTime_6).TotalMinutes < 6.0)
    {
      TimeSpan timeSpan = new TimeSpan(0, 6, 0) - DateTime.UtcNow.Subtract(obj0.dateTime_6);
      string ushort_2 = \u003CModule\u003E.smethod_9<string>(1440598668U) + (obj0.dateTime_6 != DateTime.MinValue ? (timeSpan.Minutes > 1 ? string.Format(\u003CModule\u003E.smethod_5<string>(2787238533U), (object) timeSpan.Minutes) : (timeSpan.Minutes > 0 ? string.Format(\u003CModule\u003E.smethod_8<string>(2596779901U), (object) timeSpan.Minutes) : string.Empty)) + string.Format(\u003CModule\u003E.smethod_5<string>(607617624U), (object) timeSpan.Seconds) : \u003CModule\u003E.smethod_5<string>(3578053358U));
      obj0.method_75((byte) 3, ushort_2);
    }
    obj0.string_2 = this.string_3;
    obj0.Control2_0.textBox_0.Text = this.string_3;
    int int320_2 = int_1.Int32_0;
    switch ((byte) num1)
    {
      case 0:
        byte num10 = int_1.method_2();
        for (int index = 0; index < (int) num10; ++index)
        {
          string str = int_1.method_10();
          this.SortedDictionary_0[int_1.method_6()] = str;
        }
        break;
      case 4:
        obj0.list_0.Clear();
        int_1.method_1(3);
        byte num11 = int_1.method_2();
        for (int index = 0; index < (int) num11; ++index)
        {
          int num12 = (int) int_1.method_6();
          int num13 = (int) int_1.method_2();
          int num14 = (int) int_1.method_8();
          string str = int_1.method_10();
          int_1.method_10();
          obj0.list_0.Add(str);
        }
        if (obj0.list_0.Count != 0)
        {
          StringBuilder stringBuilder = new StringBuilder();
          foreach (string str in obj0.list_0)
          {
            if (str != null)
              stringBuilder.AppendLine(str);
          }
          if (Directory.Exists(AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_9<string>(3619940547U) + obj0.String_0.ToLower()))
          {
            System.IO.File.WriteAllText(AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_6<string>(2595775113U) + obj0.String_0.ToLower() + \u003CModule\u003E.smethod_6<string>(3225596286U), stringBuilder.ToString());
            break;
          }
          Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_6<string>(2595775113U) + obj0.String_0.ToLower());
          System.IO.File.WriteAllText(AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_5<string>(1995918833U) + obj0.String_0.ToLower() + \u003CModule\u003E.smethod_6<string>(3225596286U), stringBuilder.ToString());
          break;
        }
        break;
    }
    return true;
  }

  private bool method_51(Class29 class29_0, Class100 class142_0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class112.Class126 class126 = new Class112.Class126();
    // ISSUE: reference to a compiler-generated field
    class126.class29_0 = class29_0;
    byte num1 = 0;
    string str1 = string.Empty;
    string str2 = string.Empty;
    List<string> stringList = new List<string>();
    byte num2;
    byte num3;
    ushort num4;
    byte uint_1;
    byte num5;
    ushort num6;
    byte num7;
    ushort num8;
    bool flag1;
    bool flag2;
    byte num9;
    string key1;
    string key2;
    try
    {
      num2 = class142_0.method_2();
      if (num2 == (byte) 10)
      {
        // ISSUE: reference to a compiler-generated field
        class126.class29_0.Class75_0 = (Class75) null;
        return true;
      }
      // ISSUE: reference to a compiler-generated field
      class126.byte_0 = class142_0.method_2();
      // ISSUE: reference to a compiler-generated field
      class126.int_0 = class142_0.method_7();
      num3 = class142_0.method_2();
      num4 = class142_0.method_6();
      uint_1 = class142_0.method_2();
      num5 = class142_0.method_2();
      num6 = class142_0.method_6();
      num7 = class142_0.method_2();
      // ISSUE: reference to a compiler-generated field
      class126.ushort_0 = class142_0.method_6();
      num8 = class142_0.method_6();
      flag1 = class142_0.method_4();
      flag2 = class142_0.method_4();
      num9 = class142_0.method_2();
      key1 = class142_0.method_10();
      int int320_1 = class142_0.Int32_0;
      key2 = class142_0.method_11();
      int int320_2 = class142_0.Int32_0;
      if (key2 == \u003CModule\u003E.smethod_7<string>(907856866U))
      {
        // ISSUE: reference to a compiler-generated method
        ThreadPool.QueueUserWorkItem(new WaitCallback(class126.method_0));
      }
      if (key2 == \u003CModule\u003E.smethod_7<string>(627931906U))
      {
        // ISSUE: reference to a compiler-generated field
        TimeSpan timeSpan = new TimeSpan(0, 5, 0) - DateTime.UtcNow.Subtract(class126.class29_0.dateTime_5);
        // ISSUE: reference to a compiler-generated field
        string str3 = \u003CModule\u003E.smethod_9<string>(2578070704U) + (class126.class29_0.dateTime_5 != DateTime.MinValue ? (timeSpan.Minutes > 1 ? string.Format(\u003CModule\u003E.smethod_5<string>(2787238533U), (object) timeSpan.Minutes) : (timeSpan.Minutes > 0 ? string.Format(\u003CModule\u003E.smethod_6<string>(717207165U), (object) timeSpan.Minutes) : string.Empty)) + string.Format(\u003CModule\u003E.smethod_5<string>(607617624U), (object) timeSpan.Seconds) : \u003CModule\u003E.smethod_6<string>(1001106902U));
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        class126.class29_0.method_64(num2, class126.byte_0, class126.int_0, num3, num4, uint_1, num5, num6, num7, class126.ushort_0, num8, false, false, num9, key1, str3);
        return false;
      }
      // ISSUE: reference to a compiler-generated field
      class126.class29_0.Control2_0.textBox_0.Text = key2;
      // ISSUE: reference to a compiler-generated field
      class126.class29_0.Control2_0.label_1.Text = \u003CModule\u003E.smethod_8<string>(2031368872U) + num8.ToString();
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      class126.class29_0.Control2_0.label_0.Text = \u003CModule\u003E.smethod_7<string>(2566571076U) + class126.ushort_0.ToString();
      // ISSUE: reference to a compiler-generated field
      class126.class29_0.string_2 = key2;
      switch (num2)
      {
        case 2:
          byte num10 = class142_0.method_2();
          for (int index = 0; index < (int) num10; ++index)
            stringList.Add(class142_0.method_10());
          break;
        case 4:
          str1 = class142_0.method_10();
          num1 = class142_0.method_2();
          str2 = class142_0.method_10();
          break;
      }
    }
    catch
    {
      return false;
    }
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated field
    class126.class29_0.Class75_0 = new Class75(num2, class126.byte_0, class126.int_0, num3, num4, uint_1, num5, num6, num7, class126.ushort_0, num8, flag1, flag2, num9, key1, key2, stringList, str1, num1, str2, class126.class29_0);
    if (!(key2 == \u003CModule\u003E.smethod_7<string>(845630963U)) && !(key2 == \u003CModule\u003E.smethod_5<string>(3417588991U)))
    {
      if (key2 == \u003CModule\u003E.smethod_8<string>(3725386206U))
      {
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        class126.class29_0.method_90(class126.byte_0, class126.int_0, class126.ushort_0, (ushort) ((uint) num8 + 1U), (byte) 1);
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        class126.class29_0.method_89(class126.byte_0, class126.int_0, class126.ushort_0, (ushort) ((uint) num8 + 1U));
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        class126.class29_0.method_89(class126.byte_0, class126.int_0, class126.ushort_0, (ushort) ((uint) num8 + 1U));
        return false;
      }
      if (!(key2 == \u003CModule\u003E.smethod_8<string>(337160965U)) && !(key2 == \u003CModule\u003E.smethod_7<string>(3660208030U)))
      {
        if (key2 == \u003CModule\u003E.smethod_8<string>(3802335853U))
        {
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          class126.class29_0.method_89(class126.byte_0, class126.int_0, class126.ushort_0, (ushort) ((uint) num8 + 1U));
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          class126.class29_0.method_89(class126.byte_0, class126.int_0, class126.ushort_0, (ushort) ((uint) num8 + 1U));
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          class126.class29_0.method_89(class126.byte_0, class126.int_0, class126.ushort_0, (ushort) ((uint) num8 + 1U));
          return false;
        }
        if (!(key2 == \u003CModule\u003E.smethod_9<string>(3020551833U)) && !(key2 == \u003CModule\u003E.smethod_8<string>(947720469U)))
        {
          if (key2 == \u003CModule\u003E.smethod_5<string>(1892138980U))
          {
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            class126.class29_0.method_89(class126.byte_0, class126.int_0, class126.ushort_0, (ushort) ((uint) num8 + 1U));
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            class126.class29_0.method_89(class126.byte_0, class126.int_0, class126.ushort_0, (ushort) ((uint) num8 + 1U));
            return false;
          }
          if (key2 == \u003CModule\u003E.smethod_7<string>(3026566420U))
          {
            // ISSUE: reference to a compiler-generated field
            class126.class29_0.Control2_0.button_45.Text = \u003CModule\u003E.smethod_7<string>(408486446U);
          }
          else if (key2 == \u003CModule\u003E.smethod_5<string>(3814661801U))
          {
            // ISSUE: reference to a compiler-generated field
            class126.class29_0.bool_28 = true;
          }
          else if (key2 == \u003CModule\u003E.smethod_9<string>(766061225U))
          {
            // ISSUE: reference to a compiler-generated field
            class126.class29_0.Class75_0.method_2((byte) 2);
          }
          else
          {
            // ISSUE: reference to a compiler-generated field
            if (class126.class29_0.Control2_0.button_34.Text == \u003CModule\u003E.smethod_5<string>(3530897020U))
            {
              if (key2 == \u003CModule\u003E.smethod_5<string>(2014975185U))
              {
                for (int index = 0; index < 6; ++index)
                {
                  // ISSUE: reference to a compiler-generated field
                  // ISSUE: reference to a compiler-generated field
                  // ISSUE: reference to a compiler-generated field
                  // ISSUE: reference to a compiler-generated field
                  class126.class29_0.method_89(class126.byte_0, class126.int_0, class126.ushort_0, (ushort) ((uint) num8 + 1U));
                }
                Thread.Sleep(1000);
                return false;
              }
              if (key2 == \u003CModule\u003E.smethod_7<string>(3899658672U))
              {
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                class126.class29_0.method_89(class126.byte_0, class126.int_0, class126.ushort_0, (ushort) 2);
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                class126.class29_0.method_89(class126.byte_0, class126.int_0, class126.ushort_0, (ushort) 3);
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                class126.class29_0.method_90(class126.byte_0, class126.int_0, class126.ushort_0, (ushort) 11, (byte) 1);
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                class126.class29_0.method_89(class126.byte_0, class126.int_0, class126.ushort_0, (ushort) 19);
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                class126.class29_0.method_89(class126.byte_0, class126.int_0, class126.ushort_0, (ushort) 49);
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                class126.class29_0.method_90(class126.byte_0, class126.int_0, class126.ushort_0, (ushort) 109, (byte) 2);
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                class126.class29_0.method_89(class126.byte_0, class126.int_0, class126.ushort_0, (ushort) 42);
                Thread.Sleep(1000);
                // ISSUE: reference to a compiler-generated field
                class126.class29_0.Class75_0 = (Class75) null;
                return false;
              }
              if (key2 == \u003CModule\u003E.smethod_9<string>(304734012U))
              {
                // ISSUE: reference to a compiler-generated method
                ThreadPool.QueueUserWorkItem(new WaitCallback(class126.method_1));
                return false;
              }
              if (key2 == \u003CModule\u003E.smethod_7<string>(4011628656U))
              {
                // ISSUE: reference to a compiler-generated field
                class126.class29_0.Class26_0.bool_29 = true;
                return false;
              }
              if (key2 == \u003CModule\u003E.smethod_7<string>(2991783392U))
              {
                // ISSUE: reference to a compiler-generated field
                class126.class29_0.Class26_0.bool_30 = true;
                return false;
              }
              string str4;
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              if (!class126.class29_0.Class26_0.bool_33 && class126.class29_0.Class26_0.dictionary_2.TryGetValue(key2, out str4))
              {
                int num11 = stringList.IndexOf(str4);
                if (num11 != int.MaxValue)
                {
                  // ISSUE: reference to a compiler-generated field
                  class126.class29_0.Class75_0.method_2((byte) (num11 + 1));
                }
              }
              else
              {
                string str5;
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                if (class126.class29_0.Class26_0.bool_33 && class126.class29_0.Class26_0.dictionary_3.TryGetValue(key2, out str5))
                {
                  int num12 = stringList.IndexOf(str5);
                  if (num12 != int.MaxValue)
                  {
                    // ISSUE: reference to a compiler-generated field
                    class126.class29_0.Class75_0.method_2((byte) (num12 + 1));
                  }
                }
              }
            }
          }
          // ISSUE: reference to a compiler-generated field
          if (class126.byte_0 == (byte) 2)
          {
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            class126.class29_0.Dictionary_6[key1] = class126.int_0;
          }
          // ISSUE: reference to a compiler-generated field
          if (!class126.class29_0.List_0.Contains(key1))
          {
            // ISSUE: reference to a compiler-generated field
            return !class126.class29_0.Boolean_10;
          }
          // ISSUE: reference to a compiler-generated field
          class126.class29_0.List_0.Remove(key1);
          return false;
        }
        // ISSUE: reference to a compiler-generated field
        class126.class29_0.Class75_0.method_4();
        return false;
      }
      // ISSUE: reference to a compiler-generated field
      class126.class29_0.Class75_0.method_1();
      return false;
    }
    // ISSUE: reference to a compiler-generated field
    class126.class29_0.Class75_0.method_2((byte) 1);
    return false;
  }

  private bool method_52([In] Class29 obj0, [In] Class100 obj1)
  {
    byte num1 = obj1.method_2();
    int num2 = (int) obj1.method_2();
    if (num1.Equals((byte) 2))
    {
      int num3 = (int) obj1.method_6();
      obj1.method_10();
      byte num4 = obj1.method_2();
      for (int index = 0; index < (int) num4; ++index)
      {
        obj1.method_1(1);
        int num5 = (int) obj1.method_6();
        obj1.method_10();
        int num6 = (int) obj1.method_2();
        int num7 = (int) obj1.method_2();
        obj1.method_10();
      }
    }
    if (num1.Equals((byte) 3))
    {
      int num8 = (int) obj1.method_6();
      int num9 = (int) obj1.method_2();
      obj1.method_10();
      int num10 = (int) obj1.method_2();
      int num11 = (int) obj1.method_2();
      obj1.method_10();
      obj1.method_11();
    }
    return true;
  }

  private bool method_53([In] Class29 obj0, Class100 string_7)
  {
    obj0.Boolean_5 = true;
    try
    {
      byte num1 = string_7.method_2();
      for (int index = 0; index < (int) num1; ++index)
      {
        Struct16 struct16 = new Struct16((short) string_7.method_2(), (short) string_7.method_2());
        bool flag = string_7.method_4();
        int num2 = (int) string_7.method_2();
        int int160 = (int) obj0.class88_0.Int16_0;
        int num3 = flag ? 1 : 0;
        Class91 class91 = new Class91(struct16, (short) int160, num3 != 0);
        if (!obj0.dictionary_12.ContainsKey(class91.Struct17_0))
          obj0.dictionary_12.Add(class91.Struct17_0, class91);
        else
          obj0.dictionary_12[class91.Struct17_0] = class91;
      }
    }
    catch
    {
    }
    return true;
  }

  private bool method_54([In] Class29 obj0, Class100 string_7)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class112.Class127 class127 = new Class112.Class127();
    bool flag1 = false;
    Struct16 object_0 = string_7.method_12();
    Direction direction = (Direction) string_7.method_2();
    int key = string_7.method_7();
    ushort num1 = string_7.method_6();
    bool flag2 = false;
    byte num2 = 0;
    byte num3 = 0;
    byte num4 = 0;
    byte num5 = 0;
    byte num6 = 0;
    byte num7 = 0;
    byte num8 = 0;
    byte num9 = 0;
    byte num10 = 0;
    byte num11 = 0;
    byte num12 = 0;
    ushort num13 = 0;
    ushort num14 = 0;
    ushort num15 = 0;
    ushort num16 = 0;
    ushort num17 = 0;
    ushort num18 = 0;
    ushort num19 = 0;
    ushort num20 = 0;
    byte num21;
    byte num22;
    if (num1 != ushort.MaxValue)
    {
      num2 = string_7.method_2();
      if (num2 == (byte) 0 && obj0.method_17(Enum0.SeeHidden) && !obj0.Boolean_0)
      {
        --string_7.Int32_0;
        string_7.method_14((byte) 80);
      }
      num13 = string_7.method_6();
      num3 = string_7.method_2();
      num14 = string_7.method_6();
      num4 = string_7.method_2();
      num15 = string_7.method_6();
      num21 = string_7.method_2();
      num22 = string_7.method_2();
      num5 = string_7.method_2();
      num16 = string_7.method_6();
      num6 = string_7.method_2();
      num17 = string_7.method_6();
      num7 = string_7.method_2();
      num18 = string_7.method_6();
      num8 = string_7.method_2();
      num9 = string_7.method_2();
      num19 = string_7.method_6();
      num10 = string_7.method_2();
      num11 = string_7.method_2();
      flag2 = string_7.method_4() || num2 == (byte) 0;
      num12 = string_7.method_2();
    }
    else
    {
      num20 = (ushort) ((uint) string_7.method_6() - 16384U);
      num21 = string_7.method_2();
      num22 = string_7.method_2();
      string_7.method_1(6);
    }
    byte num23 = string_7.method_2();
    // ISSUE: reference to a compiler-generated field
    class127.string_0 = string_7.method_10();
    string str = string_7.method_10();
    obj0.Dictionary_4[key] = new Struct17(obj0.class88_0.Int16_0, object_0);
    if (num2 == (byte) 0 && obj0.dictionary_1.ContainsKey(key) && obj0.method_17(Enum0.SeeHidden) && !obj0.Boolean_0)
    {
      // ISSUE: reference to a compiler-generated field
      string_7.Int32_0 -= class127.string_0.Length + str.Length + 3;
      num23 = (long) key == (long) obj0.UInt32_0 || num20 != (ushort) 0 ? num23 : (byte) 3;
      string_7.method_14(num23);
      string_7.method_22(obj0.dictionary_1[key].String_0);
      string_7.method_22(str);
    }
    // ISSUE: reference to a compiler-generated field
    Class143 class143_1 = new Class143(key, class127.string_0, object_0, obj0.class88_0, direction);
    char[] chArray = \u003CModule\u003E.smethod_5<char[]>(697458453U);
    if (string.IsNullOrEmpty(this.form5_0.string_1) && class143_1.String_5.ToArray<char>().Equals((object) chArray))
      obj0.method_59(class143_1.String_5, ((IEnumerable<IPAddress>) Dns.GetHostEntry(Dns.GetHostName()).AddressList).FirstOrDefault<IPAddress>((Func<IPAddress, bool>) (byte_0 => byte_0.AddressFamily == AddressFamily.InterNetwork))?.ToString());
    if (!string.IsNullOrEmpty(class143_1.String_5))
    {
      // ISSUE: reference to a compiler-generated method
      foreach (Class143 class143_2 in obj0.dictionary_1.Values.OfType<Class143>().Where<Class143>(new Func<Class143, bool>(class127.method_0)).ToList<Class143>())
      {
        if (class143_2.Int32_0 != key)
          obj0.dictionary_1.Remove(class143_2.Int32_0);
      }
    }
    if (obj0.dictionary_1.ContainsKey(key))
    {
      if (obj0.dictionary_1[key] is Class143)
      {
        Class143 class143_3 = obj0.dictionary_1[key] as Class143;
        class143_3.Struct16_0 = object_0;
        class143_3.Class88_0 = obj0.class88_0;
        class143_3.Direction_0 = direction;
        if (string.IsNullOrEmpty(class143_3.String_5))
        {
          // ISSUE: reference to a compiler-generated field
          class143_3.String_5 = class127.string_0;
        }
        class143_1 = class143_3;
      }
      else
        obj0.dictionary_1[key] = (Class139) class143_1;
    }
    else
    {
      obj0.dictionary_1[key] = (Class139) class143_1;
      // ISSUE: reference to a compiler-generated field
      if (string.IsNullOrEmpty(class127.string_0))
        obj0.method_78(key);
    }
    // ISSUE: reference to a compiler-generated field
    if (obj0.Class26_0.list_14.Contains<string>(class127.string_0, (IEqualityComparer<string>) StringComparer.OrdinalIgnoreCase))
      this.form5_0.method_1(class143_1.String_5, obj0);
    class143_1.UInt16_0 = num20;
    class143_1.Byte_2 = num2;
    class143_1.UInt16_2 = num13;
    class143_1.UInt16_3 = num14;
    class143_1.Byte_6 = num22;
    class143_1.Byte_10 = num8;
    class143_1.Byte_11 = num9;
    class143_1.Byte_12 = num10;
    class143_1.bool_1 = flag2;
    class143_1.Byte_15 = num23;
    class143_1.String_4 = str;
    // ISSUE: reference to a compiler-generated field
    if (num2 != (byte) 0 && (long) key != (long) obj0.UInt32_0 && obj0.Control2_0.checkBox_17.Checked && this.form5_0.dictionary_4.ContainsKey(class127.string_0) && !obj0.Boolean_0)
    {
      // ISSUE: reference to a compiler-generated field
      Class144 class144 = this.form5_0.dictionary_4[class127.string_0];
      class143_1.UInt16_1 = class144.UInt16_0;
      class143_1.Byte_3 = class144.Byte_0;
      class143_1.Byte_4 = class144.Byte_1;
      class143_1.UInt16_4 = class144.UInt16_1;
      class143_1.Byte_5 = class144.Byte_2;
      class143_1.Byte_7 = class144.Byte_3;
      class143_1.UInt16_5 = class144.UInt16_2;
      class143_1.Byte_8 = class144.Byte_4;
      class143_1.UInt16_6 = class144.UInt16_3;
      class143_1.Byte_9 = class144.Byte_5;
      class143_1.UInt16_7 = class144.UInt16_4;
      class143_1.UInt16_8 = class144.UInt16_5;
      class143_1.Byte_13 = class144.Byte_6;
      class143_1.Byte_14 = class144.Byte_7;
      flag1 = true;
    }
    else
    {
      class143_1.UInt16_1 = num1;
      class143_1.Byte_3 = num3;
      class143_1.Byte_4 = num4;
      class143_1.UInt16_4 = num15;
      class143_1.Byte_5 = num21;
      class143_1.Byte_7 = num5;
      class143_1.UInt16_5 = num16;
      class143_1.Byte_8 = num6;
      class143_1.UInt16_6 = num17;
      class143_1.Byte_9 = num7;
      class143_1.UInt16_7 = num18;
      class143_1.UInt16_8 = num19;
      class143_1.Byte_13 = num11;
      class143_1.Byte_14 = num12;
    }
    if (!obj0.hashSet_2.Contains(key))
      obj0.hashSet_2.Add(key);
    if (!string.IsNullOrEmpty(class143_1.String_5))
    {
      if (obj0.dictionary_4.ContainsKey(key))
        obj0.dictionary_4.Remove(key);
      obj0.Dictionary_7[class143_1.String_5] = class143_1;
      obj0.dictionary_2[class143_1.String_5] = class143_1;
      obj0.dictionary_3.Remove(class143_1.String_5);
    }
    else
      obj0.dictionary_4[key] = class143_1;
    if ((long) key == (long) obj0.UInt32_0)
    {
      obj0.Class143_0 = class143_1;
      obj0.Direction_1 = direction;
      obj0.struct16_1 = object_0;
      if (obj0.Boolean_9)
      {
        string_7.method_0();
        string_7.method_24(object_0);
        string_7.method_14((byte) direction);
        string_7.method_20((uint) key);
        string_7.method_18(ushort.MaxValue);
        string_7.method_18((ushort) ((uint) obj0.UInt16_0 + 16384U));
        string_7.method_14(num21);
        string_7.method_14(num22);
        string_7.method_13(new byte[6]);
        string_7.method_14(num23);
        // ISSUE: reference to a compiler-generated field
        string_7.method_22(class127.string_0);
        string_7.method_22(str);
      }
    }
    if (obj0.Control2_0 != null)
      obj0.Control2_0.method_23();
    if ((long) key == (long) obj0.UInt32_0 && !obj0.bool_31)
    {
      string path = Settings.Default.DarkAgesPath.Replace(\u003CModule\u003E.smethod_5<string>(197665510U), obj0.String_0 + \u003CModule\u003E.smethod_5<string>(2743897532U));
      if (System.IO.File.Exists(path))
      {
        obj0.Control2_0.checkBox_18.Checked = true;
        List<string> list = ((IEnumerable<string>) System.IO.File.ReadAllLines(path)).ToList<string>();
        int num24 = 0;
        foreach (NumericUpDown numericUpDown in obj0.Control2_0.groupBox_23.Controls.OfType<NumericUpDown>())
        {
          int result;
          int.TryParse(list[num24++], out result);
          Decimal num25 = (Decimal) result;
          numericUpDown.Value = num25;
        }
        CheckBox checkBox19 = obj0.Control2_0.checkBox_19;
        List<string> stringList = list;
        int index1 = num24;
        int index2 = index1 + 1;
        int num26 = Convert.ToBoolean(stringList[index1]) ? 1 : 0;
        checkBox19.Checked = num26 != 0;
        try
        {
          if (Convert.ToBoolean(list[index2]))
            obj0.Control2_0.checkBox_20.Checked = Convert.ToBoolean(list[index2]);
        }
        catch
        {
        }
      }
      obj0.bool_31 = true;
    }
    if (obj0.Class26_0.bool_19 && class143_1 != obj0.Class143_0 && (class143_1.Class88_0.String_0 == \u003CModule\u003E.smethod_7<string>(3924805523U) || class143_1.Class88_0.String_0 == \u003CModule\u003E.smethod_8<string>(3354885354U) || class143_1.Class88_0.String_0 == \u003CModule\u003E.smethod_9<string>(2454933706U)))
    {
      class143_1.Double_0 = 0.0;
      class143_1.String_1 = "";
    }
    if ((long) key == (long) obj0.UInt32_0 && obj0.Control2_0.checkBox_20.Checked && !obj0.bool_47)
    {
      obj0.method_66(obj0.Class143_0);
      return false;
    }
    if (obj0.Control2_0.checkBox_17.Checked)
    {
      Class180 stream_1 = new Class180(Enum14.DMURequest);
      stream_1.method_27(class143_1.String_5);
      this.form5_0.class178_0.method_2(stream_1);
    }
    // ISSUE: reference to a compiler-generated field
    if ((long) key != (long) obj0.UInt32_0 && !string.IsNullOrEmpty(class127.string_0) && obj0?.Control2_0?.tabControl_1.SelectedTab == obj0.Control2_0.tabPage_11 && obj0.Control2_0.tabControl_2.SelectedTab == obj0.Control2_0.tabPage_9)
      obj0.Control2_0.method_32(class143_1);
    if (!flag1 || num2 == (byte) 0 || obj0.bool_47)
      return true;
    obj0.method_66(class143_1);
    return false;
  }

  private bool method_55([In] Class29 obj0, Class100 string_7)
  {
    bool flag1 = false;
    int num1 = string_7.method_7();
    ushort[] numArray1 = new ushort[18];
    byte[] numArray2 = new byte[18];
    for (int index = 0; index < 18; ++index)
    {
      numArray1[index] = string_7.method_6();
      numArray2[index] = string_7.method_2();
    }
    byte num2 = string_7.method_2();
    string key = string_7.method_10();
    try
    {
      byte num3 = string_7.method_2();
      string str1 = string_7.method_10();
      bool flag2 = string_7.method_4();
      string str2 = string_7.method_10();
      string str3 = string_7.method_10();
      string str4 = string_7.method_10();
      byte length = string_7.method_2();
      byte[] numArray3 = new byte[(int) length];
      byte[] numArray4 = new byte[(int) length];
      string[] strArray1 = new string[(int) length];
      string[] strArray2 = new string[(int) length];
      for (int index = 0; index < (int) length; ++index)
      {
        numArray3[index] = string_7.method_2();
        numArray4[index] = string_7.method_2();
        int int320_1 = string_7.Int32_0;
        strArray1[index] = string_7.method_10();
        int int320_2 = string_7.Int32_0;
        strArray2[index] = string_7.method_10();
        if (strArray2[index].Length > 70 || strArray1[index].Length > 70)
          flag1 = true;
      }
      if (flag1)
      {
        Class100 class100 = new Class100((byte) 52);
        class100.method_19(num1);
        for (int index = 0; index < 18; ++index)
        {
          class100.method_18(numArray1[index]);
          class100.method_14(numArray2[index]);
        }
        class100.method_14(num2);
        class100.method_22(key);
        class100.method_14(num3);
        class100.method_22(str1);
        class100.method_16(flag2);
        class100.method_22(str2);
        class100.method_22(str3);
        class100.method_22(str4);
        class100.method_14(length);
        for (int index = 0; index < (int) length; ++index)
        {
          class100.method_14(numArray3[index]);
          class100.method_14(numArray4[index]);
          class100.method_22(strArray1[index].Substring(0, Math.Min(70, strArray1[index].Length)));
          class100.method_22(strArray2[index].Substring(0, Math.Min(70, strArray2[index].Length)));
        }
        obj0.method_4(new Class98[1]{ (Class98) class100 });
      }
    }
    catch
    {
      return true;
    }
    if (!obj0.dictionary_1.ContainsKey(num1) || obj0.Dictionary_7.ContainsKey(key) && obj0.Dictionary_7[key].Int32_0 == num1)
      return !flag1;
    Class143 class142_1 = obj0.dictionary_1[num1] as Class143;
    if (string.IsNullOrEmpty(class142_1.String_5))
    {
      class142_1.String_5 = key;
      obj0.dictionary_1[num1] = (Class139) class142_1;
      if (!obj0.Dictionary_7.ContainsKey(key))
        obj0.Dictionary_7.Add(key, class142_1);
      if (!obj0.Dictionary_1.ContainsKey(key))
        obj0.Dictionary_1.Add(key, class142_1);
      if (obj0.dictionary_4.ContainsKey(class142_1.Int32_0))
        obj0.dictionary_4.Remove(class142_1.Int32_0);
      if (obj0.Class26_0.list_14.Contains<string>(key, (IEqualityComparer<string>) StringComparer.OrdinalIgnoreCase))
        this.form5_0.method_1(key, obj0);
    }
    if (obj0.method_131((Class140) class142_1, 12))
    {
      obj0.Control2_0.method_23();
      obj0.method_66(class142_1);
    }
    return false;
  }

  private bool method_56(Class29 object_0, [In] Class100 obj1)
  {
    HashSet<string> stringSet = new HashSet<string>();
    int num1 = (int) obj1.method_5();
    short num2 = obj1.method_5();
    for (short index = 0; (int) index < (int) num2; ++index)
    {
      int num3 = (int) obj1.method_2();
      int num4 = (int) obj1.method_2();
      int num5 = (int) obj1.method_2();
      string str = obj1.method_10();
      obj1.method_4();
      string upper = obj1.method_10().ToUpper();
      if (!object_0.Control2_0.checkBox_21.Checked && object_0.Class26_0.list_14.Contains(upper))
      {
        int int320 = obj1.Int32_0;
        obj1.Int32_0 -= 5 + str.Length + upper.Length;
        obj1.method_14((byte) 2);
        obj1.Int32_0 = int320;
      }
      stringSet.Add(upper);
    }
    if (!object_0.Control2_0.checkBox_69.Checked)
      return true;
    foreach (string str1 in object_0.Class26_0.list_14)
    {
      if (stringSet.Contains(str1))
      {
        string str2 = AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_8<string>(260211318U);
        System.IO.File.WriteAllText(str2, \u003CModule\u003E.smethod_5<string>(3045749581U) + DateTime.UtcNow.ToLocalTime().ToString() + \u003CModule\u003E.smethod_7<string>(2802076831U) + str1 + \u003CModule\u003E.smethod_8<string>(1460504578U));
        Process.Start(str2);
        foreach (Class29 class29 in this.IEnumerable_0)
        {
          Control2 control20 = class29.Control2_0;
          if ((control20 != null ? (control20.checkBox_69.Checked ? 1 : 0) : 0) != 0)
            class29.method_6(false);
        }
        object_0.method_6(false);
      }
    }
    return false;
  }

  private bool method_57(Class29 ipaddress_0, [In] Class100 obj1)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class112.Class128 class128 = new Class112.Class128();
    byte index = obj1.method_2();
    ushort num1 = obj1.method_6();
    byte num2 = obj1.method_2();
    // ISSUE: reference to a compiler-generated field
    class128.string_0 = obj1.method_10();
    int num3 = (int) obj1.method_2();
    int num4 = obj1.method_7();
    int num5 = obj1.method_7();
    // ISSUE: reference to a compiler-generated field
    Class76 class76 = new Class76(index, num1, num2, class128.string_0, 1, num4, num5);
    ipaddress_0.Class76_0[(int) index] = class76;
    // ISSUE: reference to a compiler-generated method
    if (ipaddress_0.list_4.Any<Class24>(new Func<Class24, bool>(class128.method_0)))
    {
      class76.Boolean_0 = true;
      // ISSUE: reference to a compiler-generated method
      class76.Class24_0 = ipaddress_0.list_4.First<Class24>(new Func<Class24, bool>(class128.method_1));
    }
    else
    {
      // ISSUE: reference to a compiler-generated method
      if (ipaddress_0.list_6.Any<Class10>(new Func<Class10, bool>(class128.method_2)))
      {
        class76.Boolean_1 = true;
        // ISSUE: reference to a compiler-generated method
        class76.Class10_0 = ipaddress_0.list_6.First<Class10>(new Func<Class10, bool>(class128.method_3));
      }
    }
    return true;
  }

  private bool method_58(Class29 class143_0, [In] Class100 obj1)
  {
    byte index = obj1.method_2();
    if (index == (byte) 2)
      class143_0.string_6 = class143_0.Class76_0[(int) index].String_0;
    class143_0.Class76_0[(int) index] = (Class76) null;
    return true;
  }

  private bool method_59(Class29 object_0, [In] Class100 obj1)
  {
    if (object_0.Class26_0.control3_0 != null)
    {
      foreach (string str in object_0.HashSet_3)
      {
        if ((object_0.Class26_0.control3_1 == null || this.method_75(str) == null) && object_0.Class26_0.method_44(str))
          object_0.Class26_0.method_43(str);
      }
    }
    int num1 = (int) obj1.method_2();
    obj1.method_10();
    obj1.method_10();
    string str1 = obj1.method_10();
    obj1.method_4();
    if (obj1.method_4())
    {
      obj1.method_10();
      obj1.method_10();
      obj1.method_1(13);
    }
    int num2 = (int) obj1.method_2();
    obj1.method_1(2);
    switch (num2)
    {
      case 0:
        object_0.method_11(TemClass.Peasant);
        break;
      case 1:
        object_0.method_11(TemClass.Warrior);
        break;
      case 2:
        object_0.method_11(TemClass.Rogue);
        break;
      case 3:
        object_0.method_11(TemClass.Wizard);
        break;
      case 4:
        object_0.method_11(TemClass.Priest);
        break;
      case 5:
        object_0.method_11(TemClass.Monk);
        break;
    }
    string string_1 = obj1.method_10();
    if (string_1 != null)
      this.method_90(object_0, string_1);
    string str2 = obj1.method_10();
    byte num3 = obj1.method_2();
    for (int index = 0; index < (int) num3; ++index)
    {
      int num4 = (int) obj1.method_2();
      int num5 = (int) obj1.method_2();
      string str3 = obj1.method_10();
      if (str3 != null && str3.StartsWith(\u003CModule\u003E.smethod_9<string>(425556809U)))
        this.method_89(object_0, str3);
      if (str3 != null && str3.StartsWith(\u003CModule\u003E.smethod_8<string>(4021568757U)))
        this.method_88(object_0, str3);
      if (str3 != null && str3.Equals(\u003CModule\u003E.smethod_9<string>(4034083181U)))
        object_0.bool_42 = false;
      obj1.method_10();
    }
    object_0.Enum6_0 = (Enum6) num1;
    object_0.hashSet_4.Clear();
    if (str1.StartsWith(\u003CModule\u003E.smethod_8<string>(1407012025U)))
    {
      string str4 = str1;
      char[] chArray = new char[1]{ '\n' };
      foreach (string str5 in str4.Split(chArray))
      {
        if (str5.StartsWith(\u003CModule\u003E.smethod_6<string>(1394334923U)) || str5.StartsWith(\u003CModule\u003E.smethod_9<string>(2965052878U)))
        {
          string str6 = str5.Substring(2);
          if (str6 != object_0.String_0)
            object_0.hashSet_4.Add(str6);
        }
      }
    }
    object_0.String_1 = str2;
    object_0.Control2_0.method_27();
    object_0.Control2_0.method_23();
    object_0.Control2_0.method_26();
    object_0.Control2_0.method_41();
    object_0.Control2_0.method_40();
    if (object_0.Class26_0.control3_0 != null)
      object_0.Control2_0.method_9();
    if (this.form5_0.string_1.Equals(\u003CModule\u003E.smethod_7<string>(1221832026U)))
      object_0.Control2_0.checkBox_1.Enabled = true;
    if (!object_0.Control2_0.checkBox_20.Checked)
      return true;
    object_0.method_66(object_0.Class143_0);
    return true;
  }

  private bool method_60(Class29 object_0, [In] Class100 obj1)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class112.Class129 class129 = new Class112.Class129();
    // ISSUE: reference to a compiler-generated field
    class129.class29_0 = object_0;
    ushort num = obj1.method_6();
    if (obj1.method_2() == (byte) 0)
    {
      // ISSUE: reference to a compiler-generated field
      if (class129.class29_0.HashSet_0.Contains(num))
      {
        // ISSUE: reference to a compiler-generated field
        class129.class29_0.HashSet_0.Remove(num);
        // ISSUE: reference to a compiler-generated field
        if (num == (ushort) 19 && !class129.class29_0.Boolean_0)
        {
          // ISSUE: reference to a compiler-generated method
          ThreadPool.QueueUserWorkItem(new WaitCallback(class129.method_0));
        }
      }
    }
    else
    {
      // ISSUE: reference to a compiler-generated field
      if (!class129.class29_0.HashSet_0.Contains(num))
      {
        // ISSUE: reference to a compiler-generated field
        class129.class29_0.HashSet_0.Add(num);
      }
    }
    return true;
  }

  private bool method_61(Class29 object_0, [In] Class100 obj1)
  {
    byte num1 = obj1.method_2();
    byte num2 = obj1.method_2();
    Class99 class99 = new Class99((byte) 69);
    class99.method_14(num2);
    class99.method_14(num1);
    object_0.method_4(new Class98[1]{ (Class98) class99 });
    return false;
  }

  private bool method_62(Class29 class142_0, [In] Class100 obj1)
  {
    short num = obj1.method_5();
    string path = Class106.smethod_2(System.Environment.SpecialFolder.CommonApplicationData, \u003CModule\u003E.smethod_5<string>(2311114395U), new object[1]
    {
      (object) class142_0.class88_0.Int16_0
    });
    FileStream output = System.IO.File.Open(path, FileMode.OpenOrCreate, FileAccess.Write, FileShare.Read);
    output.Seek((long) ((int) class142_0.class88_0.Byte_0 * 6 * (int) num), SeekOrigin.Begin);
    BinaryWriter binaryWriter = new BinaryWriter((Stream) output);
    for (short index = 0; (int) index < (int) class142_0.class88_0.Byte_0; ++index)
    {
      binaryWriter.Write(obj1.method_5());
      binaryWriter.Write(obj1.method_5());
      binaryWriter.Write(obj1.method_5());
    }
    binaryWriter.Close();
    if ((int) num == (int) class142_0.class88_0.Byte_1 - 1)
    {
      byte[] numArray = System.IO.File.ReadAllBytes(path);
      if ((int) Class74.smethod_0(numArray) == (int) class142_0.class88_0.UInt16_0)
        class142_0.class88_0.method_0(numArray);
    }
    return true;
  }

  private bool method_63(Class29 string_2, [In] Class100 obj1)
  {
    int num1 = (int) obj1.method_2();
    byte intptr_0 = obj1.method_2();
    uint num2 = obj1.method_8();
    if (num1 == 0)
    {
      Class134 class134 = string_2.Class136_0[intptr_0];
      if (class134 != null)
      {
        class134.DateTime_1 = DateTime.UtcNow;
        class134.Double_0 = (double) num2;
      }
    }
    else
    {
      Class132 class132 = string_2.Class133_0[intptr_0];
      if (class132 != null)
      {
        class132.DateTime_1 = DateTime.UtcNow;
        class132.Double_0 = (double) num2;
      }
    }
    return true;
  }

  private bool method_64(Class29 class24_0, [In] Class100 obj1) => true;

  private bool method_65(Class29 class10_0, [In] Class100 obj1)
  {
    if (class10_0.bool_48)
      class10_0.bool_46 = true;
    return true;
  }

  private bool method_66(Class29 object_0, [In] Class100 obj1)
  {
    if (obj1.method_2() != (byte) 1)
      return true;
    string s = Regex.Replace(Regex.Replace(Regex.Replace(Regex.Replace(\u003CModule\u003E.smethod_6<string>(2019592814U), \u003CModule\u003E.smethod_9<string>(1426949069U), \u003CModule\u003E.smethod_9<string>(2289711745U)), \u003CModule\u003E.smethod_5<string>(2506320005U), \u003CModule\u003E.smethod_7<string>(2276460318U)), \u003CModule\u003E.smethod_7<string>(2002776269U), \u003CModule\u003E.smethod_7<string>(304686983U)), \u003CModule\u003E.smethod_7<string>(3259226530U), \u003CModule\u003E.smethod_5<string>(2184947395U)) + System.Environment.NewLine + System.Environment.NewLine + \u003CModule\u003E.smethod_5<string>(3573753479U);
    byte[] array = Class71.smethod_0(new MemoryStream(Encoding.GetEncoding(949).GetBytes(s)).ToArray()).ToArray();
    Class100 class100 = new Class100((byte) 96);
    class100.method_14((byte) 1);
    class100.method_17((short) array.Length);
    class100.method_25((Array) array);
    object_0.method_4(new Class98[1]{ (Class98) class100 });
    return false;
  }

  private bool method_67(Class29 object_0, [In] Class100 obj1)
  {
    if (obj1.method_2() != (byte) 3)
      return true;
    Class100 class100 = new Class100((byte) 102);
    class100.method_14((byte) 4);
    obj1.method_14((byte) 1);
    object_0.method_4(new Class98[1]{ (Class98) class100 });
    return true;
  }

  private bool method_68(Class29 class29_0, [In] Class100 obj1)
  {
    class29_0.Boolean_6 = true;
    return true;
  }

  private bool method_69(Class29 object_0, [In] Class100 obj1)
  {
    int specialFolder_0 = obj1.method_7();
    Class99 class99 = new Class99((byte) 117);
    class99.method_19(specialFolder_0);
    class99.method_19(System.Environment.TickCount);
    object_0.method_4(new Class98[1]{ (Class98) class99 });
    return false;
  }

  private bool method_70(Class29 class24_0, [In] Class100 obj1)
  {
    if (obj1.method_4())
    {
      short num1 = obj1.method_5();
      for (int index = 0; index < (int) num1; ++index)
      {
        string path3 = obj1.method_10();
        uint num2 = obj1.method_8();
        if (!Directory.Exists(Settings.Default.DataPath))
          Directory.CreateDirectory(Settings.Default.DataPath);
        string path1 = Path.Combine(Settings.Default.DataPath, \u003CModule\u003E.smethod_7<string>(923184333U), path3);
        if (System.IO.File.Exists(path1))
        {
          string path2 = Class106.smethod_2(System.Environment.SpecialFolder.CommonApplicationData, \u003CModule\u003E.smethod_5<string>(435727579U), new object[1]
          {
            (object) path3
          });
          Class71.smethod_3(path1, path2);
          if ((int) Class73.smethod_0(System.IO.File.ReadAllBytes(path2)) == ~(int) num2)
            this.method_74(Class96.smethod_0(path2));
          else
            System.IO.File.Delete(path2);
        }
      }
    }
    else
    {
      string str1 = obj1.method_10();
      int num3 = (int) obj1.method_8();
      ushort num4 = obj1.method_6();
      byte[] bytes = obj1.method_1((int) num4);
      string str2 = Class106.smethod_2(System.Environment.SpecialFolder.CommonApplicationData, \u003CModule\u003E.smethod_7<string>(2086753757U), new object[1]
      {
        (object) str1
      });
      System.IO.File.WriteAllBytes(str2 + \u003CModule\u003E.smethod_7<string>(3153497457U), bytes);
      Class71.smethod_3(str2 + \u003CModule\u003E.smethod_8<string>(741644295U), str2);
      System.IO.File.Delete(str2 + \u003CModule\u003E.smethod_9<string>(3328796173U));
      this.method_74(Class96.smethod_0(str2));
    }
    return true;
  }

  internal void method_71(int class10_0)
  {
    if (this.bool_0)
      return;
    this.bool_0 = true;
    this.Int32_0 = class10_0;
    this.socket_0.Bind((EndPoint) new IPEndPoint(IPAddress.Loopback, class10_0));
    this.socket_0.Listen(10);
    this.socket_0.BeginAccept(new AsyncCallback(this.method_73), (object) null);
    this.thread_0.Start();
  }

  private void method_72()
  {
    Thread.GetDomain().UnhandledException += new UnhandledExceptionEventHandler(Class106.smethod_0);
    if (System.IO.File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + \u003CModule\u003E.smethod_7<string>(2662114351U)).Length != 32)
    {
      this.thread_0.Abort();
    }
    else
    {
      while (this.bool_0)
      {
        foreach (Class29 class29 in this.IEnumerable_0)
        {
          try
          {
            if (class29?.Control2_0?.toolStripMenuItem_2?.Text == \u003CModule\u003E.smethod_5<string>(3838461908U) && class29.Control2_0.checkBox_69.Checked)
            {
              lock (class29.object_1)
                class29.method_4(new Class98[1]
                {
                  (Class98) new Class99((byte) 24)
                });
            }
            if (Settings.Default.EnableKom)
            {
              Struct16 struct16 = new Struct16(39, 40);
              if (!string.IsNullOrEmpty(class29?.String_0))
              {
                short? int160 = class29.class88_0?.Int16_0;
                int? nullable = int160.HasValue ? new int?((int) int160.GetValueOrDefault()) : new int?();
                if (nullable.GetValueOrDefault() == 10055 & nullable.HasValue && !class29.Class26_0.method_38() && class29.Struct16_1.method_0(struct16) <= 18 && class29.method_26(\u003CModule\u003E.smethod_8<string>(154541885U)) != 52)
                {
                  for (int index = class29.method_26(\u003CModule\u003E.smethod_7<string>(3728858051U)); index < 52; ++index)
                    class29.method_58(\u003CModule\u003E.smethod_5<string>(1033718838U));
                  class29.method_58(\u003CModule\u003E.smethod_5<string>(2854823517U));
                }
              }
            }
            if (DateTime.UtcNow.Subtract(class29.Control2_0.dateTime_0).TotalSeconds > 60.0)
            {
              class29.Control2_0.method_1();
              class29.Control2_0.dateTime_0 = DateTime.UtcNow;
            }
          }
          catch
          {
          }
        }
        Thread.Sleep(5000);
      }
    }
  }

  private void method_73(IAsyncResult class10_0)
  {
    Thread thread0 = this.form5_0.class178_0.thread_0;
    if ((thread0 != null ? (!thread0.IsAlive ? 1 : 0) : 1) != 0)
      return;
    try
    {
      Class29 class29 = new Class29(this, this.socket_0.EndAccept(class10_0));
      class29.method_5((EndPoint) this.ipendPoint_0);
      this.ipendPoint_0 = new IPEndPoint(IPAddress.Parse(\u003CModule\u003E.smethod_6<string>(4110972463U)), 2610);
      this.socket_0.BeginAccept(new AsyncCallback(this.method_73), (object) null);
      this.list_2.Add(class29);
    }
    catch
    {
    }
  }

  private void method_74(Class96 object_0)
  {
    this.Dictionary_1[object_0.String_0] = object_0;
    if (!object_0.String_0.StartsWith(\u003CModule\u003E.smethod_8<string>(3969391877U)))
      return;
    foreach (Class97 class97 in object_0.List_0)
      this.Dictionary_2[class97.String_0] = class97;
  }

  internal Class29 method_75(string class29_0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class112.Class130 class130 = new Class112.Class130();
    // ISSUE: reference to a compiler-generated field
    class130.string_0 = class29_0;
    try
    {
      // ISSUE: reference to a compiler-generated method
      return this.IEnumerable_0.FirstOrDefault<Class29>(new Func<Class29, bool>(class130.method_0));
    }
    catch
    {
      return (Class29) null;
    }
  }

  internal List<Class29> method_76(Class29 class29_1)
  {
    List<Class29> source = new List<Class29>();
    bool flag = false;
    try
    {
      int count;
      do
      {
        count = source.Count;
        foreach (Class29 class29 in this.IEnumerable_0)
        {
          // ISSUE: object of a compiler-generated type is created
          // ISSUE: variable of a compiler-generated type
          Class112.Class131 class131 = new Class112.Class131();
          // ISSUE: reference to a compiler-generated field
          class131.class29_0 = class29;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated method
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          if (class131.class29_0.Control2_0 != null && !class131.class29_0.String_0.Contains(\u003CModule\u003E.smethod_8<string>(688151742U)) && class131.class29_0.Control2_0.checkBox_68.Checked && (flag ? (source.Any<Class29>(new Func<Class29, bool>(class131.method_0)) ? 1 : 0) : (class131.class29_0.Control2_0.textBox_17.Text.ToUpper() == class29_1.String_0.ToUpper() ? 1 : 0)) != 0 && !source.Contains(class131.class29_0))
          {
            // ISSUE: reference to a compiler-generated field
            source.Add(class131.class29_0);
            flag = true;
          }
        }
      }
      while (count != source.Count);
    }
    catch
    {
      return new List<Class29>();
    }
    return source;
  }

  internal void method_77(bool object_0)
  {
    if (!this.bool_0)
      return;
    this.bool_0 = false;
    this.socket_0.Close();
    Class29[] array = new Class29[this.list_2.Count];
    this.list_2.CopyTo(array);
    foreach (Class29 class29 in array)
    {
      this.form5_0.method_3(class29);
      class29.method_6(object_0);
    }
    if (!object_0)
      return;
    this.thread_0.Join(1000);
    if (!this.thread_0.IsAlive)
      return;
    this.thread_0.Abort();
  }

  private void method_78() => this.method_79();

  internal void method_79()
  {
    BinaryReader binaryReader = new BinaryReader((Stream) new MemoryStream(Class9.Byte_2));
    binaryReader.ReadInt32();
    short num1 = binaryReader.ReadInt16();
    for (int index1 = 0; index1 < (int) num1; ++index1)
    {
      Class94 class94 = new Class94(binaryReader.ReadString(), Array.Empty<Class95>());
      byte num2 = binaryReader.ReadByte();
      for (int index2 = 0; index2 < (int) num2; ++index2)
      {
        short num3 = binaryReader.ReadInt16();
        short byte_5_1 = binaryReader.ReadInt16();
        string enum7_1 = binaryReader.ReadString();
        short count = binaryReader.ReadInt16();
        byte num4 = binaryReader.ReadByte();
        byte byte_5_2 = binaryReader.ReadByte();
        class94.List_0.Add(new Class95(new Struct16(num3, byte_5_1), enum7_1, count, new Struct16((short) num4, (short) byte_5_2)));
      }
      this.Dictionary_4[class94.method_0()] = class94;
    }
    short num5 = binaryReader.ReadInt16();
    for (int index3 = 0; index3 < (int) num5; ++index3)
    {
      try
      {
        short key1 = binaryReader.ReadInt16();
        byte struct16_0 = binaryReader.ReadByte();
        byte bool_1 = binaryReader.ReadByte();
        string str = binaryReader.ReadString();
        byte short_0 = binaryReader.ReadByte();
        sbyte num6 = binaryReader.ReadSByte();
        Class93 class93 = new Class93(key1, struct16_0, bool_1, short_0, str, num6);
        short num7 = binaryReader.ReadInt16();
        for (int index4 = 0; index4 < (int) num7; ++index4)
        {
          byte class142_0 = binaryReader.ReadByte();
          byte byte_5 = binaryReader.ReadByte();
          short num8 = binaryReader.ReadInt16();
          byte num9 = binaryReader.ReadByte();
          byte num10 = binaryReader.ReadByte();
          Class92 class92 = new Class92(class142_0, byte_5, num9, num10, key1, num8);
          class93.Dictionary_1[new Struct16((short) class142_0, (short) byte_5)] = class92;
        }
        byte num11 = binaryReader.ReadByte();
        for (int index5 = 0; index5 < (int) num11; ++index5)
        {
          byte num12 = binaryReader.ReadByte();
          byte byte_5 = binaryReader.ReadByte();
          uint key2 = binaryReader.ReadUInt32();
          if (this.Dictionary_4.ContainsKey(key2))
            class93.Dictionary_2[new Struct16((short) num12, (short) byte_5)] = this.Dictionary_4[key2];
        }
        this.dictionary_1.Add(key1, class93);
      }
      catch
      {
      }
    }
    binaryReader.Close();
  }

  internal void method_80([In] string obj0)
  {
    lock (Class112.object_0)
    {
      using (BinaryWriter binaryWriter = new BinaryWriter((Stream) System.IO.File.Create(obj0)))
      {
        binaryWriter.Write(1);
        binaryWriter.Write((short) this.Dictionary_4.Count);
        foreach (Class94 class94 in this.Dictionary_4.Values)
        {
          binaryWriter.Write(class94.String_0);
          binaryWriter.Write((byte) class94.List_0.Count);
          foreach (Class95 class95 in class94.List_0)
          {
            binaryWriter.Write(class95.Struct16_0.short_0);
            binaryWriter.Write(class95.Struct16_0.short_1);
            binaryWriter.Write(class95.String_0);
            binaryWriter.Write(class95.Int16_0);
            binaryWriter.Write((byte) class95.Struct16_1.short_0);
            binaryWriter.Write((byte) class95.Struct16_1.short_1);
          }
        }
        binaryWriter.Write((short) this.dictionary_1.Count);
        foreach (Class93 class93 in this.dictionary_1.Values)
        {
          binaryWriter.Write(class93.Int16_0);
          binaryWriter.Write(class93.Byte_0);
          binaryWriter.Write(class93.Byte_1);
          binaryWriter.Write(class93.String_0);
          binaryWriter.Write(class93.Byte_2);
          binaryWriter.Write(class93.SByte_0);
          binaryWriter.Write((short) class93.Dictionary_1.Count);
          foreach (Class92 class92 in class93.Dictionary_1.Values)
          {
            binaryWriter.Write(class92.Byte_0);
            binaryWriter.Write(class92.Byte_1);
            binaryWriter.Write(class92.Int16_0);
            binaryWriter.Write(class92.Byte_2);
            binaryWriter.Write(class92.Byte_3);
          }
          binaryWriter.Write((byte) class93.Dictionary_2.Count);
          foreach (KeyValuePair<Struct16, Class94> keyValuePair in class93.Dictionary_2)
          {
            binaryWriter.Write((byte) keyValuePair.Key.short_0);
            binaryWriter.Write((byte) keyValuePair.Key.short_1);
            binaryWriter.Write(keyValuePair.Value.method_0());
          }
        }
      }
    }
  }

  private void method_81(Class29 client)
  {
    client.bool_38 = true;
    Thread.Sleep(1500);
    client.bool_37 = false;
    client.bool_38 = false;
  }

  private void method_82([In] Class29 obj0, int packet, [In] bool obj2)
  {
    try
    {
      if (obj2)
        Thread.Sleep(3000);
      foreach (Class29 class29 in this.IEnumerable_0)
      {
        Class139 class139;
        if (class29.Dictionary_0.TryGetValue(packet, out class139) && class139 is Class142 class142)
          this.method_87(obj0, class142, false);
      }
    }
    catch
    {
    }
  }

  private void method_83([In] Class29 obj0, [In] int obj1, string callback)
  {
    if (obj0.class88_0.String_0.Contains(\u003CModule\u003E.smethod_6<string>(1012027685U)))
      return;
    try
    {
      foreach (Class29 class29 in this.IEnumerable_0)
      {
        if (class29.dictionary_1.ContainsKey(obj1) && class29.dictionary_1[obj1] is Class142)
        {
          if (!(class29.dictionary_1[obj1] is Class142 class142))
            break;
          class142.Double_0 = Class134.smethod_0(callback);
          class142.DateTime_1 = DateTime.UtcNow;
          class142.String_1 = callback;
        }
        else
        {
          if (!(obj0.Dictionary_0[obj1] is Class142 class142_1))
            break;
          Class142 class142_2 = new Class142(class142_1.Int32_0, new StringBuilder(class142_1.String_0).ToString(), class142_1.UInt16_0, class142_1.Byte_0, class142_1.Struct16_0, class142_1.Class88_0, class142_1.Direction_0)
          {
            Double_0 = Class134.smethod_0(callback),
            DateTime_1 = DateTime.UtcNow,
            String_1 = callback
          };
          class29.dictionary_1[obj1] = (Class139) class142_2;
        }
      }
    }
    catch
    {
    }
  }

  private void method_84(Class29 object_0, int intptr_0, [In] double obj2)
  {
    if (object_0.class88_0.String_0.Contains(\u003CModule\u003E.smethod_7<string>(731364955U)))
      return;
    try
    {
      foreach (Class29 class29 in this.IEnumerable_0)
      {
        if (class29.dictionary_1.ContainsKey(intptr_0))
        {
          if (!(class29.dictionary_1[intptr_0] is Class142 class142))
            break;
          class142.Double_1 = obj2;
          class142.DateTime_2 = DateTime.UtcNow;
        }
        else
        {
          if (!(object_0.dictionary_1[intptr_0] is Class142 class142_1))
            break;
          Class142 class142_2 = new Class142(class142_1.Int32_0, new StringBuilder(class142_1.String_0).ToString(), class142_1.UInt16_0, class142_1.Byte_0, class142_1.Struct16_0, class142_1.Class88_0, class142_1.Direction_0)
          {
            Double_1 = obj2,
            DateTime_2 = DateTime.UtcNow
          };
          class29.dictionary_1[intptr_0] = (Class139) class142_2;
        }
      }
    }
    catch
    {
    }
  }

  private void method_85([In] Class29 obj0, int packet, [In] string obj2)
  {
    if (obj0.class88_0.String_0.Contains(\u003CModule\u003E.smethod_9<string>(3679028607U)))
      return;
    try
    {
      foreach (Class29 class29 in this.IEnumerable_0)
      {
        if (class29.dictionary_1.ContainsKey(packet) && class29.dictionary_1[packet] is Class142)
        {
          if (!(class29.dictionary_1[packet] is Class142 class142))
            break;
          class142.String_2 = obj2;
          class142.Double_3 = Class134.smethod_0(obj2);
          class142.DateTime_5 = DateTime.UtcNow;
        }
        else
        {
          if (!(obj0.Dictionary_0[packet] is Class142 class142_1))
            break;
          Class142 class142_2 = new Class142(class142_1.Int32_0, new StringBuilder(class142_1.String_0).ToString(), class142_1.UInt16_0, class142_1.Byte_0, class142_1.Struct16_0, class142_1.Class88_0, class142_1.Direction_0)
          {
            String_2 = obj2,
            Double_3 = Class134.smethod_0(obj2),
            DateTime_5 = DateTime.UtcNow
          };
          class29.dictionary_1[packet] = (Class139) class142_2;
        }
      }
    }
    catch
    {
    }
  }

  private void method_86([In] Class29 obj0, [In] int obj1, byte callback)
  {
    if (obj0.class88_0.String_0.Contains(\u003CModule\u003E.smethod_9<string>(3679028607U)))
      return;
    try
    {
      foreach (Class29 class29 in this.IEnumerable_0)
      {
        short? int160 = class29.class88_0?.Int16_0;
        int? nullable1 = int160.HasValue ? new int?((int) int160.GetValueOrDefault()) : new int?();
        int160 = obj0.class88_0?.Int16_0;
        int? nullable2 = int160.HasValue ? new int?((int) int160.GetValueOrDefault()) : new int?();
        if (nullable1.GetValueOrDefault() == nullable2.GetValueOrDefault() & nullable1.HasValue == nullable2.HasValue && class29.dictionary_1.ContainsKey(obj1) && class29.dictionary_1[obj1] is Class142)
          (class29.dictionary_1[obj1] as Class142).Byte_1 = callback;
      }
    }
    catch
    {
    }
  }

  private void method_87(Class29 value, [In] Class142 obj1, [In] bool obj2)
  {
    if (obj2)
      Thread.Sleep(3000);
    obj1.Double_0 = 0.0;
    obj1.Double_1 = 0.0;
    obj1.Double_2 = 0.0;
    obj1.Double_3 = 0.0;
    if (obj1.Dictionary_0.ContainsKey((ushort) 20))
      obj1.Dictionary_0[(ushort) 20] = DateTime.MinValue;
    obj1.String_1 = "";
    if (obj1 != value.Class143_0)
      return;
    value.Class26_0.bool_3 = true;
  }

  internal void method_88(Class29 value, [In] string obj1)
  {
    if (obj1.Equals(\u003CModule\u003E.smethod_6<string>(3509410584U)))
      value.method_14(Enum1.White);
    if (obj1.Equals(\u003CModule\u003E.smethod_5<string>(3020516181U)))
      value.method_14(Enum1.Green);
    if (obj1.Equals(\u003CModule\u003E.smethod_7<string>(2304452814U)))
      value.method_14(Enum1.Blue);
    if (obj1.Equals(\u003CModule\u003E.smethod_8<string>(2902172163U)))
      value.method_14(Enum1.Yellow);
    if (obj1.Equals(\u003CModule\u003E.smethod_5<string>(2229701356U)))
      value.method_14(Enum1.Purple);
    if (obj1.Equals(\u003CModule\u003E.smethod_8<string>(2315069753U)))
      value.method_14(Enum1.Brown);
    if (obj1.Equals(\u003CModule\u003E.smethod_8<string>(3328796914U)))
      value.method_14(Enum1.Red);
    if (!obj1.Equals(\u003CModule\u003E.smethod_8<string>(4102465423U)))
      return;
    value.method_14(Enum1.Black);
  }

  internal void method_89(Class29 value, [In] string obj1)
  {
    if (obj1.Equals(\u003CModule\u003E.smethod_7<string>(1785077212U)))
      value.method_13(PreviousClass.Monk);
    else if (obj1.Equals(\u003CModule\u003E.smethod_9<string>(3583855759U)))
      value.method_13(PreviousClass.Priest);
    else if (!obj1.Equals(\u003CModule\u003E.smethod_9<string>(3024944628U)) && !obj1.Equals(\u003CModule\u003E.smethod_8<string>(3486643227U)))
    {
      if (!obj1.Equals(\u003CModule\u003E.smethod_7<string>(410416056U)) && !obj1.Equals(\u003CModule\u003E.smethod_5<string>(2453471161U)))
      {
        if (!obj1.Equals(\u003CModule\u003E.smethod_9<string>(3850015136U)) && !obj1.Equals(\u003CModule\u003E.smethod_7<string>(2817587505U)))
          value.method_13(PreviousClass.Pure);
        else
          value.method_13(PreviousClass.Wizard);
      }
      else
        value.method_13(PreviousClass.Rogue);
    }
    else
      value.method_13(PreviousClass.Warrior);
  }

  internal void method_90([In] Class29 obj0, string string_1)
  {
    if (!string_1.Contains(\u003CModule\u003E.smethod_8<string>(806527865U)) && !string_1.Contains(\u003CModule\u003E.smethod_7<string>(3740607045U)) && !string_1.Contains(\u003CModule\u003E.smethod_6<string>(1014053009U)) && !string_1.Contains(\u003CModule\u003E.smethod_5<string>(1662656336U)) && !string_1.Contains(\u003CModule\u003E.smethod_6<string>(2954471778U)) && !string_1.Contains(\u003CModule\u003E.smethod_5<string>(2909590196U)))
    {
      if (string_1.Contains(\u003CModule\u003E.smethod_7<string>(1824818702U)))
        obj0.method_12(MedClass.Gladiator);
      else if (string_1.Contains(\u003CModule\u003E.smethod_9<string>(2397591764U)))
        obj0.method_12(MedClass.Druid);
      else if (string_1.Contains(\u003CModule\u003E.smethod_5<string>(2375873459U)))
        obj0.method_12(MedClass.Bard);
      else if (string_1.Contains(\u003CModule\u003E.smethod_6<string>(3936401010U)))
        obj0.method_12(MedClass.Archer);
      else if (string_1.Contains(\u003CModule\u003E.smethod_6<string>(3806170989U)))
        obj0.method_12(MedClass.Summoner);
      else
        obj0.method_12(MedClass.Unknown);
    }
    else
      obj0.method_12(MedClass.NonMed);
  }
}
